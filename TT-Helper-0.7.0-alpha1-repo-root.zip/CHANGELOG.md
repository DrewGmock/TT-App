# TT Helper Changelog

## 0.7.0-alpha1

### Import / Export
- Added a dedicated GM **Import / Export** tab.
- Added versioned `.ttsession` packages for Session Prep, prepared encounters, and the Creature/NPC/Hazard library.
- Added `.ttenemy` and `.ttenemypack` import/export.
- Added `.ttloot` and `.ttlootpack` import/export.
- Added Android document-picker based file import/export; custom package files can be opened/saved without extracting them.
- Added an import preview with package type, content counts, and name-conflict counts.
- Added **Keep Existing**, **Merge**, **Replace**, and **Import as Copies** strategies.
- Added safeguards so package imports do not silently mutate active combat/player state.
- Added single-entry export for enemies and loot plus whole-library/pack export.

### Session Prep save UX
- Added visible Unsaved / Saved / Autosaved state for Session Notes.
- Added short-delay autosave for Session Notes.
- Added visible save confirmations for Creature/NPC/Hazard library entries and encounter templates.
- Added Objectives / Quests, Locations, Reference Notes, and Loot / Reward Suggestions fields to Session Prep.
- Imported session packages can populate the new prep fields.

### Content Library
- Added a compact Content Library summary to the Import / Export tab.
- Session, enemy, and loot packages use the existing TT Helper data model rather than importing the private whole-app save file.
- Added example `.ttsession`, `.ttenemy`, and `.ttloot` files in the repo for reference.

### Carry-forward
- Includes all 0.6 encounter/session-prep functionality.
- Includes the player container-management fix from 0.5.1.

### Version
- versionCode 14
- versionName `0.7.0-alpha1`

## 0.6.0-alpha1
- Added Session Prep 2.0, encounter budgets, Creature/NPC/Hazard library, Weak/Elite, templates, encounter history, and player container-management carry-forward.
