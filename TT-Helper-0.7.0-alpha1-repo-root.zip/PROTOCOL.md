# TT Helper LAN & Content Package Protocol — 0.7.0-alpha1

The GM Android app remains the authoritative state owner. Players connect through the embedded LAN web client and receive filtered snapshots.

## Content packages

TT Helper content packages are UTF-8 JSON documents with custom extensions. They are not the app's private save file.

Top-level shape:

```json
{
  "ttHelperPackage": true,
  "schemaVersion": 1,
  "packageType": "ttsession",
  "name": "Goblin Mine Session",
  "createdAt": 0,
  "payload": {}
}
```

Supported `packageType` values:

- `ttsession`
- `ttenemy`
- `ttenemypack`
- `ttloot`
- `ttlootpack`

The schema version is validated before preview/import. A package written for a newer schema is rejected rather than guessed at.

## Session packages

A `.ttsession` payload uses the Session Prep structure and can include:

- session title / opening scene
- objectives / quests
- locations / scene notes
- reference notes / reminders
- loot/reward suggestions
- private GM notes
- encounter/beat notes
- reusable Creature/NPC/Hazard library entries
- prepared encounter templates

Importing Session Prep never replaces PCs, active encounters, rules requests, player submissions, inventory, or completed encounter history.

## Enemy packages

`.ttenemy` and `.ttenemypack` packages use the same fields currently supported by the Creature/NPC/Hazard library, including level, HP, AC, saves, initiative modifier, role, traits, search tags, public notes, private GM notes, hazard complexity, and adjustment metadata.

## Loot packages

`.ttloot` and `.ttlootpack` use the Loot & Inventory model, including quantity, GP value, bulk, carry state, consumable uses, identification/reveal state, runes/upgrades, container metadata, player notes, and GM notes.

If an imported loot entry is assigned to a PC id that does not exist in the current campaign, the assignment is cleared instead of pointing at an invalid character.

## Conflict strategies

- **Keep Existing:** same-name content already in the destination is preserved; only new names are imported.
- **Merge:** same-name content is updated from the package and unrelated content is preserved. Session text is appended with an import divider so existing notes are not silently erased.
- **Replace:** conflicting enemy/loot entries are replaced. For `.ttsession`, Replace replaces Session Prep only.
- **Import as Copies:** imported records receive new ids so both versions remain. Imported encounter templates are labeled as imported copies.

## Security boundary

Import/export is GM-device only. Player snapshots never include package files, private Session Prep, hidden loot, enemy library data, or GM notes.

## Save behavior

The app's private session state is still persisted immediately after host mutations. The Session Prep UI now adds explicit save feedback and short-delay autosave for its text planning fields; this changes UX, not the underlying persistence boundary.
