# TT Helper 0.6.0-alpha1

TT Helper is a local-first Pathfinder 2e tabletop companion. The Android GM device is authoritative and hosts a lightweight browser client for players on the same LAN.

## 0.6 focus: Encounter & Session Prep 2.0

The GM **Session Prep** workspace now acts as an encounter-building hub:

- searchable Creature / NPC / Hazard library
- reusable role, trait, tag, public-note, and GM-note fields
- Simple vs Complex hazard classification
- prepared encounter templates with party level and party size
- live encounter XP budget and difficulty display
- Trivial / Low / Moderate / Severe / Extreme thresholds adjusted for party size
- per-entry Weak / Normal / Elite selection
- quantity controls and fast duplicate-style roster building
- saved template styles such as Standard, Boss, Horde, Hazard, Mixed, or Custom
- one-tap **Start Encounter** from a saved encounter
- Duplicate/Delete controls for saved encounter templates
- concise built-in PF2e quick-reference card for common combat bookkeeping

Weak/Elite adjusts the entry's effective level for encounter budgeting. When the prepared encounter launches, TT Helper also applies the tracked combat-stat adjustment to the fields the app currently stores (HP, AC, saves, and initiative modifier). Full attack/damage/DC statblock automation remains future work.

## Encounter history

Ending an encounter now archives a summary in the new **History** GM tab. The archive keeps:

- encounter name and completion time
- party size and level
- approximate XP/difficulty
- rounds completed
- defeated/non-PC counts
- recent combat-history labels

The active ended encounter is still preserved for loot review until the GM clears it. Loot continues into **Loot & Inventory**.

## Inventory carry-forward

0.6 includes the 0.5.1 player-container fix. Players can move their own items into and out of containers they own. Host-side ownership and cycle checks remain authoritative.

## Build

`versionCode = 13`

`versionName = "0.6.0-alpha1"`

The repo contains the same local-development signing key used by the prior signed builds, so Android should install it as a normal update.
