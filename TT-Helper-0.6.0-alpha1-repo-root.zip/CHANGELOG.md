# TT Helper Changelog

## 0.6.0-alpha1

### Session Prep 2.0
- Rebuilt Session Prep around a searchable Creature / NPC / Hazard library.
- Added role, traits, search tags, player-visible notes, and private GM notes to prep entries.
- Added Simple / Complex hazard classification.
- Added encounter party level and party size inputs.
- Added live XP budgeting with adjusted Trivial / Low / Moderate / Severe / Extreme thresholds.
- Added per-roster Weak / Normal / Elite adjustments.
- Added quantity controls and effective-level / XP readouts per roster entry.
- Added saved encounter template styles and a starter-note helper.
- Added Duplicate and one-tap Start Encounter controls to saved encounter templates.
- Weak/Elite now modifies tracked HP, AC, saves, initiative modifier, and effective level when a prepared encounter launches.
- Added a collapsible PF2e quick-reference card to Session Prep.

### Encounter history
- Added a dedicated GM **History** tab.
- Ending an encounter automatically archives its summary and recent combat log.
- Encounter history persists after the Live encounter is cleared.

### Live encounter context
- Live encounter header now shows party size/level plus an approximate XP/difficulty readout when combatant levels are available.
- Library entries added during live play preserve Creature / NPC / Hazard kind.

### Inventory carry-forward
- Includes the 0.5.1 player ability to place owned items into and out of owned containers.
- Container-cycle and ownership protection remain host-enforced.

### Version
- versionCode 13
- versionName `0.6.0-alpha1`

## 0.5.1-alpha1
- Players can move their own items into and out of containers from the Inventory screen.
- Container choices are limited to containers owned by that PC.
- Prevents placing an item inside itself or creating container loops.

## 0.5.0-alpha2
- Fixed Android/Compose compilation in `InventoryScreen.kt` by removing an invalid explicit `weight` import.
