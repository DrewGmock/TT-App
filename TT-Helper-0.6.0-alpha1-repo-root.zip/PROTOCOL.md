# TT Helper LAN Protocol Notes — 0.6.0-alpha1

The GM Android app remains the authoritative state owner. Players connect through the embedded LAN web client and receive filtered snapshots.

## Session Prep boundary

Creature/NPC/Hazard library records, encounter templates, encounter budgets, template tags, and private preparation notes remain GM-local. They are not included in player snapshots.

Starting a prepared encounter copies the prepared data into a separate Live encounter. Editing or resolving the Live encounter does not mutate the saved prep template.

## Encounter budget

The prep UI calculates XP from the party level and the effective level of each roster entry. Weak and Elite shift effective level by -1/+1 for the encounter budget. Simple hazards use a reduced XP contribution; Complex hazards use the normal level-based entry value.

The UI scales the standard four-character Trivial / Low / Moderate / Severe / Extreme thresholds to the selected party size.

## Weak / Elite launch behavior

When a saved encounter starts, TT Helper applies the selected Weak/Elite adjustment to fields currently tracked by the app:

- effective level
- max/current HP
- AC
- Fortitude / Reflex / Will
- initiative modifier

The app does not yet rewrite untracked attack damage, spell DCs, or full statblock text.

## Encounter history

Ending an encounter creates a persistent GM-only archive entry. The archive is not sent to player clients. It stores a summary plus recent combat-history labels; inventory/loot remains in the existing inventory and encounter-loot structures.

## Inventory security boundary

A player receives only revealed shared loot and revealed items assigned to that PC. Player inventory mutations are authenticated against the assigned PC id. Container changes are allowed only for owned items and owned containers, and the host rejects container cycles.
