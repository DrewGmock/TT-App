# TT Helper Changelog

## 0.7.1-alpha1

### Navigation & Prep Workspace
- Rebuilt the GM tablet sidebar as a vertically scrollable navigation workspace so lower tabs can no longer be clipped off-screen.
- Grouped GM navigation into collapsible **Play**, **Campaign**, and **Prep** sections.
- Added an icon-width collapsed sidebar mode for more workspace on smaller tablets.
- Reworked Session Prep into compact collapsible headers instead of one long page.
- Added separate collapsible sections for Overview, Objectives, Locations, Loot & Rewards, Reference Notes, Encounter Beats, private GM notes, library entries, encounter building, quick rules, and backups.
- Added summary text to collapsed headers so the GM can see what is populated without opening every section.

### Pinned Prep
- Added persistent prep pins saved with the local campaign state.
- Sections, saved encounters, creatures, NPCs, and hazards can be pinned while actively prepping.
- Added a **Pinned Prep** strip at the top of Session Prep with one-tap unpin and Clear All.
- Deleted library/encounter entries automatically clean up their stale pins.
- Prep pins are local workspace state and are intentionally excluded from exported `.ttsession` packages.

### Carry-forward
- Includes all 0.7.0 import/export, Session Prep 2.0, rules intelligence, inventory, player builder, spellcasting, effect automation, and LAN sync functionality.

### Version
- versionCode 15
- versionName `0.7.1-alpha1`

## 0.7.0-alpha1

### Import / Export
- Added a dedicated GM **Import / Export** tab.
- Added versioned `.ttsession` packages for Session Prep, prepared encounters, and the Creature/NPC/Hazard library.
- Added `.ttenemy` and `.ttenemypack` import/export.
- Added `.ttloot` and `.ttlootpack` import/export.
- Added Android document-picker based file import/export; custom package files can be opened/saved without extracting them.
- Added an import preview with package type, content counts, and name-conflict counts.
- Added **Keep Existing**, **Merge**, **Replace**, and **Import as Copies** strategies.
- Added safeguards so package imports do not silently mutate active combat/player state.
- Added single-entry export for enemies and loot plus whole-library/pack export.

### Session Prep save UX
- Added visible Unsaved / Saved / Autosaved state for Session Notes.
- Added short-delay autosave for Session Notes.
- Added visible save confirmations for Creature/NPC/Hazard library entries and encounter templates.
- Added Objectives / Quests, Locations, Reference Notes, and Loot / Reward Suggestions fields to Session Prep.
- Imported session packages can populate the new prep fields.

### Content Library
- Added a compact Content Library summary to the Import / Export tab.
- Session, enemy, and loot packages use the existing TT Helper data model rather than importing the private whole-app save file.
- Added example `.ttsession`, `.ttenemy`, and `.ttloot` files in the repo for reference.

### Carry-forward
- Includes all 0.6 encounter/session-prep functionality.
- Includes the player container-management fix from 0.5.1.

### Version
- versionCode 14
- versionName `0.7.0-alpha1`

## 0.6.0-alpha1
- Added Session Prep 2.0, encounter budgets, Creature/NPC/Hazard library, Weak/Elite, templates, encounter history, and player container-management carry-forward.
