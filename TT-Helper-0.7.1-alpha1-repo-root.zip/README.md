# TT Helper

## 0.7.1-alpha1 UI update
The GM tablet now uses a scrollable, collapsible sidebar and Session Prep uses collapsible section headers plus persistent Pinned Prep items. Pins can surface current encounters, creatures/NPCs/hazards, or entire prep sections without moving the underlying content. 0.7.0-alpha1

TT Helper is a local-first Pathfinder 2e tabletop companion. The Android GM device is authoritative and hosts a lightweight browser client for players on the same LAN.

## 0.7 focus: Import / Export + Content Library

0.7 adds a dedicated **Import / Export** GM workspace so prep discussed outside the app can be moved into TT Helper without retyping it.

Supported package types:

- `.ttsession` — Session Prep, prepared encounters, and the reusable Creature/NPC/Hazard library
- `.ttenemy` — one Creature/NPC/Hazard library entry
- `.ttenemypack` — multiple Creature/NPC/Hazard entries
- `.ttloot` — one loot/inventory entry
- `.ttlootpack` — multiple loot/inventory entries

Every import is previewed before it changes campaign data. The GM can choose:

- **Keep Existing** — import only non-conflicting names
- **Merge** — merge/update same-name records while preserving unrelated content
- **Replace** — replace conflicting records; a `.ttsession` Replace replaces Session Prep
- **Import as Copies** — preserve both versions using new ids

The package format is versioned JSON so ChatGPT or another editor can generate or revise TT Helper content without changing the app's private save file.

## Session Prep save UX

Session notes now visibly show **Unsaved changes**, **Saved ✓**, or **Autosaved ✓**. Session-note fields autosave after a short pause. Saving creatures and encounter templates also gives visible confirmation.

Session Prep now has additional planning fields intended for imported/chat-assisted prep:

- objectives / quests
- locations / scene notes
- reference notes / reminders
- loot / reward suggestions

## Content Library

The Import / Export screen summarizes the current reusable library and can export:

- the current Session Prep as a `.ttsession`
- the full enemy/NPC/hazard library or individual entries
- the full Loot & Inventory collection or individual entries

Exports include GM-only data. Player clients never receive import packages or private library data.

## Build

`versionCode = 14`

`versionName = "0.7.0-alpha1"`

The repo contains the same local-development signing key used by the prior signed builds, so Android should install it as a normal update.
