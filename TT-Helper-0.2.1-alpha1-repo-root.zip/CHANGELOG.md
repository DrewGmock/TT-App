# Changelog

## 0.2.1-alpha1

- Replaced the always-visible condition/effect wall with a compact searchable picker.
- Added Common, PF2e, Cubeborne/homebrew, recent/active, and custom effect paths.
- Added source/target anchored effect timing at start or end of turn.
- Added finite trigger counts and automatic remove/decrement behavior.
- Added recurring skill/save/flat/recovery/custom check reminders with configurable outcomes.
- Added persistent GM attention banners for End Turn requests and unresolved effect checks.
- Added vibration plus optional alert sound for new GM attention items.
- Added approve/dismiss controls directly on End Turn alerts.
- Added effect-check outcome controls and digital d20 resolution for flat/recovery checks.
- Added Live/Players attention counts in navigation.
- Disabled Next Turn until all initiative values are present and required checks are resolved.
- Cleaned up TURN / SELECTED / TIE / GROUP / REQUEST badges in initiative rows.
- Improved grouped-enemy tie visibility while preserving individual HP and conditions.
- Added effect timing summaries to active effect cards.
- Player browser now uses a compact condition dropdown instead of a wall of quick-condition buttons.
- Check-triggered effects now honor finite trigger counts.
- Stabilizing from Dying through the recovery effect flow adds/increases Wounded, with Undo available.

## 0.2.0-alpha1

- Added encounter/initiative engine.
- Added quick and prepared encounter starts.
- Added reusable enemy library.
- Added manual/player/digital initiative paths.
- Added group initiative controls with individual enemy state.
- Added round/turn, Delay, Ready, tie reordering, End Turn requests.
- Added player-safe enemy health/condition display.
- Added conservative condition automation and Dying/Wounded transitions.
- Added combat history integrated with Undo.
- Added automatic GM-only loot draft on encounter end, reveal flow, and Party Loot.
- Kept compile/target path on API 36 after successful 0.1 cloud-build troubleshooting.
