(() => {
  const $ = id => document.getElementById(id);
  const quickConditions = ['Frightened','Prone','Off-Guard','Dying','Wounded','Sickened','Slowed','Stunned','Chaos Aura','Thorn-Crowned Rage'];
  const commonEffects = ['', 'Frightened','Prone','Off-Guard','Grabbed','Immobilized','Slowed','Stunned','Sickened','Persistent Damage','Clumsy','Enfeebled','Stupefied','Chaos Aura','Thorn-Crowned Rage'];
  const standardSkills = ['Acrobatics','Arcana','Athletics','Crafting','Deception','Diplomacy','Intimidation','Medicine','Nature','Occultism','Performance','Religion','Society','Stealth','Survival','Thievery'];
  const state = { token: localStorage.getItem('tthelper.token'), ws: null, snapshot: null, reconnectTimer: null, currentPage: localStorage.getItem('tthelper.playerPage') || 'combat', sheetDirty:false, sheetLoadedFor:null };

  async function loadLobby() {
    const response = await fetch('/api/public', { cache: 'no-store' });
    if (!response.ok) throw new Error(`Host returned ${response.status}`);
    const lobby = await response.json();
    $('campaign-title').textContent = lobby.campaignName || 'TT Helper';
    const select = $('pc-select'); select.innerHTML = '';
    (lobby.pcs || []).forEach(pc => {
      const option = document.createElement('option');
      option.value = pc.id;
      option.textContent = `${pc.name} — ${pc.characterClass}`;
      select.appendChild(option);
    });
  }

  async function join() {
    $('join-error').textContent = '';
    const response = await fetch('/api/join', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ pin:$('pin').value.trim(), displayName:$('display-name').value.trim(), pcId:$('pc-select').value })
    });
    const result = await response.json();
    if (!response.ok || !result.ok) { $('join-error').textContent = result.error || 'Could not join.'; return; }
    state.token = result.token;
    localStorage.setItem('tthelper.token', state.token);
    showGame();
    connect();
  }

  async function tryResume() {
    if (!state.token) return false;
    const response = await fetch(`/api/resume?token=${encodeURIComponent(state.token)}`, {cache:'no-store'});
    if (response.ok) { showGame(); connect(); return true; }
    localStorage.removeItem('tthelper.token');
    state.token = null;
    return false;
  }

  function showGame() { $('join-view').classList.add('hidden'); $('game-view').classList.remove('hidden'); }
  function showJoin() { $('game-view').classList.add('hidden'); $('join-view').classList.remove('hidden'); setOnline(false); }

  function setOnline(online) {
    const pill = $('connection-pill');
    if (!pill) return;
    pill.textContent = online ? 'Connected' : 'Offline';
    pill.classList.toggle('online', !!online);
    pill.classList.toggle('offline', !online);
  }

  function showPlayerPage(page) {
    state.currentPage = page;
    localStorage.setItem('tthelper.playerPage', page);
    document.querySelectorAll('[data-player-page]').forEach(el => el.classList.toggle('page-hidden', el.dataset.playerPage !== page));
    document.querySelectorAll('[data-player-nav]').forEach(btn => btn.classList.toggle('active', btn.dataset.playerNav === page));
    window.scrollTo({top:0, behavior:'smooth'});
  }

  function connect() {
    if (!state.token) return;
    clearTimeout(state.reconnectTimer);
    const scheme = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${scheme}://${location.host}/ws?token=${encodeURIComponent(state.token)}`);
    state.ws = ws;
    ws.onopen = () => setOnline(true);
    ws.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.type === 'snapshot') { state.snapshot = message; render(message); cacheSnapshot(message); }
    };
    ws.onclose = () => {
      setOnline(false);
      if (state.token) state.reconnectTimer = setTimeout(connect, 1500);
    };
    ws.onerror = () => ws.close();
  }

  function action(actionName, payload = {}) {
    if (!state.ws || state.ws.readyState !== WebSocket.OPEN) return false;
    const requestId = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`);
    state.ws.send(JSON.stringify({ type:'action', requestId, action:actionName, payload }));
    return true;
  }

  function render(snapshot) {
    $('campaign-title').textContent = snapshot.campaignName || 'TT Helper';
    $('scene-name').textContent = snapshot.sceneName || '—';
    const pc = snapshot.you;
    if (!pc) return;
    $('pc-name').textContent = pc.name;
    $('pc-meta').textContent = `${pc.ancestry} • ${pc.characterClass} • ${pc.level == null ? 'Level not set' : `Level ${pc.level}`}`;
    renderCharacterProfile(pc);
    renderInventory(snapshot.inventory || [], snapshot.sharedLoot || []);
    $('hp').textContent = pc.hp;
    $('max-hp').textContent = pc.maxHp;
    $('temp-hp').textContent = pc.tempHp > 0 ? `+${pc.tempHp} temporary HP` : '';
    $('ready-button').textContent = pc.ready ? 'Ready ✓' : 'Ready';
    $('hero-points').textContent = `Hero Points: ${pc.heroPoints || 0}/3`;
    $('hero-spend').disabled = Number(pc.heroPoints || 0) <= 0;
    $('hero-add').disabled = Number(pc.heroPoints || 0) >= 3;

    $('conditions').innerHTML = '';
    (pc.conditions || []).forEach(c => $('conditions').appendChild(chip(conditionText(c), () => action('toggleCondition', { name:c.name }))));

    renderActionEconomy(pc.actionEconomy || {}, snapshot.encounter);
    renderTargeting(pc, snapshot.encounter);
    renderSpellcasting(pc.spellcasting || {}, pc.actionEconomy || {}, snapshot.encounter);
    renderCharacterContent(pc, snapshot.encounter);
    renderDrafts(pc);

    $('party-list').innerHTML = '';
    (snapshot.party || []).forEach(member => {
      const row = document.createElement('div'); row.className = 'party-row';
      const left = document.createElement('div');
      const conditionTextValue = member.conditions?.length ? ` • ${member.conditions.map(conditionText).map(escapeHtml).join(', ')}` : '';
      left.innerHTML = `<strong>${escapeHtml(member.name)}</strong><div class="muted">${member.ready ? 'Ready' : 'Not ready'}${conditionTextValue}</div>`;
      const right = document.createElement('strong'); right.textContent = `${member.hp}/${member.maxHp}`;
      row.append(left, right); $('party-list').appendChild(row);
    });

    renderEncounter(snapshot.encounter);
  }

  function renderEncounter(encounter) {
    const panel = $('encounter-panel');
    if (!encounter) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    $('encounter-name').textContent = encounter.name || 'Encounter';
    $('encounter-round').textContent = `Round ${encounter.round}${encounter.ended ? ' • Encounter ended' : ''}`;
    $('current-turn').textContent = encounter.currentName ? `Current turn: ${encounter.currentName}` : 'Waiting for combatants';
    $('turn-pill').textContent = encounter.currentIsYou ? 'YOUR TURN' : (encounter.active ? 'Live' : 'Ended');
    $('turn-pill').classList.toggle('your-turn', !!encounter.currentIsYou);

    const initiativeEntry = $('initiative-entry');
    if (encounter.active && encounter.yourInitiative == null) initiativeEntry.classList.remove('hidden');
    else initiativeEntry.classList.add('hidden');

    const endButton = $('end-turn-button');
    if (encounter.active) {
      endButton.classList.remove('hidden');
      endButton.disabled = !encounter.currentIsYou || encounter.endTurnRequested;
      endButton.textContent = encounter.endTurnRequested ? 'End Turn Requested ✓' : (encounter.currentIsYou ? 'Request End Turn' : 'Wait for your turn');
    } else {
      endButton.classList.add('hidden');
    }

    $('initiative-list').innerHTML = '';
    (encounter.initiative || []).forEach(entry => {
      const row = document.createElement('div');
      row.className = `initiative-row${entry.current ? ' current' : ''}${entry.isYou ? ' you' : ''}`;
      const flags = [entry.isYou ? 'You' : '', entry.delayed ? 'Delayed' : '', entry.defeated ? 'Defeated' : ''].filter(Boolean).join(' • ');
      row.innerHTML = `<strong>${escapeHtml(entry.name)}</strong><span class="muted">${escapeHtml(flags)}</span>`;
      $('initiative-list').appendChild(row);
    });

    const enemies = encounter.enemies || [];
    $('enemy-heading').classList.toggle('hidden', enemies.length === 0);
    $('enemy-list').innerHTML = '';
    enemies.forEach(enemy => {
      const card = document.createElement('div'); card.className = 'enemy-card';
      const conditionHtml = (enemy.conditions || []).map(c => `<span class="mini-chip">${escapeHtml(conditionText(c))}</span>`).join('');
      const note = enemy.publicNote ? `<div class="muted">${escapeHtml(enemy.publicNote)}</div>` : '';
      card.innerHTML = `<div class="row split"><strong>${escapeHtml(enemy.name)}</strong><span>${escapeHtml(enemy.health)}</span></div>${note}<div class="mini-chips">${conditionHtml}</div>`;
      $('enemy-list').appendChild(card);
    });

    const loot = encounter.loot;
    if (loot) {
      $('revealed-loot').classList.remove('hidden');
      $('loot-coins').textContent = loot.coinsGp > 0 ? `${formatGp(loot.coinsGp)} gp` : 'No coins';
      $('loot-items').innerHTML = '';
      (loot.items || []).forEach(item => {
        const row = document.createElement('div'); row.className = 'loot-row';
        row.textContent = `${item.quantity > 1 ? `${item.quantity}× ` : ''}${item.name}${item.category ? ` • ${item.category}` : ''}`;
        $('loot-items').appendChild(row);
      });
    } else {
      $('revealed-loot').classList.add('hidden');
    }
  }

  function renderActionEconomy(economy, encounter) {
    const base = Math.max(0, Number(economy.baseActions ?? 3));
    const remaining = Math.max(0, Math.min(base, Number(economy.actionsRemaining ?? base)));
    $('action-pips').textContent = Array.from({length:base}, (_, i) => i < remaining ? '●' : '○').join(' ');
    $('action-summary').textContent = `${remaining} / ${base} actions remaining`;
    const actionTurnAllowed = !encounter || !encounter.active || !!encounter.currentIsYou;
    document.querySelectorAll('[data-action-spend]').forEach(button => {
      button.disabled = !actionTurnAllowed || remaining < Number(button.dataset.actionSpend || 1);
    });
    $('refund-action').disabled = remaining >= base;
    const reactionAvailable = economy.reactionAvailable !== false;
    $('reaction-button').textContent = reactionAvailable ? 'Reaction available' : 'Reaction used — restore';
    $('reaction-button').dataset.available = reactionAvailable ? 'true' : 'false';
  }

  function mapPenalty(attacksThisTurn, agile=false) {
    const attacks = Number(attacksThisTurn || 0);
    if (attacks <= 0) return 0;
    if (attacks === 1) return agile ? -4 : -5;
    return agile ? -8 : -10;
  }

  function renderTargeting(pc, encounter) {
    const panel = $('target-rules-panel');
    if (!panel) return;
    if (!encounter || !encounter.active) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    const attacks = Number(pc.actionEconomy?.attacksThisTurn || 0);
    const normal = mapPenalty(attacks, false);
    const agile = mapPenalty(attacks, true);
    $('map-summary').textContent = `MAP ${attacks} • next ${normal >= 0 ? '+' : ''}${normal} (${agile >= 0 ? '+' : ''}${agile} agile)`;

    const select = $('target-select');
    const desired = pc.selectedTargetId || '';
    select.innerHTML = '<option value="">No target</option>';
    (encounter.enemies || []).filter(e => !e.defeated).forEach(enemy => {
      const option = document.createElement('option'); option.value = enemy.id; option.textContent = `${enemy.name} • ${enemy.health}`; select.appendChild(option);
    });
    select.value = [...select.options].some(o => o.value === desired) ? desired : '';
    select.onchange = () => action('setTarget', {combatantId:select.value});

    const list = $('rule-result-list'); list.innerHTML = '';
    const rules = (encounter.rules || []).slice().reverse();
    if (!rules.length) { list.innerHTML = '<div class="muted">No attack/save resolutions yet.</div>'; return; }
    rules.forEach(req => {
      const card = document.createElement('div'); card.className = 'dashboard-card';
      const target = req.targetName ? ` → ${escapeHtml(req.targetName)}` : '';
      let detail = req.secret ? 'Secret check sent to GM' : '';
      if (!req.secret && req.total != null) detail = `d20 ${req.roll} ${Number(req.modifier||0) >= 0 ? '+' : ''}${req.modifier||0} = ${req.total}`;
      const outcome = req.status === 'RESOLVED' && req.outcome ? ` • ${escapeHtml(req.outcome)}` : req.status === 'PENDING' ? ' • Awaiting GM' : ` • ${escapeHtml(req.status)}`;
      const consequence=req.proposedAmount!=null?`<div class="meta">${req.consequenceApplied?'Applied':'Proposed'}: ${req.proposedAmount} ${req.damageType?escapeHtml(req.damageType):''}${req.consequenceApplied?' ✓':''}</div>`:'';
      card.innerHTML = `<strong>${escapeHtml(req.label)}${target}</strong><div class="meta">${escapeHtml(detail)}${outcome}</div>${consequence}`;
      if (req.canPlayerRoll) {
        const b=document.createElement('button'); b.className='secondary'; b.textContent='Roll digitally'; b.onclick=()=>action('rollRuleRequest',{requestId:req.id}); card.appendChild(b);
      }
      list.appendChild(card);
    });
  }

  function renderSpellcasting(casting, economy, encounter) {
    const panel = $('spell-panel');
    if (!casting.enabled) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    const mode = casting.castingMode === 'SPONTANEOUS' ? 'Spontaneous' : 'Prepared';
    $('spell-title').textContent = `${casting.tradition || 'Spellcasting'} • ${mode}`;
    $('focus-points').textContent = `Focus Points: ${casting.focusPoints || 0} / ${casting.maxFocusPoints || 0}`;
    $('refocus-button').disabled = Number(casting.focusPoints || 0) >= Number(casting.maxFocusPoints || 0);

    $('spell-slots').innerHTML = '';
    (casting.slots || []).sort((a,b) => a.rank-b.rank).forEach(slot => {
      const pill = document.createElement('div'); pill.className = 'slot-pill';
      pill.textContent = `Rank ${slot.rank}: ${slot.remaining}/${slot.total}`;
      $('spell-slots').appendChild(pill);
    });

    const cantrips = (casting.spells || []).filter(s => s.isCantrip);
    const focusSpells = (casting.spells || []).filter(s => s.isFocus && !s.isCantrip);
    const ranked = (casting.spells || []).filter(s => !s.isCantrip && !s.isFocus).sort((a,b) => a.rank-b.rank || a.name.localeCompare(b.name));
    renderSpellList('cantrip-section', 'cantrip-list', cantrips, casting, economy, encounter);
    renderSpellList('focus-section', 'focus-list', focusSpells, casting, economy, encounter);
    renderSpellList('prepared-section', 'prepared-list', ranked, casting, economy, encounter);
  }

  function renderSpellList(sectionId, listId, spells, casting, economy, encounter) {
    const section = $(sectionId); const list = $(listId);
    section.classList.toggle('hidden', spells.length === 0);
    list.innerHTML = '';
    spells.forEach(spell => {
      const card = document.createElement('div');
      card.className = `spell-card${spell.expended ? ' expended' : ''}`;
      const type = spell.isCantrip ? 'Cantrip' : spell.isFocus ? 'Focus' : `Rank ${spell.rank}`;
      const actionText = Number(spell.actions || 0) === 0 ? 'Free action' : `${spell.actions} action${Number(spell.actions) === 1 ? '' : 's'}`;
      const slot = (casting.slots || []).find(s => Number(s.rank) === Number(spell.rank));
      const resourceOk = spell.isCantrip || (spell.isFocus ? Number(casting.focusPoints || 0) > 0 : (slot ? Number(slot.remaining || 0) > 0 : true));
      const preparedOk = casting.castingMode !== 'PREPARED' || spell.isCantrip || spell.isFocus || !spell.expended;
      const actionOk = Number(economy.actionsRemaining ?? 3) >= Number(spell.actions || 0);
      const turnOk = !encounter || !encounter.active || !!encounter.currentIsYou || Number(spell.actions || 0) === 0;
      const buttonDisabled = !(resourceOk && preparedOk && actionOk && turnOk);
      const detail = [spell.range, spell.targets, spell.checkOrSave, spell.damage ? `${spell.healing?'Healing':'Damage'} ${spell.damage}${spell.damageType?` ${spell.damageType}`:''}` : '', spell.traits ? `Traits: ${spell.traits}` : ''].filter(Boolean).join(' • ');
      card.innerHTML = `<strong>${escapeHtml(spell.name)}</strong><div class="spell-meta">${escapeHtml(type)} • ${escapeHtml(actionText)}${spell.expended ? ' • Expended' : ''}</div>${detail ? `<div class="muted">${escapeHtml(detail)}</div>` : ''}${spell.notes ? `<div class="muted">${escapeHtml(spell.notes)}</div>` : ''}`;
      const castButton = document.createElement('button');
      castButton.textContent = buttonDisabled ? 'Unavailable' : 'Cast';
      castButton.disabled = buttonDisabled;
      castButton.onclick = () => action('castSpell', { spellId:spell.id });
      card.appendChild(castButton);
      const controls = document.createElement('div'); controls.className = 'controls';
      const pin = document.createElement('button'); pin.className = 'ghost'; pin.textContent = spell.pinned ? 'Unpin' : 'Pin'; pin.onclick = () => action('togglePinned', {kind:'SPELL', entryId:spell.id});
      const edit = document.createElement('button'); edit.className = 'secondary'; edit.textContent = 'Suggest edit'; edit.onclick = () => editApproved('SPELL', spell);
      controls.append(pin, edit); card.appendChild(controls);
      list.appendChild(card);
    });
  }

  function renderCharacterContent(pc, encounter) {
    const economy = pc.actionEconomy || {};
    const ownTurn = !encounter || !encounter.active || !!encounter.currentIsYou;

    const abilities = pc.abilities || [];
    $('abilities-panel').classList.toggle('hidden', abilities.length === 0);
    $('ability-list').innerHTML = '';
    abilities.slice().sort((a,b) => Number(b.pinned)-Number(a.pinned) || a.name.localeCompare(b.name)).forEach(entry => {
      const card = document.createElement('div'); card.className = 'dashboard-card';
      const cost = abilityActionLabel(entry);
      const limited = entry.usageMode && entry.usageMode !== 'UNLIMITED';
      const usage = limited ? ` • ${entry.remainingUses}/${entry.maxUses || 1} uses` : '';
      const mechanics=[entry.range,entry.targets,entry.checkOrSave,entry.damage?`${entry.healing?'Healing':'Damage'} ${entry.damage}${entry.damageType?` ${entry.damageType}`:''}`:'',entry.traits?`Traits: ${entry.traits}`:''].filter(Boolean).join(' • ');
      card.innerHTML = `<strong>${escapeHtml(entry.name)}</strong><div class="meta">${escapeHtml(entry.category || 'Ability')} • ${escapeHtml(cost)}${escapeHtml(usage)}</div>${mechanics?`<div class="muted">${escapeHtml(mechanics)}</div>`:''}${entry.notes ? `<div class="muted">${escapeHtml(entry.notes)}</div>` : ''}`;
      const controls = document.createElement('div'); controls.className='controls';
      if (entry.actionType !== 'PASSIVE') {
        const use = document.createElement('button'); use.textContent='Use';
        const actionCost = entry.actionType === 'ACTION' ? Number(entry.actions || 1) : 0;
        const reactionOk = entry.actionType !== 'REACTION' || economy.reactionAvailable !== false;
        const usageOk = !limited || Number(entry.remainingUses || 0) > 0;
        use.disabled = !usageOk || !reactionOk || (entry.actionType === 'ACTION' && (!ownTurn || Number(economy.actionsRemaining || 0) < actionCost));
        use.onclick = () => action('useAbility', {abilityId:entry.id}); controls.appendChild(use);
      }
      const pin = document.createElement('button'); pin.className='ghost'; pin.textContent=entry.pinned?'Unpin':'Pin'; pin.onclick=()=>action('togglePinned',{kind:'ABILITY',entryId:entry.id});
      const edit = document.createElement('button'); edit.className='secondary'; edit.textContent='Suggest edit'; edit.onclick=()=>editApproved('ABILITY',entry);
      controls.append(pin,edit); card.appendChild(controls); $('ability-list').appendChild(card);
    });

    const strikes = pc.strikes || [];
    $('strikes-panel').classList.toggle('hidden', strikes.length === 0);
    $('strike-list').innerHTML='';
    strikes.slice().sort((a,b)=>Number(b.pinned)-Number(a.pinned)||a.name.localeCompare(b.name)).forEach(entry=>{
      const card=document.createElement('div'); card.className='dashboard-card';
      const mod=Number(entry.attackModifier||0); const agile=(entry.traits||'').toLowerCase().includes('agile'); const penalty=mapPenalty(economy.attacksThisTurn||0,agile); const finalMod=mod+penalty;
      const modText=`${mod>=0?'+':''}${mod}`; const finalText=`${finalMod>=0?'+':''}${finalMod}`;
      card.innerHTML=`<strong>${escapeHtml(entry.name)}</strong><div class="meta">${entry.actions||1} action • Base ${modText} • This attack ${finalText} • ${escapeHtml(entry.damage||'damage not entered')}${entry.damageType?` ${escapeHtml(entry.damageType)}`:''}</div>${entry.traits?`<div class="muted">${escapeHtml(entry.traits)}</div>`:''}`;
      const controls=document.createElement('div'); controls.className='controls';
      const use=document.createElement('button'); use.textContent='Roll strike'; use.disabled=!ownTurn||Number(economy.actionsRemaining||0)<Number(entry.actions||1); use.onclick=()=>action('useStrike',{strikeId:entry.id});
      const physical=document.createElement('button'); physical.className='secondary'; physical.textContent='Physical d20'; physical.disabled=use.disabled; physical.onclick=()=>{ const raw=window.prompt('Enter the raw d20 result (1–20). TT Helper will add the attack modifier and MAP.'); const die=Number.parseInt(raw||'',10); if(die>=1&&die<=20) action('useStrike',{strikeId:entry.id,d20:die}); };
      const pin=document.createElement('button'); pin.className='ghost'; pin.textContent=entry.pinned?'Unpin':'Pin'; pin.onclick=()=>action('togglePinned',{kind:'STRIKE',entryId:entry.id});
      const edit=document.createElement('button'); edit.className='secondary'; edit.textContent='Suggest edit'; edit.onclick=()=>editApproved('STRIKE',entry);
      controls.append(use,physical,pin,edit); card.appendChild(controls); $('strike-list').appendChild(card);
    });

    const resources=pc.resources||[];
    $('resources-panel').classList.toggle('hidden', resources.length===0);
    $('resource-list').innerHTML='';
    resources.forEach(entry=>{
      const card=document.createElement('div'); card.className='dashboard-card';
      card.innerHTML=`<strong>${escapeHtml(entry.name)}</strong><div class="meta">${entry.current}/${entry.max}${entry.notes?` • ${escapeHtml(entry.notes)}`:''}</div>`;
      const controls=document.createElement('div'); controls.className='controls';
      const minus=document.createElement('button'); minus.className='ghost'; minus.textContent='−1'; minus.disabled=Number(entry.current)<=0; minus.onclick=()=>action('adjustResource',{resourceId:entry.id,delta:-1});
      const plus=document.createElement('button'); plus.className='secondary'; plus.textContent='+1'; plus.disabled=Number(entry.current)>=Number(entry.max); plus.onclick=()=>action('adjustResource',{resourceId:entry.id,delta:1});
      const pin=document.createElement('button'); pin.className='ghost'; pin.textContent=entry.pinned?'Unpin':'Pin'; pin.onclick=()=>action('togglePinned',{kind:'RESOURCE',entryId:entry.id});
      const edit=document.createElement('button'); edit.className='secondary'; edit.textContent='Suggest edit'; edit.onclick=()=>editApproved('RESOURCE',entry);
      controls.append(minus,plus,pin,edit); card.appendChild(controls); $('resource-list').appendChild(card);
    });

    renderPinned(pc, economy, encounter);
  }

  function renderPinned(pc, economy, encounter) {
    const pinned = [];
    (pc.spellcasting?.spells||[]).filter(x=>x.pinned).forEach(x=>pinned.push({kind:'SPELL',entry:x}));
    (pc.abilities||[]).filter(x=>x.pinned).forEach(x=>pinned.push({kind:'ABILITY',entry:x}));
    (pc.strikes||[]).filter(x=>x.pinned).forEach(x=>pinned.push({kind:'STRIKE',entry:x}));
    (pc.resources||[]).filter(x=>x.pinned).forEach(x=>pinned.push({kind:'RESOURCE',entry:x}));
    $('pinned-panel').classList.toggle('hidden', pinned.length===0);
    $('pinned-list').innerHTML='';
    pinned.forEach(item=>{
      const card=document.createElement('div'); card.className='dashboard-card'; const e=item.entry;
      card.innerHTML=`<strong>${escapeHtml(e.name)}</strong><div class="meta">${escapeHtml(item.kind)}</div>`;
      const controls=document.createElement('div'); controls.className='controls';
      if(item.kind==='SPELL'){ const b=document.createElement('button'); b.textContent='Cast'; b.onclick=()=>action('castSpell',{spellId:e.id}); controls.appendChild(b); }
      if(item.kind==='ABILITY' && e.actionType!=='PASSIVE'){ const b=document.createElement('button'); b.textContent='Use'; b.onclick=()=>action('useAbility',{abilityId:e.id}); controls.appendChild(b); }
      if(item.kind==='STRIKE'){ const b=document.createElement('button'); b.textContent='Strike'; b.onclick=()=>action('useStrike',{strikeId:e.id}); controls.appendChild(b); }
      if(item.kind==='RESOURCE'){ const b=document.createElement('button'); b.className='ghost'; b.textContent=`${e.current}/${e.max}`; b.disabled=true; controls.appendChild(b); }
      card.appendChild(controls); $('pinned-list').appendChild(card);
    });
  }

  function renderCharacterProfile(pc) {
    const profile = $('character-profile');
    if (!profile) return;
    const st = pc.stats || {};
    const rows = [
      ['Ancestry', pc.ancestry || '—'], ['Heritage', pc.heritage || '—'], ['Background', pc.background || '—'],
      ['Class', pc.characterClass || '—'], ['Level', pc.level == null ? 'Not set' : pc.level], ['Size / Speed', `${st.size || 'Medium'} / ${st.speed ?? 25} ft`],
      ['AC', st.armorClass ?? 10], ['Perception', signedText(st.perception ?? 0)], ['Fort / Ref / Will', `${signedText(st.fortitude ?? 0)} / ${signedText(st.reflex ?? 0)} / ${signedText(st.will ?? 0)}`],
      ['Class DC', st.classDc ?? 0], ['Spell DC / Attack', `${pc.spellcasting?.spellDc ?? 0} / ${signedText(pc.spellcasting?.spellAttackModifier ?? 0)}`],
    ];
    profile.innerHTML = rows.map(([k,v]) => `<div class="profile-row"><span class="muted">${escapeHtml(k)}</span><strong>${escapeHtml(v)}</strong></div>`).join('');
    if (!state.sheetDirty) populateCharacterSheet(pc);
    const list = $('feat-list'); if (!list) return; list.innerHTML='';
    const feats = pc.feats || [];
    if (!feats.length) { list.innerHTML='<div class="muted">No feats entered yet.</div>'; return; }
    feats.forEach(feat => {
      const card=document.createElement('div'); card.className='dashboard-card';
      card.innerHTML=`<strong>${escapeHtml(feat.name)}</strong><div class="meta">${escapeHtml(feat.type || 'Feat')}${feat.level==null?'':` • Level ${feat.level}`}</div>${feat.traits?`<div class="meta">Traits: ${escapeHtml(feat.traits)}</div>`:''}${feat.prerequisites?`<div class="meta">Prerequisites: ${escapeHtml(feat.prerequisites)}</div>`:''}${feat.notes?`<div>${escapeHtml(feat.notes)}</div>`:''}`;
      list.appendChild(card);
    });
  }

  function signedText(value){ const n=Number(value||0); return `${n>=0?'+':''}${n}`; }

  function populateCharacterSheet(pc){
    const st=pc.stats||{}; state.sheetLoadedFor=pc.id;
    const set=(id,value)=>{ if($(id)) $(id).value=value ?? ''; };
    set('sheet-hp',pc.hp); set('sheet-max-hp',pc.maxHp); set('sheet-temp-hp',pc.tempHp); set('sheet-size',st.size||'Medium'); set('sheet-speed',st.speed??25); set('sheet-ac',st.armorClass??10);
    set('sheet-str',st.strength??0); set('sheet-dex',st.dexterity??0); set('sheet-con',st.constitution??0); set('sheet-int',st.intelligence??0); set('sheet-wis',st.wisdom??0); set('sheet-cha',st.charisma??0);
    set('sheet-perception',st.perception??0); set('sheet-fort',st.fortitude??0); set('sheet-reflex',st.reflex??0); set('sheet-will',st.will??0); set('sheet-class-dc',st.classDc??0);
    set('sheet-spell-dc',pc.spellcasting?.spellDc??0); set('sheet-spell-attack',pc.spellcasting?.spellAttackModifier??0); set('sheet-languages',st.languages||''); set('sheet-senses',st.senses||'');
    set('sheet-weapon-prof',st.weaponProficiency||''); set('sheet-armor-prof',st.armorProficiency||''); set('sheet-immunities',st.immunities||''); set('sheet-resistances',st.resistances||''); set('sheet-weaknesses',st.weaknesses||'');
    const holder=$('sheet-skills'); if(holder){ holder.innerHTML=''; standardSkills.forEach(skill=>{ const wrap=document.createElement('div'); wrap.className='skill-entry'; const mod=st.skillModifiers?.[skill]??0; const prof=st.skillProficiencies?.[skill]||'Untrained'; wrap.innerHTML=`<strong>${escapeHtml(skill)}</strong><label>Modifier<input data-skill-mod="${escapeHtml(skill)}" inputmode="numeric" value="${escapeHtml(mod)}"></label><label>Proficiency<select data-skill-prof="${escapeHtml(skill)}">${['Untrained','Trained','Expert','Master','Legendary'].map(x=>`<option${x===prof?' selected':''}>${x}</option>`).join('')}</select></label>`; holder.appendChild(wrap); }); }
  }

  function saveCharacterSheet(){
    if(!state.snapshot?.you) return;
    const int=(id,fallback=0)=>Number.parseInt($(id)?.value||String(fallback),10)||0;
    const skillModifiers={}; const skillProficiencies={};
    document.querySelectorAll('[data-skill-mod]').forEach(el=>skillModifiers[el.dataset.skillMod]=Number.parseInt(el.value||'0',10)||0);
    document.querySelectorAll('[data-skill-prof]').forEach(el=>skillProficiencies[el.dataset.skillProf]=el.value);
    const stats={size:$('sheet-size').value,speed:int('sheet-speed',25),languages:$('sheet-languages').value.trim(),senses:$('sheet-senses').value.trim(),strength:int('sheet-str'),dexterity:int('sheet-dex'),constitution:int('sheet-con'),intelligence:int('sheet-int'),wisdom:int('sheet-wis'),charisma:int('sheet-cha'),armorClass:int('sheet-ac',10),perception:int('sheet-perception'),fortitude:int('sheet-fort'),reflex:int('sheet-reflex'),will:int('sheet-will'),classDc:int('sheet-class-dc'),skillModifiers,skillProficiencies,weaponProficiency:$('sheet-weapon-prof').value.trim(),armorProficiency:$('sheet-armor-prof').value.trim(),immunities:$('sheet-immunities').value.trim(),resistances:$('sheet-resistances').value.trim(),weaknesses:$('sheet-weaknesses').value.trim()};
    action('saveCharacterSheet',{hp:int('sheet-hp'),maxHp:int('sheet-max-hp',1),tempHp:int('sheet-temp-hp'),spellDc:int('sheet-spell-dc'),spellAttackModifier:int('sheet-spell-attack'),stats});
    state.sheetDirty=false; state.sheetLoadedFor=null; $('sheet-status').textContent='Character sheet saved.';
  }

  function renderInventory(items, shared) {
    const bulkTotal=(items||[]).reduce((sum,item)=>sum+(Number(item.bulk||0)*Number(item.quantity||1)),0);
    if($('inventory-bulk')) $('inventory-bulk').textContent=`Bulk ${formatBulk(bulkTotal)}`;
    const renderList = (id, arr, emptyText, owned=false) => {
      const el=$(id); if(!el)return; el.innerHTML='';
      if(!arr.length){el.innerHTML=`<div class="muted">${emptyText}</div>`;return;}
      arr.forEach(item=>{
        const card=document.createElement('div'); card.className='dashboard-card';
        const chargeText=item.consumable?` • Uses ${item.charges??0}/${item.maxCharges??item.charges??0}`:'';
        const containerText=item.containerName?` • in ${escapeHtml(item.containerName)}`:'';
        const traitText=item.traits?`<div class="meta">Traits: ${escapeHtml(item.traits)}</div>`:'';
        const runeText=item.runes?`<div class="meta">Runes: ${escapeHtml(item.runes)}</div>`:'';
        card.innerHTML=`<strong>${item.quantity>1?`${item.quantity}× `:''}${escapeHtml(item.name)}</strong>${!item.identified?'<span class="status-badge pending">Unidentified</span>':''}<div class="meta">${escapeHtml(item.category||'Item')} • ${owned?escapeHtml(item.carryState||'Stowed'):'Shared'}${Number(item.bulk||0)>0?` • Bulk ${formatBulk(Number(item.bulk)*Number(item.quantity||1))}`:''}${Number(item.valueGp||0)>0?` • ${formatGp(item.valueGp)} gp`:''}${chargeText}${containerText}</div>${traitText}${runeText}${item.notes?`<div>${escapeHtml(item.notes)}</div>`:''}`;
        if(owned){
          const controls=document.createElement('div'); controls.className='controls';
          const stateSelect=document.createElement('select'); ['Stowed','Worn','Held','Equipped'].forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;if(v===(item.carryState||'Stowed'))o.selected=true;stateSelect.appendChild(o);});
          stateSelect.onchange=()=>action('inventoryCarryState',{itemId:item.id,carryState:stateSelect.value}); controls.appendChild(stateSelect);
          if(item.consumable){const use=document.createElement('button');use.className='secondary';use.textContent='Use';use.disabled=Number(item.charges??1)<=0;use.onclick=()=>action('inventoryUse',{itemId:item.id});controls.appendChild(use);}
          card.appendChild(controls);
        }
        el.appendChild(card);
      });
    };
    renderList('inventory-list', items, 'No items assigned to you.', true);
    renderList('shared-loot-list', shared, 'No shared party loot.', false);
  }

  function formatBulk(value){ const n=Number(value||0); if(n<=0)return '—'; if(n<1){const l=Math.max(1,Math.round(n*10));return l===1?'L':`${l}L`;} return Number.isInteger(n)?String(n):n.toFixed(1); }

  function renderDrafts(pc) {
    const list=$('draft-list'); list.innerHTML='';
    const drafts=(pc.contentDrafts||[]).slice().sort((a,b)=>(b.submittedAt||0)-(a.submittedAt||0));
    if(!drafts.length){ list.innerHTML='<div class="muted">No drafts or submission history yet.</div>'; return; }
    drafts.forEach(draft=>{
      const card=document.createElement('div'); card.className='dashboard-card';
      const status=draft.status==='PENDING'?'Pending GM':draft.status==='APPROVED_HISTORY'?'Approved':'Draft';
      const statusClass=draft.status==='PENDING'?'pending':draft.status==='APPROVED_HISTORY'?'approved':'draft';
      card.innerHTML=`<strong>${escapeHtml(draft.name)}</strong><span class="status-badge ${statusClass}">${escapeHtml(status)}</span><div class="meta">${escapeHtml(draft.kind)}</div>${draft.gmFeedback&&draft.gmFeedback!=='Approved'?`<div class="feedback">GM: ${escapeHtml(draft.gmFeedback)}</div>`:''}`;
      const controls=document.createElement('div'); controls.className='controls';
      if(draft.status==='DRAFT'){
        const edit=document.createElement('button'); edit.className='secondary'; edit.textContent='Edit'; edit.onclick=()=>populateBuilder(draft);
        const submit=document.createElement('button'); submit.textContent='Submit'; submit.onclick=()=>action('submitContentDraft',{draftId:draft.id});
        const del=document.createElement('button'); del.className='ghost'; del.textContent='Delete'; del.onclick=()=>action('deleteContentDraft',{draftId:draft.id});
        controls.append(edit,submit,del);
      }
      if(draft.status==='PENDING'){ const wait=document.createElement('button'); wait.className='ghost'; wait.textContent='Waiting for GM'; wait.disabled=true; controls.appendChild(wait); }
      card.appendChild(controls); list.appendChild(card);
    });
  }

  function abilityActionLabel(entry){
    if(entry.actionType==='REACTION') return 'Reaction'; if(entry.actionType==='FREE') return 'Free action'; if(entry.actionType==='PASSIVE') return 'Passive';
    return `${entry.actions||1} action${Number(entry.actions||1)===1?'':'s'}`;
  }

  function setSelectOrCustom(selectId, customId, value, fallback=''){
    const select=$(selectId), custom=$(customId); if(!select||!custom)return;
    const options=[...select.options].map(x=>x.value);
    if(value && options.includes(value)){ select.value=value; custom.value=''; custom.classList.add('hidden'); }
    else if(value){ select.value='CUSTOM'; custom.value=value; custom.classList.remove('hidden'); }
    else { select.value=fallback && options.includes(fallback)?fallback:select.options[0]?.value||''; custom.value=''; custom.classList.add('hidden'); }
  }
  function readSelectOrCustom(selectId, customId){ const select=$(selectId), custom=$(customId); return select?.value==='CUSTOM'?(custom?.value||'').trim():(select?.value||'').trim(); }
  function toggleCustom(selectId, customId){ const custom=$(customId); if(custom) custom.classList.toggle('hidden', $(selectId).value!=='CUSTOM'); }

  function populateBuilder(entry){
    $('builder-id').value=entry.id||''; $('builder-source-id').value=entry.sourceEntryId||''; $('builder-kind').value=entry.kind||'ABILITY'; $('builder-kind').disabled=!!entry.sourceEntryId; $('builder-name').value=entry.name||'';
    $('builder-actions').value=entry.actions??1; $('builder-rank').value=entry.rank??1; $('builder-cantrip').checked=!!entry.isCantrip; $('builder-focus').checked=!!entry.isFocus;
    setSelectOrCustom('builder-range-select','builder-range-custom',entry.range||'','30 ft'); setSelectOrCustom('builder-targets-select','builder-targets-custom',entry.targets||'','1 creature'); setSelectOrCustom('builder-check-select','builder-check-custom',entry.checkOrSave||'','none');
    $('builder-category').value=entry.abilityCategory||entry.category||'Ability'; $('builder-action-type').value=entry.actionType||'ACTION'; $('builder-usage').value=entry.usageMode||'UNLIMITED'; $('builder-max-uses').value=entry.maxUses??1;
    $('builder-attack').value=entry.attackModifier??0; $('builder-damage').value=entry.damage||''; setSelectOrCustom('builder-damage-type-select','builder-damage-type-custom',entry.damageType||'',''); $('builder-healing').checked=!!entry.healing; $('builder-basic-save').checked=!!entry.basicSave; $('builder-traits').value=entry.traits||'';
    $('builder-effect-cs').value=entry.effectCriticalSuccess||''; $('builder-effect-s').value=entry.effectSuccess||''; $('builder-effect-f').value=entry.effectFailure||''; $('builder-effect-cf').value=entry.effectCriticalFailure||'';
    $('builder-resource-max').value=entry.resourceMax??entry.max??1; $('builder-notes').value=entry.notes||'';
    updateBuilderVisibility(); showPlayerPage('builder'); $('builder-panel').scrollIntoView({behavior:'smooth',block:'start'});
  }

  function editApproved(kind, entry){
    const draft={...entry,id:(crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`),kind,status:'DRAFT',sourceEntryId:entry.id};
    if(kind==='ABILITY'){draft.abilityCategory=entry.category;} if(kind==='RESOURCE'){draft.resourceMax=entry.max;}
    populateBuilder(draft); $('builder-status').textContent='Editing an approved entry. Your changes still require GM approval.';
  }

  function builderPayload(){
    let id=$('builder-id').value.trim(); if(!id){id=crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`; $('builder-id').value=id;}
    return {id,sourceEntryId:$('builder-source-id').value.trim(),kind:$('builder-kind').value,name:$('builder-name').value.trim(),actions:Number.parseInt($('builder-actions').value||'1',10)||0,rank:Number.parseInt($('builder-rank').value||'1',10)||1,isCantrip:$('builder-cantrip').checked,isFocus:$('builder-focus').checked,range:readSelectOrCustom('builder-range-select','builder-range-custom'),targets:readSelectOrCustom('builder-targets-select','builder-targets-custom'),checkOrSave:readSelectOrCustom('builder-check-select','builder-check-custom'),abilityCategory:$('builder-category').value.trim(),actionType:$('builder-action-type').value,usageMode:$('builder-usage').value,maxUses:Number.parseInt($('builder-max-uses').value||'0',10)||0,attackModifier:Number.parseInt($('builder-attack').value||'0',10)||0,damage:$('builder-damage').value.trim(),damageType:readSelectOrCustom('builder-damage-type-select','builder-damage-type-custom'),basicSave:$('builder-basic-save').checked,healing:$('builder-healing').checked,traits:$('builder-traits').value.trim(),effectCriticalSuccess:$('builder-effect-cs').value,effectSuccess:$('builder-effect-s').value,effectFailure:$('builder-effect-f').value,effectCriticalFailure:$('builder-effect-cf').value,resourceMax:Number.parseInt($('builder-resource-max').value||'0',10)||0,notes:$('builder-notes').value.trim()};
  }

  function saveDraft(submit){ const payload=builderPayload(); if(!payload.name){$('builder-status').textContent='Give it a name first.'; return;} action('saveContentDraft',payload); if(submit) action('submitContentDraft',{draftId:payload.id}); $('builder-status').textContent=submit?'Submitted to GM.':'Draft saved.'; if(submit) clearBuilder(false); }

  function clearBuilder(clearStatus=true){
    $('builder-id').value=''; $('builder-source-id').value=''; $('builder-kind').disabled=false; $('builder-kind').value='SPELL'; $('builder-name').value=''; $('builder-actions').value='1'; $('builder-rank').value='1'; $('builder-cantrip').checked=false; $('builder-focus').checked=false;
    setSelectOrCustom('builder-range-select','builder-range-custom','30 ft','30 ft'); setSelectOrCustom('builder-targets-select','builder-targets-custom','1 creature','1 creature'); setSelectOrCustom('builder-check-select','builder-check-custom','none','none');
    $('builder-category').value='Ability'; $('builder-action-type').value='ACTION'; $('builder-usage').value='UNLIMITED'; $('builder-max-uses').value='1'; $('builder-attack').value='0'; $('builder-damage').value=''; setSelectOrCustom('builder-damage-type-select','builder-damage-type-custom','',''); $('builder-healing').checked=false; $('builder-basic-save').checked=false; $('builder-traits').value=''; $('builder-effect-cs').value=''; $('builder-effect-s').value=''; $('builder-effect-f').value=''; $('builder-effect-cf').value=''; $('builder-resource-max').value='1'; $('builder-notes').value=''; if(clearStatus)$('builder-status').textContent=''; updateBuilderVisibility();
  }

  function updateBuilderVisibility(){
    const kind=$('builder-kind').value;
    document.querySelectorAll('.spell-only').forEach(x=>x.classList.toggle('hidden',kind!=='SPELL'));
    document.querySelectorAll('.ability-only').forEach(x=>x.classList.toggle('hidden',kind!=='ABILITY'));
    document.querySelectorAll('.strike-only').forEach(x=>x.classList.toggle('hidden',kind!=='STRIKE'));
    document.querySelectorAll('.resource-only').forEach(x=>x.classList.toggle('hidden',kind!=='RESOURCE'));
    document.querySelectorAll('.mechanics-only').forEach(x=>x.classList.toggle('hidden',kind==='RESOURCE'));
    document.querySelectorAll('.builder-actions').forEach(x=>x.classList.toggle('hidden',kind==='RESOURCE'));
    document.querySelectorAll('.save-option').forEach(x=>x.classList.toggle('hidden',!(kind==='SPELL'||kind==='ABILITY')));
  }

  async function requestCharacter() {
    const status=$('request-character-status'); status.textContent='';
    const payload={pin:$('pin').value.trim(),displayName:$('display-name').value.trim(),characterName:$('request-character-name').value.trim(),ancestry:$('request-ancestry').value.trim(),heritage:$('request-heritage').value.trim(),background:$('request-background').value.trim(),characterClass:$('request-class').value.trim(),level:Number.parseInt($('request-level').value||'-1',10),notes:$('request-notes').value.trim()};
    if(!payload.characterName){status.textContent='Enter a character name.';return;}
    const response=await fetch('/api/request-character',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const result=await response.json();
    if(!response.ok||!result.ok){status.textContent=result.error||'Could not send request.';return;}
    status.textContent='Request sent to the GM. Refresh the character list after approval.';
    await loadLobby();
  }

  function cacheSnapshot(snapshot) {
    try { localStorage.setItem('tthelper.snapshot', JSON.stringify(snapshot)); } catch (_) {}
  }

  function renderCached() {
    try { const cached = JSON.parse(localStorage.getItem('tthelper.snapshot')); if (cached) { state.snapshot = cached; render(cached); } } catch (_) {}
  }

  function chip(text, onClick) {
    const button = document.createElement('button'); button.className = 'chip'; button.textContent = text; button.onclick = onClick; return button;
  }

  function conditionText(condition) {
    return condition.value == null ? condition.name : `${condition.name} ${condition.value}`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }

  function formatGp(value) {
    const number = Number(value || 0);
    return Number.isInteger(number) ? String(number) : number.toFixed(1);
  }

  function setupQuickConditions() {
    const select = $('condition-select');
    select.innerHTML = '';
    quickConditions.forEach(name => {
      const option = document.createElement('option');
      option.value = name; option.textContent = name; select.appendChild(option);
    });
    $('add-condition').onclick = () => {
      if (select.value) action('toggleCondition', { name:select.value });
    };
  }

  $('hero-spend').onclick = () => action('heroDelta',{delta:-1});
  $('hero-add').onclick = () => action('heroDelta',{delta:1});
  commonEffects.forEach(name=>document.querySelectorAll('.effect-select').forEach(select=>{ if(![...select.options].some(o=>o.value===name)){ const o=document.createElement('option'); o.value=name; o.textContent=name||'None'; select.appendChild(o); } }));
  $('builder-kind').onchange = updateBuilderVisibility;
  ['range','targets','check','damage-type'].forEach(key=>{ const sel=$(`builder-${key}-select`), custom=$(`builder-${key}-custom`); if(sel&&custom) sel.onchange=()=>toggleCustom(`builder-${key}-select`,`builder-${key}-custom`); });
  $('builder-add-trait').onclick=()=>{ const select=$('builder-trait-preset'); let value=select.value; if(!value)return; if(value==='CUSTOM') value=window.prompt('Custom trait')||''; value=value.trim(); if(!value)return; const parts=$('builder-traits').value.split(',').map(x=>x.trim()).filter(Boolean); if(!parts.some(x=>x.toLowerCase()===value.toLowerCase())) parts.push(value); $('builder-traits').value=parts.join(', '); select.value=''; };
  $('save-draft').onclick = () => saveDraft(false);
  $('submit-draft').onclick = () => saveDraft(true);
  $('clear-builder').onclick = () => clearBuilder();
  $('save-character-sheet').onclick = saveCharacterSheet;
  document.querySelectorAll('.sheet-editor input,.sheet-editor select,.sheet-editor textarea').forEach(el=>el.addEventListener('input',()=>{state.sheetDirty=true;}));
  $('sheet-skills')?.addEventListener('input',()=>{state.sheetDirty=true;});
  const commonActions=['Stride','Step','Raise a Shield','Take Cover','Recall Knowledge','Seek','Demoralize','Grapple','Trip','Shove','Sustain'];
  commonActions.forEach(label=>{const b=document.createElement('button');b.className='secondary';b.textContent=`${label} • 1A`;b.onclick=()=>action('commonAction',{label,actions:1});$('common-actions').appendChild(b);});
  updateBuilderVisibility();

  $('join-button').onclick = join;
  $('request-character-button').onclick = requestCharacter;
  document.querySelectorAll('[data-player-nav]').forEach(btn => btn.onclick = () => showPlayerPage(btn.dataset.playerNav));
  showPlayerPage(state.currentPage);
  $('ready-button').onclick = () => action('toggleReady');
  document.querySelectorAll('[data-hp]').forEach(button => button.onclick = () => action('hpDelta', { delta:Number(button.dataset.hp) }));
  document.querySelectorAll('[data-action-spend]').forEach(button => button.onclick = () => action('spendActions', { count:Number(button.dataset.actionSpend) }));
  $('refund-action').onclick = () => action('refundAction', { count:1 });
  $('reaction-button').onclick = () => action($('reaction-button').dataset.available === 'true' ? 'useReaction' : 'restoreReaction');
  $('refocus-button').onclick = () => action('refocus');
  $('d20-button').onclick = () => {
    const result = 1 + Math.floor(Math.random() * 20);
    $('roll-result').textContent = `d20 → ${result}`;
    action('recordRoll', { label:'d20', result });
  };
  $('submit-initiative').onclick = () => {
    const value = Number.parseInt($('initiative-result').value, 10);
    if (Number.isFinite(value)) {
      action('submitInitiative', { value, source:'Physical result' });
      $('initiative-roll-result').textContent = `Submitted ${value}`;
    }
  };
  $('roll-initiative').onclick = () => {
    const modifier = Number.parseInt($('initiative-modifier').value || '0', 10) || 0;
    const die = 1 + Math.floor(Math.random() * 20);
    const result = die + modifier;
    action('submitInitiative', { value:result, source:'Player digital' });
    action('recordRoll', { label:`initiative d20 (${die}) ${modifier >= 0 ? '+' : ''}${modifier}`, result });
    $('initiative-roll-result').textContent = `${die} ${modifier >= 0 ? '+' : '−'} ${Math.abs(modifier)} = ${result}`;
  };
  $('end-turn-button').onclick = () => action('requestEndTurn');
  $('forget-button').onclick = () => {
    if (state.ws) state.ws.close();
    state.token = null;
    localStorage.removeItem('tthelper.token');
    localStorage.removeItem('tthelper.snapshot');
    showJoin();
  };

  const pinFromUrl = new URLSearchParams(location.search).get('pin');
  if (pinFromUrl) $('pin').value = pinFromUrl;
  setupQuickConditions();
  renderCached();
  loadLobby().then(tryResume).catch(error => { $('join-error').textContent = `Can't reach GM host: ${error.message}`; });
})();
