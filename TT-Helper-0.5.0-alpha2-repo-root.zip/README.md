# TT Helper 0.5.0-alpha2

TT Helper is a local-first Pathfinder 2e tabletop companion. The Android GM device is authoritative and hosts a lightweight browser client for players on the same LAN.

## 0.5 focus: Loot & Inventory

The GM **Loot & Inventory** workspace now manages:

- shared party stash
- character inventories
- assignment/movement between stash and PCs
- stowed / worn / held / equipped state
- consumables and remaining uses
- containers
- bulk
- quantity and value
- item category / level / traits
- runes and upgrades
- identified vs unidentified items
- GM-hidden loot
- player-visible notes and GM-only notes
- encounter loot moving directly into inventory

Players keep a separate Inventory screen. They can see only revealed items, use their own consumables, and update the carry state of their own gear. Hidden GM loot is filtered server-side.

## Rules resolution clarity

0.5 also carries the remaining 0.4 UI polish. Rules requests distinguish:

- target saving throw vs caster DC
- attacker roll vs target defense
- natural d20 result
- modifier and final total
- base degree of success
- natural 1 / natural 20 degree shift
- final suggested result

The GM remains final authority and can override any suggested degree.

## Build

`versionCode = 11`

`versionName = "0.5.0-alpha2"`

The repo contains the same local-development signing key used by the prior signed builds so normal Android updates should continue to work.
