# TT Helper Changelog

## 0.5.0-alpha2

### Build fix
- Fixed Android/Compose compilation in `InventoryScreen.kt` by removing an invalid explicit `weight` import. The `Modifier.weight(...)` calls now resolve through the proper Row/Column scope.
- Bumped build to versionCode `11` / versionName `0.5.0-alpha2`.

## 0.5.0-alpha1

### Loot & Inventory
- Rebuilt the GM Inventory tab as **Loot & Inventory**.
- Added a shared stash plus per-character inventory views.
- Added item assignment/movement between the party stash and PCs.
- Added item states: **Stowed, Worn, Held, Equipped**.
- Added consumables with remaining/max uses and player-side Use controls.
- Added containers and container assignment.
- Added bulk per item and inventory bulk summaries.
- Added quantity, value, category, level, traits, runes/upgrades, player notes, and GM-only notes.
- Added hidden GM-only items that do not appear in player snapshots until revealed.
- Added identified/unidentified item state and a separate unidentified display name.
- Encounter loot still flows through Generate -> Reveal -> Move to inventory, and generated consumables now carry basic use/bulk metadata.
- Player Inventory is still separated from Combat and shows personal gear separately from shared loot.
- Inventory mutations participate in the existing Undo/persistence system.

### Rules clarity carried forward from 0.4
- Saving throws now explicitly show **TARGET ROLLS** and **CASTER DC**.
- Attacks now explicitly show **ATTACKER ROLLS** and **TARGET DEFENSE**.
- Rules cards show the natural die, modifier, total, base degree of success, natural 1/20 degree shift, and final suggested result.
- This is presentation/traceability work; the underlying PF2e degree-of-success math is unchanged.

### Version
- versionCode 10
- versionName `0.5.0-alpha1`
