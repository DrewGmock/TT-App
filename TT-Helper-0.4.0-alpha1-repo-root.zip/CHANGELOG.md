# TT Helper Changelog

## 0.4.0-alpha1
- Added GM Rules & Resolution queue.
- Added player target selection without exposing enemy defenses.
- Added automatic PF2e Multiple Attack Penalty tracking, including Agile progression.
- Strikes now support digital d20 rolls or entered physical d20 results and create GM resolution requests.
- Added PF2e degree-of-success suggestions including natural 20 / natural 1 shifts when a DC is known.
- Added enemy AC, Fortitude, Reflex, and Will fields to Quick Add and Enemy Library.
- Spellcasting now stores Spell DC and Spell Attack modifier.
- Fortitude/Reflex/Will spell saves and spell attacks create GM rule requests when a target is selected.
- Grapple, Trip, and Shove advance MAP and route to the Rules queue.
- Recall Knowledge and Seek route as secret GM checks.
- Added player-facing rule-resolution history without leaking GM-only defenses or secret-roll results.
- Pending rule requests for the active PC block turn advancement until the GM resolves or dismisses them.
- Renamed GM Inventory to Loot & Inventory.
- Preserves 0.3.1 character/profile, builder, approvals, spellcasting, action economy, inventory, and LAN behavior.
