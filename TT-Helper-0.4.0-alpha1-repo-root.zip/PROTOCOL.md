# TT Helper LAN protocol notes — 0.4.0 alpha 1

The Samsung tablet remains authoritative. Player browsers receive filtered snapshots over WebSocket and submit actions to the host.

## New player actions
- `setTarget` — stores the player's selected encounter target after host-side validation.
- `useStrike` — may include a raw physical `d20`; otherwise the host generates a digital d20. The host applies the approved strike modifier and current MAP.
- `rollRuleRequest` — lets the owning player digitally roll a pending attack-type rule request (for example a spell attack) without exposing target defenses.

## Player snapshot additions
- `you.selectedTargetId`
- `you.actionEconomy.attacksThisTurn`
- `you.spellcasting.spellDc` and `spellAttackModifier`
- `encounter.rules` — only requests belonging to that PC; secret details and GM-only defenses are filtered out.

## GM-only state
Encounter rule requests may include target AC/save information, roll modifiers, suggested degree of success, and secret-check status. Enemy AC/Fortitude/Reflex/Will are never included in player enemy JSON.

## Save migration
All new fields have defaults. Existing 0.3.1 saves load without requiring a reset.
