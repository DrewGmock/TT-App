# TT Helper 0.4.0 Alpha 1

0.4 starts the Rules Intelligence layer while keeping the Samsung tablet authoritative and the player clients lightweight.

## Rules & Resolution
- New GM **Rules** tab with a pending resolution queue.
- Player strikes create attack-resolution requests with the d20, attack modifier, MAP, total, target, and a suggested PF2e degree of success when enemy AC is known.
- The GM can accept the suggestion, override the result, digitally roll unresolved checks, or dismiss the request.
- Natural 20 / natural 1 degree shifts are included in the suggestion logic.
- Pending rule requests for the current PC must be resolved or dismissed before advancing that turn.

## Multiple Attack Penalty
- TT Helper now tracks attacks made during the current turn.
- Standard MAP: 0 / -5 / -10.
- Agile MAP: 0 / -4 / -8.
- MAP resets automatically at the start of the PC's next turn.
- Strikes show the effective modifier for the next attack.
- Grapple, Trip, and Shove advance MAP and create GM rule requests.

## Targeting
- Player Combat now has a private target selector using the enemies currently visible in the encounter.
- Players still do **not** receive AC, Fortitude, Reflex, or Will values.
- The selected target is used for strikes and spell checks behind the scenes.

## Spell checks
- Spellcasting setup now supports **Spell DC** and **Spell Attack modifier**.
- Spells whose Check / Save text contains Fortitude, Reflex, Will, or attack create resolution requests when a target is selected.
- Enemy save modifiers and AC remain GM-only.
- Spell attacks participate in MAP.

## Secret checks
- Recall Knowledge and Seek now create secret GM-side rule requests instead of exposing a result to the player.
- The player only sees that the check was sent to the GM.

## Enemy rule stats
- Enemy Library and Quick Add now accept AC, Fortitude, Reflex, and Will.
- These numbers are used by the resolution engine and are never included in player enemy snapshots.

## Navigation
- GM rail adds **Rules**.
- GM Inventory is renamed **Loot & Inventory** to match its actual role.

## Version
- versionCode: 8
- versionName: 0.4.0-alpha1
