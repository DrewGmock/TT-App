package com.drew.tthelper.state

import android.content.Context
import com.drew.tthelper.model.ActionEconomy
import com.drew.tthelper.model.AbilityActionType
import com.drew.tthelper.model.AbilityEntry
import com.drew.tthelper.model.CharacterResource
import com.drew.tthelper.model.CharacterCreationRequest
import com.drew.tthelper.model.FeatEntry
import com.drew.tthelper.model.ContentKind
import com.drew.tthelper.model.ContentStatus
import com.drew.tthelper.model.DegreeOfSuccess
import com.drew.tthelper.model.PlayerContentDraft
import com.drew.tthelper.model.StrikeEntry
import com.drew.tthelper.model.UsageMode
import com.drew.tthelper.model.CastingMode
import com.drew.tthelper.model.SpellEntry
import com.drew.tthelper.model.SpellSlotPool
import com.drew.tthelper.model.CombatLogEntry
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.Condition
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.EffectAnchor
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EffectOutcomeAction
import com.drew.tthelper.model.EffectPhase
import com.drew.tthelper.model.EffectPreset
import com.drew.tthelper.model.EffectTriggerAction
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.RuleRequest
import com.drew.tthelper.model.RuleRequestStatus
import com.drew.tthelper.model.RuleRequestType
import com.drew.tthelper.model.SessionPrep
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.StateSnapshot
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.model.effectPresets
import com.drew.tthelper.model.obviousEnemyConditions
import com.drew.tthelper.model.valuedConditions
import java.io.File
import java.util.ArrayDeque
import java.util.LinkedHashSet
import java.util.UUID
import kotlin.random.Random
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class SessionStore(context: Context) {
    private val sessionFile = File(context.filesDir, "session-state.json")
    private val backupDir = File(context.filesDir, "backups").also { it.mkdirs() }
    private val undoStack = ArrayDeque<StateSnapshot>()
    private val processedRequestIds = LinkedHashSet<String>()

    private val _state = MutableStateFlow(loadOrDefault())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    @Synchronized
    fun setHp(pcId: String, hp: Int, label: String = "Set HP") {
        val currentPc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val delta = hp.coerceIn(0, currentPc.maxHp) - currentPc.hp
        hpDelta(pcId, delta, label)
    }

    @Synchronized
    fun hpDelta(pcId: String, delta: Int, label: String = if (delta < 0) "Damage" else "Healing") {
        val beforePc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val displayLabel = if (label == "Damage" || label == "Healing") {
            if (delta < 0) "${beforePc.name} took ${-delta} damage" else "${beforePc.name} healed ${delta}"
        } else label

        mutate(displayLabel, logEncounter = _state.value.encounter != null) { current ->
            val encounterActive = current.encounter?.active == true
            var updatedPc = applyPcHpDelta(beforePc = current.pcs.first { it.id == pcId }, delta = delta, encounterActive = encounterActive)
            val pcs = current.pcs.map { if (it.id == pcId) updatedPc else it }
            val encounter = current.encounter?.let { syncPcIntoEncounter(it, updatedPc) }
            current.copy(pcs = pcs, encounter = encounter)
        }
    }

    @Synchronized
    fun tempHpDelta(pcId: String, delta: Int) = mutate("Temp HP", logEncounter = _state.value.encounter != null) { current ->
        val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
        val updated = pc.copy(tempHp = (pc.tempHp + delta).coerceAtLeast(0))
        current.copy(
            pcs = current.pcs.map { if (it.id == pcId) updated else it },
            encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
        )
    }

    @Synchronized
    fun toggleReady(pcId: String) = mutate("Ready status") { current ->
        current.updatePc(pcId) { it.copy(ready = !it.ready) }
    }


    @Synchronized
    fun spendActions(pcId: String, count: Int) {
        val amount = count.coerceIn(1, 3)
        val encounter = _state.value.encounter
        if (encounter?.active == true && encounter.currentCombatant()?.pcId != pcId) return
        mutate("Action spent", logEncounter = _state.value.encounter != null) { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(actionEconomy = pc.actionEconomy.copy(
                    actionsRemaining = (pc.actionEconomy.actionsRemaining - amount).coerceAtLeast(0),
                ))
            }
        }
    }

    @Synchronized
    fun refundAction(pcId: String, count: Int = 1) {
        val amount = count.coerceIn(1, 3)
        mutate("Action refunded", logEncounter = _state.value.encounter != null) { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(actionEconomy = pc.actionEconomy.copy(
                    actionsRemaining = (pc.actionEconomy.actionsRemaining + amount).coerceAtMost(pc.actionEconomy.baseActions),
                ))
            }
        }
    }

    @Synchronized
    fun useReaction(pcId: String) = mutate("Reaction used", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(actionEconomy = it.actionEconomy.copy(reactionAvailable = false)) }
    }

    @Synchronized
    fun restoreReaction(pcId: String) = mutate("Reaction restored", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(actionEconomy = it.actionEconomy.copy(reactionAvailable = true)) }
    }

    @Synchronized
    fun resetActionEconomy(pcId: String) = mutate("Action economy reset", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            resetTurnAbilityUses(pc.copy(actionEconomy = ActionEconomy(baseActions = 3, actionsRemaining = 3, reactionAvailable = true)))
        }
    }

    @Synchronized
    fun configureSpellcasting(
        pcId: String,
        enabled: Boolean,
        tradition: String,
        castingMode: String,
        maxFocusPoints: Int,
        spellDc: Int? = null,
        spellAttackModifier: Int? = null,
    ) = mutate("Spellcasting configured") { current ->
        current.updatePc(pcId) { pc ->
            val old = pc.spellcasting
            val maxFocus = maxFocusPoints.coerceIn(0, 3)
            pc.copy(spellcasting = old.copy(
                enabled = enabled,
                tradition = tradition.trim().take(30),
                castingMode = if (castingMode == CastingMode.SPONTANEOUS) CastingMode.SPONTANEOUS else CastingMode.PREPARED,
                maxFocusPoints = maxFocus,
                focusPoints = old.focusPoints.coerceIn(0, maxFocus),
                spellDc = (spellDc ?: old.spellDc).coerceIn(0, 60),
                spellAttackModifier = (spellAttackModifier ?: old.spellAttackModifier).coerceIn(-20, 50),
            ))
        }
    }

    @Synchronized
    fun setFocusPoints(pcId: String, value: Int) = mutate("Focus points changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(
                focusPoints = value.coerceIn(0, pc.spellcasting.maxFocusPoints),
            ))
        }
    }

    @Synchronized
    fun refocus(pcId: String) = mutate("Refocused", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(focusPoints = pc.spellcasting.maxFocusPoints))
        }
    }

    @Synchronized
    fun setSpellSlotPool(pcId: String, rank: Int, total: Int, remaining: Int? = null) {
        val r = rank.coerceIn(1, 10)
        val t = total.coerceIn(0, 10)
        mutate("Spell slots updated") { current ->
            current.updatePc(pcId) { pc ->
                val old = pc.spellcasting.slots.firstOrNull { it.rank == r }
                val rem = (remaining ?: old?.remaining ?: t).coerceIn(0, t)
                val slots = (pc.spellcasting.slots.filterNot { it.rank == r } + SpellSlotPool(r, t, rem)).sortedBy { it.rank }
                pc.copy(spellcasting = pc.spellcasting.copy(slots = slots))
            }
        }
    }

    @Synchronized
    fun restoreSpellSlots(pcId: String) = mutate("Spell slots restored") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(
                slots = pc.spellcasting.slots.map { it.copy(remaining = it.total) },
                spells = pc.spellcasting.spells.map { if (it.isCantrip || it.isFocus) it else it.copy(expended = false) },
            ))
        }
    }

    @Synchronized
    fun addSpell(
        pcId: String,
        name: String,
        rank: Int,
        actions: Int,
        isCantrip: Boolean,
        isFocus: Boolean,
        notes: String = "",
    ) {
        val clean = name.trim().take(60)
        if (clean.isBlank()) return
        mutate("Spell added: $clean") { current ->
            current.updatePc(pcId) { pc ->
                val spell = SpellEntry(
                    name = clean,
                    rank = if (isCantrip) 0 else rank.coerceIn(1, 10),
                    actions = actions.coerceIn(0, 3),
                    isCantrip = isCantrip,
                    isFocus = isFocus,
                    notes = notes.trim().take(200),
                )
                pc.copy(spellcasting = pc.spellcasting.copy(enabled = true, spells = pc.spellcasting.spells + spell))
            }
        }
    }

    @Synchronized
    fun removeSpell(pcId: String, spellId: String) = mutate("Spell removed") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.filterNot { it.id == spellId }))
        }
    }

    @Synchronized
    fun setSpellExpended(pcId: String, spellId: String, expended: Boolean) = mutate("Prepared spell updated") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.map {
                if (it.id == spellId) it.copy(expended = expended) else it
            }))
        }
    }

    @Synchronized
    fun castSpell(pcId: String, spellId: String) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val spell = pc.spellcasting.spells.firstOrNull { it.id == spellId } ?: return
        if (!pc.spellcasting.enabled) return

        val encounter = snapshot.encounter
        val encounterActive = encounter?.active == true
        val inOwnTurn = encounterActive && encounter?.currentCombatant()?.pcId == pcId
        if (encounterActive && !inOwnTurn && spell.actions > 0) return
        if (inOwnTurn && pc.actionEconomy.actionsRemaining < spell.actions) return
        if (spell.isFocus && pc.spellcasting.focusPoints <= 0) return
        if (!spell.isCantrip && !spell.isFocus) {
            val pool = pc.spellcasting.slots.firstOrNull { it.rank == spell.rank }
            if (pool != null && pool.remaining <= 0) return
            if (pc.spellcasting.castingMode == CastingMode.PREPARED && spell.expended) return
        }

        val checkText = spell.checkOrSave.trim().lowercase()
        val isAttack = "attack" in checkText
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && it.kind != "pc" && !it.defeated }
        val attackMapPenalty = if (isAttack) mapPenalty(pc.actionEconomy.attacksThisTurn, agile = false) else 0
        val request = if (encounter != null && target != null && checkText.isNotBlank() && checkText !in setOf("none", "—", "-")) {
            when {
                "fort" in checkText -> saveRequest(pc, spell.name, target, "Fortitude", target.fortitude)
                "reflex" in checkText -> saveRequest(pc, spell.name, target, "Reflex", target.reflex)
                "will" in checkText -> saveRequest(pc, spell.name, target, "Will", target.will)
                isAttack -> RuleRequest(
                    actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name,
                    type = RuleRequestType.ATTACK, label = "${spell.name} • spell attack",
                    modifier = pc.spellcasting.spellAttackModifier + attackMapPenalty, mapPenalty = attackMapPenalty,
                    dc = target.armorClass, dcLabel = "AC",
                    notes = "Spell attack ${signed(pc.spellcasting.spellAttackModifier)} • MAP ${signed(attackMapPenalty)}",
                )
                else -> RuleRequest(
                    actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name,
                    type = RuleRequestType.SKILL, label = "${spell.name} • ${spell.checkOrSave}",
                    notes = "Resolve the spell's listed check/save manually.",
                )
            }
        } else null

        mutate("${pc.name} cast ${spell.name}", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { currentPc ->
                var casting = currentPc.spellcasting
                var actionsState = currentPc.actionEconomy
                if (inOwnTurn && spell.actions > 0) {
                    actionsState = actionsState.copy(actionsRemaining = (actionsState.actionsRemaining - spell.actions).coerceAtLeast(0))
                }
                if (isAttack) actionsState = actionsState.copy(attacksThisTurn = actionsState.attacksThisTurn + 1)
                if (spell.isFocus) {
                    casting = casting.copy(focusPoints = (casting.focusPoints - 1).coerceAtLeast(0))
                } else if (!spell.isCantrip) {
                    casting = casting.copy(
                        slots = casting.slots.map { slot ->
                            if (slot.rank == spell.rank) slot.copy(remaining = (slot.remaining - 1).coerceAtLeast(0)) else slot
                        },
                        spells = if (casting.castingMode == CastingMode.PREPARED) {
                            casting.spells.map { if (it.id == spellId) it.copy(expended = true) else it }
                        } else casting.spells,
                    )
                }
                currentPc.copy(spellcasting = casting, actionEconomy = actionsState)
            }
            if (request != null) {
                val updatedEncounter = updated.encounter
                if (updatedEncounter != null) updated.copy(encounter = updatedEncounter.copy(ruleRequests = addRuleRequest(updatedEncounter.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun updateCharacterProfile(
        pcId: String,
        name: String,
        ancestry: String,
        heritage: String,
        background: String,
        characterClass: String,
        level: Int?,
    ) = mutate("Character profile updated") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(
                name = name.trim().ifBlank { pc.name }.take(60),
                ancestry = ancestry.trim().take(60),
                heritage = heritage.trim().take(80),
                background = background.trim().take(80),
                characterClass = characterClass.trim().take(80),
                level = level?.coerceIn(0, 30),
            )
        }
    }

    @Synchronized
    fun addFeat(
        pcId: String,
        name: String,
        type: String,
        level: Int?,
        traits: String,
        prerequisites: String,
        notes: String,
    ) {
        val cleanName = name.trim().take(80)
        if (cleanName.isBlank()) return
        val feat = FeatEntry(
            name = cleanName,
            type = type.trim().ifBlank { "General Feat" }.take(50),
            level = level?.coerceIn(0, 30),
            traits = traits.trim().take(180),
            prerequisites = prerequisites.trim().take(240),
            notes = notes.trim().take(600),
        )
        mutate("Feat added") { current ->
            current.updatePc(pcId) { pc -> pc.copy(feats = pc.feats + feat) }
        }
    }

    @Synchronized
    fun removeFeat(pcId: String, featId: String) = mutate("Feat removed") { current ->
        current.updatePc(pcId) { pc -> pc.copy(feats = pc.feats.filterNot { it.id == featId }) }
    }

    @Synchronized
    fun requestCharacterCreation(
        playerName: String,
        characterName: String,
        ancestry: String,
        heritage: String,
        background: String,
        characterClass: String,
        level: Int?,
        notes: String,
    ): Boolean {
        val cleanName = characterName.trim().take(60)
        if (cleanName.isBlank()) return false
        val request = CharacterCreationRequest(
            playerName = playerName.trim().ifBlank { "Player" }.take(30),
            characterName = cleanName,
            ancestry = ancestry.trim().take(60),
            heritage = heritage.trim().take(80),
            background = background.trim().take(80),
            characterClass = characterClass.trim().take(80),
            level = level?.coerceIn(0, 30),
            notes = notes.trim().take(600),
        )
        mutate("New character requested") { current ->
            current.copy(characterRequests = (current.characterRequests + request).takeLast(50))
        }
        return true
    }

    @Synchronized
    fun approveCharacterRequest(requestId: String) {
        val request = _state.value.characterRequests.firstOrNull { it.id == requestId } ?: return
        val pc = PlayerCharacter(
            id = UUID.randomUUID().toString(),
            name = request.characterName,
            ancestry = request.ancestry,
            heritage = request.heritage,
            background = request.background,
            characterClass = request.characterClass,
            level = request.level,
            hp = 10,
            maxHp = 10,
        )
        mutate("Approved new character ${request.characterName}") { current ->
            current.copy(
                pcs = current.pcs + pc,
                characterRequests = current.characterRequests.filterNot { it.id == requestId },
            )
        }
    }

    @Synchronized
    fun declineCharacterRequest(requestId: String) = mutate("Character request declined") { current ->
        current.copy(characterRequests = current.characterRequests.filterNot { it.id == requestId })
    }

    fun pendingSubmissionCount(): Int = _state.value.pcs.sumOf { pc ->
        pc.contentDrafts.count { it.status == ContentStatus.PENDING }
    }

    @Synchronized
    fun setHeroPoints(pcId: String, value: Int) = mutate("Hero Points changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(heroPoints = value.coerceIn(0, 3)) }
    }

    @Synchronized
    fun saveContentDraft(pcId: String, payload: JSONObject) {
        val id = payload.optString("id").ifBlank { UUID.randomUUID().toString() }
        val currentPc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val old = currentPc.contentDrafts.firstOrNull { it.id == id }
        if (old?.status == ContentStatus.PENDING) return
        val kind = payload.optString("kind", old?.kind ?: ContentKind.ABILITY).let {
            if (it in setOf(ContentKind.SPELL, ContentKind.ABILITY, ContentKind.STRIKE, ContentKind.RESOURCE)) it else ContentKind.ABILITY
        }
        val cleanName = payload.optString("name", old?.name.orEmpty()).trim().take(60)
        if (cleanName.isBlank()) return
        val draft = PlayerContentDraft(
            id = id,
            kind = kind,
            status = ContentStatus.DRAFT,
            name = cleanName,
            rank = payload.optInt("rank", old?.rank ?: 1).coerceIn(0, 10),
            actions = payload.optInt("actions", old?.actions ?: 1).coerceIn(0, 3),
            isCantrip = payload.optBoolean("isCantrip", old?.isCantrip ?: false),
            isFocus = payload.optBoolean("isFocus", old?.isFocus ?: false),
            notes = payload.optString("notes", old?.notes.orEmpty()).trim().take(500),
            range = payload.optString("range", old?.range.orEmpty()).trim().take(80),
            targets = payload.optString("targets", old?.targets.orEmpty()).trim().take(120),
            checkOrSave = payload.optString("checkOrSave", old?.checkOrSave.orEmpty()).trim().take(120),
            abilityCategory = payload.optString("abilityCategory", old?.abilityCategory ?: "Ability").trim().take(40),
            actionType = payload.optString("actionType", old?.actionType ?: AbilityActionType.ACTION).let {
                if (it in setOf(AbilityActionType.ACTION, AbilityActionType.REACTION, AbilityActionType.FREE, AbilityActionType.PASSIVE)) it else AbilityActionType.ACTION
            },
            usageMode = payload.optString("usageMode", old?.usageMode ?: UsageMode.UNLIMITED).let {
                if (it in setOf(UsageMode.UNLIMITED, UsageMode.ONCE_PER_TURN, UsageMode.ENCOUNTER, UsageMode.DAILY, UsageMode.CUSTOM)) it else UsageMode.UNLIMITED
            },
            maxUses = payload.optInt("maxUses", old?.maxUses ?: 0).coerceIn(0, 99),
            attackModifier = payload.optInt("attackModifier", old?.attackModifier ?: 0).coerceIn(-99, 99),
            damage = payload.optString("damage", old?.damage.orEmpty()).trim().take(80),
            traits = payload.optString("traits", old?.traits.orEmpty()).trim().take(160),
            resourceMax = payload.optInt("resourceMax", old?.resourceMax ?: 0).coerceIn(0, 999),
            gmFeedback = old?.gmFeedback.orEmpty(),
            sourceEntryId = payload.optString("sourceEntryId").takeIf { it.isNotBlank() } ?: old?.sourceEntryId,
            submittedAt = null,
        )
        mutate("${currentPc.name} saved a ${kind.lowercase()} draft") { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(contentDrafts = (pc.contentDrafts.filterNot { it.id == id } + draft).takeLast(100))
            }
        }
    }

    @Synchronized
    fun submitContentDraft(pcId: String, draftId: String) {
        val pc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val draft = pc.contentDrafts.firstOrNull { it.id == draftId && it.status == ContentStatus.DRAFT } ?: return
        mutate("${pc.name} submitted ${draft.name} for approval") { current ->
            current.updatePc(pcId) { target ->
                target.copy(contentDrafts = target.contentDrafts.map {
                    if (it.id == draftId) it.copy(status = ContentStatus.PENDING, submittedAt = System.currentTimeMillis()) else it
                })
            }
        }
    }

    @Synchronized
    fun deleteContentDraft(pcId: String, draftId: String) = mutate("Draft deleted") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(contentDrafts = pc.contentDrafts.filterNot { it.id == draftId && it.status != ContentStatus.PENDING })
        }
    }

    @Synchronized
    fun declineContentDraft(pcId: String, draftId: String, feedback: String) {
        val pc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val draft = pc.contentDrafts.firstOrNull { it.id == draftId && it.status == ContentStatus.PENDING } ?: return
        mutate("${draft.name} returned to ${pc.name}'s drafts") { current ->
            current.updatePc(pcId) { target ->
                target.copy(contentDrafts = target.contentDrafts.map {
                    if (it.id == draftId) it.copy(
                        status = ContentStatus.DRAFT,
                        gmFeedback = feedback.trim().take(500),
                        submittedAt = null,
                    ) else it
                })
            }
        }
    }

    @Synchronized
    fun approveContentDraft(
        pcId: String,
        draftId: String,
        nameOverride: String? = null,
        actionsOverride: Int? = null,
        notesOverride: String? = null,
    ) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val draft = pc.contentDrafts.firstOrNull { it.id == draftId && it.status == ContentStatus.PENDING } ?: return
        val approvedName = nameOverride?.trim()?.take(60)?.takeIf { it.isNotBlank() } ?: draft.name
        val approvedActions = (actionsOverride ?: draft.actions).coerceIn(0, 3)
        val approvedNotes = notesOverride?.trim()?.take(500) ?: draft.notes
        val approvedId = draft.sourceEntryId ?: UUID.randomUUID().toString()
        mutate("Approved ${draft.name} for ${pc.name}") { current ->
            current.updatePc(pcId) { target ->
                var next = target
                when (draft.kind) {
                    ContentKind.SPELL -> {
                        val existing = next.spellcasting.spells.firstOrNull { it.id == approvedId }
                        val entry = SpellEntry(
                            id = approvedId,
                            name = approvedName,
                            rank = if (draft.isCantrip) 0 else draft.rank.coerceIn(1, 10),
                            actions = approvedActions,
                            isCantrip = draft.isCantrip,
                            isFocus = draft.isFocus,
                            expended = existing?.expended ?: false,
                            notes = approvedNotes,
                            range = draft.range,
                            targets = draft.targets,
                            checkOrSave = draft.checkOrSave,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(spellcasting = next.spellcasting.copy(
                            enabled = true,
                            spells = next.spellcasting.spells.filterNot { it.id == approvedId } + entry,
                        ))
                    }
                    ContentKind.ABILITY -> {
                        val maxUses = usageMax(draft.usageMode, draft.maxUses)
                        val existing = next.abilities.firstOrNull { it.id == approvedId }
                        val entry = AbilityEntry(
                            id = approvedId,
                            name = approvedName,
                            category = draft.abilityCategory.ifBlank { "Ability" },
                            actionType = draft.actionType,
                            actions = approvedActions,
                            usageMode = draft.usageMode,
                            maxUses = maxUses,
                            remainingUses = existing?.remainingUses?.coerceAtMost(maxUses) ?: maxUses,
                            notes = approvedNotes,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(abilities = next.abilities.filterNot { it.id == approvedId } + entry)
                    }
                    ContentKind.STRIKE -> {
                        val existing = next.strikes.firstOrNull { it.id == approvedId }
                        val entry = StrikeEntry(
                            id = approvedId,
                            name = approvedName,
                            actions = approvedActions.coerceAtLeast(1),
                            attackModifier = draft.attackModifier,
                            damage = draft.damage,
                            traits = draft.traits,
                            notes = approvedNotes,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(strikes = next.strikes.filterNot { it.id == approvedId } + entry)
                    }
                    ContentKind.RESOURCE -> {
                        val max = draft.resourceMax.coerceAtLeast(0)
                        val existing = next.resources.firstOrNull { it.id == approvedId }
                        val entry = CharacterResource(
                            id = approvedId,
                            name = approvedName,
                            current = existing?.current?.coerceIn(0, max) ?: max,
                            max = max,
                            notes = approvedNotes,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(resources = next.resources.filterNot { it.id == approvedId } + entry)
                    }
                }
                next.copy(contentDrafts = next.contentDrafts.map {
                    if (it.id == draftId) it.copy(
                        status = ContentStatus.APPROVED_HISTORY,
                        name = approvedName,
                        actions = approvedActions,
                        notes = approvedNotes,
                        gmFeedback = "Approved",
                        sourceEntryId = approvedId,
                    ) else it
                }.takeLast(100))
            }
        }
    }

    @Synchronized
    fun togglePinned(pcId: String, kind: String, entryId: String) = mutate("Dashboard pin changed") { current ->
        current.updatePc(pcId) { pc ->
            when (kind) {
                ContentKind.SPELL -> pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it }))
                ContentKind.ABILITY -> pc.copy(abilities = pc.abilities.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it })
                ContentKind.STRIKE -> pc.copy(strikes = pc.strikes.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it })
                ContentKind.RESOURCE -> pc.copy(resources = pc.resources.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it })
                else -> pc
            }
        }
    }

    @Synchronized
    fun useAbility(pcId: String, abilityId: String) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val ability = pc.abilities.firstOrNull { it.id == abilityId } ?: return
        val encounter = snapshot.encounter
        val ownTurn = encounter?.active != true || encounter.currentCombatant()?.pcId == pcId
        if (ability.actionType == AbilityActionType.ACTION && (!ownTurn || pc.actionEconomy.actionsRemaining < ability.actions)) return
        if (ability.actionType == AbilityActionType.REACTION && !pc.actionEconomy.reactionAvailable) return
        if (ability.usageMode != UsageMode.UNLIMITED && ability.remainingUses <= 0) return
        mutate("${pc.name} used ${ability.name}", logEncounter = encounter != null) { current ->
            current.updatePc(pcId) { target ->
                var economy = target.actionEconomy
                if (ability.actionType == AbilityActionType.ACTION) economy = economy.copy(actionsRemaining = (economy.actionsRemaining - ability.actions).coerceAtLeast(0))
                if (ability.actionType == AbilityActionType.REACTION) economy = economy.copy(reactionAvailable = false)
                val abilities = target.abilities.map { entry ->
                    if (entry.id != abilityId || entry.usageMode == UsageMode.UNLIMITED) entry
                    else entry.copy(remainingUses = (entry.remainingUses - 1).coerceAtLeast(0))
                }
                target.copy(actionEconomy = economy, abilities = abilities)
            }
        }
    }

    @Synchronized
    fun restoreAbilityUses(pcId: String, abilityId: String) = mutate("Ability uses restored") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(abilities = pc.abilities.map { ability ->
                if (ability.id == abilityId && ability.usageMode != UsageMode.UNLIMITED) {
                    ability.copy(remainingUses = usageMax(ability.usageMode, ability.maxUses))
                } else ability
            })
        }
    }

    @Synchronized
    fun useStrike(pcId: String, strikeId: String, physicalD20: Int? = null) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val strike = pc.strikes.firstOrNull { it.id == strikeId } ?: return
        val encounter = snapshot.encounter
        val ownTurn = encounter?.active != true || encounter.currentCombatant()?.pcId == pcId
        if (!ownTurn || pc.actionEconomy.actionsRemaining < strike.actions) return
        val agile = strike.traits.contains("agile", ignoreCase = true)
        val penalty = mapPenalty(pc.actionEconomy.attacksThisTurn, agile)
        val modifier = strike.attackModifier + penalty
        val natural = physicalD20?.coerceIn(1, 20) ?: Random.nextInt(1, 21)
        val total = natural + modifier
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && it.kind != "pc" && !it.defeated }
        val request = encounter?.let {
            RuleRequest(
                actorPcId = pc.id, actorName = pc.name, targetCombatantId = target?.id, targetName = target?.name,
                type = RuleRequestType.ATTACK, label = strike.name, roll = natural, modifier = modifier,
                mapPenalty = penalty, total = total, dc = target?.armorClass, dcLabel = "AC",
                suggestedOutcome = target?.armorClass?.let { degreeOfSuccess(total, it, natural) },
                notes = "Base ${signed(strike.attackModifier)} • MAP ${signed(penalty)} • ${strike.damage.ifBlank { "damage not entered" }}",
            )
        }
        mutate("${pc.name} used ${strike.name}", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { targetPc ->
                targetPc.copy(actionEconomy = targetPc.actionEconomy.copy(
                    actionsRemaining = (targetPc.actionEconomy.actionsRemaining - strike.actions).coerceAtLeast(0),
                    attacksThisTurn = targetPc.actionEconomy.attacksThisTurn + 1,
                ))
            }
            if (request != null) {
                val updatedEncounter = updated.encounter
                if (updatedEncounter != null) updated.copy(encounter = updatedEncounter.copy(ruleRequests = addRuleRequest(updatedEncounter.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun performCommonAction(pcId: String, label: String, actions: Int = 1) {
        val clean = label.trim().take(40)
        if (clean.isBlank()) return
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val cost = actions.coerceIn(0, 3)
        val encounter = snapshot.encounter
        val ownTurn = encounter?.active != true || encounter.currentCombatant()?.pcId == pcId
        if (!ownTurn || pc.actionEconomy.actionsRemaining < cost) return
        val attackAction = clean in setOf("Grapple", "Trip", "Shove")
        val secretAction = clean in setOf("Recall Knowledge", "Seek")
        val penalty = if (attackAction) mapPenalty(pc.actionEconomy.attacksThisTurn, agile = false) else 0
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && it.kind != "pc" && !it.defeated }
        val request = if (encounter != null && (attackAction || secretAction)) {
            RuleRequest(
                actorPcId = pc.id, actorName = pc.name, targetCombatantId = target?.id, targetName = target?.name,
                type = if (secretAction) RuleRequestType.SECRET else RuleRequestType.SKILL,
                label = clean, secret = secretAction, mapPenalty = penalty,
                notes = if (secretAction) "Secret check: GM rolls/resolves without exposing the result automatically." else "Athletics attack action • apply MAP ${signed(penalty)}.",
            )
        } else null
        mutate("${pc.name}: $clean", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { targetPc -> targetPc.copy(actionEconomy = targetPc.actionEconomy.copy(
                actionsRemaining = (targetPc.actionEconomy.actionsRemaining - cost).coerceAtLeast(0),
                attacksThisTurn = targetPc.actionEconomy.attacksThisTurn + if (attackAction) 1 else 0,
            )) }
            if (request != null) {
                val updatedEncounter = updated.encounter
                if (updatedEncounter != null) updated.copy(encounter = updatedEncounter.copy(ruleRequests = addRuleRequest(updatedEncounter.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun adjustResource(pcId: String, resourceId: String, delta: Int) = mutate("Character resource changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(resources = pc.resources.map { resource ->
                if (resource.id == resourceId) resource.copy(current = (resource.current + delta).coerceIn(0, resource.max.coerceAtLeast(0))) else resource
            })
        }
    }

    private fun usageMax(mode: String, custom: Int): Int = when (mode) {
        UsageMode.ONCE_PER_TURN, UsageMode.ENCOUNTER, UsageMode.DAILY -> 1
        UsageMode.CUSTOM -> custom.coerceIn(1, 99)
        else -> 0
    }

    private fun resetEncounterAbilityUses(pc: PlayerCharacter): PlayerCharacter = pc.copy(
        abilities = pc.abilities.map { ability ->
            when (ability.usageMode) {
                UsageMode.ONCE_PER_TURN, UsageMode.ENCOUNTER -> ability.copy(remainingUses = usageMax(ability.usageMode, ability.maxUses))
                else -> ability
            }
        }
    )

    private fun resetTurnAbilityUses(pc: PlayerCharacter): PlayerCharacter = pc.copy(
        abilities = pc.abilities.map { ability ->
            if (ability.usageMode == UsageMode.ONCE_PER_TURN) ability.copy(remainingUses = 1) else ability
        }
    )

    @Synchronized
    fun setTarget(pcId: String, combatantId: String?) {
        val encounter = _state.value.encounter
        val valid = combatantId?.takeIf { id -> encounter?.combatants?.any { it.id == id && it.kind != "pc" && !it.defeated } == true }
        mutate("Target changed") { current -> current.updatePc(pcId) { it.copy(selectedTargetId = valid) } }
    }

    @Synchronized
    fun rollRuleRequest(requestId: String, requestedByPcId: String? = null) {
        mutate("Rule check rolled", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val request = encounter.ruleRequests.firstOrNull { it.id == requestId && it.status == RuleRequestStatus.PENDING } ?: return@mutate current
            if (requestedByPcId != null && (request.actorPcId != requestedByPcId || request.type != RuleRequestType.ATTACK)) return@mutate current
            val modifier = request.modifier ?: return@mutate current
            val natural = Random.nextInt(1, 21)
            val total = natural + modifier
            val updated = request.copy(roll = natural, total = total, suggestedOutcome = request.dc?.let { degreeOfSuccess(total, it, natural) })
            current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { if (it.id == requestId) updated else it }))
        }
    }

    @Synchronized
    fun resolveRuleRequest(requestId: String, outcome: String) {
        val allowed = setOf(DegreeOfSuccess.CRITICAL_SUCCESS, DegreeOfSuccess.SUCCESS, DegreeOfSuccess.FAILURE, DegreeOfSuccess.CRITICAL_FAILURE)
        if (outcome !in allowed) return
        mutate("Rule request resolved: $outcome", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { request ->
                if (request.id == requestId && request.status == RuleRequestStatus.PENDING) request.copy(status = RuleRequestStatus.RESOLVED, outcome = outcome) else request
            }))
        }
    }

    @Synchronized
    fun dismissRuleRequest(requestId: String) = mutate("Rule request dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { request ->
            if (request.id == requestId && request.status == RuleRequestStatus.PENDING) request.copy(status = RuleRequestStatus.DISMISSED) else request
        }))
    }

    @Synchronized
    fun toggleCondition(pcId: String, name: String, value: Int? = null) {
        val trimmed = name.trim().take(40)
        if (trimmed.isBlank()) return
        mutate("Condition: $trimmed", logEncounter = _state.value.encounter != null) { current ->
            val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
            val existing = pc.conditions.firstOrNull { it.name.equals(trimmed, ignoreCase = true) }
            val nextConditions = if (existing != null) {
                pc.conditions.filterNot { it.id == existing.id }
            } else {
                val sourceId = current.encounter?.currentCombatant()?.id
                pc.conditions + conditionFromPreset(
                    name = trimmed,
                    sourceCombatantId = sourceId,
                    publicToPlayers = true,
                    partyInflicted = false,
                    valueOverride = value,
                )
            }
            val updated = pc.copy(conditions = nextConditions)
            current.copy(
                pcs = current.pcs.map { if (it.id == pcId) updated else it },
                encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
            )
        }
    }

    @Synchronized
    fun setPcConditionValue(pcId: String, name: String, value: Int) {
        mutate("$name ${value.coerceAtLeast(0)}", logEncounter = _state.value.encounter != null) { current ->
            val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
            val existing = pc.conditions.firstOrNull { it.name.equals(name, true) }
            val next = if (value <= 0) {
                pc.conditions.filterNot { it.name.equals(name, true) }
            } else if (existing != null) {
                pc.conditions.map { if (it.id == existing.id) it.copy(value = value) else it }
            } else {
                pc.conditions + conditionFromPreset(
                    name = name,
                    sourceCombatantId = current.encounter?.currentCombatant()?.id,
                    publicToPlayers = true,
                    partyInflicted = false,
                    valueOverride = value,
                )
            }
            val updated = pc.copy(conditions = next)
            current.copy(
                pcs = current.pcs.map { if (it.id == pcId) updated else it },
                encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
            )
        }
    }

    @Synchronized
    fun updatePrep(prep: SessionPrep) = mutate("Session prep saved") { it.copy(prep = prep) }

    @Synchronized
    fun saveEnemyToLibrary(enemy: PreparedEnemy) = mutate("Enemy saved to library") { current ->
        current.copy(prep = current.prep.copy(enemyLibrary = current.prep.enemyLibrary + enemy.copy(quantity = 1)))
    }

    @Synchronized
    fun deleteEnemyFromLibrary(enemyId: String) = mutate("Enemy removed from library") { current ->
        current.copy(prep = current.prep.copy(enemyLibrary = current.prep.enemyLibrary.filterNot { it.id == enemyId }))
    }

    @Synchronized
    fun savePreparedEncounter(encounter: PreparedEncounter) = mutate("Prepared encounter saved") { current ->
        val withoutOld = current.prep.preparedEncounters.filterNot { it.id == encounter.id }
        current.copy(prep = current.prep.copy(preparedEncounters = withoutOld + encounter))
    }

    @Synchronized
    fun deletePreparedEncounter(encounterId: String) = mutate("Prepared encounter removed") { current ->
        current.copy(prep = current.prep.copy(preparedEncounters = current.prep.preparedEncounters.filterNot { it.id == encounterId }))
    }

    @Synchronized
    fun updateScene(sceneName: String) = mutate("Scene changed") {
        it.copy(sceneName = sceneName.trim().ifBlank { "Unnamed Scene" })
    }

    @Synchronized
    fun startQuickEncounter(name: String = "Quick Encounter") = mutate("Encounter started", logEncounter = true) { current ->
        val resetPcs = current.pcs.map { resetEncounterAbilityUses(it.copy(actionEconomy = ActionEconomy(), selectedTargetId = null)) }
        val resetState = current.copy(pcs = resetPcs)
        resetState.copy(encounter = newEncounter(resetState, name.trim().ifBlank { "Quick Encounter" }, emptyList()))
    }

    @Synchronized
    fun startPreparedEncounter(preparedId: String) {
        val prepared = _state.value.prep.preparedEncounters.firstOrNull { it.id == preparedId } ?: return
        mutate("Encounter started: ${prepared.name}", logEncounter = true) { current ->
            val resetPcs = current.pcs.map { resetEncounterAbilityUses(it.copy(actionEconomy = ActionEconomy(), selectedTargetId = null)) }
            val resetState = current.copy(pcs = resetPcs)
            resetState.copy(encounter = newEncounter(resetState, prepared.name, prepared.enemies, prepared.gmNotes, prepared.startingNotes))
        }
    }

    @Synchronized
    fun clearEncounter() = mutate("Encounter cleared") { it.copy(encounter = null) }

    @Synchronized
    fun addQuickEnemy(
        name: String,
        maxHp: Int,
        level: Int? = null,
        initiativeModifier: Int = 0,
        quantity: Int = 1,
        gmNote: String = "",
        armorClass: Int? = null,
        fortitude: Int? = null,
        reflex: Int? = null,
        will: Int? = null,
    ) {
        val cleanName = name.trim().ifBlank { "Enemy" }.take(50)
        val qty = quantity.coerceIn(1, 20)
        mutate("Added $cleanName ×$qty", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val group = UUID.randomUUID().toString()
            val additions = (1..qty).map { index ->
                Combatant(
                    name = if (qty == 1) cleanName else "$cleanName $index",
                    kind = "enemy",
                    level = level,
                    initiativeModifier = initiativeModifier,
                    hp = maxHp.coerceAtLeast(1),
                    maxHp = maxHp.coerceAtLeast(1),
                    armorClass = armorClass,
                    fortitude = fortitude,
                    reflex = reflex,
                    will = will,
                    gmNote = gmNote,
                    groupKey = group,
                )
            }
            current.copy(encounter = encounter.copy(combatants = encounter.combatants + additions))
        }
    }

    @Synchronized
    fun addEnemyFromLibrary(enemyId: String, quantity: Int = 1) {
        val enemy = _state.value.prep.enemyLibrary.firstOrNull { it.id == enemyId } ?: return
        addQuickEnemy(enemy.name, enemy.maxHp, enemy.level, enemy.initiativeModifier, quantity, enemy.gmNotes, enemy.armorClass, enemy.fortitude, enemy.reflex, enemy.will)
    }

    @Synchronized
    fun setInitiative(combatantId: String, value: Int, source: String = "GM") {
        mutate("Initiative set", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val changed = encounter.combatants.map {
                if (it.id == combatantId) it.copy(initiative = value, initiativeSource = source) else it
            }
            val sorted = stableInitiativeSort(changed)
            val newIndex = currentId?.let { id -> sorted.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
            current.copy(encounter = encounter.copy(combatants = sorted, turnIndex = newIndex.coerceAtLeast(0)))
        }
    }

    @Synchronized
    fun rollInitiative(combatantId: String) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val result = Random.nextInt(1, 21) + combatant.initiativeModifier
        setInitiative(combatantId, result, "Digital roll")
    }

    @Synchronized
    fun setGroupInitiative(groupKey: String, value: Int, source: String = "GM group") {
        mutate("Group initiative set", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val changed = encounter.combatants.map {
                if (it.groupKey == groupKey) it.copy(initiative = value, initiativeSource = source) else it
            }
            val sorted = stableInitiativeSort(changed)
            val newIndex = currentId?.let { id -> sorted.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
            current.copy(encounter = encounter.copy(combatants = sorted, turnIndex = newIndex.coerceAtLeast(0)))
        }
    }

    @Synchronized
    fun rollGroupInitiative(groupKey: String) {
        val group = _state.value.encounter?.combatants?.filter { it.groupKey == groupKey }.orEmpty()
        val first = group.firstOrNull() ?: return
        val result = Random.nextInt(1, 21) + first.initiativeModifier
        setGroupInitiative(groupKey, result, "Digital group roll")
    }

    @Synchronized
    fun submitPlayerInitiative(pcId: String, value: Int, source: String) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.pcId == pcId } ?: return
        setInitiative(combatant.id, value, source)
    }

    @Synchronized
    fun moveCombatant(combatantId: String, delta: Int) {
        mutate("Initiative order adjusted", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val oldIndex = encounter.combatants.indexOfFirst { it.id == combatantId }
            if (oldIndex < 0) return@mutate current
            val newIndex = (oldIndex + delta).coerceIn(0, encounter.combatants.lastIndex.coerceAtLeast(0))
            if (newIndex == oldIndex) return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val mutable = encounter.combatants.toMutableList()
            val item = mutable.removeAt(oldIndex)
            mutable.add(newIndex, item)
            val turn = currentId?.let { id -> mutable.indexOfFirst { it.id == id } }?.takeIf { it >= 0 } ?: 0
            current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = turn))
        }
    }

    @Synchronized
    fun nextTurn() {
        val snapshot = _state.value
        val encounter = snapshot.encounter ?: return
        if (!encounter.active || encounter.combatants.isEmpty()) return
        if (encounter.combatants.any { it.initiative == null }) return
        if (encounter.pendingEffectChecks.isNotEmpty()) return
        val currentActor = encounter.currentCombatant() ?: return
        if (encounter.ruleRequests.any { it.status == RuleRequestStatus.PENDING && it.actorPcId != null && it.actorPcId == currentActor.pcId }) return
        val currentName = currentActor.name

        mutate("Turn ended: $currentName", logEncounter = true) { current ->
            val activeEncounter = current.encounter ?: return@mutate current
            val actor = activeEncounter.currentCombatant() ?: return@mutate current

            val endProcessed = processEffectPhase(
                pcs = current.pcs,
                encounter = activeEncounter,
                actorId = actor.id,
                phase = EffectPhase.END,
            )

            if (endProcessed.encounter.pendingEffectChecks.isNotEmpty()) {
                return@mutate current.copy(
                    pcs = endProcessed.pcs,
                    encounter = endProcessed.encounter.copy(pendingTurnAdvance = true),
                )
            }

            val advanced = advanceEncounterTurn(current.copy(pcs = endProcessed.pcs), endProcessed.encounter)
            advanced
        }
    }

    @Synchronized
    fun previousTurn() = mutate("Previous turn", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.combatants.isEmpty()) return@mutate current
        val wraps = encounter.turnIndex <= 0
        current.copy(encounter = encounter.copy(
            turnIndex = if (wraps) encounter.combatants.lastIndex else encounter.turnIndex - 1,
            round = if (wraps) (encounter.round - 1).coerceAtLeast(1) else encounter.round,
        ))
    }

    @Synchronized
    fun delayCurrent() {
        val name = _state.value.encounter?.currentCombatant()?.name ?: return
        mutate("$name delayed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            if (encounter.combatants.size < 2) return@mutate current
            val index = encounter.turnIndex.coerceIn(0, encounter.combatants.lastIndex)
            val mutable = encounter.combatants.toMutableList()
            val delayed = mutable.removeAt(index).copy(delayed = true)
            mutable.add(delayed)
            val nextIndex = index.coerceAtMost(mutable.lastIndex)
            current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = nextIndex))
        }
    }

    @Synchronized
    fun resumeDelayed(combatantId: String) = mutate("Delayed combatant resumed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val oldIndex = encounter.combatants.indexOfFirst { it.id == combatantId && it.delayed }
        if (oldIndex < 0) return@mutate current
        val mutable = encounter.combatants.toMutableList()
        val combatant = mutable.removeAt(oldIndex).copy(delayed = false)
        val target = encounter.turnIndex.coerceIn(0, mutable.size)
        mutable.add(target, combatant)
        current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = target))
    }

    @Synchronized
    fun setReadyDetails(combatantId: String, action: String, trigger: String) = mutate("Ready action set", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId) it.copy(readyAction = action.trim().take(120), readyTrigger = trigger.trim().take(120)) else it
        }))
    }

    @Synchronized
    fun clearReadyDetails(combatantId: String) = mutate("Ready action cleared", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId) it.copy(readyAction = "", readyTrigger = "") else it
        }))
    }

    @Synchronized
    fun combatantHpDelta(combatantId: String, delta: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        if (combatant.pcId != null) {
            hpDelta(combatant.pcId, delta)
            return
        }
        val label = if (delta < 0) "${combatant.name} took ${-delta} damage" else "${combatant.name} healed $delta"
        mutate(label, logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val next = encounter.combatants.map { c ->
                if (c.id != combatantId) return@map c
                var remaining = delta
                var temp = c.tempHp
                var hp = c.hp
                if (remaining < 0 && temp > 0) {
                    val absorbed = minOf(temp, -remaining)
                    temp -= absorbed
                    remaining += absorbed
                }
                hp = (hp + remaining).coerceIn(0, c.maxHp.coerceAtLeast(1))
                c.copy(hp = hp, tempHp = temp, defeated = hp <= 0)
            }
            current.copy(encounter = encounter.copy(combatants = next))
        }
    }

    @Synchronized
    fun combatantTempHpDelta(combatantId: String, delta: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        if (combatant.pcId != null) {
            tempHpDelta(combatant.pcId, delta)
            return
        }
        mutate("Temp HP: ${combatant.name}", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
                if (it.id == combatantId) it.copy(tempHp = (it.tempHp + delta).coerceAtLeast(0)) else it
            }))
        }
    }

    @Synchronized
    fun addCombatantEffect(
        combatantId: String,
        presetName: String,
        sourceCombatantId: String? = null,
        partyInflicted: Boolean = false,
        valueOverride: Int? = null,
    ) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val cleanName = presetName.trim().take(40)
        if (cleanName.isBlank()) return
        val effect = conditionFromPreset(
            name = cleanName,
            sourceCombatantId = sourceCombatantId ?: _state.value.encounter?.currentCombatant()?.id,
            publicToPlayers = combatant.kind == "pc" || partyInflicted || cleanName in obviousEnemyConditions,
            partyInflicted = partyInflicted,
            valueOverride = valueOverride,
        )
        addEffectToCombatant(combatantId, effect)
    }

    @Synchronized
    fun addCustomEffect(
        combatantId: String,
        name: String,
        value: Int?,
        sourceCombatantId: String?,
        partyInflicted: Boolean,
        timingAnchor: String,
        timingPhase: String,
        remainingTriggers: Int?,
        triggerAction: String,
        checkType: String?,
        checkLabel: String,
        checkDc: Int?,
        successAction: String,
        failureAction: String,
        criticalSuccessAction: String,
        criticalFailureAction: String,
        repeatCheck: Boolean,
    ) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val cleanName = name.trim().take(60)
        if (cleanName.isBlank()) return
        val effect = Condition(
            name = cleanName,
            value = value?.coerceAtLeast(0)?.takeIf { it > 0 },
            publicToPlayers = combatant.kind == "pc" || partyInflicted || cleanName in obviousEnemyConditions,
            partyInflicted = partyInflicted,
            sourceCombatantId = sourceCombatantId,
            timingAnchor = timingAnchor,
            timingPhase = timingPhase,
            remainingTriggers = remainingTriggers?.coerceAtLeast(1),
            triggerAction = triggerAction,
            checkType = checkType,
            checkLabel = checkLabel.trim().take(160),
            checkDc = checkDc?.coerceIn(1, 99),
            checkSuccessAction = successAction,
            checkFailureAction = failureAction,
            checkCriticalSuccessAction = criticalSuccessAction,
            checkCriticalFailureAction = criticalFailureAction,
            repeatCheck = repeatCheck,
        )
        addEffectToCombatant(combatantId, effect)
    }

    @Synchronized
    fun removeCombatantEffect(combatantId: String, effectId: String) {
        mutate("Effect removed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id == combatantId) c.copy(conditions = c.conditions.filterNot { it.id == effectId }) else c
            }
            val cleanedEncounter = encounter.copy(
                combatants = updatedCombatants,
                pendingEffectChecks = encounter.pendingEffectChecks.filterNot { it.effectId == effectId },
            )
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = cleanedEncounter,
            )
        }
    }

    @Synchronized
    fun setCombatantEffectValue(combatantId: String, effectId: String, value: Int) {
        mutate("Effect value changed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id != combatantId) c else c.copy(
                    conditions = if (value <= 0) c.conditions.filterNot { it.id == effectId }
                    else c.conditions.map { effect -> if (effect.id == effectId) effect.copy(value = value) else effect }
                )
            }
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = encounter.copy(
                    combatants = updatedCombatants,
                    pendingEffectChecks = if (value <= 0) encounter.pendingEffectChecks.filterNot { it.effectId == effectId } else encounter.pendingEffectChecks,
                ),
            )
        }
    }

    @Synchronized
    fun toggleCombatantCondition(combatantId: String, name: String, partyInflicted: Boolean = false) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val existing = combatant.conditions.firstOrNull { it.name.equals(name.trim(), true) }
        if (existing != null) removeCombatantEffect(combatantId, existing.id)
        else addCombatantEffect(combatantId, name, partyInflicted = partyInflicted)
    }

    @Synchronized
    fun setCombatantConditionValue(combatantId: String, name: String, value: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val existing = combatant.conditions.firstOrNull { it.name.equals(name, true) }
        if (existing != null) setCombatantEffectValue(combatantId, existing.id, value)
        else if (value > 0) addCombatantEffect(combatantId, name, valueOverride = value)
    }

    @Synchronized
    fun setDefeated(combatantId: String, defeated: Boolean) = mutate(if (defeated) "Combatant defeated" else "Combatant restored", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId && it.kind != "pc") it.copy(defeated = defeated) else it
        }))
    }

    @Synchronized
    fun requestEndTurn(pcId: String) = mutate("End turn requested", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (pcId in encounter.endTurnRequests) current
        else current.copy(encounter = encounter.copy(endTurnRequests = encounter.endTurnRequests + pcId))
    }

    @Synchronized
    fun dismissEndTurnRequest(pcId: String) = mutate("End turn request dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(endTurnRequests = encounter.endTurnRequests.filterNot { it == pcId }))
    }

    @Synchronized
    fun approveEndTurnRequest(pcId: String) {
        val encounter = _state.value.encounter ?: return
        if (encounter.currentCombatant()?.pcId != pcId) {
            dismissEndTurnRequest(pcId)
            return
        }
        dismissEndTurnRequest(pcId)
        nextTurn()
    }

    @Synchronized
    fun dismissEffectCheck(promptId: String) = mutate("Effect check dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val remaining = encounter.pendingEffectChecks.filterNot { it.id == promptId }
        val updated = encounter.copy(pendingEffectChecks = remaining)
        if (remaining.isEmpty() && encounter.pendingTurnAdvance) {
            advanceEncounterTurn(current, updated.copy(pendingTurnAdvance = false))
        } else {
            current.copy(encounter = updated)
        }
    }

    @Synchronized
    fun resolveEffectCheck(promptId: String, outcome: String) = mutate("Effect check resolved", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val prompt = encounter.pendingEffectChecks.firstOrNull { it.id == promptId } ?: return@mutate current
        val action = when (outcome) {
            "criticalSuccess" -> prompt.criticalSuccessAction
            "success" -> prompt.successAction
            "criticalFailure" -> prompt.criticalFailureAction
            else -> prompt.failureAction
        }

        var updatedCombatants = encounter.combatants.map { combatant ->
            if (combatant.id != prompt.targetCombatantId) return@map combatant
            val effect = combatant.conditions.firstOrNull { it.id == prompt.effectId } ?: return@map combatant
            var nextEffect = applyOutcomeToEffect(effect, action)

            // Check-triggered effects can also have a finite number of trigger windows.
            val remainingTriggerCount = nextEffect?.remainingTriggers
            if (nextEffect != null && remainingTriggerCount != null) {
                nextEffect = if (remainingTriggerCount <= 1) null
                else nextEffect.copy(remainingTriggers = remainingTriggerCount - 1)
            }

            var nextConditions = if (nextEffect == null) {
                combatant.conditions.filterNot { it.id == effect.id }
            } else {
                combatant.conditions.map { if (it.id == effect.id) nextEffect else it }
            }

            // Stabilizing from Dying increases Wounded. Keep this GM-overridable via Undo.
            if (effect.name.equals("Dying", true) && nextEffect == null && combatant.pcId != null) {
                val wounded = nextConditions.firstOrNull { it.name.equals("Wounded", true) }
                nextConditions = if (wounded == null) {
                    nextConditions + conditionFromPreset(
                        name = "Wounded",
                        sourceCombatantId = effect.sourceCombatantId,
                        publicToPlayers = true,
                        partyInflicted = false,
                        valueOverride = 1,
                    )
                } else {
                    nextConditions.map { condition ->
                        if (condition.id == wounded.id) condition.copy(value = (condition.value ?: 0) + 1) else condition
                    }
                }
            }

            combatant.copy(conditions = nextConditions)
        }

        if (!prompt.repeatCheck) {
            updatedCombatants = updatedCombatants.map { combatant ->
                if (combatant.id != prompt.targetCombatantId) combatant else combatant.copy(
                    conditions = combatant.conditions.map { effect ->
                        if (effect.id == prompt.effectId) effect.copy(triggerAction = EffectTriggerAction.NONE, timingPhase = EffectPhase.MANUAL)
                        else effect
                    }
                )
            }
        }

        val remaining = encounter.pendingEffectChecks.filterNot { it.id == promptId }
        val baseEncounter = encounter.copy(
            combatants = updatedCombatants,
            pendingEffectChecks = remaining,
        )
        val baseState = current.copy(
            pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
            encounter = baseEncounter,
        )
        if (remaining.isEmpty() && encounter.pendingTurnAdvance) {
            advanceEncounterTurn(baseState, baseEncounter.copy(pendingTurnAdvance = false))
        } else baseState
    }

    @Synchronized
    fun recordPlayerRoll(pcId: String, label: String, result: Int) {
        val name = _state.value.pcs.firstOrNull { it.id == pcId }?.name ?: "Player"
        mutate("$name rolled $label: $result", logEncounter = _state.value.encounter != null) { it }
    }

    @Synchronized
    fun endEncounter() = mutate("Encounter ended • loot draft generated", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val loot = if (encounter.loot.generatedAt == null) LootGenerator.generate(encounter) else encounter.loot
        current.copy(encounter = encounter.copy(active = false, ended = true, loot = loot))
    }

    @Synchronized
    fun generateLoot() = mutate("Loot generated", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = LootGenerator.generate(encounter)))
    }

    @Synchronized
    fun revealLoot() = mutate("Loot revealed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = encounter.loot.copy(revealed = true)))
    }

    @Synchronized
    fun addEncounterLootItem(name: String, category: String = "Treasure", valueGp: Double = 0.0) {
        val clean = name.trim().take(80)
        if (clean.isBlank()) return
        mutate("Loot item added", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(loot = encounter.loot.copy(
                items = encounter.loot.items + LootItem(name = clean, category = category, valueGp = valueGp),
            )))
        }
    }

    @Synchronized
    fun removeEncounterLootItem(itemId: String) = mutate("Loot item removed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = encounter.loot.copy(
            items = encounter.loot.items.filterNot { it.id == itemId },
        )))
    }

    @Synchronized
    fun moveLootToParty() = mutate("Loot moved to party", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.loot.movedToParty) return@mutate current
        val coinItem = if (encounter.loot.coinsGp > 0) {
            listOf(LootItem(name = "${formatGp(encounter.loot.coinsGp)} gp", category = "Coins", valueGp = encounter.loot.coinsGp))
        } else emptyList()
        current.copy(
            partyLoot = current.partyLoot + coinItem + encounter.loot.items,
            encounter = encounter.copy(loot = encounter.loot.copy(movedToParty = true)),
        )
    }

    @Synchronized
    fun assignPartyLoot(itemId: String, pcId: String?) = mutate("Party loot assigned") { current ->
        current.copy(partyLoot = current.partyLoot.map {
            if (it.id == itemId) it.copy(assignedToPcId = pcId) else it
        })
    }

    @Synchronized
    fun removePartyLoot(itemId: String) = mutate("Party loot removed") { current ->
        current.copy(partyLoot = current.partyLoot.filterNot { it.id == itemId })
    }

    @Synchronized
    fun applyPlayerRequest(requestId: String, block: () -> Unit): Boolean {
        if (requestId.isBlank() || requestId in processedRequestIds) return false
        processedRequestIds += requestId
        while (processedRequestIds.size > 500) {
            val first = processedRequestIds.firstOrNull() ?: break
            processedRequestIds.remove(first)
        }
        block()
        return true
    }

    @Synchronized
    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        val previous = undoStack.removeLast()
        val restoredBase = previous.state
        val restoredEncounter = restoredBase.encounter?.let { encounter ->
            encounter.copy(history = (encounter.history + CombatLogEntry(label = "Undo: ${previous.label}")).takeLast(250))
        }
        val restored = restoredBase.copy(
            encounter = restoredEncounter,
            revision = _state.value.revision + 1,
            lastEventLabel = "Undo: ${previous.label}",
        )
        _state.value = restored
        persist(restored)
        return true
    }

    fun canUndo(): Boolean = synchronized(this) { undoStack.isNotEmpty() }

    fun publicLobbyJson(): String {
        val current = _state.value
        return JSONObject().apply {
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("revision", current.revision)
            put("pcs", JSONArray().apply {
                current.pcs.forEach { pc ->
                    put(JSONObject().apply {
                        put("id", pc.id)
                        put("name", pc.name)
                        put("ancestry", pc.ancestry)
                        put("heritage", pc.heritage)
                        put("background", pc.background)
                        put("characterClass", pc.characterClass)
                        put("level", pc.level ?: JSONObject.NULL)
                    })
                }
            })
        }.toString()
    }

    fun playerSnapshotJson(pcId: String): String {
        val current = _state.value
        val ownPc = current.pcs.firstOrNull { it.id == pcId }
        return JSONObject().apply {
            put("type", "snapshot")
            put("revision", current.revision)
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("lastEventLabel", current.lastEventLabel ?: JSONObject.NULL)
            put("you", ownPc?.toPublicJson() ?: JSONObject.NULL)
            put("inventory", JSONArray().apply { current.partyLoot.filter { it.assignedToPcId == pcId }.forEach { item -> put(item.toPlayerJson()) } })
            put("sharedLoot", JSONArray().apply { current.partyLoot.filter { it.assignedToPcId == null }.forEach { item -> put(item.toPlayerJson()) } })
            put("party", JSONArray().apply { current.pcs.forEach { put(it.toPartyJson()) } })
            put("encounter", current.encounter?.toPlayerJson(pcId) ?: JSONObject.NULL)
        }.toString()
    }

    fun exportBackup(): File {
        val stamp = System.currentTimeMillis()
        val file = File(backupDir, "tt-helper-$stamp.json")
        file.writeText(SessionCodec.encode(_state.value))
        return file
    }

    fun listBackups(): List<File> = backupDir.listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()

    @Synchronized
    fun restoreBackup(file: File): Boolean = runCatching {
        val restored = SessionCodec.decode(file.readText()).copy(
            revision = _state.value.revision + 1,
            lastEventLabel = "Backup restored",
        )
        undoStack.addLast(StateSnapshot(_state.value, "Restore backup"))
        _state.value = restored
        persist(restored)
        true
    }.getOrDefault(false)

    private data class EffectProcessingResult(
        val pcs: List<PlayerCharacter>,
        val encounter: EncounterState,
    )

    private fun saveRequest(pc: PlayerCharacter, spellName: String, target: Combatant, saveName: String, modifier: Int?): RuleRequest = RuleRequest(
        actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name,
        type = RuleRequestType.SAVE, label = "$spellName • $saveName save",
        modifier = modifier, dc = pc.spellcasting.spellDc.takeIf { it > 0 }, dcLabel = "Spell DC",
        notes = if (modifier == null) "$saveName modifier is not entered; resolve manually." else "$saveName modifier ${signed(modifier)}",
    )

    private fun mapPenalty(attacksThisTurn: Int, agile: Boolean): Int = when {
        attacksThisTurn <= 0 -> 0
        attacksThisTurn == 1 -> if (agile) -4 else -5
        else -> if (agile) -8 else -10
    }

    private fun signed(value: Int): String = if (value >= 0) "+$value" else value.toString()

    private fun degreeOfSuccess(total: Int, dc: Int, natural: Int): String {
        val base = when {
            total >= dc + 10 -> 3
            total >= dc -> 2
            total <= dc - 10 -> 0
            else -> 1
        }
        val shifted = (base + when (natural) { 20 -> 1; 1 -> -1; else -> 0 }).coerceIn(0, 3)
        return when (shifted) {
            3 -> DegreeOfSuccess.CRITICAL_SUCCESS
            2 -> DegreeOfSuccess.SUCCESS
            1 -> DegreeOfSuccess.FAILURE
            else -> DegreeOfSuccess.CRITICAL_FAILURE
        }
    }

    private fun addRuleRequest(existing: List<RuleRequest>, request: RuleRequest): List<RuleRequest> = (existing + request).takeLast(80)

    private fun conditionFromPreset(
        name: String,
        sourceCombatantId: String?,
        publicToPlayers: Boolean,
        partyInflicted: Boolean,
        valueOverride: Int? = null,
    ): Condition {
        val preset: EffectPreset? = effectPresets.firstOrNull { it.name.equals(name, true) }
        return Condition(
            name = name,
            value = valueOverride ?: preset?.defaultValue,
            publicToPlayers = publicToPlayers,
            partyInflicted = partyInflicted,
            sourceCombatantId = sourceCombatantId,
            timingAnchor = preset?.timingAnchor ?: EffectAnchor.TARGET,
            timingPhase = preset?.timingPhase ?: EffectPhase.MANUAL,
            triggerAction = preset?.triggerAction ?: EffectTriggerAction.NONE,
            checkType = preset?.checkType,
            checkLabel = preset?.checkLabel.orEmpty(),
            checkDc = preset?.checkDc,
            checkSuccessAction = preset?.successAction ?: EffectOutcomeAction.REMOVE,
            checkFailureAction = preset?.failureAction ?: EffectOutcomeAction.KEEP,
            checkCriticalSuccessAction = preset?.criticalSuccessAction ?: EffectOutcomeAction.REMOVE,
            checkCriticalFailureAction = preset?.criticalFailureAction ?: EffectOutcomeAction.KEEP,
        )
    }

    private fun addEffectToCombatant(combatantId: String, effect: Condition) {
        mutate("Effect added: ${effect.name}", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id != combatantId) c else c.copy(
                    conditions = c.conditions.filterNot { it.name.equals(effect.name, true) } + effect
                )
            }
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = encounter.copy(combatants = updatedCombatants),
            )
        }
    }

    private fun applyOutcomeToEffect(effect: Condition, action: String): Condition? = when (action) {
        EffectOutcomeAction.REMOVE -> null
        EffectOutcomeAction.DECREMENT -> effect.value?.let { next ->
            if (next - 1 <= 0) null else effect.copy(value = next - 1)
        } ?: effect
        EffectOutcomeAction.DECREMENT_2 -> effect.value?.let { next ->
            if (next - 2 <= 0) null else effect.copy(value = next - 2)
        } ?: effect
        EffectOutcomeAction.INCREMENT -> effect.copy(value = (effect.value ?: 0) + 1)
        EffectOutcomeAction.INCREMENT_2 -> effect.copy(value = (effect.value ?: 0) + 2)
        else -> effect
    }

    private fun processEffectPhase(
        pcs: List<PlayerCharacter>,
        encounter: EncounterState,
        actorId: String,
        phase: String,
    ): EffectProcessingResult {
        val prompts = encounter.pendingEffectChecks.toMutableList()
        val updatedCombatants = encounter.combatants.map { target ->
            val nextConditions = target.conditions.mapNotNull { effect ->
                val matchesActor = when (effect.timingAnchor) {
                    EffectAnchor.SOURCE -> effect.sourceCombatantId == actorId
                    else -> target.id == actorId
                }
                if (effect.timingPhase != phase || !matchesActor) return@mapNotNull effect

                var next: Condition? = when (effect.triggerAction) {
                    EffectTriggerAction.REMOVE -> null
                    EffectTriggerAction.DECREMENT_VALUE -> {
                        val value = effect.value ?: 1
                        if (value - 1 <= 0) null else effect.copy(value = value - 1)
                    }
                    EffectTriggerAction.CHECK -> {
                        if (prompts.none { it.effectId == effect.id }) {
                            val dynamicDc = if (effect.name.equals("Dying", true) && effect.value != null) {
                                10 + effect.value
                            } else effect.checkDc
                            prompts += EffectCheckPrompt(
                                effectId = effect.id,
                                targetCombatantId = target.id,
                                targetName = target.name,
                                effectName = effect.name,
                                checkType = effect.checkType ?: "Custom roll",
                                checkLabel = effect.checkLabel,
                                dc = dynamicDc,
                                timingText = effectTimingText(effect, target, encounter),
                                successAction = effect.checkSuccessAction,
                                failureAction = effect.checkFailureAction,
                                criticalSuccessAction = effect.checkCriticalSuccessAction,
                                criticalFailureAction = effect.checkCriticalFailureAction,
                                repeatCheck = effect.repeatCheck,
                            )
                        }
                        effect
                    }
                    else -> effect
                }

                val remainingTriggerCount = next?.remainingTriggers
                if (next != null && effect.triggerAction != EffectTriggerAction.CHECK && remainingTriggerCount != null) {
                    next = if (remainingTriggerCount <= 1) null else next.copy(remainingTriggers = remainingTriggerCount - 1)
                }
                next
            }
            target.copy(conditions = nextConditions)
        }
        return EffectProcessingResult(
            pcs = syncPcsFromCombatants(pcs, updatedCombatants),
            encounter = encounter.copy(
                combatants = updatedCombatants,
                pendingEffectChecks = prompts,
            ),
        )
    }

    private fun advanceEncounterTurn(state: SessionState, encounter: EncounterState): SessionState {
        if (encounter.combatants.isEmpty()) return state.copy(encounter = encounter)
        val oldCurrent = encounter.currentCombatant()
        val wraps = encounter.turnIndex >= encounter.combatants.lastIndex
        val nextIndex = if (wraps) 0 else encounter.turnIndex + 1
        val nextRound = if (wraps) encounter.round + 1 else encounter.round
        var moved = encounter.copy(
            turnIndex = nextIndex,
            round = nextRound,
            pendingTurnAdvance = false,
            endTurnRequests = encounter.endTurnRequests.filterNot { it == oldCurrent?.pcId },
        )
        val nextActor = moved.currentCombatant()
        if (nextActor != null) {
            val startProcessed = processEffectPhase(state.pcs, moved, nextActor.id, EffectPhase.START)
            moved = startProcessed.encounter
            val nextPcs = if (nextActor.pcId != null) {
                startProcessed.pcs.map { pc ->
                    if (pc.id == nextActor.pcId) resetTurnAbilityUses(pc.copy(actionEconomy = ActionEconomy())) else pc
                }
            } else startProcessed.pcs
            return state.copy(pcs = nextPcs, encounter = moved)
        }
        return state.copy(encounter = moved)
    }

    private fun effectTimingText(effect: Condition, target: Combatant, encounter: EncounterState): String {
        val phaseText = when (effect.timingPhase) {
            EffectPhase.START -> "start"
            EffectPhase.END -> "end"
            else -> "manual timing"
        }
        if (effect.timingPhase == EffectPhase.MANUAL) return "Manual timing"
        val anchorName = if (effect.timingAnchor == EffectAnchor.SOURCE) {
            encounter.combatants.firstOrNull { it.id == effect.sourceCombatantId }?.name ?: "source"
        } else target.name
        return "$phaseText of $anchorName's turn"
    }

    private fun syncPcsFromCombatants(
        pcs: List<PlayerCharacter>,
        combatants: List<Combatant>,
    ): List<PlayerCharacter> = pcs.map { pc ->
        val combatant = combatants.firstOrNull { it.pcId == pc.id }
        if (combatant == null) pc else pc.copy(conditions = combatant.conditions)
    }

    private fun mutate(label: String, logEncounter: Boolean = false, transform: (SessionState) -> SessionState) {
        val before = _state.value
        undoStack.addLast(StateSnapshot(before, label))
        while (undoStack.size > 100) undoStack.removeFirst()
        var after = transform(before)
        val encounterAfter = after.encounter
        if (logEncounter && encounterAfter != null) {
            after = after.copy(encounter = encounterAfter.copy(
                history = (encounterAfter.history + CombatLogEntry(label = label)).takeLast(250),
            ))
        }
        after = after.copy(revision = before.revision + 1, lastEventLabel = label)
        _state.value = after
        persist(after)
    }

    private fun loadOrDefault(): SessionState = runCatching {
        if (sessionFile.exists()) SessionCodec.decode(sessionFile.readText()) else SessionState()
    }.getOrElse { SessionState() }

    private fun persist(state: SessionState) {
        val temp = File(sessionFile.parentFile, "${sessionFile.name}.tmp")
        temp.writeText(SessionCodec.encode(state))
        if (!temp.renameTo(sessionFile)) {
            sessionFile.writeText(temp.readText())
            temp.delete()
        }
    }

    private fun newEncounter(
        current: SessionState,
        name: String,
        enemies: List<PreparedEnemy>,
        gmNote: String = "",
        startingNotes: String = "",
    ): EncounterState {
        val pcs = current.pcs.map { pc ->
            Combatant(
                id = "pc-${pc.id}",
                name = pc.name,
                kind = "pc",
                pcId = pc.id,
                level = pc.level,
                hp = pc.hp,
                maxHp = pc.maxHp,
                tempHp = pc.tempHp,
                conditions = pc.conditions,
                gmNote = pc.gmNote,
                publicNote = pc.publicNote,
            )
        }
        val enemyCombatants = enemies.flatMap { enemy ->
            val qty = enemy.quantity.coerceIn(1, 20)
            val group = enemy.id.ifBlank { UUID.randomUUID().toString() }
            (1..qty).map { index ->
                Combatant(
                    name = if (qty == 1) enemy.name else "${enemy.name} $index",
                    kind = "enemy",
                    level = enemy.level,
                    initiativeModifier = enemy.initiativeModifier,
                    hp = enemy.maxHp.coerceAtLeast(1),
                    maxHp = enemy.maxHp.coerceAtLeast(1),
                    armorClass = enemy.armorClass,
                    fortitude = enemy.fortitude,
                    reflex = enemy.reflex,
                    will = enemy.will,
                    gmNote = listOf(gmNote, enemy.gmNotes).filter { it.isNotBlank() }.joinToString("\n"),
                    publicNote = enemy.publicNotes,
                    groupKey = group,
                )
            }
        }
        return EncounterState(
            name = name,
            gmNotes = gmNote,
            startingNotes = startingNotes,
            combatants = pcs + enemyCombatants,
        )
    }

    private fun stableInitiativeSort(combatants: List<Combatant>): List<Combatant> = combatants.withIndex()
        .sortedWith(compareByDescending<IndexedValue<Combatant>> { it.value.initiative ?: Int.MIN_VALUE }.thenBy { it.index })
        .map { it.value }

    private fun applyPcHpDelta(beforePc: PlayerCharacter, delta: Int, encounterActive: Boolean): PlayerCharacter {
        var remaining = delta
        var temp = beforePc.tempHp
        var hp = beforePc.hp
        if (remaining < 0 && temp > 0) {
            val absorbed = minOf(temp, -remaining)
            temp -= absorbed
            remaining += absorbed
        }
        hp = (hp + remaining).coerceIn(0, beforePc.maxHp.coerceAtLeast(1))
        var conditions = beforePc.conditions

        if (encounterActive && beforePc.hp > 0 && hp == 0) {
            val wounded = conditions.firstOrNull { it.name.equals("Wounded", true) }?.value ?: 0
            val dyingValue = 1 + wounded
            conditions = conditions.filterNot { it.name.equals("Dying", true) } + Condition("Dying", dyingValue, publicToPlayers = true)
        }
        if (encounterActive && beforePc.hp == 0 && hp > 0 && conditions.any { it.name.equals("Dying", true) }) {
            val wounded = (conditions.firstOrNull { it.name.equals("Wounded", true) }?.value ?: 0) + 1
            conditions = conditions.filterNot { it.name.equals("Dying", true) || it.name.equals("Wounded", true) } +
                Condition("Wounded", wounded, publicToPlayers = true)
        }
        return beforePc.copy(hp = hp, tempHp = temp, conditions = conditions)
    }

    private fun syncPcIntoEncounter(encounter: EncounterState, pc: PlayerCharacter): EncounterState = encounter.copy(
        combatants = encounter.combatants.map { combatant ->
            if (combatant.pcId == pc.id) combatant.copy(
                hp = pc.hp,
                maxHp = pc.maxHp,
                tempHp = pc.tempHp,
                conditions = pc.conditions,
            ) else combatant
        }
    )

    private fun SessionState.updatePc(pcId: String, transform: (PlayerCharacter) -> PlayerCharacter): SessionState =
        copy(pcs = pcs.map { if (it.id == pcId) transform(it) else it })

    private fun PlayerCharacter.toPublicJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("ancestry", ancestry)
        put("heritage", heritage)
        put("background", background)
        put("characterClass", characterClass)
        put("level", level ?: JSONObject.NULL)
        put("hp", hp)
        put("maxHp", maxHp)
        put("tempHp", tempHp)
        put("heroPoints", heroPoints)
        put("ready", ready)
        put("publicNote", publicNote)
        put("actionEconomy", JSONObject().apply {
            put("baseActions", actionEconomy.baseActions)
            put("actionsRemaining", actionEconomy.actionsRemaining)
            put("reactionAvailable", actionEconomy.reactionAvailable)
            put("attacksThisTurn", actionEconomy.attacksThisTurn)
        })
        put("spellcasting", JSONObject().apply {
            put("enabled", spellcasting.enabled)
            put("tradition", spellcasting.tradition)
            put("castingMode", spellcasting.castingMode)
            put("focusPoints", spellcasting.focusPoints)
            put("maxFocusPoints", spellcasting.maxFocusPoints)
            put("spellDc", spellcasting.spellDc)
            put("spellAttackModifier", spellcasting.spellAttackModifier)
            put("slots", JSONArray().apply {
                spellcasting.slots.sortedBy { it.rank }.forEach { slot ->
                    put(JSONObject().apply {
                        put("rank", slot.rank)
                        put("total", slot.total)
                        put("remaining", slot.remaining)
                    })
                }
            })
            put("spells", JSONArray().apply {
                spellcasting.spells.forEach { spell ->
                    put(JSONObject().apply {
                        put("id", spell.id)
                        put("name", spell.name)
                        put("rank", spell.rank)
                        put("actions", spell.actions)
                        put("isCantrip", spell.isCantrip)
                        put("isFocus", spell.isFocus)
                        put("expended", spell.expended)
                        put("notes", spell.notes)
                        put("range", spell.range)
                        put("targets", spell.targets)
                        put("checkOrSave", spell.checkOrSave)
                        put("pinned", spell.pinned)
                    })
                }
            })
        })
        put("abilities", JSONArray().apply {
            abilities.forEach { ability ->
                put(JSONObject().apply {
                    put("id", ability.id); put("name", ability.name); put("category", ability.category); put("actionType", ability.actionType)
                    put("actions", ability.actions); put("usageMode", ability.usageMode); put("maxUses", ability.maxUses); put("remainingUses", ability.remainingUses)
                    put("notes", ability.notes); put("pinned", ability.pinned)
                })
            }
        })
        put("strikes", JSONArray().apply {
            strikes.forEach { strike ->
                put(JSONObject().apply {
                    put("id", strike.id); put("name", strike.name); put("actions", strike.actions); put("attackModifier", strike.attackModifier)
                    put("damage", strike.damage); put("traits", strike.traits); put("notes", strike.notes); put("pinned", strike.pinned)
                })
            }
        })
        put("resources", JSONArray().apply {
            resources.forEach { resource ->
                put(JSONObject().apply {
                    put("id", resource.id); put("name", resource.name); put("current", resource.current); put("max", resource.max); put("notes", resource.notes); put("pinned", resource.pinned)
                })
            }
        })
        put("feats", JSONArray().apply {
            feats.forEach { feat ->
                put(JSONObject().apply {
                    put("id", feat.id); put("name", feat.name); put("type", feat.type); put("level", feat.level ?: JSONObject.NULL)
                    put("traits", feat.traits); put("prerequisites", feat.prerequisites); put("notes", feat.notes)
                })
            }
        })
        put("contentDrafts", JSONArray().apply {
            contentDrafts.forEach { draft ->
                put(JSONObject().apply {
                    put("id", draft.id); put("kind", draft.kind); put("status", draft.status); put("name", draft.name); put("rank", draft.rank); put("actions", draft.actions)
                    put("isCantrip", draft.isCantrip); put("isFocus", draft.isFocus); put("notes", draft.notes); put("range", draft.range); put("targets", draft.targets); put("checkOrSave", draft.checkOrSave); put("abilityCategory", draft.abilityCategory)
                    put("actionType", draft.actionType); put("usageMode", draft.usageMode); put("maxUses", draft.maxUses); put("attackModifier", draft.attackModifier)
                    put("damage", draft.damage); put("traits", draft.traits); put("resourceMax", draft.resourceMax); put("gmFeedback", draft.gmFeedback)
                    put("sourceEntryId", draft.sourceEntryId ?: JSONObject.NULL); put("submittedAt", draft.submittedAt ?: JSONObject.NULL)
                })
            }
        })
        put("selectedTargetId", selectedTargetId ?: JSONObject.NULL)
        put("conditions", JSONArray().apply {
            conditions.forEach { c -> put(c.toJson()) }
        })
    }

    private fun PlayerCharacter.toPartyJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("hp", hp)
        put("maxHp", maxHp)
        put("tempHp", tempHp)
        put("ready", ready)
        put("conditions", JSONArray().apply { conditions.forEach { put(it.toJson()) } })
    }

    private fun Condition.toJson() = JSONObject().apply {
        put("name", name)
        put("value", value ?: JSONObject.NULL)
        put("partyInflicted", partyInflicted)
    }

    private fun LootItem.toPlayerJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("category", category)
        put("quantity", quantity)
        put("valueGp", valueGp)
        put("notes", notes)
    }

    private fun EncounterState.toPlayerJson(pcId: String) = JSONObject().apply {
        val current = currentCombatant()
        val own = combatants.firstOrNull { it.pcId == pcId }
        put("id", id)
        put("name", name)
        put("active", active)
        put("ended", ended)
        put("round", round)
        put("currentCombatantId", current?.id ?: JSONObject.NULL)
        put("currentName", current?.name ?: JSONObject.NULL)
        put("currentIsYou", current?.pcId == pcId)
        put("yourInitiative", own?.initiative ?: JSONObject.NULL)
        put("endTurnRequested", pcId in endTurnRequests)
        put("initiative", JSONArray().apply {
            combatants.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("kind", c.kind)
                    put("isYou", c.pcId == pcId)
                    put("current", c.id == current?.id)
                    put("delayed", c.delayed)
                    put("defeated", c.defeated)
                })
            }
        })
        put("enemies", JSONArray().apply {
            combatants.filter { it.kind != "pc" }.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("health", healthState(c))
                    put("defeated", c.defeated)
                    put("publicNote", c.publicNote)
                    put("conditions", JSONArray().apply {
                        c.conditions.filter { it.publicToPlayers || it.partyInflicted }.forEach { put(it.toJson()) }
                    })
                })
            }
        })
        put("rules", JSONArray().apply {
            ruleRequests.filter { it.actorPcId == pcId }.takeLast(10).forEach { request ->
                put(JSONObject().apply {
                    put("id", request.id)
                    put("type", request.type)
                    put("label", request.label)
                    put("targetName", request.targetName ?: JSONObject.NULL)
                    put("secret", request.secret)
                    put("status", request.status)
                    put("outcome", if (request.secret && request.status == RuleRequestStatus.RESOLVED) JSONObject.NULL else request.outcome ?: JSONObject.NULL)
                    put("roll", if (request.secret) JSONObject.NULL else request.roll ?: JSONObject.NULL)
                    put("modifier", if (request.secret) JSONObject.NULL else request.modifier ?: JSONObject.NULL)
                    put("mapPenalty", request.mapPenalty)
                    put("total", if (request.secret) JSONObject.NULL else request.total ?: JSONObject.NULL)
                    put("canPlayerRoll", request.status == RuleRequestStatus.PENDING && request.type == RuleRequestType.ATTACK && request.total == null && request.modifier != null)
                })
            }
        })
        put("loot", if (loot.revealed) JSONObject().apply {
            put("coinsGp", loot.coinsGp)
            put("items", JSONArray().apply {
                loot.items.forEach { item ->
                    put(JSONObject().apply {
                        put("name", item.name)
                        put("category", item.category)
                        put("quantity", item.quantity)
                        put("notes", item.notes)
                    })
                }
            })
        } else JSONObject.NULL)
    }

    private fun healthState(c: Combatant): String {
        if (c.defeated || c.hp <= 0) return "Defeated"
        val ratio = c.hp.toDouble() / c.maxHp.coerceAtLeast(1).toDouble()
        return when {
            ratio > 0.75 -> "Healthy"
            ratio > 0.50 -> "Hurt"
            ratio > 0.25 -> "Badly Hurt"
            else -> "Near Death"
        }
    }

    private fun formatGp(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
}
