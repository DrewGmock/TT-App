# TT Helper Changelog

## 0.9.0-alpha1

### Stability & recovery
- Added rotating automatic backups with a bounded retention set plus manual Backup Now snapshots.
- Added atomic-ish temp-file validation before primary save replacement and a continuously maintained last-known-good save.
- Added startup recovery from last-known-good or recent backups if the primary save is unreadable.
- Added save-schema version 9 and automatic pre-upgrade backup creation when older campaign data is opened.
- Added full-campaign export/restore with a pre-restore safety backup.
- Added Campaign Health diagnostics and an integrity-check action.
- Added backup listing/preview metadata and confirmed restore from Settings.

### Network/session resilience
- Player assignments and tokens now survive GM app process restarts.
- WebSocket connect/disconnect updates assignment state accurately.
- Player reconnect now uses bounded exponential retry and foreground-resume reconnect.
- Added a short duplicate-tap guard on player actions in addition to host request-id de-duplication.

### Import safety
- Added package-size and entry-count validation.
- Added import warnings for suspicious/invalid names, HP, quantities, and unusually large session content.
- Existing preview/merge/replace/copy workflow remains authoritative.

### Appearance
- Added independent GM accent colors: Blue, Purple, Ember, Orange, Forest, Teal, Gold, and Steel.
- Added the same independent accent options to player browser settings.
- Added per-character accent color stored with campaign data; player party rows show the character accent for faster scanning.

### Version
- versionCode 17
- versionName `0.9.0-alpha1`

## 0.8.0-alpha1

### Table Experience & Customization
- Added GM appearance settings for System/Light/Dark themes, four text-size options, Compact/Comfortable workspace density, high-contrast mode, and a persistent GM quick-bar toggle.
- Added a persistent **GM Quick Bar** with current round/turn, Next Turn, Undo, pending Rules/Approvals/Player-request shortcuts, and one-tap return to Prep.
- Added Live workspace presets on tablets: **Split / Initiative / Focus** during encounters and **Split / Party / Focus** between encounters.
- Made the smaller-screen GM navigation horizontally scrollable so every GM page remains reachable.

### Second-screen / TV mode
- Added a player-safe `/display` page served by the GM tablet for TVs, monitors, or spare browsers on the same Wi-Fi.
- The display shows campaign/scene, active encounter, round/current turn, initiative, public party status, visible enemy health descriptions, and public/party-inflicted conditions.
- Added the second-screen URL to Players and Settings. Hidden HP/defenses, GM notes, hidden loot, and private prep are never included.

### Player customization & reconnect polish
- Added a **More** page to the player client with theme and text-size controls.
- Players can reorder Combat / Character / Inventory / Spells / Builder / More tabs; order persists in that browser.
- Reconnect state now reads **Reconnecting…** instead of immediately showing Offline, and the player header shows the last successful live-sync time.

### Session recap
- Encounter History now generates a concise recap and can copy it to the Android clipboard for campaign notes or chat.

### Carry-forward
- Includes all 0.7.1 collapsible prep, pinned prep, import/export, Session Prep 2.0, rules intelligence, inventory, builder, spellcasting, effect automation, and LAN sync functionality.

### Version
- versionCode 16
- versionName `0.8.0-alpha1`


## 0.7.1-alpha1

### Navigation & Prep Workspace
- Rebuilt the GM tablet sidebar as a vertically scrollable navigation workspace so lower tabs can no longer be clipped off-screen.
- Grouped GM navigation into collapsible **Play**, **Campaign**, and **Prep** sections.
- Added an icon-width collapsed sidebar mode for more workspace on smaller tablets.
- Reworked Session Prep into compact collapsible headers instead of one long page.
- Added separate collapsible sections for Overview, Objectives, Locations, Loot & Rewards, Reference Notes, Encounter Beats, private GM notes, library entries, encounter building, quick rules, and backups.
- Added summary text to collapsed headers so the GM can see what is populated without opening every section.

### Pinned Prep
- Added persistent prep pins saved with the local campaign state.
- Sections, saved encounters, creatures, NPCs, and hazards can be pinned while actively prepping.
- Added a **Pinned Prep** strip at the top of Session Prep with one-tap unpin and Clear All.
- Deleted library/encounter entries automatically clean up their stale pins.
- Prep pins are local workspace state and are intentionally excluded from exported `.ttsession` packages.

### Carry-forward
- Includes all 0.7.0 import/export, Session Prep 2.0, rules intelligence, inventory, player builder, spellcasting, effect automation, and LAN sync functionality.

### Version
- versionCode 15
- versionName `0.7.1-alpha1`

## 0.7.0-alpha1

### Import / Export
- Added a dedicated GM **Import / Export** tab.
- Added versioned `.ttsession` packages for Session Prep, prepared encounters, and the Creature/NPC/Hazard library.
- Added `.ttenemy` and `.ttenemypack` import/export.
- Added `.ttloot` and `.ttlootpack` import/export.
- Added Android document-picker based file import/export; custom package files can be opened/saved without extracting them.
- Added an import preview with package type, content counts, and name-conflict counts.
- Added **Keep Existing**, **Merge**, **Replace**, and **Import as Copies** strategies.
- Added safeguards so package imports do not silently mutate active combat/player state.
- Added single-entry export for enemies and loot plus whole-library/pack export.

### Session Prep save UX
- Added visible Unsaved / Saved / Autosaved state for Session Notes.
- Added short-delay autosave for Session Notes.
- Added visible save confirmations for Creature/NPC/Hazard library entries and encounter templates.
- Added Objectives / Quests, Locations, Reference Notes, and Loot / Reward Suggestions fields to Session Prep.
- Imported session packages can populate the new prep fields.

### Content Library
- Added a compact Content Library summary to the Import / Export tab.
- Session, enemy, and loot packages use the existing TT Helper data model rather than importing the private whole-app save file.
- Added example `.ttsession`, `.ttenemy`, and `.ttloot` files in the repo for reference.

### Carry-forward
- Includes all 0.6 encounter/session-prep functionality.
- Includes the player container-management fix from 0.5.1.

### Version
- versionCode 14
- versionName `0.7.0-alpha1`

## 0.6.0-alpha1
- Added Session Prep 2.0, encounter budgets, Creature/NPC/Hazard library, Weak/Elite, templates, encounter history, and player container-management carry-forward.
