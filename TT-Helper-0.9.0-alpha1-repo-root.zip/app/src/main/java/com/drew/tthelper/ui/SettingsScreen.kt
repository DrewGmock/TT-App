package com.drew.tthelper.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime
import java.text.DateFormat
import java.util.Date

internal data class UiPreferences(
    val themeMode: String = "system",
    val accentColor: String = "blue",
    val fontScale: Float = 1f,
    val densityMode: String = "comfortable",
    val highContrast: Boolean = false,
    val quickBar: Boolean = true,
)

internal fun loadUiPreferences(context: Context): UiPreferences {
    val p = context.getSharedPreferences("tthelper-ui", Context.MODE_PRIVATE)
    return UiPreferences(
        themeMode = p.getString("themeMode", "system") ?: "system",
        accentColor = p.getString("accentColor", "blue") ?: "blue",
        fontScale = p.getFloat("fontScale", 1f),
        densityMode = p.getString("densityMode", "comfortable") ?: "comfortable",
        highContrast = p.getBoolean("highContrast", false),
        quickBar = p.getBoolean("quickBar", true),
    )
}

internal fun saveUiPreferences(context: Context, value: UiPreferences) {
    context.getSharedPreferences("tthelper-ui", Context.MODE_PRIVATE).edit()
        .putString("themeMode", value.themeMode)
        .putString("accentColor", value.accentColor)
        .putFloat("fontScale", value.fontScale)
        .putString("densityMode", value.densityMode)
        .putBoolean("highContrast", value.highContrast)
        .putBoolean("quickBar", value.quickBar)
        .apply()
}

@Composable
internal fun SettingsScreen(
    runtime: HostRuntime,
    preferences: UiPreferences,
    onPreferencesChanged: (UiPreferences) -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val status by runtime.status.collectAsState()
    val session by runtime.store.state.collectAsState()
    var message by remember { mutableStateOf("") }
    var restoreCandidate by remember { mutableStateOf<String?>(null) }
    val diagnostics = runtime.store.diagnostics()
    val backups = runtime.store.backupSummaries().take(8)
    val displayUrl = if (status.running && status.address != null) "http://${status.address}:${status.port}/display" else null

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(runtime.store.fullCampaignJson()) }
                ?: error("Could not create backup file")
        }.onSuccess { message = "Full campaign backup exported ✓" }
            .onFailure { message = "Export failed: ${it.message ?: "unknown error"}" }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Could not open backup")
        }.onSuccess { raw ->
            message = if (runtime.store.restoreFullCampaign(raw)) "Full campaign restored ✓" else "Restore failed. Current campaign was left unchanged."
        }.onFailure { message = "Restore failed: ${it.message ?: "unknown error"}" }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Settings & Diagnostics", fontSize = 26.sp)
        Text("Appearance stays on this device. Campaign safety tools protect the shared GM state.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Appearance", fontSize = 20.sp)
                Text("Theme")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (value, label) ->
                        FilterChip(selected = preferences.themeMode == value, onClick = { onPreferencesChanged(preferences.copy(themeMode = value)) }, label = { Text(label) })
                    }
                }
                Text("Accent color")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("blue" to "Blue", "purple" to "Purple", "red" to "Ember", "orange" to "Orange", "green" to "Forest", "teal" to "Teal", "gold" to "Gold", "steel" to "Steel").forEach { (value, label) ->
                        FilterChip(selected = preferences.accentColor == value, onClick = { onPreferencesChanged(preferences.copy(accentColor = value)) }, label = { Text(label) })
                    }
                }
                Text("Text size")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(.9f to "Small", 1f to "Normal", 1.15f to "Large", 1.3f to "Extra large").forEach { (value, label) ->
                        FilterChip(selected = kotlin.math.abs(preferences.fontScale - value) < .02f, onClick = { onPreferencesChanged(preferences.copy(fontScale = value)) }, label = { Text(label) })
                    }
                }
                Text("Workspace density")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("compact" to "Compact", "comfortable" to "Comfortable").forEach { (value, label) ->
                        FilterChip(selected = preferences.densityMode == value, onClick = { onPreferencesChanged(preferences.copy(densityMode = value)) }, label = { Text(label) })
                    }
                }
                ToggleRow("High contrast", preferences.highContrast) { onPreferencesChanged(preferences.copy(highContrast = it)) }
                ToggleRow("Persistent GM quick bar", preferences.quickBar) { onPreferencesChanged(preferences.copy(quickBar = it)) }
                OutlinedButton(onClick = { onPreferencesChanged(UiPreferences()) }) { Text("Reset display settings") }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Campaign Health", fontSize = 20.sp)
                Text(if (diagnostics.saveHealthy) "Save status: Healthy ✓" else "Save status: Needs attention")
                Text("Revision ${diagnostics.sessionRevision} • Schema ${diagnostics.schemaVersion} • ${session.pcs.size} PCs")
                Text("Last save: ${formatTimestamp(diagnostics.lastPersistAt)}")
                Text("Last backup: ${formatTimestamp(diagnostics.lastBackupAt)} • ${diagnostics.backupCount} rotating backups")
                diagnostics.recoveryMessage?.let { Text("Recovery: $it") }
                diagnostics.lastPersistenceError?.let { Text("Storage warning: $it") }
                if (message.isNotBlank()) Text(message)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { val f = runtime.store.exportBackup(); message = "Backup created: ${f.name}" }) { Text("Backup Now") }
                    OutlinedButton(onClick = { message = if (runtime.store.runIntegrityCheck()) "Integrity check passed ✓" else "Integrity check failed — use a backup before continuing." }) { Text("Run integrity check") }
                    OutlinedButton(onClick = { message = if (runtime.store.recoverLastKnownGood()) "Recovered last known-good save ✓" else "No usable last known-good save found." }) { Text("Recover last good") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Rotating Backups", fontSize = 20.sp)
                Text("TT Helper keeps recent automatic/manual snapshots. Restore always validates the backup first.")
                if (backups.isEmpty()) Text("No rotating backups yet.")
                backups.forEach { b ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(if (b.valid) "${b.campaignName} • rev ${b.revision}" else "Unreadable backup")
                            Text("${formatTimestamp(b.timestamp)} • ${b.fileName}", fontSize = 12.sp)
                            b.encounterName?.let { Text("Encounter: $it", fontSize = 12.sp) }
                        }
                        OutlinedButton(enabled = b.valid, onClick = { restoreCandidate = b.fileName }) { Text("Restore") }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Full Campaign Portability", fontSize = 20.sp)
                Text("Exports PCs, prep, encounter state, inventory, history, drafts, and approvals. Importing creates a safety backup first.")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exportLauncher.launch("TT-Helper-${session.campaignName.replace(Regex("[^A-Za-z0-9_-]"), "-")}-Full-Backup.json") }) { Text("Export full campaign") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("Restore full campaign") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Second-screen / TV mode", fontSize = 20.sp)
                if (displayUrl == null) Text("Start the host to get a player-safe display address.") else {
                    Text(displayUrl)
                    Text("Open this on a device on the same Wi-Fi. GM-only defenses, notes, prep, and hidden loot are filtered out.")
                }
            }
        }
    }

    restoreCandidate?.let { fileName ->
        AlertDialog(
            onDismissRequest = { restoreCandidate = null },
            title = { Text("Restore backup?") },
            text = { Text("This replaces the live campaign state with $fileName. Your current state remains available through Undo and future backups.") },
            confirmButton = {
                Button(onClick = {
                    message = if (runtime.store.restoreBackupByName(fileName)) "Backup restored ✓" else "Backup restore failed."
                    restoreCandidate = null
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { restoreCandidate = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

private fun formatTimestamp(value: Long): String = if (value <= 0L) "Not yet" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(value))
