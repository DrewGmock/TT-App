# TT Helper LAN, Recovery & Display Protocol — 0.9.0-alpha1

The GM Android app remains the authoritative state owner. Players connect through the embedded LAN web client and receive filtered snapshots.

## Persistence and recovery
- The live campaign is persisted to Android private storage after authoritative mutations.
- Save writes use a validated temporary file before primary replacement.
- The previous decodable primary save is retained as a last-known-good copy.
- Rotating backups are created periodically and can also be created manually.
- Campaign save schema is versioned; older decodable saves get a pre-upgrade backup before tolerant migration/defaulting.
- Full-campaign restore validates input and creates a safety backup of the current campaign first.

## Player client and assignment recovery
- `GET /` serves the player application.
- Authenticated state is delivered over `/ws` using a player token.
- Player token, character assignment, display name, and join PIN persist in Android private preferences across GM app process restarts.
- Restored assignments start Offline and become Connected only after an authenticated WebSocket opens.
- Browser tokens remain in localStorage so refreshes and short host restarts can resume the same assignment.
- Cached snapshots remain visible during reconnect; retries back off up to 15 seconds and foregrounding the browser triggers an immediate retry.

## Device-local appearance
- GM theme mode, accent color, font scale, density, high contrast, and Quick Bar visibility are local to the GM tablet.
- Player theme, accent color, text size, and tab order are local to that browser.
- Character accent is campaign data and can be used as a shared identity marker.

## Second-screen / TV mode
- `GET /display` serves a read-only public display.
- `GET /api/display` returns a filtered snapshot.
- Public display data includes scene, round/current turn, initiative, party HP/status, visible enemy health descriptions, and public effects.
- It excludes exact enemy HP/AC/saves, GM notes, hidden loot, private prep, submissions, secret checks, and private Rules data.

## Content packages
Supported content-package types remain `.ttsession`, `.ttenemy`, `.ttenemypack`, `.ttloot`, and `.ttlootpack`. They remain separate from full-campaign backups. Packages are decoded and validated before the user chooses Keep Existing, Merge, Replace, or Import as Copies.
