package com.drew.tthelper.model

val standardSkillAbilities: Map<String, String> = linkedMapOf(
    "Acrobatics" to "DEX",
    "Arcana" to "INT",
    "Athletics" to "STR",
    "Crafting" to "INT",
    "Deception" to "CHA",
    "Diplomacy" to "CHA",
    "Intimidation" to "CHA",
    "Medicine" to "WIS",
    "Nature" to "WIS",
    "Occultism" to "INT",
    "Performance" to "CHA",
    "Religion" to "WIS",
    "Society" to "INT",
    "Stealth" to "DEX",
    "Survival" to "WIS",
    "Thievery" to "DEX",
)

val proficiencyRanks = listOf("Untrained", "Trained", "Expert", "Master", "Legendary")

fun proficiencyBonus(rank: String, level: Int?): Int = when (rank.trim().lowercase()) {
    "trained" -> (level ?: 0) + 2
    "expert" -> (level ?: 0) + 4
    "master" -> (level ?: 0) + 6
    "legendary" -> (level ?: 0) + 8
    else -> 0
}

fun CharacterStats.abilityModifier(code: String): Int = when (code.trim().uppercase()) {
    "STR" -> strength
    "DEX" -> dexterity
    "CON" -> constitution
    "INT" -> intelligence
    "WIS" -> wisdom
    "CHA" -> charisma
    else -> 0
}

fun CharacterStats.skillAbility(skill: String): String =
    skillAbilityOverrides[skill]?.uppercase()?.takeIf { it in setOf("STR", "DEX", "CON", "INT", "WIS", "CHA") }
        ?: standardSkillAbilities[skill]
        ?: "INT"

fun CharacterStats.calculatedSkillModifier(skill: String, level: Int?): Int {
    skillManualOverrides[skill]?.let { return it }
    if (!autoCalculateSkills) return skillModifiers[skill] ?: 0
    val ability = abilityModifier(skillAbility(skill))
    val proficiency = proficiencyBonus(skillProficiencies[skill] ?: "Untrained", level)
    val itemBonus = skillItemBonuses[skill] ?: 0
    return (ability + proficiency + itemBonus).coerceIn(-99, 199)
}

fun CharacterStats.withRecalculatedSkills(level: Int?): CharacterStats =
    copy(skillModifiers = standardSkillNames.associateWith { calculatedSkillModifier(it, level) })

fun signedModifier(value: Int): String = if (value >= 0) "+$value" else value.toString()
