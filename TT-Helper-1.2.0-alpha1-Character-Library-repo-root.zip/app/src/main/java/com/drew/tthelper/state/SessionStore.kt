package com.drew.tthelper.state

import android.content.Context
import com.drew.tthelper.model.ActionEconomy
import com.drew.tthelper.model.AbilityActionType
import com.drew.tthelper.model.AbilityEntry
import com.drew.tthelper.model.CharacterResource
import com.drew.tthelper.model.CharacterCreationRequest
import com.drew.tthelper.model.CharacterStats
import com.drew.tthelper.model.LibraryEntry
import com.drew.tthelper.model.LibraryKind
import com.drew.tthelper.model.proficiencyRanks
import com.drew.tthelper.model.rulesLibraryEntries
import com.drew.tthelper.model.withRecalculatedSkills
import com.drew.tthelper.model.LoreSkill
import com.drew.tthelper.model.standardSkillNames
import com.drew.tthelper.model.FeatEntry
import com.drew.tthelper.model.ContentKind
import com.drew.tthelper.model.ContentStatus
import com.drew.tthelper.model.DegreeOfSuccess
import com.drew.tthelper.model.PlayerContentDraft
import com.drew.tthelper.model.StrikeEntry
import com.drew.tthelper.model.UsageMode
import com.drew.tthelper.model.CastingMode
import com.drew.tthelper.model.SpellEntry
import com.drew.tthelper.model.SpellSlotPool
import com.drew.tthelper.model.CombatLogEntry
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.Condition
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.EncounterHistoryEntry
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.encounterBudget
import com.drew.tthelper.model.creatureXpForLevel
import com.drew.tthelper.model.adjustedPreparedEntry
import com.drew.tthelper.model.EffectAnchor
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EffectOutcomeAction
import com.drew.tthelper.model.EffectPhase
import com.drew.tthelper.model.EffectPreset
import com.drew.tthelper.model.EffectTriggerAction
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.RuleRequest
import com.drew.tthelper.model.RuleRequestStatus
import com.drew.tthelper.model.RuleRequestType
import com.drew.tthelper.model.SessionPrep
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.StateSnapshot
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.model.effectPresets
import com.drew.tthelper.model.obviousEnemyConditions
import com.drew.tthelper.model.valuedConditions
import java.io.File
import java.util.ArrayDeque
import java.util.LinkedHashSet
import java.util.UUID
import kotlin.random.Random
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class BackupSummary(
    val fileName: String,
    val timestamp: Long,
    val sizeBytes: Long,
    val revision: Long,
    val campaignName: String,
    val sceneName: String,
    val encounterName: String?,
    val valid: Boolean,
)

data class StoreDiagnostics(
    val saveHealthy: Boolean,
    val sessionRevision: Long,
    val lastPersistAt: Long,
    val lastBackupAt: Long,
    val backupCount: Int,
    val recoveryMessage: String?,
    val lastPersistenceError: String?,
    val schemaVersion: Int,
)

class SessionStore(context: Context) {
    private val sessionFile = File(context.filesDir, "session-state.json")
    private val lastGoodFile = File(context.filesDir, "session-state.last-good.json")
    private val backupDir = File(context.filesDir, "backups").also { it.mkdirs() }
    private val undoStack = ArrayDeque<StateSnapshot>()
    private val processedRequestIds = LinkedHashSet<String>()
    private val autoBackupIntervalMs = 5 * 60 * 1000L
    private val maxRotatingBackups = 12
    @Volatile private var lastPersistAt: Long = sessionFile.takeIf { it.exists() }?.lastModified() ?: 0L
    @Volatile private var lastAutoBackupAt: Long = backupDir.listFiles()?.maxOfOrNull { it.lastModified() } ?: 0L
    @Volatile private var recoveryMessage: String? = null
    @Volatile private var lastPersistenceError: String? = null

    private val _state = MutableStateFlow(loadOrDefault())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    @Synchronized
    fun setHp(pcId: String, hp: Int, label: String = "Set HP") {
        val currentPc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val delta = hp.coerceIn(0, currentPc.maxHp) - currentPc.hp
        hpDelta(pcId, delta, label)
    }

    @Synchronized
    fun hpDelta(pcId: String, delta: Int, label: String = if (delta < 0) "Damage" else "Healing") {
        val beforePc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val displayLabel = if (label == "Damage" || label == "Healing") {
            if (delta < 0) "${beforePc.name} took ${-delta} damage" else "${beforePc.name} healed ${delta}"
        } else label

        mutate(displayLabel, logEncounter = _state.value.encounter != null) { current ->
            val encounterActive = current.encounter?.active == true
            var updatedPc = applyPcHpDelta(beforePc = current.pcs.first { it.id == pcId }, delta = delta, encounterActive = encounterActive)
            val pcs = current.pcs.map { if (it.id == pcId) updatedPc else it }
            val encounter = current.encounter?.let { syncPcIntoEncounter(it, updatedPc) }
            current.copy(pcs = pcs, encounter = encounter)
        }
    }

    @Synchronized
    fun tempHpDelta(pcId: String, delta: Int) = mutate("Temp HP", logEncounter = _state.value.encounter != null) { current ->
        val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
        val updated = pc.copy(tempHp = (pc.tempHp + delta).coerceAtLeast(0))
        current.copy(
            pcs = current.pcs.map { if (it.id == pcId) updated else it },
            encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
        )
    }

    @Synchronized
    fun toggleReady(pcId: String) = mutate("Ready status") { current ->
        current.updatePc(pcId) { it.copy(ready = !it.ready) }
    }


    @Synchronized
    fun spendActions(pcId: String, count: Int) {
        val amount = count.coerceIn(1, 3)
        val encounter = _state.value.encounter
        if (encounter?.active == true && encounter.currentCombatant()?.pcId != pcId) return
        mutate("Action spent", logEncounter = _state.value.encounter != null) { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(actionEconomy = pc.actionEconomy.copy(
                    actionsRemaining = (pc.actionEconomy.actionsRemaining - amount).coerceAtLeast(0),
                ))
            }
        }
    }

    @Synchronized
    fun refundAction(pcId: String, count: Int = 1) {
        val amount = count.coerceIn(1, 3)
        mutate("Action refunded", logEncounter = _state.value.encounter != null) { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(actionEconomy = pc.actionEconomy.copy(
                    actionsRemaining = (pc.actionEconomy.actionsRemaining + amount).coerceAtMost(pc.actionEconomy.baseActions),
                ))
            }
        }
    }

    @Synchronized
    fun useReaction(pcId: String) = mutate("Reaction used", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(actionEconomy = it.actionEconomy.copy(reactionAvailable = false)) }
    }

    @Synchronized
    fun restoreReaction(pcId: String) = mutate("Reaction restored", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(actionEconomy = it.actionEconomy.copy(reactionAvailable = true)) }
    }

    @Synchronized
    fun resetActionEconomy(pcId: String) = mutate("Action economy reset", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            resetTurnAbilityUses(pc.copy(actionEconomy = ActionEconomy(baseActions = 3, actionsRemaining = 3, reactionAvailable = true)))
        }
    }

    @Synchronized
    fun configureSpellcasting(
        pcId: String,
        enabled: Boolean,
        tradition: String,
        castingMode: String,
        maxFocusPoints: Int,
        spellDc: Int? = null,
        spellAttackModifier: Int? = null,
    ) = mutate("Spellcasting configured") { current ->
        current.updatePc(pcId) { pc ->
            val old = pc.spellcasting
            val maxFocus = maxFocusPoints.coerceIn(0, 3)
            pc.copy(spellcasting = old.copy(
                enabled = enabled,
                tradition = tradition.trim().take(30),
                castingMode = if (castingMode == CastingMode.SPONTANEOUS) CastingMode.SPONTANEOUS else CastingMode.PREPARED,
                maxFocusPoints = maxFocus,
                focusPoints = old.focusPoints.coerceIn(0, maxFocus),
                spellDc = (spellDc ?: old.spellDc).coerceIn(0, 60),
                spellAttackModifier = (spellAttackModifier ?: old.spellAttackModifier).coerceIn(-20, 50),
            ))
        }
    }

    @Synchronized
    fun setFocusPoints(pcId: String, value: Int) = mutate("Focus points changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(
                focusPoints = value.coerceIn(0, pc.spellcasting.maxFocusPoints),
            ))
        }
    }

    @Synchronized
    fun refocus(pcId: String) = mutate("Refocused", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(focusPoints = pc.spellcasting.maxFocusPoints))
        }
    }

    @Synchronized
    fun setSpellSlotPool(pcId: String, rank: Int, total: Int, remaining: Int? = null) {
        val r = rank.coerceIn(1, 10)
        val t = total.coerceIn(0, 10)
        mutate("Spell slots updated") { current ->
            current.updatePc(pcId) { pc ->
                val old = pc.spellcasting.slots.firstOrNull { it.rank == r }
                val rem = (remaining ?: old?.remaining ?: t).coerceIn(0, t)
                val slots = (pc.spellcasting.slots.filterNot { it.rank == r } + SpellSlotPool(r, t, rem)).sortedBy { it.rank }
                pc.copy(spellcasting = pc.spellcasting.copy(slots = slots))
            }
        }
    }

    @Synchronized
    fun restoreSpellSlots(pcId: String) = mutate("Spell slots restored") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(
                slots = pc.spellcasting.slots.map { it.copy(remaining = it.total) },
                spells = pc.spellcasting.spells.map { if (it.isCantrip || it.isFocus) it else it.copy(expended = false) },
            ))
        }
    }

    @Synchronized
    fun addSpell(
        pcId: String,
        name: String,
        rank: Int,
        actions: Int,
        isCantrip: Boolean,
        isFocus: Boolean,
        notes: String = "",
    ) {
        val clean = name.trim().take(60)
        if (clean.isBlank()) return
        mutate("Spell added: $clean") { current ->
            current.updatePc(pcId) { pc ->
                val spell = SpellEntry(
                    name = clean,
                    rank = if (isCantrip) 0 else rank.coerceIn(1, 10),
                    actions = actions.coerceIn(0, 3),
                    isCantrip = isCantrip,
                    isFocus = isFocus,
                    notes = notes.trim().take(200),
                )
                pc.copy(spellcasting = pc.spellcasting.copy(enabled = true, spells = pc.spellcasting.spells + spell))
            }
        }
    }

    @Synchronized
    fun removeSpell(pcId: String, spellId: String) = mutate("Spell removed") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.filterNot { it.id == spellId }))
        }
    }

    @Synchronized
    fun setSpellExpended(pcId: String, spellId: String, expended: Boolean) = mutate("Prepared spell updated") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.map {
                if (it.id == spellId) it.copy(expended = expended) else it
            }))
        }
    }

    @Synchronized
    fun castSpell(pcId: String, spellId: String) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val spell = pc.spellcasting.spells.firstOrNull { it.id == spellId } ?: return
        if (!pc.spellcasting.enabled) return

        val encounter = snapshot.encounter
        val encounterActive = encounter?.active == true
        val inOwnTurn = encounterActive && encounter?.currentCombatant()?.pcId == pcId
        if (encounterActive && !inOwnTurn && spell.actions > 0) return
        if (inOwnTurn && pc.actionEconomy.actionsRemaining < spell.actions) return
        if (spell.isFocus && pc.spellcasting.focusPoints <= 0) return
        if (!spell.isCantrip && !spell.isFocus) {
            val pool = pc.spellcasting.slots.firstOrNull { it.rank == spell.rank }
            if (pool != null && pool.remaining <= 0) return
            if (pc.spellcasting.castingMode == CastingMode.PREPARED && spell.expended) return
        }

        val checkText = spell.checkOrSave.trim().lowercase()
        val isAttack = "attack" in checkText
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && it.kind != "pc" && !it.defeated }
        val attackMapPenalty = if (isAttack) mapPenalty(pc.actionEconomy.attacksThisTurn, agile = false) else 0
        val request = if (encounter != null && target != null && checkText.isNotBlank() && checkText !in setOf("none", "—", "-")) {
            when {
                "fort" in checkText -> saveRequest(pc, spell.name, target, "Fortitude", target.fortitude, spell)
                "reflex" in checkText -> saveRequest(pc, spell.name, target, "Reflex", target.reflex, spell)
                "will" in checkText -> saveRequest(pc, spell.name, target, "Will", target.will, spell)
                isAttack -> RuleRequest(
                    actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name,
                    type = RuleRequestType.ATTACK, label = "${spell.name} • spell attack",
                    modifier = pc.spellcasting.spellAttackModifier + attackMapPenalty, mapPenalty = attackMapPenalty,
                    dc = target.armorClass, dcLabel = "AC",
                    notes = "Spell attack ${signed(pc.spellcasting.spellAttackModifier)} • MAP ${signed(attackMapPenalty)}",
                    damageFormula = spell.damage, damageType = spell.damageType, basicSave = false, healing = spell.healing,
                    effectCriticalSuccess = spell.effectCriticalSuccess, effectSuccess = spell.effectSuccess, effectFailure = spell.effectFailure, effectCriticalFailure = spell.effectCriticalFailure,
                )
                else -> RuleRequest(
                    actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name,
                    type = RuleRequestType.SKILL, label = "${spell.name} • ${spell.checkOrSave}",
                    notes = "Resolve the spell's listed check/save manually.",
                )
            }
        } else null

        mutate("${pc.name} cast ${spell.name}", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { currentPc ->
                var casting = currentPc.spellcasting
                var actionsState = currentPc.actionEconomy
                if (inOwnTurn && spell.actions > 0) {
                    actionsState = actionsState.copy(actionsRemaining = (actionsState.actionsRemaining - spell.actions).coerceAtLeast(0))
                }
                if (isAttack) actionsState = actionsState.copy(attacksThisTurn = actionsState.attacksThisTurn + 1)
                if (spell.isFocus) {
                    casting = casting.copy(focusPoints = (casting.focusPoints - 1).coerceAtLeast(0))
                } else if (!spell.isCantrip) {
                    casting = casting.copy(
                        slots = casting.slots.map { slot ->
                            if (slot.rank == spell.rank) slot.copy(remaining = (slot.remaining - 1).coerceAtLeast(0)) else slot
                        },
                        spells = if (casting.castingMode == CastingMode.PREPARED) {
                            casting.spells.map { if (it.id == spellId) it.copy(expended = true) else it }
                        } else casting.spells,
                    )
                }
                currentPc.copy(spellcasting = casting, actionEconomy = actionsState)
            }
            if (request != null) {
                val updatedEncounter = updated.encounter
                if (updatedEncounter != null) updated.copy(encounter = updatedEncounter.copy(ruleRequests = addRuleRequest(updatedEncounter.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun updateCharacterProfile(
        pcId: String,
        name: String,
        ancestry: String,
        heritage: String,
        background: String,
        characterClass: String,
        level: Int?,
    ) = mutate("Character profile updated") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(
                name = name.trim().ifBlank { pc.name }.take(60),
                ancestry = ancestry.trim().take(60),
                heritage = heritage.trim().take(80),
                background = background.trim().take(80),
                characterClass = characterClass.trim().take(80),
                level = level?.coerceIn(0, 30),
            )
        }
    }

    @Synchronized
    fun setCharacterAccent(pcId: String, color: String) = mutate("Character accent changed") { current ->
        val normalized = color.lowercase().takeIf { it in setOf("blue", "purple", "red", "orange", "green", "teal", "gold", "steel") } ?: "blue"
        current.updatePc(pcId) { it.copy(accentColor = normalized) }
    }

    @Synchronized
    fun saveCharacterSheet(pcId: String, payload: JSONObject) {
        val before = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val oldStats = before.stats
        val statsJson = payload.optJSONObject("stats") ?: JSONObject()
        val skillJson = statsJson.optJSONObject("skillModifiers") ?: JSONObject()
        val profJson = statsJson.optJSONObject("skillProficiencies") ?: JSONObject()
        val itemBonusJson = statsJson.optJSONObject("skillItemBonuses") ?: JSONObject()
        val abilityOverrideJson = statsJson.optJSONObject("skillAbilityOverrides") ?: JSONObject()
        val manualOverrideJson = statsJson.optJSONObject("skillManualOverrides") ?: JSONObject()
        val skills = standardSkillNames.associateWith { name -> skillJson.optInt(name, oldStats.skillModifiers[name] ?: 0).coerceIn(-99, 199) }
        val profs = standardSkillNames.associateWith { name ->
            profJson.optString(name, oldStats.skillProficiencies[name] ?: "Untrained").let { rank ->
                proficiencyRanks.firstOrNull { it.equals(rank, true) } ?: "Untrained"
            }
        }
        val itemBonuses = standardSkillNames.associateWith { name -> itemBonusJson.optInt(name, oldStats.skillItemBonuses[name] ?: 0).coerceIn(-20, 50) }
        val abilityOverrides = buildMap {
            standardSkillNames.forEach { name ->
                val raw = abilityOverrideJson.optString(name, oldStats.skillAbilityOverrides[name].orEmpty()).uppercase()
                if (raw in setOf("STR", "DEX", "CON", "INT", "WIS", "CHA")) put(name, raw)
            }
        }
        val manualOverrides = buildMap {
            standardSkillNames.forEach { name ->
                if (manualOverrideJson.has(name) && !manualOverrideJson.isNull(name)) {
                    put(name, manualOverrideJson.optInt(name, 0).coerceIn(-99, 199))
                }
            }
        }
        val autoCalculateSkills = statsJson.optBoolean("autoCalculateSkills", oldStats.autoCalculateSkills)
        val lore = buildList {
            val array = statsJson.optJSONArray("loreSkills")
            if (array != null) for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val name = item.optString("name").trim().take(80)
                if (name.isNotBlank()) add(LoreSkill(
                    id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                    name = name, modifier = item.optInt("modifier", 0).coerceIn(-20, 99),
                    proficiency = item.optString("proficiency", "Untrained").take(20),
                ))
            } else addAll(oldStats.loreSkills)
        }
        val nextStats = CharacterStats(
            size = statsJson.optString("size", oldStats.size).trim().ifBlank { "Medium" }.take(30),
            speed = statsJson.optInt("speed", oldStats.speed).coerceIn(0, 999),
            languages = statsJson.optString("languages", oldStats.languages).trim().take(500),
            senses = statsJson.optString("senses", oldStats.senses).trim().take(500),
            strength = statsJson.optInt("strength", oldStats.strength).coerceIn(-10, 20),
            dexterity = statsJson.optInt("dexterity", oldStats.dexterity).coerceIn(-10, 20),
            constitution = statsJson.optInt("constitution", oldStats.constitution).coerceIn(-10, 20),
            intelligence = statsJson.optInt("intelligence", oldStats.intelligence).coerceIn(-10, 20),
            wisdom = statsJson.optInt("wisdom", oldStats.wisdom).coerceIn(-10, 20),
            charisma = statsJson.optInt("charisma", oldStats.charisma).coerceIn(-10, 20),
            armorClass = statsJson.optInt("armorClass", oldStats.armorClass).coerceIn(0, 99),
            perception = statsJson.optInt("perception", oldStats.perception).coerceIn(-20, 99),
            fortitude = statsJson.optInt("fortitude", oldStats.fortitude).coerceIn(-20, 99),
            reflex = statsJson.optInt("reflex", oldStats.reflex).coerceIn(-20, 99),
            will = statsJson.optInt("will", oldStats.will).coerceIn(-20, 99),
            classDc = statsJson.optInt("classDc", oldStats.classDc).coerceIn(0, 99),
            skillModifiers = skills,
            skillProficiencies = profs,
            skillItemBonuses = itemBonuses,
            skillAbilityOverrides = abilityOverrides,
            skillManualOverrides = manualOverrides,
            autoCalculateSkills = autoCalculateSkills,
            loreSkills = lore,
            weaponProficiency = statsJson.optString("weaponProficiency", oldStats.weaponProficiency).trim().take(500),
            armorProficiency = statsJson.optString("armorProficiency", oldStats.armorProficiency).trim().take(500),
            immunities = statsJson.optString("immunities", oldStats.immunities).trim().take(500),
            resistances = statsJson.optString("resistances", oldStats.resistances).trim().take(500),
            weaknesses = statsJson.optString("weaknesses", oldStats.weaknesses).trim().take(500),
        ).withRecalculatedSkills(before.level)
        val maxHp = payload.optInt("maxHp", before.maxHp).coerceAtLeast(1)
        val hp = payload.optInt("hp", before.hp).coerceIn(0, maxHp)
        val tempHp = payload.optInt("tempHp", before.tempHp).coerceAtLeast(0)
        val spellDc = payload.optInt("spellDc", before.spellcasting.spellDc).coerceIn(0, 99)
        val spellAttack = payload.optInt("spellAttackModifier", before.spellcasting.spellAttackModifier).coerceIn(-20, 99)
        mutate("Character sheet updated") { current ->
            current.updatePc(pcId) { pc -> pc.copy(
                hp = hp, maxHp = maxHp, tempHp = tempHp, stats = nextStats,
                spellcasting = pc.spellcasting.copy(spellDc = spellDc, spellAttackModifier = spellAttack),
            ) }.let { updated ->
                val pc = updated.pcs.first { it.id == pcId }
                updated.copy(encounter = updated.encounter?.let { syncPcIntoEncounter(it, pc) })
            }
        }
    }

    @Synchronized
    fun addFeat(
        pcId: String,
        name: String,
        type: String,
        level: Int?,
        traits: String,
        prerequisites: String,
        notes: String,
    ) {
        val cleanName = name.trim().take(80)
        if (cleanName.isBlank()) return
        val feat = FeatEntry(
            name = cleanName,
            type = type.trim().ifBlank { "General Feat" }.take(50),
            level = level?.coerceIn(0, 30),
            traits = traits.trim().take(180),
            prerequisites = prerequisites.trim().take(240),
            notes = notes.trim().take(600),
        )
        mutate("Feat added") { current ->
            current.updatePc(pcId) { pc -> pc.copy(feats = pc.feats + feat) }
        }
    }

    @Synchronized
    fun removeFeat(pcId: String, featId: String) = mutate("Feat removed") { current ->
        current.updatePc(pcId) { pc -> pc.copy(feats = pc.feats.filterNot { it.id == featId }) }
    }

    @Synchronized
    fun requestCharacterCreation(
        playerName: String,
        characterName: String,
        ancestry: String,
        heritage: String,
        background: String,
        characterClass: String,
        level: Int?,
        notes: String,
    ): Boolean {
        val cleanName = characterName.trim().take(60)
        if (cleanName.isBlank()) return false
        val request = CharacterCreationRequest(
            playerName = playerName.trim().ifBlank { "Player" }.take(30),
            characterName = cleanName,
            ancestry = ancestry.trim().take(60),
            heritage = heritage.trim().take(80),
            background = background.trim().take(80),
            characterClass = characterClass.trim().take(80),
            level = level?.coerceIn(0, 30),
            notes = notes.trim().take(600),
        )
        mutate("New character requested") { current ->
            current.copy(characterRequests = (current.characterRequests + request).takeLast(50))
        }
        return true
    }

    @Synchronized
    fun approveCharacterRequest(requestId: String) {
        val request = _state.value.characterRequests.firstOrNull { it.id == requestId } ?: return
        val pc = PlayerCharacter(
            id = UUID.randomUUID().toString(),
            name = request.characterName,
            ancestry = request.ancestry,
            heritage = request.heritage,
            background = request.background,
            characterClass = request.characterClass,
            level = request.level,
            hp = 10,
            maxHp = 10,
        )
        mutate("Approved new character ${request.characterName}") { current ->
            current.copy(
                pcs = current.pcs + pc,
                characterRequests = current.characterRequests.filterNot { it.id == requestId },
            )
        }
    }

    @Synchronized
    fun declineCharacterRequest(requestId: String) = mutate("Character request declined") { current ->
        current.copy(characterRequests = current.characterRequests.filterNot { it.id == requestId })
    }

    fun pendingSubmissionCount(): Int = _state.value.pcs.sumOf { pc ->
        pc.contentDrafts.count { it.status == ContentStatus.PENDING }
    }

    @Synchronized
    fun setHeroPoints(pcId: String, value: Int) = mutate("Hero Points changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(heroPoints = value.coerceIn(0, 3)) }
    }

    @Synchronized
    fun saveContentDraft(pcId: String, payload: JSONObject) {
        val id = payload.optString("id").ifBlank { UUID.randomUUID().toString() }
        val currentPc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val old = currentPc.contentDrafts.firstOrNull { it.id == id }
        if (old?.status == ContentStatus.PENDING) return
        val kind = payload.optString("kind", old?.kind ?: ContentKind.ABILITY).let {
            if (it in setOf(ContentKind.SPELL, ContentKind.ABILITY, ContentKind.STRIKE, ContentKind.RESOURCE, ContentKind.FEAT)) it else ContentKind.ABILITY
        }
        val cleanName = payload.optString("name", old?.name.orEmpty()).trim().take(60)
        if (cleanName.isBlank()) return
        val draft = PlayerContentDraft(
            id = id,
            kind = kind,
            status = ContentStatus.DRAFT,
            name = cleanName,
            rank = payload.optInt("rank", old?.rank ?: 1).coerceIn(0, 10),
            actions = payload.optInt("actions", old?.actions ?: 1).coerceIn(0, 3),
            isCantrip = payload.optBoolean("isCantrip", old?.isCantrip ?: false),
            isFocus = payload.optBoolean("isFocus", old?.isFocus ?: false),
            notes = payload.optString("notes", old?.notes.orEmpty()).trim().take(500),
            range = payload.optString("range", old?.range.orEmpty()).trim().take(80),
            targets = payload.optString("targets", old?.targets.orEmpty()).trim().take(120),
            checkOrSave = payload.optString("checkOrSave", old?.checkOrSave.orEmpty()).trim().take(120),
            abilityCategory = payload.optString("abilityCategory", old?.abilityCategory ?: "Ability").trim().take(40),
            actionType = payload.optString("actionType", old?.actionType ?: AbilityActionType.ACTION).let {
                if (it in setOf(AbilityActionType.ACTION, AbilityActionType.REACTION, AbilityActionType.FREE, AbilityActionType.PASSIVE)) it else AbilityActionType.ACTION
            },
            usageMode = payload.optString("usageMode", old?.usageMode ?: UsageMode.UNLIMITED).let {
                if (it in setOf(UsageMode.UNLIMITED, UsageMode.ONCE_PER_TURN, UsageMode.ENCOUNTER, UsageMode.DAILY, UsageMode.CUSTOM)) it else UsageMode.UNLIMITED
            },
            maxUses = payload.optInt("maxUses", old?.maxUses ?: 0).coerceIn(0, 99),
            attackModifier = payload.optInt("attackModifier", old?.attackModifier ?: 0).coerceIn(-99, 99),
            damage = payload.optString("damage", old?.damage.orEmpty()).trim().take(80),
            damageType = payload.optString("damageType", old?.damageType.orEmpty()).trim().take(40),
            basicSave = payload.optBoolean("basicSave", old?.basicSave ?: false),
            healing = payload.optBoolean("healing", old?.healing ?: false),
            traits = payload.optString("traits", old?.traits.orEmpty()).trim().take(240),
            prerequisites = payload.optString("prerequisites", old?.prerequisites.orEmpty()).trim().take(240),
            effectCriticalSuccess = payload.optString("effectCriticalSuccess", old?.effectCriticalSuccess.orEmpty()).trim().take(80),
            effectSuccess = payload.optString("effectSuccess", old?.effectSuccess.orEmpty()).trim().take(80),
            effectFailure = payload.optString("effectFailure", old?.effectFailure.orEmpty()).trim().take(80),
            effectCriticalFailure = payload.optString("effectCriticalFailure", old?.effectCriticalFailure.orEmpty()).trim().take(80),
            resourceMax = payload.optInt("resourceMax", old?.resourceMax ?: 0).coerceIn(0, 999),
            gmFeedback = old?.gmFeedback.orEmpty(),
            sourceEntryId = payload.optString("sourceEntryId").takeIf { it.isNotBlank() } ?: old?.sourceEntryId,
            submittedAt = null,
        )
        mutate("${currentPc.name} saved a ${kind.lowercase()} draft") { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(contentDrafts = (pc.contentDrafts.filterNot { it.id == id } + draft).takeLast(100))
            }
        }
    }

    @Synchronized
    fun addLibraryDraft(pcId: String, libraryId: String): Boolean {
        val entry = rulesLibraryEntries.firstOrNull { it.id == libraryId } ?: return false
        if (entry.kind in setOf(LibraryKind.SKILL, LibraryKind.TRAIT, LibraryKind.CONDITION)) return false
        val pc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return false
        val draftKind = when (entry.kind) {
            LibraryKind.SPELL -> ContentKind.SPELL
            LibraryKind.FEAT -> ContentKind.FEAT
            LibraryKind.ACTION, LibraryKind.ABILITY -> ContentKind.ABILITY
            else -> return false
        }
        val sourceId = "library:${entry.id}"
        val existing = pc.contentDrafts.lastOrNull { it.sourceEntryId == sourceId && it.status != ContentStatus.PENDING }
        val draft = PlayerContentDraft(
            id = existing?.id ?: UUID.randomUUID().toString(),
            kind = draftKind,
            status = ContentStatus.DRAFT,
            name = entry.name.take(60),
            rank = (entry.level ?: 1).coerceIn(0, 10),
            actions = (entry.actions ?: 0).coerceIn(0, 3),
            isCantrip = entry.kind == LibraryKind.SPELL && entry.level == 0,
            isFocus = false,
            notes = entry.summary.take(500),
            range = entry.range.take(80),
            targets = entry.targets.take(120),
            checkOrSave = entry.checkOrSave.take(120),
            abilityCategory = entry.category.ifBlank { if (draftKind == ContentKind.FEAT) "General Feat" else "Ability" }.take(40),
            actionType = if ((entry.actions ?: 0) == 0) AbilityActionType.PASSIVE else AbilityActionType.ACTION,
            usageMode = UsageMode.UNLIMITED,
            maxUses = 0,
            damage = entry.damage.take(80),
            damageType = entry.damageType.take(40),
            basicSave = entry.basicSave,
            healing = entry.healing,
            traits = entry.traits.joinToString(", ").take(240),
            prerequisites = entry.prerequisites.take(240),
            sourceEntryId = sourceId,
            gmFeedback = existing?.gmFeedback.orEmpty(),
        )
        mutate("${pc.name} added ${entry.name} from the library") { current ->
            current.updatePc(pcId) { target ->
                target.copy(contentDrafts = (target.contentDrafts.filterNot { it.id == draft.id } + draft).takeLast(100))
            }
        }
        return true
    }

    @Synchronized
    fun submitContentDraft(pcId: String, draftId: String) {
        val pc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val draft = pc.contentDrafts.firstOrNull { it.id == draftId && it.status == ContentStatus.DRAFT } ?: return
        mutate("${pc.name} submitted ${draft.name} for approval") { current ->
            current.updatePc(pcId) { target ->
                target.copy(contentDrafts = target.contentDrafts.map {
                    if (it.id == draftId) it.copy(status = ContentStatus.PENDING, submittedAt = System.currentTimeMillis()) else it
                })
            }
        }
    }

    @Synchronized
    fun deleteContentDraft(pcId: String, draftId: String) = mutate("Draft deleted") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(contentDrafts = pc.contentDrafts.filterNot { it.id == draftId && it.status != ContentStatus.PENDING })
        }
    }

    @Synchronized
    fun declineContentDraft(pcId: String, draftId: String, feedback: String) {
        val pc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val draft = pc.contentDrafts.firstOrNull { it.id == draftId && it.status == ContentStatus.PENDING } ?: return
        mutate("${draft.name} returned to ${pc.name}'s drafts") { current ->
            current.updatePc(pcId) { target ->
                target.copy(contentDrafts = target.contentDrafts.map {
                    if (it.id == draftId) it.copy(
                        status = ContentStatus.DRAFT,
                        gmFeedback = feedback.trim().take(500),
                        submittedAt = null,
                    ) else it
                })
            }
        }
    }

    @Synchronized
    fun approveContentDraft(
        pcId: String,
        draftId: String,
        nameOverride: String? = null,
        actionsOverride: Int? = null,
        notesOverride: String? = null,
    ) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val draft = pc.contentDrafts.firstOrNull { it.id == draftId && it.status == ContentStatus.PENDING } ?: return
        val approvedName = nameOverride?.trim()?.take(60)?.takeIf { it.isNotBlank() } ?: draft.name
        val approvedActions = (actionsOverride ?: draft.actions).coerceIn(0, 3)
        val approvedNotes = notesOverride?.trim()?.take(500) ?: draft.notes
        val approvedId = draft.sourceEntryId ?: UUID.randomUUID().toString()
        mutate("Approved ${draft.name} for ${pc.name}") { current ->
            current.updatePc(pcId) { target ->
                var next = target
                when (draft.kind) {
                    ContentKind.SPELL -> {
                        val existing = next.spellcasting.spells.firstOrNull { it.id == approvedId }
                        val entry = SpellEntry(
                            id = approvedId,
                            name = approvedName,
                            rank = if (draft.isCantrip) 0 else draft.rank.coerceIn(1, 10),
                            actions = approvedActions,
                            isCantrip = draft.isCantrip,
                            isFocus = draft.isFocus,
                            expended = existing?.expended ?: false,
                            notes = approvedNotes,
                            range = draft.range,
                            targets = draft.targets,
                            checkOrSave = draft.checkOrSave,
                            damage = draft.damage, damageType = draft.damageType, basicSave = draft.basicSave, healing = draft.healing, traits = draft.traits,
                            effectCriticalSuccess = draft.effectCriticalSuccess, effectSuccess = draft.effectSuccess, effectFailure = draft.effectFailure, effectCriticalFailure = draft.effectCriticalFailure,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(spellcasting = next.spellcasting.copy(
                            enabled = true,
                            spells = next.spellcasting.spells.filterNot { it.id == approvedId } + entry,
                        ))
                    }
                    ContentKind.ABILITY -> {
                        val maxUses = usageMax(draft.usageMode, draft.maxUses)
                        val existing = next.abilities.firstOrNull { it.id == approvedId }
                        val entry = AbilityEntry(
                            id = approvedId,
                            name = approvedName,
                            category = draft.abilityCategory.ifBlank { "Ability" },
                            actionType = draft.actionType,
                            actions = approvedActions,
                            usageMode = draft.usageMode,
                            maxUses = maxUses,
                            remainingUses = existing?.remainingUses?.coerceAtMost(maxUses) ?: maxUses,
                            range = draft.range, targets = draft.targets, checkOrSave = draft.checkOrSave,
                            damage = draft.damage, damageType = draft.damageType, basicSave = draft.basicSave, healing = draft.healing, traits = draft.traits,
                            effectCriticalSuccess = draft.effectCriticalSuccess, effectSuccess = draft.effectSuccess, effectFailure = draft.effectFailure, effectCriticalFailure = draft.effectCriticalFailure,
                            notes = approvedNotes,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(abilities = next.abilities.filterNot { it.id == approvedId } + entry)
                    }
                    ContentKind.STRIKE -> {
                        val existing = next.strikes.firstOrNull { it.id == approvedId }
                        val entry = StrikeEntry(
                            id = approvedId,
                            name = approvedName,
                            actions = approvedActions.coerceAtLeast(1),
                            attackModifier = draft.attackModifier,
                            damage = draft.damage, damageType = draft.damageType, healing = draft.healing,
                            traits = draft.traits, effectCriticalSuccess = draft.effectCriticalSuccess, effectSuccess = draft.effectSuccess,
                            notes = approvedNotes,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(strikes = next.strikes.filterNot { it.id == approvedId } + entry)
                    }
                    ContentKind.FEAT -> {
                        val entry = FeatEntry(
                            id = approvedId,
                            name = approvedName,
                            type = draft.abilityCategory.ifBlank { "General Feat" },
                            level = draft.rank.takeIf { it > 0 },
                            traits = draft.traits,
                            prerequisites = draft.prerequisites,
                            notes = approvedNotes,
                        )
                        next = next.copy(feats = next.feats.filterNot { it.id == approvedId } + entry)
                    }
                    ContentKind.RESOURCE -> {
                        val max = draft.resourceMax.coerceAtLeast(0)
                        val existing = next.resources.firstOrNull { it.id == approvedId }
                        val entry = CharacterResource(
                            id = approvedId,
                            name = approvedName,
                            current = existing?.current?.coerceIn(0, max) ?: max,
                            max = max,
                            notes = approvedNotes,
                            pinned = existing?.pinned ?: true,
                        )
                        next = next.copy(resources = next.resources.filterNot { it.id == approvedId } + entry)
                    }
                }
                next.copy(contentDrafts = next.contentDrafts.map {
                    if (it.id == draftId) it.copy(
                        status = ContentStatus.APPROVED_HISTORY,
                        name = approvedName,
                        actions = approvedActions,
                        notes = approvedNotes,
                        gmFeedback = "Approved",
                        sourceEntryId = approvedId,
                    ) else it
                }.takeLast(100))
            }
        }
    }

    @Synchronized
    fun togglePinned(pcId: String, kind: String, entryId: String) = mutate("Dashboard pin changed") { current ->
        current.updatePc(pcId) { pc ->
            when (kind) {
                ContentKind.SPELL -> pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it }))
                ContentKind.ABILITY -> pc.copy(abilities = pc.abilities.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it })
                ContentKind.STRIKE -> pc.copy(strikes = pc.strikes.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it })
                ContentKind.RESOURCE -> pc.copy(resources = pc.resources.map { if (it.id == entryId) it.copy(pinned = !it.pinned) else it })
                else -> pc
            }
        }
    }

    @Synchronized
    fun useAbility(pcId: String, abilityId: String) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val ability = pc.abilities.firstOrNull { it.id == abilityId } ?: return
        val encounter = snapshot.encounter
        val ownTurn = encounter?.active != true || encounter.currentCombatant()?.pcId == pcId
        if (ability.actionType == AbilityActionType.ACTION && (!ownTurn || pc.actionEconomy.actionsRemaining < ability.actions)) return
        if (ability.actionType == AbilityActionType.REACTION && !pc.actionEconomy.reactionAvailable) return
        if (ability.usageMode != UsageMode.UNLIMITED && ability.remainingUses <= 0) return
        val checkText = ability.checkOrSave.trim().lowercase()
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && !it.defeated }
        val request = if (encounter != null && target != null && (checkText.isNotBlank() || ability.damage.isNotBlank() || listOf(ability.effectCriticalSuccess, ability.effectSuccess, ability.effectFailure, ability.effectCriticalFailure).any { it.isNotBlank() })) {
            when {
                "fort" in checkText -> abilitySaveRequest(pc, ability, target, "Fortitude", target.fortitude)
                "reflex" in checkText -> abilitySaveRequest(pc, ability, target, "Reflex", target.reflex)
                "will" in checkText -> abilitySaveRequest(pc, ability, target, "Will", target.will)
                "attack" in checkText -> RuleRequest(
                    actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name, type = RuleRequestType.ATTACK, label = ability.name,
                    dc = target.armorClass, dcLabel = "AC", notes = ability.checkOrSave, damageFormula = ability.damage, damageType = ability.damageType, healing = ability.healing,
                    effectCriticalSuccess = ability.effectCriticalSuccess, effectSuccess = ability.effectSuccess, effectFailure = ability.effectFailure, effectCriticalFailure = ability.effectCriticalFailure,
                )
                else -> RuleRequest(
                    actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name, type = RuleRequestType.SKILL, label = ability.name,
                    notes = ability.checkOrSave.ifBlank { "Resolve ability outcome" }, damageFormula = ability.damage, damageType = ability.damageType, basicSave = ability.basicSave, healing = ability.healing,
                    effectCriticalSuccess = ability.effectCriticalSuccess, effectSuccess = ability.effectSuccess, effectFailure = ability.effectFailure, effectCriticalFailure = ability.effectCriticalFailure,
                )
            }
        } else null
        mutate("${pc.name} used ${ability.name}", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { targetPc ->
                var economy = targetPc.actionEconomy
                if (ability.actionType == AbilityActionType.ACTION) economy = economy.copy(actionsRemaining = (economy.actionsRemaining - ability.actions).coerceAtLeast(0))
                if (ability.actionType == AbilityActionType.REACTION) economy = economy.copy(reactionAvailable = false)
                val abilities = targetPc.abilities.map { entry ->
                    if (entry.id != abilityId || entry.usageMode == UsageMode.UNLIMITED) entry
                    else entry.copy(remainingUses = (entry.remainingUses - 1).coerceAtLeast(0))
                }
                targetPc.copy(actionEconomy = economy, abilities = abilities)
            }
            if (request != null) {
                val e = updated.encounter
                if (e != null) updated.copy(encounter = e.copy(ruleRequests = addRuleRequest(e.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun restoreAbilityUses(pcId: String, abilityId: String) = mutate("Ability uses restored") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(abilities = pc.abilities.map { ability ->
                if (ability.id == abilityId && ability.usageMode != UsageMode.UNLIMITED) {
                    ability.copy(remainingUses = usageMax(ability.usageMode, ability.maxUses))
                } else ability
            })
        }
    }

    @Synchronized
    fun useStrike(pcId: String, strikeId: String, physicalD20: Int? = null) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val strike = pc.strikes.firstOrNull { it.id == strikeId } ?: return
        val encounter = snapshot.encounter
        val ownTurn = encounter?.active != true || encounter.currentCombatant()?.pcId == pcId
        if (!ownTurn || pc.actionEconomy.actionsRemaining < strike.actions) return
        val agile = strike.traits.contains("agile", ignoreCase = true)
        val penalty = mapPenalty(pc.actionEconomy.attacksThisTurn, agile)
        val modifier = strike.attackModifier + penalty
        val natural = physicalD20?.coerceIn(1, 20) ?: Random.nextInt(1, 21)
        val total = natural + modifier
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && it.kind != "pc" && !it.defeated }
        val request = encounter?.let {
            RuleRequest(
                actorPcId = pc.id, actorName = pc.name, targetCombatantId = target?.id, targetName = target?.name,
                type = RuleRequestType.ATTACK, label = strike.name, roll = natural, modifier = modifier,
                mapPenalty = penalty, total = total, dc = target?.armorClass, dcLabel = "AC",
                suggestedOutcome = target?.armorClass?.let { degreeOfSuccess(total, it, natural) },
                notes = "Base ${signed(strike.attackModifier)} • MAP ${signed(penalty)} • ${strike.damage.ifBlank { "damage not entered" }}",
                damageFormula = strike.damage, damageType = strike.damageType, healing = strike.healing,
                effectCriticalSuccess = strike.effectCriticalSuccess, effectSuccess = strike.effectSuccess,
            )
        }
        mutate("${pc.name} used ${strike.name}", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { targetPc ->
                targetPc.copy(actionEconomy = targetPc.actionEconomy.copy(
                    actionsRemaining = (targetPc.actionEconomy.actionsRemaining - strike.actions).coerceAtLeast(0),
                    attacksThisTurn = targetPc.actionEconomy.attacksThisTurn + 1,
                ))
            }
            if (request != null) {
                val updatedEncounter = updated.encounter
                if (updatedEncounter != null) updated.copy(encounter = updatedEncounter.copy(ruleRequests = addRuleRequest(updatedEncounter.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun performCommonAction(pcId: String, label: String, actions: Int = 1) {
        val clean = label.trim().take(40)
        if (clean.isBlank()) return
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val cost = actions.coerceIn(0, 3)
        val encounter = snapshot.encounter
        val ownTurn = encounter?.active != true || encounter.currentCombatant()?.pcId == pcId
        if (!ownTurn || pc.actionEconomy.actionsRemaining < cost) return
        val attackAction = clean in setOf("Grapple", "Trip", "Shove")
        val secretAction = clean in setOf("Recall Knowledge", "Seek")
        val penalty = if (attackAction) mapPenalty(pc.actionEconomy.attacksThisTurn, agile = false) else 0
        val target = encounter?.combatants?.firstOrNull { it.id == pc.selectedTargetId && it.kind != "pc" && !it.defeated }
        val request = if (encounter != null && (attackAction || secretAction)) {
            RuleRequest(
                actorPcId = pc.id, actorName = pc.name, targetCombatantId = target?.id, targetName = target?.name,
                type = if (secretAction) RuleRequestType.SECRET else RuleRequestType.SKILL,
                label = clean, secret = secretAction, mapPenalty = penalty,
                notes = if (secretAction) "Secret check: GM rolls/resolves without exposing the result automatically." else "Athletics attack action • apply MAP ${signed(penalty)}.",
            )
        } else null
        mutate("${pc.name}: $clean", logEncounter = encounter != null) { current ->
            val updated = current.updatePc(pcId) { targetPc -> targetPc.copy(actionEconomy = targetPc.actionEconomy.copy(
                actionsRemaining = (targetPc.actionEconomy.actionsRemaining - cost).coerceAtLeast(0),
                attacksThisTurn = targetPc.actionEconomy.attacksThisTurn + if (attackAction) 1 else 0,
            )) }
            if (request != null) {
                val updatedEncounter = updated.encounter
                if (updatedEncounter != null) updated.copy(encounter = updatedEncounter.copy(ruleRequests = addRuleRequest(updatedEncounter.ruleRequests, request))) else updated
            } else updated
        }
    }

    @Synchronized
    fun adjustResource(pcId: String, resourceId: String, delta: Int) = mutate("Character resource changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(resources = pc.resources.map { resource ->
                if (resource.id == resourceId) resource.copy(current = (resource.current + delta).coerceIn(0, resource.max.coerceAtLeast(0))) else resource
            })
        }
    }

    private fun usageMax(mode: String, custom: Int): Int = when (mode) {
        UsageMode.ONCE_PER_TURN, UsageMode.ENCOUNTER, UsageMode.DAILY -> 1
        UsageMode.CUSTOM -> custom.coerceIn(1, 99)
        else -> 0
    }

    private fun resetEncounterAbilityUses(pc: PlayerCharacter): PlayerCharacter = pc.copy(
        abilities = pc.abilities.map { ability ->
            when (ability.usageMode) {
                UsageMode.ONCE_PER_TURN, UsageMode.ENCOUNTER -> ability.copy(remainingUses = usageMax(ability.usageMode, ability.maxUses))
                else -> ability
            }
        }
    )

    private fun resetTurnAbilityUses(pc: PlayerCharacter): PlayerCharacter = pc.copy(
        abilities = pc.abilities.map { ability ->
            if (ability.usageMode == UsageMode.ONCE_PER_TURN) ability.copy(remainingUses = 1) else ability
        }
    )

    @Synchronized
    fun setTarget(pcId: String, combatantId: String?) {
        val encounter = _state.value.encounter
        val valid = combatantId?.takeIf { id -> encounter?.combatants?.any { it.id == id && it.kind != "pc" && !it.defeated } == true }
        mutate("Target changed") { current -> current.updatePc(pcId) { it.copy(selectedTargetId = valid) } }
    }

    @Synchronized
    fun rollRuleRequest(requestId: String, requestedByPcId: String? = null) {
        mutate("Rule check rolled", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val request = encounter.ruleRequests.firstOrNull { it.id == requestId && it.status == RuleRequestStatus.PENDING } ?: return@mutate current
            if (requestedByPcId != null && (request.actorPcId != requestedByPcId || request.type != RuleRequestType.ATTACK)) return@mutate current
            val modifier = request.modifier ?: return@mutate current
            val natural = Random.nextInt(1, 21)
            val total = natural + modifier
            val updated = request.copy(roll = natural, total = total, suggestedOutcome = request.dc?.let { degreeOfSuccess(total, it, natural) })
            current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { if (it.id == requestId) updated else it }))
        }
    }

    @Synchronized
    fun resolveRuleRequest(requestId: String, outcome: String) {
        val allowed = setOf(DegreeOfSuccess.CRITICAL_SUCCESS, DegreeOfSuccess.SUCCESS, DegreeOfSuccess.FAILURE, DegreeOfSuccess.CRITICAL_FAILURE)
        if (outcome !in allowed) return
        mutate("Rule request resolved: $outcome", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { request ->
                if (request.id == requestId && request.status == RuleRequestStatus.PENDING) {
                    val rolled = rollFormula(request.damageFormula)
                    request.copy(
                        status = RuleRequestStatus.RESOLVED, outcome = outcome, rolledDamage = rolled,
                        proposedAmount = rolled?.let { consequenceAmount(it, outcome, request.basicSave) },
                    )
                } else request
            }))
        }
    }

    @Synchronized
    fun rerollRuleDamage(requestId: String) = mutate("Damage rerolled", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { request ->
            if (request.id == requestId && request.status == RuleRequestStatus.RESOLVED && !request.consequenceApplied) {
                val rolled = rollFormula(request.damageFormula)
                request.copy(rolledDamage = rolled, proposedAmount = rolled?.let { consequenceAmount(it, request.outcome ?: DegreeOfSuccess.FAILURE, request.basicSave) })
            } else request
        }))
    }

    @Synchronized
    fun applyRuleRequestConsequences(requestId: String) = mutate("Rule consequences applied", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val request = encounter.ruleRequests.firstOrNull { it.id == requestId && it.status == RuleRequestStatus.RESOLVED && !it.consequenceApplied } ?: return@mutate current
        val targetId = request.targetCombatantId ?: return@mutate current
        val amount = request.proposedAmount ?: 0
        val effectName = when (request.outcome) {
            DegreeOfSuccess.CRITICAL_SUCCESS -> request.effectCriticalSuccess
            DegreeOfSuccess.SUCCESS -> request.effectSuccess
            DegreeOfSuccess.FAILURE -> request.effectFailure
            DegreeOfSuccess.CRITICAL_FAILURE -> request.effectCriticalFailure
            else -> ""
        }.trim()
        val sourceId = encounter.combatants.firstOrNull { it.pcId == request.actorPcId }?.id
        var pcs = current.pcs
        var combatants = encounter.combatants
        val target = combatants.firstOrNull { it.id == targetId } ?: return@mutate current
        if (target.pcId != null) {
            val pcBefore = pcs.firstOrNull { it.id == target.pcId }
            if (pcBefore != null) {
                val delta = if (request.healing) amount else -amount
                var pcAfter = applyPcHpDelta(pcBefore, delta, encounter.active)
                if (effectName.isNotBlank()) pcAfter = pcAfter.copy(conditions = pcAfter.conditions + conditionFromPreset(effectName, sourceId, true, true))
                pcs = pcs.map { if (it.id == pcAfter.id) pcAfter else it }
                combatants = syncPcIntoEncounter(encounter.copy(combatants = combatants), pcAfter).combatants
            }
        } else {
            combatants = combatants.map { c -> if (c.id != targetId) c else {
                val nextHp = if (request.healing) (c.hp + amount).coerceAtMost(c.maxHp) else (c.hp - amount).coerceAtLeast(0)
                val nextConditions = if (effectName.isBlank()) c.conditions else c.conditions + conditionFromPreset(effectName, sourceId, true, true)
                c.copy(hp = nextHp, defeated = nextHp <= 0, conditions = nextConditions)
            } }
        }
        val requests = encounter.ruleRequests.map { if (it.id == requestId) it.copy(consequenceApplied = true) else it }
        current.copy(pcs = pcs, encounter = encounter.copy(combatants = combatants, ruleRequests = requests))
    }

    @Synchronized
    fun dismissRuleRequest(requestId: String) = mutate("Rule request dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(ruleRequests = encounter.ruleRequests.map { request ->
            if (request.id == requestId && request.status != RuleRequestStatus.DISMISSED) request.copy(status = RuleRequestStatus.DISMISSED) else request
        }))
    }

    @Synchronized
    fun toggleCondition(pcId: String, name: String, value: Int? = null) {
        val trimmed = name.trim().take(40)
        if (trimmed.isBlank()) return
        mutate("Condition: $trimmed", logEncounter = _state.value.encounter != null) { current ->
            val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
            val existing = pc.conditions.firstOrNull { it.name.equals(trimmed, ignoreCase = true) }
            val nextConditions = if (existing != null) {
                pc.conditions.filterNot { it.id == existing.id }
            } else {
                val sourceId = current.encounter?.currentCombatant()?.id
                pc.conditions + conditionFromPreset(
                    name = trimmed,
                    sourceCombatantId = sourceId,
                    publicToPlayers = true,
                    partyInflicted = false,
                    valueOverride = value,
                )
            }
            val updated = pc.copy(conditions = nextConditions)
            current.copy(
                pcs = current.pcs.map { if (it.id == pcId) updated else it },
                encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
            )
        }
    }

    @Synchronized
    fun setPcConditionValue(pcId: String, name: String, value: Int) {
        mutate("$name ${value.coerceAtLeast(0)}", logEncounter = _state.value.encounter != null) { current ->
            val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
            val existing = pc.conditions.firstOrNull { it.name.equals(name, true) }
            val next = if (value <= 0) {
                pc.conditions.filterNot { it.name.equals(name, true) }
            } else if (existing != null) {
                pc.conditions.map { if (it.id == existing.id) it.copy(value = value) else it }
            } else {
                pc.conditions + conditionFromPreset(
                    name = name,
                    sourceCombatantId = current.encounter?.currentCombatant()?.id,
                    publicToPlayers = true,
                    partyInflicted = false,
                    valueOverride = value,
                )
            }
            val updated = pc.copy(conditions = next)
            current.copy(
                pcs = current.pcs.map { if (it.id == pcId) updated else it },
                encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
            )
        }
    }

    @Synchronized
    fun updatePrep(prep: SessionPrep) = mutate("Session prep saved") { it.copy(prep = prep) }

    @Synchronized
    fun updatePrepNotes(
        sessionTitle: String,
        openingScene: String,
        objectives: String,
        locations: String,
        referenceNotes: String,
        lootSuggestions: String,
        encounterNotes: String,
        gmNotes: String,
    ) = mutate("Session prep saved") { current ->
        current.copy(prep = current.prep.copy(
            sessionTitle = sessionTitle,
            openingScene = openingScene,
            objectives = objectives,
            locations = locations,
            referenceNotes = referenceNotes,
            lootSuggestions = lootSuggestions,
            encounterNotes = encounterNotes,
            gmNotes = gmNotes,
        ))
    }

    @Synchronized
    fun importSessionPrep(incoming: SessionPrep, strategy: String) = mutate("Session prep imported") { current ->
        val existing = current.prep
        val next = when (strategy) {
            ImportStrategy.REPLACE -> incoming.copy(pinnedPrepKeys = existing.pinnedPrepKeys)
            ImportStrategy.COPY -> existing.copy(
                openingScene = appendImportedText(existing.openingScene, incoming.openingScene, incoming.sessionTitle),
                objectives = appendImportedText(existing.objectives, incoming.objectives, incoming.sessionTitle),
                locations = appendImportedText(existing.locations, incoming.locations, incoming.sessionTitle),
                referenceNotes = appendImportedText(existing.referenceNotes, incoming.referenceNotes, incoming.sessionTitle),
                lootSuggestions = appendImportedText(existing.lootSuggestions, incoming.lootSuggestions, incoming.sessionTitle),
                gmNotes = appendImportedText(existing.gmNotes, incoming.gmNotes, incoming.sessionTitle),
                encounterNotes = appendImportedText(existing.encounterNotes, incoming.encounterNotes, incoming.sessionTitle),
                enemyLibrary = existing.enemyLibrary + incoming.enemyLibrary.map { ContentPackageCodec.copyEnemy(it) },
                preparedEncounters = existing.preparedEncounters + incoming.preparedEncounters.map { prepared ->
                    prepared.copy(
                        id = UUID.randomUUID().toString(),
                        name = "${prepared.name} (Imported)",
                        enemies = prepared.enemies.map { it.copy(id = UUID.randomUUID().toString()) },
                    )
                },
            )
            ImportStrategy.MERGE -> existing.copy(
                sessionTitle = if (incoming.sessionTitle.isNotBlank()) incoming.sessionTitle else existing.sessionTitle,
                openingScene = appendImportedText(existing.openingScene, incoming.openingScene, incoming.sessionTitle),
                objectives = appendImportedText(existing.objectives, incoming.objectives, incoming.sessionTitle),
                locations = appendImportedText(existing.locations, incoming.locations, incoming.sessionTitle),
                referenceNotes = appendImportedText(existing.referenceNotes, incoming.referenceNotes, incoming.sessionTitle),
                lootSuggestions = appendImportedText(existing.lootSuggestions, incoming.lootSuggestions, incoming.sessionTitle),
                gmNotes = appendImportedText(existing.gmNotes, incoming.gmNotes, incoming.sessionTitle),
                encounterNotes = appendImportedText(existing.encounterNotes, incoming.encounterNotes, incoming.sessionTitle),
                enemyLibrary = mergeEnemies(existing.enemyLibrary, incoming.enemyLibrary, replaceConflicts = true),
                preparedEncounters = mergePreparedEncounters(existing.preparedEncounters, incoming.preparedEncounters, replaceConflicts = true),
            )
            else -> existing.copy(
                enemyLibrary = mergeEnemies(existing.enemyLibrary, incoming.enemyLibrary, replaceConflicts = false),
                preparedEncounters = mergePreparedEncounters(existing.preparedEncounters, incoming.preparedEncounters, replaceConflicts = false),
            )
        }
        current.copy(prep = next)
    }

    @Synchronized
    fun importEnemies(incoming: List<PreparedEnemy>, strategy: String) = mutate("Enemy library imported") { current ->
        val existing = current.prep.enemyLibrary
        val merged = when (strategy) {
            ImportStrategy.COPY -> existing + incoming.map { ContentPackageCodec.copyEnemy(it) }
            ImportStrategy.REPLACE -> {
                val names = incoming.map { it.name.trim().lowercase() }.toSet()
                existing.filterNot { it.name.trim().lowercase() in names } + incoming
            }
            ImportStrategy.MERGE -> mergeEnemies(existing, incoming, replaceConflicts = true)
            else -> mergeEnemies(existing, incoming, replaceConflicts = false)
        }
        current.copy(prep = current.prep.copy(enemyLibrary = merged))
    }

    @Synchronized
    fun importLoot(incoming: List<LootItem>, strategy: String) = mutate("Loot imported") { current ->
        val validPcIds = current.pcs.map { it.id }.toSet()
        val normalized = incoming.map { item ->
            item.copy(assignedToPcId = item.assignedToPcId?.takeIf { it in validPcIds })
        }
        val existing = current.partyLoot
        val merged = when (strategy) {
            ImportStrategy.COPY -> existing + ContentPackageCodec.copyLootPack(normalized)
            ImportStrategy.REPLACE -> {
                val names = normalized.map { it.name.trim().lowercase() }.toSet()
                existing.filterNot { it.name.trim().lowercase() in names } + normalized
            }
            ImportStrategy.MERGE -> mergeLoot(existing, normalized, replaceConflicts = true)
            else -> mergeLoot(existing, normalized, replaceConflicts = false)
        }
        current.copy(partyLoot = merged)
    }

    @Synchronized
    fun togglePrepPin(key: String) = mutate("Prep pin updated") { current ->
        val pins = current.prep.pinnedPrepKeys
        val next = if (key in pins) pins.filterNot { it == key } else pins + key
        current.copy(prep = current.prep.copy(pinnedPrepKeys = next.distinct()))
    }

    @Synchronized
    fun clearPrepPins() = mutate("Prep pins cleared") { current ->
        current.copy(prep = current.prep.copy(pinnedPrepKeys = emptyList()))
    }

    @Synchronized
    fun saveEnemyToLibrary(enemy: PreparedEnemy) = mutate("Enemy saved to library") { current ->
        current.copy(prep = current.prep.copy(enemyLibrary = current.prep.enemyLibrary + enemy.copy(quantity = 1)))
    }

    @Synchronized
    fun deleteEnemyFromLibrary(enemyId: String) = mutate("Enemy removed from library") { current ->
        current.copy(prep = current.prep.copy(
            enemyLibrary = current.prep.enemyLibrary.filterNot { it.id == enemyId },
            pinnedPrepKeys = current.prep.pinnedPrepKeys.filterNot { it == "enemy:$enemyId" },
        ))
    }

    @Synchronized
    fun savePreparedEncounter(encounter: PreparedEncounter) = mutate("Prepared encounter saved") { current ->
        val withoutOld = current.prep.preparedEncounters.filterNot { it.id == encounter.id }
        current.copy(prep = current.prep.copy(preparedEncounters = withoutOld + encounter))
    }

    @Synchronized
    fun deletePreparedEncounter(encounterId: String) = mutate("Prepared encounter removed") { current ->
        current.copy(prep = current.prep.copy(
            preparedEncounters = current.prep.preparedEncounters.filterNot { it.id == encounterId },
            pinnedPrepKeys = current.prep.pinnedPrepKeys.filterNot { it == "encounter:$encounterId" },
        ))
    }

    @Synchronized
    fun duplicatePreparedEncounter(encounterId: String) = mutate("Prepared encounter duplicated") { current ->
        val source = current.prep.preparedEncounters.firstOrNull { it.id == encounterId } ?: return@mutate current
        val copy = source.copy(
            id = UUID.randomUUID().toString(),
            name = "${source.name} Copy",
            enemies = source.enemies.map { it.copy(id = UUID.randomUUID().toString()) },
        )
        current.copy(prep = current.prep.copy(preparedEncounters = current.prep.preparedEncounters + copy))
    }

    @Synchronized
    fun updateScene(sceneName: String) = mutate("Scene changed") {
        it.copy(sceneName = sceneName.trim().ifBlank { "Unnamed Scene" })
    }

    @Synchronized
    fun startQuickEncounter(name: String = "Quick Encounter") = mutate("Encounter started", logEncounter = true) { current ->
        val resetPcs = current.pcs.map { resetEncounterAbilityUses(it.copy(actionEconomy = ActionEconomy(), selectedTargetId = null)) }
        val resetState = current.copy(pcs = resetPcs)
        val partyLevel = averagePartyLevel(resetState.pcs)
        resetState.copy(encounter = newEncounter(
            current = resetState,
            name = name.trim().ifBlank { "Quick Encounter" },
            enemies = emptyList(),
            partyLevel = partyLevel,
            partySize = resetState.pcs.size.coerceAtLeast(1),
        ))
    }

    @Synchronized
    fun startPreparedEncounter(preparedId: String) {
        val prepared = _state.value.prep.preparedEncounters.firstOrNull { it.id == preparedId } ?: return
        mutate("Encounter started: ${prepared.name}", logEncounter = true) { current ->
            val resetPcs = current.pcs.map { resetEncounterAbilityUses(it.copy(actionEconomy = ActionEconomy(), selectedTargetId = null)) }
            val resetState = current.copy(pcs = resetPcs)
            resetState.copy(encounter = newEncounter(
                current = resetState,
                name = prepared.name,
                enemies = prepared.enemies,
                gmNote = prepared.gmNotes,
                startingNotes = prepared.startingNotes,
                partyLevel = prepared.partyLevel,
                partySize = prepared.partySize,
                sourcePreparedEncounterId = prepared.id,
            ))
        }
    }

    @Synchronized
    fun clearEncounter() = mutate("Encounter cleared") { it.copy(encounter = null) }

    @Synchronized
    fun deleteEncounterHistory(historyId: String) = mutate("Encounter history removed") { current ->
        current.copy(completedEncounters = current.completedEncounters.filterNot { it.id == historyId })
    }

    @Synchronized
    fun addQuickEnemy(
        name: String,
        maxHp: Int,
        level: Int? = null,
        initiativeModifier: Int = 0,
        quantity: Int = 1,
        gmNote: String = "",
        armorClass: Int? = null,
        fortitude: Int? = null,
        reflex: Int? = null,
        will: Int? = null,
        kind: String = "enemy",
    ) {
        val cleanName = name.trim().ifBlank { "Enemy" }.take(50)
        val qty = quantity.coerceIn(1, 20)
        mutate("Added $cleanName ×$qty", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val group = UUID.randomUUID().toString()
            val additions = (1..qty).map { index ->
                Combatant(
                    name = if (qty == 1) cleanName else "$cleanName $index",
                    kind = kind,
                    level = level,
                    initiativeModifier = initiativeModifier,
                    hp = maxHp.coerceAtLeast(1),
                    maxHp = maxHp.coerceAtLeast(1),
                    armorClass = armorClass,
                    fortitude = fortitude,
                    reflex = reflex,
                    will = will,
                    gmNote = gmNote,
                    groupKey = group,
                )
            }
            current.copy(encounter = encounter.copy(combatants = encounter.combatants + additions))
        }
    }

    @Synchronized
    fun addEnemyFromLibrary(enemyId: String, quantity: Int = 1) {
        val source = _state.value.prep.enemyLibrary.firstOrNull { it.id == enemyId } ?: return
        val enemy = adjustedPreparedEntry(source)
        addQuickEnemy(
            enemy.name, enemy.maxHp, enemy.level, enemy.initiativeModifier, quantity, enemy.gmNotes,
            enemy.armorClass, enemy.fortitude, enemy.reflex, enemy.will,
            kind = when (source.kind) {
                "Hazard" -> "hazard"
                "NPC" -> "npc"
                else -> "enemy"
            },
        )
    }

    @Synchronized
    fun setInitiative(combatantId: String, value: Int, source: String = "GM") {
        mutate("Initiative set", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val changed = encounter.combatants.map {
                if (it.id == combatantId) it.copy(initiative = value, initiativeSource = source) else it
            }
            val sorted = stableInitiativeSort(changed)
            val newIndex = currentId?.let { id -> sorted.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
            current.copy(encounter = encounter.copy(combatants = sorted, turnIndex = newIndex.coerceAtLeast(0)))
        }
    }

    @Synchronized
    fun rollInitiative(combatantId: String) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val result = Random.nextInt(1, 21) + combatant.initiativeModifier
        setInitiative(combatantId, result, "Digital roll")
    }

    @Synchronized
    fun setGroupInitiative(groupKey: String, value: Int, source: String = "GM group") {
        mutate("Group initiative set", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val changed = encounter.combatants.map {
                if (it.groupKey == groupKey) it.copy(initiative = value, initiativeSource = source) else it
            }
            val sorted = stableInitiativeSort(changed)
            val newIndex = currentId?.let { id -> sorted.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
            current.copy(encounter = encounter.copy(combatants = sorted, turnIndex = newIndex.coerceAtLeast(0)))
        }
    }

    @Synchronized
    fun rollGroupInitiative(groupKey: String) {
        val group = _state.value.encounter?.combatants?.filter { it.groupKey == groupKey }.orEmpty()
        val first = group.firstOrNull() ?: return
        val result = Random.nextInt(1, 21) + first.initiativeModifier
        setGroupInitiative(groupKey, result, "Digital group roll")
    }

    @Synchronized
    fun submitPlayerInitiative(pcId: String, value: Int, source: String) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.pcId == pcId } ?: return
        setInitiative(combatant.id, value, source)
    }

    @Synchronized
    fun moveCombatant(combatantId: String, delta: Int) {
        mutate("Initiative order adjusted", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val oldIndex = encounter.combatants.indexOfFirst { it.id == combatantId }
            if (oldIndex < 0) return@mutate current
            val newIndex = (oldIndex + delta).coerceIn(0, encounter.combatants.lastIndex.coerceAtLeast(0))
            if (newIndex == oldIndex) return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val mutable = encounter.combatants.toMutableList()
            val item = mutable.removeAt(oldIndex)
            mutable.add(newIndex, item)
            val turn = currentId?.let { id -> mutable.indexOfFirst { it.id == id } }?.takeIf { it >= 0 } ?: 0
            current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = turn))
        }
    }

    @Synchronized
    fun nextTurn() {
        val snapshot = _state.value
        val encounter = snapshot.encounter ?: return
        if (!encounter.active || encounter.combatants.isEmpty()) return
        if (encounter.combatants.any { it.initiative == null }) return
        if (encounter.pendingEffectChecks.isNotEmpty()) return
        val currentActor = encounter.currentCombatant() ?: return
        if (encounter.ruleRequests.any { request -> request.actorPcId == currentActor.pcId && (request.status == RuleRequestStatus.PENDING || (request.status == RuleRequestStatus.RESOLVED && !request.consequenceApplied && (request.damageFormula.isNotBlank() || listOf(request.effectCriticalSuccess, request.effectSuccess, request.effectFailure, request.effectCriticalFailure).any { it.isNotBlank() }))) }) return
        val currentName = currentActor.name

        mutate("Turn ended: $currentName", logEncounter = true) { current ->
            val activeEncounter = current.encounter ?: return@mutate current
            val actor = activeEncounter.currentCombatant() ?: return@mutate current

            val endProcessed = processEffectPhase(
                pcs = current.pcs,
                encounter = activeEncounter,
                actorId = actor.id,
                phase = EffectPhase.END,
            )

            if (endProcessed.encounter.pendingEffectChecks.isNotEmpty()) {
                return@mutate current.copy(
                    pcs = endProcessed.pcs,
                    encounter = endProcessed.encounter.copy(pendingTurnAdvance = true),
                )
            }

            val advanced = advanceEncounterTurn(current.copy(pcs = endProcessed.pcs), endProcessed.encounter)
            advanced
        }
    }

    @Synchronized
    fun previousTurn() = mutate("Previous turn", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.combatants.isEmpty()) return@mutate current
        val wraps = encounter.turnIndex <= 0
        current.copy(encounter = encounter.copy(
            turnIndex = if (wraps) encounter.combatants.lastIndex else encounter.turnIndex - 1,
            round = if (wraps) (encounter.round - 1).coerceAtLeast(1) else encounter.round,
        ))
    }

    @Synchronized
    fun delayCurrent() {
        val name = _state.value.encounter?.currentCombatant()?.name ?: return
        mutate("$name delayed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            if (encounter.combatants.size < 2) return@mutate current
            val index = encounter.turnIndex.coerceIn(0, encounter.combatants.lastIndex)
            val mutable = encounter.combatants.toMutableList()
            val delayed = mutable.removeAt(index).copy(delayed = true)
            mutable.add(delayed)
            val nextIndex = index.coerceAtMost(mutable.lastIndex)
            current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = nextIndex))
        }
    }

    @Synchronized
    fun resumeDelayed(combatantId: String) = mutate("Delayed combatant resumed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val oldIndex = encounter.combatants.indexOfFirst { it.id == combatantId && it.delayed }
        if (oldIndex < 0) return@mutate current
        val mutable = encounter.combatants.toMutableList()
        val combatant = mutable.removeAt(oldIndex).copy(delayed = false)
        val target = encounter.turnIndex.coerceIn(0, mutable.size)
        mutable.add(target, combatant)
        current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = target))
    }

    @Synchronized
    fun setReadyDetails(combatantId: String, action: String, trigger: String) = mutate("Ready action set", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId) it.copy(readyAction = action.trim().take(120), readyTrigger = trigger.trim().take(120)) else it
        }))
    }

    @Synchronized
    fun clearReadyDetails(combatantId: String) = mutate("Ready action cleared", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId) it.copy(readyAction = "", readyTrigger = "") else it
        }))
    }

    @Synchronized
    fun combatantHpDelta(combatantId: String, delta: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        if (combatant.pcId != null) {
            hpDelta(combatant.pcId, delta)
            return
        }
        val label = if (delta < 0) "${combatant.name} took ${-delta} damage" else "${combatant.name} healed $delta"
        mutate(label, logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val next = encounter.combatants.map { c ->
                if (c.id != combatantId) return@map c
                var remaining = delta
                var temp = c.tempHp
                var hp = c.hp
                if (remaining < 0 && temp > 0) {
                    val absorbed = minOf(temp, -remaining)
                    temp -= absorbed
                    remaining += absorbed
                }
                hp = (hp + remaining).coerceIn(0, c.maxHp.coerceAtLeast(1))
                c.copy(hp = hp, tempHp = temp, defeated = hp <= 0)
            }
            current.copy(encounter = encounter.copy(combatants = next))
        }
    }

    @Synchronized
    fun combatantTempHpDelta(combatantId: String, delta: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        if (combatant.pcId != null) {
            tempHpDelta(combatant.pcId, delta)
            return
        }
        mutate("Temp HP: ${combatant.name}", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
                if (it.id == combatantId) it.copy(tempHp = (it.tempHp + delta).coerceAtLeast(0)) else it
            }))
        }
    }

    @Synchronized
    fun addCombatantEffect(
        combatantId: String,
        presetName: String,
        sourceCombatantId: String? = null,
        partyInflicted: Boolean = false,
        valueOverride: Int? = null,
    ) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val cleanName = presetName.trim().take(40)
        if (cleanName.isBlank()) return
        val effect = conditionFromPreset(
            name = cleanName,
            sourceCombatantId = sourceCombatantId ?: _state.value.encounter?.currentCombatant()?.id,
            publicToPlayers = combatant.kind == "pc" || partyInflicted || cleanName in obviousEnemyConditions,
            partyInflicted = partyInflicted,
            valueOverride = valueOverride,
        )
        addEffectToCombatant(combatantId, effect)
    }

    @Synchronized
    fun addCustomEffect(
        combatantId: String,
        name: String,
        value: Int?,
        sourceCombatantId: String?,
        partyInflicted: Boolean,
        timingAnchor: String,
        timingPhase: String,
        remainingTriggers: Int?,
        triggerAction: String,
        checkType: String?,
        checkLabel: String,
        checkDc: Int?,
        successAction: String,
        failureAction: String,
        criticalSuccessAction: String,
        criticalFailureAction: String,
        repeatCheck: Boolean,
    ) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val cleanName = name.trim().take(60)
        if (cleanName.isBlank()) return
        val effect = Condition(
            name = cleanName,
            value = value?.coerceAtLeast(0)?.takeIf { it > 0 },
            publicToPlayers = combatant.kind == "pc" || partyInflicted || cleanName in obviousEnemyConditions,
            partyInflicted = partyInflicted,
            sourceCombatantId = sourceCombatantId,
            timingAnchor = timingAnchor,
            timingPhase = timingPhase,
            remainingTriggers = remainingTriggers?.coerceAtLeast(1),
            triggerAction = triggerAction,
            checkType = checkType,
            checkLabel = checkLabel.trim().take(160),
            checkDc = checkDc?.coerceIn(1, 99),
            checkSuccessAction = successAction,
            checkFailureAction = failureAction,
            checkCriticalSuccessAction = criticalSuccessAction,
            checkCriticalFailureAction = criticalFailureAction,
            repeatCheck = repeatCheck,
        )
        addEffectToCombatant(combatantId, effect)
    }

    @Synchronized
    fun removeCombatantEffect(combatantId: String, effectId: String) {
        mutate("Effect removed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id == combatantId) c.copy(conditions = c.conditions.filterNot { it.id == effectId }) else c
            }
            val cleanedEncounter = encounter.copy(
                combatants = updatedCombatants,
                pendingEffectChecks = encounter.pendingEffectChecks.filterNot { it.effectId == effectId },
            )
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = cleanedEncounter,
            )
        }
    }

    @Synchronized
    fun setCombatantEffectValue(combatantId: String, effectId: String, value: Int) {
        mutate("Effect value changed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id != combatantId) c else c.copy(
                    conditions = if (value <= 0) c.conditions.filterNot { it.id == effectId }
                    else c.conditions.map { effect -> if (effect.id == effectId) effect.copy(value = value) else effect }
                )
            }
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = encounter.copy(
                    combatants = updatedCombatants,
                    pendingEffectChecks = if (value <= 0) encounter.pendingEffectChecks.filterNot { it.effectId == effectId } else encounter.pendingEffectChecks,
                ),
            )
        }
    }

    @Synchronized
    fun toggleCombatantCondition(combatantId: String, name: String, partyInflicted: Boolean = false) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val existing = combatant.conditions.firstOrNull { it.name.equals(name.trim(), true) }
        if (existing != null) removeCombatantEffect(combatantId, existing.id)
        else addCombatantEffect(combatantId, name, partyInflicted = partyInflicted)
    }

    @Synchronized
    fun setCombatantConditionValue(combatantId: String, name: String, value: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val existing = combatant.conditions.firstOrNull { it.name.equals(name, true) }
        if (existing != null) setCombatantEffectValue(combatantId, existing.id, value)
        else if (value > 0) addCombatantEffect(combatantId, name, valueOverride = value)
    }

    @Synchronized
    fun setDefeated(combatantId: String, defeated: Boolean) = mutate(if (defeated) "Combatant defeated" else "Combatant restored", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId && it.kind != "pc") it.copy(defeated = defeated) else it
        }))
    }

    @Synchronized
    fun requestEndTurn(pcId: String) = mutate("End turn requested", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (pcId in encounter.endTurnRequests) current
        else current.copy(encounter = encounter.copy(endTurnRequests = encounter.endTurnRequests + pcId))
    }

    @Synchronized
    fun dismissEndTurnRequest(pcId: String) = mutate("End turn request dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(endTurnRequests = encounter.endTurnRequests.filterNot { it == pcId }))
    }

    @Synchronized
    fun approveEndTurnRequest(pcId: String) {
        val encounter = _state.value.encounter ?: return
        if (encounter.currentCombatant()?.pcId != pcId) {
            dismissEndTurnRequest(pcId)
            return
        }
        dismissEndTurnRequest(pcId)
        nextTurn()
    }

    @Synchronized
    fun dismissEffectCheck(promptId: String) = mutate("Effect check dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val remaining = encounter.pendingEffectChecks.filterNot { it.id == promptId }
        val updated = encounter.copy(pendingEffectChecks = remaining)
        if (remaining.isEmpty() && encounter.pendingTurnAdvance) {
            advanceEncounterTurn(current, updated.copy(pendingTurnAdvance = false))
        } else {
            current.copy(encounter = updated)
        }
    }

    @Synchronized
    fun resolveEffectCheck(promptId: String, outcome: String) = mutate("Effect check resolved", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val prompt = encounter.pendingEffectChecks.firstOrNull { it.id == promptId } ?: return@mutate current
        val action = when (outcome) {
            "criticalSuccess" -> prompt.criticalSuccessAction
            "success" -> prompt.successAction
            "criticalFailure" -> prompt.criticalFailureAction
            else -> prompt.failureAction
        }

        var updatedCombatants = encounter.combatants.map { combatant ->
            if (combatant.id != prompt.targetCombatantId) return@map combatant
            val effect = combatant.conditions.firstOrNull { it.id == prompt.effectId } ?: return@map combatant
            var nextEffect = applyOutcomeToEffect(effect, action)

            // Check-triggered effects can also have a finite number of trigger windows.
            val remainingTriggerCount = nextEffect?.remainingTriggers
            if (nextEffect != null && remainingTriggerCount != null) {
                nextEffect = if (remainingTriggerCount <= 1) null
                else nextEffect.copy(remainingTriggers = remainingTriggerCount - 1)
            }

            var nextConditions = if (nextEffect == null) {
                combatant.conditions.filterNot { it.id == effect.id }
            } else {
                combatant.conditions.map { if (it.id == effect.id) nextEffect else it }
            }

            // Stabilizing from Dying increases Wounded. Keep this GM-overridable via Undo.
            if (effect.name.equals("Dying", true) && nextEffect == null && combatant.pcId != null) {
                val wounded = nextConditions.firstOrNull { it.name.equals("Wounded", true) }
                nextConditions = if (wounded == null) {
                    nextConditions + conditionFromPreset(
                        name = "Wounded",
                        sourceCombatantId = effect.sourceCombatantId,
                        publicToPlayers = true,
                        partyInflicted = false,
                        valueOverride = 1,
                    )
                } else {
                    nextConditions.map { condition ->
                        if (condition.id == wounded.id) condition.copy(value = (condition.value ?: 0) + 1) else condition
                    }
                }
            }

            combatant.copy(conditions = nextConditions)
        }

        if (!prompt.repeatCheck) {
            updatedCombatants = updatedCombatants.map { combatant ->
                if (combatant.id != prompt.targetCombatantId) combatant else combatant.copy(
                    conditions = combatant.conditions.map { effect ->
                        if (effect.id == prompt.effectId) effect.copy(triggerAction = EffectTriggerAction.NONE, timingPhase = EffectPhase.MANUAL)
                        else effect
                    }
                )
            }
        }

        val remaining = encounter.pendingEffectChecks.filterNot { it.id == promptId }
        val baseEncounter = encounter.copy(
            combatants = updatedCombatants,
            pendingEffectChecks = remaining,
        )
        val baseState = current.copy(
            pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
            encounter = baseEncounter,
        )
        if (remaining.isEmpty() && encounter.pendingTurnAdvance) {
            advanceEncounterTurn(baseState, baseEncounter.copy(pendingTurnAdvance = false))
        } else baseState
    }

    @Synchronized
    fun recordPlayerRoll(pcId: String, label: String, result: Int) {
        val name = _state.value.pcs.firstOrNull { it.id == pcId }?.name ?: "Player"
        mutate("$name rolled $label: $result", logEncounter = _state.value.encounter != null) { it }
    }

    @Synchronized
    fun endEncounter() = mutate("Encounter ended • loot draft generated", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.ended) return@mutate current
        val loot = if (encounter.loot.generatedAt == null) LootGenerator.generate(encounter) else encounter.loot
        val finished = encounter.copy(active = false, ended = true, loot = loot)
        val enemyEntries = finished.combatants.filter { it.pcId == null && it.level != null }.map { c ->
            PreparedEnemy(name = c.name, level = c.level, quantity = 1)
        }
        val budget = encounterBudget(enemyEntries, finished.partyLevel, finished.partySize)
        val archive = EncounterHistoryEntry(
            encounterId = finished.id,
            name = finished.name,
            rounds = finished.round,
            partyLevel = finished.partyLevel,
            partySize = finished.partySize,
            totalXp = budget.totalXp,
            difficulty = budget.difficulty,
            defeatedCount = finished.combatants.count { it.pcId == null && it.defeated },
            combatantCount = finished.combatants.count { it.pcId == null },
            history = finished.history.takeLast(80).map { it.label },
        )
        current.copy(
            encounter = finished,
            completedEncounters = current.completedEncounters.filterNot { it.encounterId == finished.id } + archive,
        )
    }

    @Synchronized
    fun generateLoot() = mutate("Loot generated", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = LootGenerator.generate(encounter)))
    }

    @Synchronized
    fun revealLoot() = mutate("Loot revealed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = encounter.loot.copy(revealed = true)))
    }

    @Synchronized
    fun addEncounterLootItem(name: String, category: String = "Treasure", valueGp: Double = 0.0) {
        val clean = name.trim().take(80)
        if (clean.isBlank()) return
        mutate("Loot item added", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(loot = encounter.loot.copy(
                items = encounter.loot.items + LootItem(name = clean, category = category, valueGp = valueGp),
            )))
        }
    }

    @Synchronized
    fun removeEncounterLootItem(itemId: String) = mutate("Loot item removed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = encounter.loot.copy(
            items = encounter.loot.items.filterNot { it.id == itemId },
        )))
    }

    @Synchronized
    fun moveLootToParty() = mutate("Loot moved to party", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.loot.movedToParty) return@mutate current
        val coinItem = if (encounter.loot.coinsGp > 0) {
            listOf(LootItem(name = "${formatGp(encounter.loot.coinsGp)} gp", category = "Coins", valueGp = encounter.loot.coinsGp))
        } else emptyList()
        current.copy(
            partyLoot = current.partyLoot + coinItem + encounter.loot.items,
            encounter = encounter.copy(loot = encounter.loot.copy(movedToParty = true)),
        )
    }

    @Synchronized
    fun assignPartyLoot(itemId: String, pcId: String?) = mutate("Inventory item assigned") { current ->
        current.copy(partyLoot = current.partyLoot.map {
            if (it.id == itemId) it.copy(assignedToPcId = pcId, containerId = null) else it
        })
    }

    @Synchronized
    fun addInventoryItem(
        name: String,
        category: String = "Gear",
        quantity: Int = 1,
        valueGp: Double = 0.0,
        assignedToPcId: String? = null,
        bulk: Double = 0.0,
        consumable: Boolean = false,
        charges: Int? = null,
        traits: String = "",
        runes: String = "",
        level: Int? = null,
        notes: String = "",
        gmNotes: String = "",
        identified: Boolean = true,
        revealedToPlayers: Boolean = true,
        unidentifiedName: String = "Unidentified item",
        capacityBulk: Double? = null,
    ) {
        val clean = name.trim().take(100)
        if (clean.isBlank()) return
        mutate("Inventory item added") { current ->
            current.copy(partyLoot = current.partyLoot + LootItem(
                name = clean,
                category = category.trim().ifBlank { "Gear" }.take(40),
                quantity = quantity.coerceIn(1, 999),
                valueGp = valueGp.coerceAtLeast(0.0),
                assignedToPcId = assignedToPcId?.takeIf { id -> current.pcs.any { it.id == id } },
                bulk = bulk.coerceAtLeast(0.0),
                consumable = consumable,
                charges = charges?.coerceAtLeast(0),
                maxCharges = charges?.coerceAtLeast(0),
                traits = traits.trim().take(300),
                runes = runes.trim().take(500),
                level = level?.coerceIn(0, 30),
                notes = notes.trim().take(1200),
                gmNotes = gmNotes.trim().take(1200),
                identified = identified,
                revealedToPlayers = revealedToPlayers,
                unidentifiedName = unidentifiedName.trim().ifBlank { "Unidentified item" }.take(100),
                capacityBulk = capacityBulk?.coerceAtLeast(0.0),
            ))
        }
    }

    @Synchronized
    fun updateInventoryItem(itemId: String, payload: JSONObject) = mutate("Inventory item updated") { current ->
        val validPcId = payload.optString("assignedToPcId").takeIf { id -> id.isNotBlank() && current.pcs.any { it.id == id } }
        current.copy(partyLoot = current.partyLoot.map { item ->
            if (item.id != itemId) item else item.copy(
                name = payload.optString("name", item.name).trim().ifBlank { item.name }.take(100),
                category = payload.optString("category", item.category).trim().ifBlank { item.category }.take(40),
                quantity = payload.optInt("quantity", item.quantity).coerceIn(1, 999),
                valueGp = payload.optDouble("valueGp", item.valueGp).coerceAtLeast(0.0),
                notes = payload.optString("notes", item.notes).trim().take(1200),
                assignedToPcId = if (payload.has("assignedToPcId")) validPcId else item.assignedToPcId,
                revealedToPlayers = payload.optBoolean("revealedToPlayers", item.revealedToPlayers),
                identified = payload.optBoolean("identified", item.identified),
                unidentifiedName = payload.optString("unidentifiedName", item.unidentifiedName).trim().ifBlank { "Unidentified item" }.take(100),
                level = if (payload.has("level") && !payload.isNull("level")) payload.optInt("level").coerceIn(0, 30) else item.level,
                traits = payload.optString("traits", item.traits).trim().take(300),
                runes = payload.optString("runes", item.runes).trim().take(500),
                bulk = payload.optDouble("bulk", item.bulk).coerceAtLeast(0.0),
                carryState = payload.optString("carryState", item.carryState).take(30),
                consumable = payload.optBoolean("consumable", item.consumable),
                charges = if (payload.has("charges") && !payload.isNull("charges")) payload.optInt("charges").coerceAtLeast(0) else item.charges,
                maxCharges = if (payload.has("maxCharges") && !payload.isNull("maxCharges")) payload.optInt("maxCharges").coerceAtLeast(0) else item.maxCharges,
                containerId = if (payload.has("containerId")) payload.optString("containerId").takeIf { id -> id.isNotBlank() && id != item.id && current.partyLoot.any { it.id == id && it.category.equals("Container", true) } } else item.containerId,
                capacityBulk = if (payload.has("capacityBulk") && !payload.isNull("capacityBulk")) payload.optDouble("capacityBulk").coerceAtLeast(0.0) else item.capacityBulk,
                gmNotes = payload.optString("gmNotes", item.gmNotes).trim().take(1200),
            )
        })
    }

    @Synchronized
    fun toggleInventoryReveal(itemId: String) = mutate("Inventory visibility changed") { current ->
        current.copy(partyLoot = current.partyLoot.map { if (it.id == itemId) it.copy(revealedToPlayers = !it.revealedToPlayers) else it })
    }

    @Synchronized
    fun toggleInventoryIdentified(itemId: String) = mutate("Item identification changed") { current ->
        current.copy(partyLoot = current.partyLoot.map { if (it.id == itemId) it.copy(identified = !it.identified) else it })
    }

    @Synchronized
    fun setInventoryCarryState(itemId: String, pcId: String, carryState: String) = mutate("Inventory state changed") { current ->
        current.copy(partyLoot = current.partyLoot.map { item ->
            if (item.id == itemId && item.assignedToPcId == pcId) item.copy(carryState = carryState.take(30)) else item
        })
    }

    @Synchronized
    fun setInventoryContainer(itemId: String, pcId: String, containerId: String?) = mutate("Inventory container changed") { current ->
        val ownedItem = current.partyLoot.firstOrNull { it.id == itemId && it.assignedToPcId == pcId }
            ?: return@mutate current
        val validContainer = containerId?.takeIf { cid ->
            cid != ownedItem.id &&
                current.partyLoot.any { it.id == cid && it.assignedToPcId == pcId && it.category.equals("Container", true) } &&
                !wouldCreateContainerCycle(current.partyLoot, ownedItem.id, cid)
        }
        current.copy(partyLoot = current.partyLoot.map { item ->
            if (item.id == itemId && item.assignedToPcId == pcId) item.copy(containerId = validContainer) else item
        })
    }

    private fun wouldCreateContainerCycle(items: List<LootItem>, itemId: String, candidateContainerId: String): Boolean {
        var cursor: String? = candidateContainerId
        val visited = mutableSetOf<String>()
        while (cursor != null && visited.add(cursor)) {
            if (cursor == itemId) return true
            cursor = items.firstOrNull { it.id == cursor }?.containerId
        }
        return false
    }

    @Synchronized
    fun useInventoryItem(itemId: String, pcId: String) = mutate("Inventory item used") { current ->
        current.copy(partyLoot = current.partyLoot.mapNotNull { item ->
            if (item.id != itemId || item.assignedToPcId != pcId || !item.consumable) return@mapNotNull item
            val max = item.maxCharges ?: item.charges ?: 1
            val currentCharges = item.charges ?: max
            when {
                currentCharges > 1 -> item.copy(charges = currentCharges - 1)
                item.quantity > 1 -> item.copy(quantity = item.quantity - 1, charges = max)
                else -> item.copy(charges = 0)
            }
        })
    }

    @Synchronized
    fun removePartyLoot(itemId: String) = mutate("Inventory item removed") { current ->
        current.copy(partyLoot = current.partyLoot.filterNot { it.id == itemId }.map { if (it.containerId == itemId) it.copy(containerId = null) else it })
    }

    @Synchronized
    fun applyPlayerRequest(requestId: String, block: () -> Unit): Boolean {
        if (requestId.isBlank() || requestId in processedRequestIds) return false
        processedRequestIds += requestId
        while (processedRequestIds.size > 500) {
            val first = processedRequestIds.firstOrNull() ?: break
            processedRequestIds.remove(first)
        }
        block()
        return true
    }

    @Synchronized
    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        val previous = undoStack.removeLast()
        val restoredBase = previous.state
        val restoredEncounter = restoredBase.encounter?.let { encounter ->
            encounter.copy(history = (encounter.history + CombatLogEntry(label = "Undo: ${previous.label}")).takeLast(250))
        }
        val restored = restoredBase.copy(
            encounter = restoredEncounter,
            revision = _state.value.revision + 1,
            lastEventLabel = "Undo: ${previous.label}",
        )
        _state.value = restored
        persist(restored)
        maybeAutoBackup(restored)
        return true
    }

    fun canUndo(): Boolean = synchronized(this) { undoStack.isNotEmpty() }

    fun publicLobbyJson(): String {
        val current = _state.value
        return JSONObject().apply {
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("revision", current.revision)
            put("pcs", JSONArray().apply {
                current.pcs.forEach { pc ->
                    put(JSONObject().apply {
                        put("id", pc.id)
                        put("name", pc.name)
                        put("ancestry", pc.ancestry)
                        put("heritage", pc.heritage)
                        put("background", pc.background)
                        put("characterClass", pc.characterClass)
                        put("level", pc.level ?: JSONObject.NULL)
                    })
                }
            })
        }.toString()
    }

    fun displaySnapshotJson(): String {
        val current = _state.value
        val encounter = current.encounter
        val currentCombatant = encounter?.currentCombatant()
        return JSONObject().apply {
            put("type", "displaySnapshot")
            put("revision", current.revision)
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("encounter", if (encounter == null) JSONObject.NULL else JSONObject().apply {
                put("name", encounter.name)
                put("active", encounter.active)
                put("ended", encounter.ended)
                put("round", encounter.round)
                put("currentName", currentCombatant?.name ?: JSONObject.NULL)
                put("initiative", JSONArray().apply {
                    encounter.combatants.forEach { combatant ->
                        put(JSONObject().apply {
                            put("name", combatant.name)
                            put("kind", combatant.kind)
                            put("current", combatant.id == currentCombatant?.id)
                            put("defeated", combatant.defeated)
                            put("initiative", combatant.initiative ?: JSONObject.NULL)
                        })
                    }
                })
                put("enemies", JSONArray().apply {
                    encounter.combatants.filter { it.kind != "pc" }.forEach { enemy ->
                        put(JSONObject().apply {
                            put("name", enemy.name)
                            put("health", healthState(enemy))
                            put("defeated", enemy.defeated)
                            put("conditions", JSONArray().apply {
                                enemy.conditions.filter { it.publicToPlayers || it.partyInflicted }.forEach { condition ->
                                    put(condition.toJson())
                                }
                            })
                        })
                    }
                })
            })
            put("party", JSONArray().apply {
                current.pcs.forEach { pc ->
                    put(JSONObject().apply {
                        put("name", pc.name)
                        put("hp", pc.hp)
                        put("maxHp", pc.maxHp)
                        put("tempHp", pc.tempHp)
                        put("conditions", JSONArray().apply {
                            pc.conditions.filter { it.publicToPlayers }.forEach { put(it.toJson()) }
                        })
                    })
                }
            })
        }.toString()
    }

    fun fullCampaignJson(): String = SessionCodec.encode(_state.value)

    @Synchronized
    fun restoreFullCampaign(raw: String): Boolean = runCatching {
        val incomingSchema = SessionCodec.detectSchemaVersion(raw)
        require(incomingSchema <= SessionCodec.CURRENT_SCHEMA_VERSION) { "Backup schema $incomingSchema is newer than this app supports" }
        val restoredRaw = SessionCodec.decode(raw)
        writeBackup("before-import", _state.value)
        val restored = restoredRaw.copy(
            revision = _state.value.revision + 1,
            lastEventLabel = "Full campaign restored",
        )
        undoStack.addLast(StateSnapshot(_state.value, "Full campaign restore"))
        _state.value = restored
        persist(restored)
        maybeAutoBackup(restored, force = true)
        true
    }.onFailure { lastPersistenceError = "Full restore failed: ${it.message ?: "unknown error"}" }.getOrDefault(false)

    fun playerSnapshotJson(pcId: String): String {
        val current = _state.value
        val ownPc = current.pcs.firstOrNull { it.id == pcId }
        return JSONObject().apply {
            put("type", "snapshot")
            put("revision", current.revision)
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("lastEventLabel", current.lastEventLabel ?: JSONObject.NULL)
            put("you", ownPc?.toPublicJson() ?: JSONObject.NULL)
            put("inventory", JSONArray().apply { current.partyLoot.filter { it.assignedToPcId == pcId && it.revealedToPlayers }.forEach { item -> put(item.toPlayerJson(current.partyLoot)) } })
            put("sharedLoot", JSONArray().apply { current.partyLoot.filter { it.assignedToPcId == null && it.revealedToPlayers }.forEach { item -> put(item.toPlayerJson(current.partyLoot)) } })
            put("library", JSONArray().apply { rulesLibraryEntries.forEach { entry -> put(entry.toPlayerJson(ownPc)) } })
            put("party", JSONArray().apply { current.pcs.forEach { put(it.toPartyJson()) } })
            put("encounter", current.encounter?.toPlayerJson(pcId) ?: JSONObject.NULL)
        }.toString()
    }

    fun exportBackup(): File = writeBackup("manual", _state.value)

    fun listBackups(): List<File> = backupDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("json", true) }
        ?.sortedByDescending { it.lastModified() }
        .orEmpty()

    fun backupSummaries(): List<BackupSummary> = listBackups().map { file ->
        runCatching {
            val restored = SessionCodec.decode(file.readText())
            BackupSummary(
                fileName = file.name,
                timestamp = file.lastModified(),
                sizeBytes = file.length(),
                revision = restored.revision,
                campaignName = restored.campaignName,
                sceneName = restored.sceneName,
                encounterName = restored.encounter?.name,
                valid = true,
            )
        }.getOrElse {
            BackupSummary(
                fileName = file.name,
                timestamp = file.lastModified(),
                sizeBytes = file.length(),
                revision = -1,
                campaignName = "Unreadable backup",
                sceneName = "",
                encounterName = null,
                valid = false,
            )
        }
    }

    fun diagnostics(): StoreDiagnostics {
        val healthy = runCatching {
            sessionFile.exists() && SessionCodec.decode(sessionFile.readText()).pcs.isNotEmpty()
        }.getOrDefault(false)
        return StoreDiagnostics(
            saveHealthy = healthy,
            sessionRevision = _state.value.revision,
            lastPersistAt = lastPersistAt,
            lastBackupAt = listBackups().firstOrNull()?.lastModified() ?: 0L,
            backupCount = listBackups().size,
            recoveryMessage = recoveryMessage,
            lastPersistenceError = lastPersistenceError,
            schemaVersion = SessionCodec.CURRENT_SCHEMA_VERSION,
        )
    }

    fun runIntegrityCheck(): Boolean = diagnostics().saveHealthy

    @Synchronized
    fun restoreBackup(file: File): Boolean = runCatching {
        val decoded = SessionCodec.decode(file.readText())
        writeBackup("before-restore", _state.value)
        val restored = decoded.copy(
            revision = _state.value.revision + 1,
            lastEventLabel = "Backup restored",
        )
        undoStack.addLast(StateSnapshot(_state.value, "Restore backup"))
        _state.value = restored
        persist(restored)
        maybeAutoBackup(restored, force = true)
        true
    }.onFailure { lastPersistenceError = "Restore failed: ${it.message ?: "unknown error"}" }.getOrDefault(false)

    @Synchronized
    fun restoreBackupByName(fileName: String): Boolean {
        val file = listBackups().firstOrNull { it.name == fileName } ?: return false
        return restoreBackup(file)
    }

    @Synchronized
    fun recoverLastKnownGood(): Boolean {
        if (!lastGoodFile.exists()) return false
        return runCatching {
            val restored = SessionCodec.decode(lastGoodFile.readText()).copy(
                revision = _state.value.revision + 1,
                lastEventLabel = "Recovered last known-good save",
            )
            undoStack.addLast(StateSnapshot(_state.value, "Recover last known-good"))
            _state.value = restored
            persist(restored)
            recoveryMessage = "Recovered the last known-good campaign save."
            maybeAutoBackup(restored, force = true)
            true
        }.onFailure { lastPersistenceError = "Recovery failed: ${it.message ?: "unknown error"}" }.getOrDefault(false)
    }

    private data class EffectProcessingResult(
        val pcs: List<PlayerCharacter>,
        val encounter: EncounterState,
    )

    private fun saveRequest(pc: PlayerCharacter, spellName: String, target: Combatant, saveName: String, modifier: Int?, spell: SpellEntry): RuleRequest = RuleRequest(
        actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name,
        type = RuleRequestType.SAVE, label = "$spellName • $saveName save",
        modifier = modifier, dc = pc.spellcasting.spellDc.takeIf { it > 0 }, dcLabel = "Spell DC",
        notes = if (modifier == null) "$saveName modifier is not entered; resolve manually." else "$saveName modifier ${signed(modifier)}",
        damageFormula = spell.damage, damageType = spell.damageType, basicSave = spell.basicSave, healing = spell.healing,
        effectCriticalSuccess = spell.effectCriticalSuccess, effectSuccess = spell.effectSuccess, effectFailure = spell.effectFailure, effectCriticalFailure = spell.effectCriticalFailure,
    )

    private fun abilitySaveRequest(pc: PlayerCharacter, ability: AbilityEntry, target: Combatant, saveName: String, modifier: Int?): RuleRequest = RuleRequest(
        actorPcId = pc.id, actorName = pc.name, targetCombatantId = target.id, targetName = target.name, type = RuleRequestType.SAVE,
        label = "${ability.name} • $saveName save", modifier = modifier, dc = pc.stats.classDc.takeIf { it > 0 } ?: pc.spellcasting.spellDc.takeIf { it > 0 }, dcLabel = "DC",
        notes = if (modifier == null) "$saveName modifier is not entered; resolve manually." else "$saveName modifier ${signed(modifier)}",
        damageFormula = ability.damage, damageType = ability.damageType, basicSave = ability.basicSave, healing = ability.healing,
        effectCriticalSuccess = ability.effectCriticalSuccess, effectSuccess = ability.effectSuccess, effectFailure = ability.effectFailure, effectCriticalFailure = ability.effectCriticalFailure,
    )

    private fun rollFormula(formula: String): Int? {
        val clean = formula.trim().lowercase()
        if (clean.isBlank()) return null
        clean.toIntOrNull()?.let { return it.coerceAtLeast(0) }
        val match = Regex("""(\d*)d(\d+)([+-]\d+)?""").find(clean) ?: return null
        val count = match.groupValues[1].ifBlank { "1" }.toIntOrNull()?.coerceIn(1, 100) ?: return null
        val sides = match.groupValues[2].toIntOrNull()?.coerceIn(2, 1000) ?: return null
        val bonus = match.groupValues[3].toIntOrNull() ?: 0
        return ((1..count).sumOf { Random.nextInt(1, sides + 1) } + bonus).coerceAtLeast(0)
    }

    private fun consequenceAmount(base: Int, outcome: String, basicSave: Boolean): Int = if (basicSave) {
        when (outcome) {
            DegreeOfSuccess.CRITICAL_SUCCESS -> 0
            DegreeOfSuccess.SUCCESS -> base / 2
            DegreeOfSuccess.FAILURE -> base
            DegreeOfSuccess.CRITICAL_FAILURE -> base * 2
            else -> 0
        }
    } else {
        when (outcome) {
            DegreeOfSuccess.CRITICAL_SUCCESS -> base * 2
            DegreeOfSuccess.SUCCESS -> base
            else -> 0
        }
    }

    private fun mapPenalty(attacksThisTurn: Int, agile: Boolean): Int = when {
        attacksThisTurn <= 0 -> 0
        attacksThisTurn == 1 -> if (agile) -4 else -5
        else -> if (agile) -8 else -10
    }

    private fun signed(value: Int): String = if (value >= 0) "+$value" else value.toString()

    private fun degreeOfSuccess(total: Int, dc: Int, natural: Int): String {
        val base = when {
            total >= dc + 10 -> 3
            total >= dc -> 2
            total <= dc - 10 -> 0
            else -> 1
        }
        val shifted = (base + when (natural) { 20 -> 1; 1 -> -1; else -> 0 }).coerceIn(0, 3)
        return when (shifted) {
            3 -> DegreeOfSuccess.CRITICAL_SUCCESS
            2 -> DegreeOfSuccess.SUCCESS
            1 -> DegreeOfSuccess.FAILURE
            else -> DegreeOfSuccess.CRITICAL_FAILURE
        }
    }

    private fun addRuleRequest(existing: List<RuleRequest>, request: RuleRequest): List<RuleRequest> = (existing + request).takeLast(80)

    private fun conditionFromPreset(
        name: String,
        sourceCombatantId: String?,
        publicToPlayers: Boolean,
        partyInflicted: Boolean,
        valueOverride: Int? = null,
    ): Condition {
        val preset: EffectPreset? = effectPresets.firstOrNull { it.name.equals(name, true) }
        return Condition(
            name = name,
            value = valueOverride ?: preset?.defaultValue,
            publicToPlayers = publicToPlayers,
            partyInflicted = partyInflicted,
            sourceCombatantId = sourceCombatantId,
            timingAnchor = preset?.timingAnchor ?: EffectAnchor.TARGET,
            timingPhase = preset?.timingPhase ?: EffectPhase.MANUAL,
            triggerAction = preset?.triggerAction ?: EffectTriggerAction.NONE,
            checkType = preset?.checkType,
            checkLabel = preset?.checkLabel.orEmpty(),
            checkDc = preset?.checkDc,
            checkSuccessAction = preset?.successAction ?: EffectOutcomeAction.REMOVE,
            checkFailureAction = preset?.failureAction ?: EffectOutcomeAction.KEEP,
            checkCriticalSuccessAction = preset?.criticalSuccessAction ?: EffectOutcomeAction.REMOVE,
            checkCriticalFailureAction = preset?.criticalFailureAction ?: EffectOutcomeAction.KEEP,
        )
    }

    private fun addEffectToCombatant(combatantId: String, effect: Condition) {
        mutate("Effect added: ${effect.name}", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id != combatantId) c else c.copy(
                    conditions = c.conditions.filterNot { it.name.equals(effect.name, true) } + effect
                )
            }
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = encounter.copy(combatants = updatedCombatants),
            )
        }
    }

    private fun applyOutcomeToEffect(effect: Condition, action: String): Condition? = when (action) {
        EffectOutcomeAction.REMOVE -> null
        EffectOutcomeAction.DECREMENT -> effect.value?.let { next ->
            if (next - 1 <= 0) null else effect.copy(value = next - 1)
        } ?: effect
        EffectOutcomeAction.DECREMENT_2 -> effect.value?.let { next ->
            if (next - 2 <= 0) null else effect.copy(value = next - 2)
        } ?: effect
        EffectOutcomeAction.INCREMENT -> effect.copy(value = (effect.value ?: 0) + 1)
        EffectOutcomeAction.INCREMENT_2 -> effect.copy(value = (effect.value ?: 0) + 2)
        else -> effect
    }

    private fun processEffectPhase(
        pcs: List<PlayerCharacter>,
        encounter: EncounterState,
        actorId: String,
        phase: String,
    ): EffectProcessingResult {
        val prompts = encounter.pendingEffectChecks.toMutableList()
        val updatedCombatants = encounter.combatants.map { target ->
            val nextConditions = target.conditions.mapNotNull { effect ->
                val matchesActor = when (effect.timingAnchor) {
                    EffectAnchor.SOURCE -> effect.sourceCombatantId == actorId
                    else -> target.id == actorId
                }
                if (effect.timingPhase != phase || !matchesActor) return@mapNotNull effect

                var next: Condition? = when (effect.triggerAction) {
                    EffectTriggerAction.REMOVE -> null
                    EffectTriggerAction.DECREMENT_VALUE -> {
                        val value = effect.value ?: 1
                        if (value - 1 <= 0) null else effect.copy(value = value - 1)
                    }
                    EffectTriggerAction.CHECK -> {
                        if (prompts.none { it.effectId == effect.id }) {
                            val dynamicDc = if (effect.name.equals("Dying", true) && effect.value != null) {
                                10 + effect.value
                            } else effect.checkDc
                            prompts += EffectCheckPrompt(
                                effectId = effect.id,
                                targetCombatantId = target.id,
                                targetName = target.name,
                                effectName = effect.name,
                                checkType = effect.checkType ?: "Custom roll",
                                checkLabel = effect.checkLabel,
                                dc = dynamicDc,
                                timingText = effectTimingText(effect, target, encounter),
                                successAction = effect.checkSuccessAction,
                                failureAction = effect.checkFailureAction,
                                criticalSuccessAction = effect.checkCriticalSuccessAction,
                                criticalFailureAction = effect.checkCriticalFailureAction,
                                repeatCheck = effect.repeatCheck,
                            )
                        }
                        effect
                    }
                    else -> effect
                }

                val remainingTriggerCount = next?.remainingTriggers
                if (next != null && effect.triggerAction != EffectTriggerAction.CHECK && remainingTriggerCount != null) {
                    next = if (remainingTriggerCount <= 1) null else next.copy(remainingTriggers = remainingTriggerCount - 1)
                }
                next
            }
            target.copy(conditions = nextConditions)
        }
        return EffectProcessingResult(
            pcs = syncPcsFromCombatants(pcs, updatedCombatants),
            encounter = encounter.copy(
                combatants = updatedCombatants,
                pendingEffectChecks = prompts,
            ),
        )
    }

    private fun advanceEncounterTurn(state: SessionState, encounter: EncounterState): SessionState {
        if (encounter.combatants.isEmpty()) return state.copy(encounter = encounter)
        val oldCurrent = encounter.currentCombatant()
        val wraps = encounter.turnIndex >= encounter.combatants.lastIndex
        val nextIndex = if (wraps) 0 else encounter.turnIndex + 1
        val nextRound = if (wraps) encounter.round + 1 else encounter.round
        var moved = encounter.copy(
            turnIndex = nextIndex,
            round = nextRound,
            pendingTurnAdvance = false,
            endTurnRequests = encounter.endTurnRequests.filterNot { it == oldCurrent?.pcId },
        )
        val nextActor = moved.currentCombatant()
        if (nextActor != null) {
            val startProcessed = processEffectPhase(state.pcs, moved, nextActor.id, EffectPhase.START)
            moved = startProcessed.encounter
            val nextPcs = if (nextActor.pcId != null) {
                startProcessed.pcs.map { pc ->
                    if (pc.id == nextActor.pcId) resetTurnAbilityUses(pc.copy(actionEconomy = ActionEconomy())) else pc
                }
            } else startProcessed.pcs
            return state.copy(pcs = nextPcs, encounter = moved)
        }
        return state.copy(encounter = moved)
    }

    private fun effectTimingText(effect: Condition, target: Combatant, encounter: EncounterState): String {
        val phaseText = when (effect.timingPhase) {
            EffectPhase.START -> "start"
            EffectPhase.END -> "end"
            else -> "manual timing"
        }
        if (effect.timingPhase == EffectPhase.MANUAL) return "Manual timing"
        val anchorName = if (effect.timingAnchor == EffectAnchor.SOURCE) {
            encounter.combatants.firstOrNull { it.id == effect.sourceCombatantId }?.name ?: "source"
        } else target.name
        return "$phaseText of $anchorName's turn"
    }

    private fun syncPcsFromCombatants(
        pcs: List<PlayerCharacter>,
        combatants: List<Combatant>,
    ): List<PlayerCharacter> = pcs.map { pc ->
        val combatant = combatants.firstOrNull { it.pcId == pc.id }
        if (combatant == null) pc else pc.copy(conditions = combatant.conditions)
    }

    private fun mergeEnemies(existing: List<PreparedEnemy>, incoming: List<PreparedEnemy>, replaceConflicts: Boolean): List<PreparedEnemy> {
        val next = existing.toMutableList()
        incoming.forEach { item ->
            val index = next.indexOfFirst { it.name.trim().equals(item.name.trim(), ignoreCase = true) && it.kind == item.kind }
            if (index < 0) next += item else if (replaceConflicts) next[index] = item.copy(id = next[index].id)
        }
        return next
    }

    private fun mergePreparedEncounters(existing: List<PreparedEncounter>, incoming: List<PreparedEncounter>, replaceConflicts: Boolean): List<PreparedEncounter> {
        val next = existing.toMutableList()
        incoming.forEach { item ->
            val index = next.indexOfFirst { it.name.trim().equals(item.name.trim(), ignoreCase = true) }
            if (index < 0) next += item else if (replaceConflicts) next[index] = item.copy(id = next[index].id)
        }
        return next
    }

    private fun mergeLoot(existing: List<LootItem>, incoming: List<LootItem>, replaceConflicts: Boolean): List<LootItem> {
        val next = existing.toMutableList()
        incoming.forEach { item ->
            val index = next.indexOfFirst {
                it.name.trim().equals(item.name.trim(), ignoreCase = true) && it.assignedToPcId == item.assignedToPcId
            }
            if (index < 0) next += item else if (replaceConflicts) next[index] = item.copy(id = next[index].id)
        }
        return next
    }

    private fun appendImportedText(existing: String, incoming: String, sourceName: String): String {
        if (incoming.isBlank()) return existing
        if (existing.isBlank()) return incoming
        if (existing.trim() == incoming.trim()) return existing
        return existing.trimEnd() + "\n\n--- Imported: ${sourceName.ifBlank { "TT Helper package" }} ---\n" + incoming.trim()
    }

    private fun mutate(label: String, logEncounter: Boolean = false, transform: (SessionState) -> SessionState) {
        val before = _state.value
        undoStack.addLast(StateSnapshot(before, label))
        while (undoStack.size > 100) undoStack.removeFirst()
        var after = transform(before)
        val encounterAfter = after.encounter
        if (logEncounter && encounterAfter != null) {
            after = after.copy(encounter = encounterAfter.copy(
                history = (encounterAfter.history + CombatLogEntry(label = label)).takeLast(250),
            ))
        }
        after = after.copy(revision = before.revision + 1, lastEventLabel = label)
        _state.value = after
        persist(after)
        maybeAutoBackup(after)
    }

    private fun loadOrDefault(): SessionState {
        if (!sessionFile.exists()) return SessionState()
        val raw = runCatching { sessionFile.readText() }.getOrElse {
            recoveryMessage = "Could not read the primary campaign save."
            return recoverFromDiskFallback() ?: SessionState()
        }
        return runCatching {
            val oldSchema = SessionCodec.detectSchemaVersion(raw)
            val decoded = SessionCodec.decode(raw)
            if (oldSchema < SessionCodec.CURRENT_SCHEMA_VERSION) {
                runCatching {
                    val stamp = System.currentTimeMillis()
                    File(backupDir, "pre-upgrade-v${oldSchema}-$stamp.json").writeText(raw)
                    pruneBackups()
                }
                recoveryMessage = "Campaign upgraded from data schema $oldSchema to ${SessionCodec.CURRENT_SCHEMA_VERSION}; a pre-upgrade backup was kept."
            }
            decoded
        }.getOrElse {
            recoveryMessage = "Primary save was unreadable. TT Helper attempted recovery."
            recoverFromDiskFallback() ?: SessionState(lastEventLabel = "Recovery fallback: new session")
        }
    }

    private fun recoverFromDiskFallback(): SessionState? {
        val candidates = buildList {
            if (lastGoodFile.exists()) add(lastGoodFile)
            addAll(listBackups())
        }
        candidates.forEach { file ->
            val recovered = runCatching { SessionCodec.decode(file.readText()) }.getOrNull()
            if (recovered != null) {
                recoveryMessage = "Recovered campaign data from ${if (file == lastGoodFile) "last known-good save" else file.name}."
                return recovered.copy(lastEventLabel = "Recovered campaign data")
            }
        }
        return null
    }

    private fun persist(state: SessionState) {
        runCatching {
            val encoded = SessionCodec.encode(state)
            val temp = File(sessionFile.parentFile, "${sessionFile.name}.tmp")
            temp.writeText(encoded)
            SessionCodec.decode(temp.readText())
            if (sessionFile.exists()) {
                runCatching {
                    SessionCodec.decode(sessionFile.readText())
                    sessionFile.copyTo(lastGoodFile, overwrite = true)
                }
            }
            if (!temp.renameTo(sessionFile)) {
                sessionFile.writeText(encoded)
                temp.delete()
            }
            SessionCodec.decode(sessionFile.readText())
            lastPersistAt = System.currentTimeMillis()
            lastPersistenceError = null
        }.onFailure {
            lastPersistenceError = "Save failed: ${it.message ?: "unknown error"}"
        }
    }

    private fun writeBackup(prefix: String, state: SessionState): File {
        val stamp = System.currentTimeMillis()
        val file = File(backupDir, "$prefix-tt-helper-$stamp.json")
        file.writeText(SessionCodec.encode(state))
        SessionCodec.decode(file.readText())
        lastAutoBackupAt = maxOf(lastAutoBackupAt, file.lastModified())
        pruneBackups()
        return file
    }

    private fun maybeAutoBackup(state: SessionState, force: Boolean = false) {
        val now = System.currentTimeMillis()
        val dueByTime = now - lastAutoBackupAt >= autoBackupIntervalMs
        val dueByRevision = state.revision > 0 && state.revision % 25L == 0L
        if (!force && !dueByTime && !dueByRevision) return
        runCatching { writeBackup("auto", state) }
            .onFailure { lastPersistenceError = "Auto-backup failed: ${it.message ?: "unknown error"}" }
    }

    private fun pruneBackups() {
        val files = backupDir.listFiles()
            ?.filter { it.isFile && it.extension.equals("json", true) }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()
        files.drop(maxRotatingBackups).forEach { runCatching { it.delete() } }
    }

    private fun newEncounter(
        current: SessionState,
        name: String,
        enemies: List<PreparedEnemy>,
        gmNote: String = "",
        startingNotes: String = "",
        partyLevel: Int,
        partySize: Int,
        sourcePreparedEncounterId: String? = null,
    ): EncounterState {
        val pcs = current.pcs.map { pc ->
            Combatant(
                id = "pc-${pc.id}",
                name = pc.name,
                kind = "pc",
                pcId = pc.id,
                level = pc.level,
                hp = pc.hp,
                maxHp = pc.maxHp,
                tempHp = pc.tempHp,
                conditions = pc.conditions,
                gmNote = pc.gmNote,
                publicNote = pc.publicNote,
            )
        }
        val enemyCombatants = enemies.flatMap { source ->
            val enemy = adjustedPreparedEntry(source)
            val qty = enemy.quantity.coerceIn(1, 20)
            val group = source.id.ifBlank { UUID.randomUUID().toString() }
            (1..qty).map { index ->
                Combatant(
                    name = if (qty == 1) enemy.name else "${enemy.name} $index",
                    kind = when (source.kind) {
                        "Hazard" -> "hazard"
                        "NPC" -> "npc"
                        else -> "enemy"
                    },
                    level = enemy.level,
                    initiativeModifier = enemy.initiativeModifier,
                    hp = enemy.maxHp.coerceAtLeast(1),
                    maxHp = enemy.maxHp.coerceAtLeast(1),
                    armorClass = enemy.armorClass,
                    fortitude = enemy.fortitude,
                    reflex = enemy.reflex,
                    will = enemy.will,
                    gmNote = listOf(gmNote, source.gmNotes, source.role.takeIf { it.isNotBlank() }?.let { "Role: $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString("\n"),
                    publicNote = source.publicNotes,
                    groupKey = group,
                )
            }
        }
        return EncounterState(
            name = name,
            gmNotes = gmNote,
            startingNotes = startingNotes,
            combatants = pcs + enemyCombatants,
            partyLevel = partyLevel.coerceAtLeast(1),
            partySize = partySize.coerceIn(1, 12),
            sourcePreparedEncounterId = sourcePreparedEncounterId,
        )
    }

    private fun averagePartyLevel(pcs: List<PlayerCharacter>): Int {
        val levels = pcs.mapNotNull { it.level }
        return if (levels.isEmpty()) 1 else (levels.average() + 0.5).toInt().coerceAtLeast(1)
    }

    private fun stableInitiativeSort(combatants: List<Combatant>): List<Combatant> = combatants.withIndex()
        .sortedWith(compareByDescending<IndexedValue<Combatant>> { it.value.initiative ?: Int.MIN_VALUE }.thenBy { it.index })
        .map { it.value }

    private fun applyPcHpDelta(beforePc: PlayerCharacter, delta: Int, encounterActive: Boolean): PlayerCharacter {
        var remaining = delta
        var temp = beforePc.tempHp
        var hp = beforePc.hp
        if (remaining < 0 && temp > 0) {
            val absorbed = minOf(temp, -remaining)
            temp -= absorbed
            remaining += absorbed
        }
        hp = (hp + remaining).coerceIn(0, beforePc.maxHp.coerceAtLeast(1))
        var conditions = beforePc.conditions

        if (encounterActive && beforePc.hp > 0 && hp == 0) {
            val wounded = conditions.firstOrNull { it.name.equals("Wounded", true) }?.value ?: 0
            val dyingValue = 1 + wounded
            conditions = conditions.filterNot { it.name.equals("Dying", true) } + Condition("Dying", dyingValue, publicToPlayers = true)
        }
        if (encounterActive && beforePc.hp == 0 && hp > 0 && conditions.any { it.name.equals("Dying", true) }) {
            val wounded = (conditions.firstOrNull { it.name.equals("Wounded", true) }?.value ?: 0) + 1
            conditions = conditions.filterNot { it.name.equals("Dying", true) || it.name.equals("Wounded", true) } +
                Condition("Wounded", wounded, publicToPlayers = true)
        }
        return beforePc.copy(hp = hp, tempHp = temp, conditions = conditions)
    }

    private fun syncPcIntoEncounter(encounter: EncounterState, pc: PlayerCharacter): EncounterState = encounter.copy(
        combatants = encounter.combatants.map { combatant ->
            if (combatant.pcId == pc.id) combatant.copy(
                hp = pc.hp,
                maxHp = pc.maxHp,
                tempHp = pc.tempHp,
                conditions = pc.conditions,
            ) else combatant
        }
    )

    private fun SessionState.updatePc(pcId: String, transform: (PlayerCharacter) -> PlayerCharacter): SessionState =
        copy(pcs = pcs.map { if (it.id == pcId) transform(it) else it })

    private fun LibraryEntry.toPlayerJson(pc: PlayerCharacter?) = JSONObject().apply {
        val pcLevel = pc?.level
        val levelOk = level == null || pcLevel == null || level <= pcLevel
        val classOk = classes.isEmpty() || pc == null || classes.any { it.equals(pc.characterClass, true) }
        val tradition = pc?.spellcasting?.tradition.orEmpty()
        val traditionOk = traditions.isEmpty() || tradition.isBlank() || traditions.any { it.equals(tradition, true) }
        val available = levelOk && classOk && traditionOk
        put("id", id); put("name", name); put("kind", kind); put("category", category); put("level", level ?: JSONObject.NULL)
        put("actions", actions ?: JSONObject.NULL); put("governingAbility", governingAbility)
        put("traditions", JSONArray().apply { traditions.forEach { put(it) } }); put("classes", JSONArray().apply { classes.forEach { put(it) } })
        put("traits", JSONArray().apply { traits.forEach { put(it) } }); put("prerequisites", prerequisites); put("range", range); put("targets", targets)
        put("checkOrSave", checkOrSave); put("damage", damage); put("damageType", damageType); put("basicSave", basicSave); put("healing", healing)
        put("summary", summary); put("sourceLabel", sourceLabel); put("homebrew", homebrew); put("availableToCharacter", available)
        put("referenceOnly", kind in setOf(LibraryKind.SKILL, LibraryKind.TRAIT, LibraryKind.CONDITION))
        put("availabilityNote", when {
            !levelOk -> "Requires level ${level ?: "?"}"
            !classOk -> "Usually for ${classes.joinToString(" / ")}"
            !traditionOk -> "Traditions: ${traditions.joinToString(", ")}"
            prerequisites.isNotBlank() -> prerequisites
            else -> ""
        })
    }

    private fun PlayerCharacter.toPublicJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("accentColor", accentColor)
        put("ancestry", ancestry)
        put("heritage", heritage)
        put("background", background)
        put("characterClass", characterClass)
        put("level", level ?: JSONObject.NULL)
        put("hp", hp)
        put("maxHp", maxHp)
        put("tempHp", tempHp)
        put("heroPoints", heroPoints)
        put("ready", ready)
        put("publicNote", publicNote)
        put("stats", JSONObject().apply {
            put("size", stats.size); put("speed", stats.speed); put("languages", stats.languages); put("senses", stats.senses)
            put("strength", stats.strength); put("dexterity", stats.dexterity); put("constitution", stats.constitution); put("intelligence", stats.intelligence); put("wisdom", stats.wisdom); put("charisma", stats.charisma)
            put("armorClass", stats.armorClass); put("perception", stats.perception); put("fortitude", stats.fortitude); put("reflex", stats.reflex); put("will", stats.will); put("classDc", stats.classDc)
            put("weaponProficiency", stats.weaponProficiency); put("armorProficiency", stats.armorProficiency); put("immunities", stats.immunities); put("resistances", stats.resistances); put("weaknesses", stats.weaknesses)
            put("skillModifiers", JSONObject().apply { stats.skillModifiers.forEach { (k,v) -> put(k,v) } })
            put("skillProficiencies", JSONObject().apply { stats.skillProficiencies.forEach { (k,v) -> put(k,v) } })
            put("skillItemBonuses", JSONObject().apply { stats.skillItemBonuses.forEach { (k,v) -> put(k,v) } })
            put("skillAbilityOverrides", JSONObject().apply { stats.skillAbilityOverrides.forEach { (k,v) -> put(k,v) } })
            put("skillManualOverrides", JSONObject().apply { stats.skillManualOverrides.forEach { (k,v) -> put(k,v) } })
            put("autoCalculateSkills", stats.autoCalculateSkills)
            put("loreSkills", JSONArray().apply { stats.loreSkills.forEach { lore -> put(JSONObject().apply { put("id", lore.id); put("name", lore.name); put("modifier", lore.modifier); put("proficiency", lore.proficiency) }) } })
        })
        put("actionEconomy", JSONObject().apply {
            put("baseActions", actionEconomy.baseActions)
            put("actionsRemaining", actionEconomy.actionsRemaining)
            put("reactionAvailable", actionEconomy.reactionAvailable)
            put("attacksThisTurn", actionEconomy.attacksThisTurn)
        })
        put("spellcasting", JSONObject().apply {
            put("enabled", spellcasting.enabled)
            put("tradition", spellcasting.tradition)
            put("castingMode", spellcasting.castingMode)
            put("focusPoints", spellcasting.focusPoints)
            put("maxFocusPoints", spellcasting.maxFocusPoints)
            put("spellDc", spellcasting.spellDc)
            put("spellAttackModifier", spellcasting.spellAttackModifier)
            put("slots", JSONArray().apply {
                spellcasting.slots.sortedBy { it.rank }.forEach { slot ->
                    put(JSONObject().apply {
                        put("rank", slot.rank)
                        put("total", slot.total)
                        put("remaining", slot.remaining)
                    })
                }
            })
            put("spells", JSONArray().apply {
                spellcasting.spells.forEach { spell ->
                    put(JSONObject().apply {
                        put("id", spell.id)
                        put("name", spell.name)
                        put("rank", spell.rank)
                        put("actions", spell.actions)
                        put("isCantrip", spell.isCantrip)
                        put("isFocus", spell.isFocus)
                        put("expended", spell.expended)
                        put("notes", spell.notes)
                        put("range", spell.range)
                        put("targets", spell.targets)
                        put("checkOrSave", spell.checkOrSave); put("damage", spell.damage); put("damageType", spell.damageType); put("basicSave", spell.basicSave); put("healing", spell.healing); put("traits", spell.traits)
                        put("effectCriticalSuccess", spell.effectCriticalSuccess); put("effectSuccess", spell.effectSuccess); put("effectFailure", spell.effectFailure); put("effectCriticalFailure", spell.effectCriticalFailure)
                        put("pinned", spell.pinned)
                    })
                }
            })
        })
        put("abilities", JSONArray().apply {
            abilities.forEach { ability ->
                put(JSONObject().apply {
                    put("id", ability.id); put("name", ability.name); put("category", ability.category); put("actionType", ability.actionType)
                    put("actions", ability.actions); put("usageMode", ability.usageMode); put("maxUses", ability.maxUses); put("remainingUses", ability.remainingUses)
                    put("range", ability.range); put("targets", ability.targets); put("checkOrSave", ability.checkOrSave); put("damage", ability.damage); put("damageType", ability.damageType); put("basicSave", ability.basicSave); put("healing", ability.healing); put("traits", ability.traits)
                    put("effectCriticalSuccess", ability.effectCriticalSuccess); put("effectSuccess", ability.effectSuccess); put("effectFailure", ability.effectFailure); put("effectCriticalFailure", ability.effectCriticalFailure)
                    put("notes", ability.notes); put("pinned", ability.pinned)
                })
            }
        })
        put("strikes", JSONArray().apply {
            strikes.forEach { strike ->
                put(JSONObject().apply {
                    put("id", strike.id); put("name", strike.name); put("actions", strike.actions); put("attackModifier", strike.attackModifier)
                    put("damage", strike.damage); put("damageType", strike.damageType); put("healing", strike.healing); put("traits", strike.traits); put("effectCriticalSuccess", strike.effectCriticalSuccess); put("effectSuccess", strike.effectSuccess); put("notes", strike.notes); put("pinned", strike.pinned)
                })
            }
        })
        put("resources", JSONArray().apply {
            resources.forEach { resource ->
                put(JSONObject().apply {
                    put("id", resource.id); put("name", resource.name); put("current", resource.current); put("max", resource.max); put("notes", resource.notes); put("pinned", resource.pinned)
                })
            }
        })
        put("feats", JSONArray().apply {
            feats.forEach { feat ->
                put(JSONObject().apply {
                    put("id", feat.id); put("name", feat.name); put("type", feat.type); put("level", feat.level ?: JSONObject.NULL)
                    put("traits", feat.traits); put("prerequisites", feat.prerequisites); put("notes", feat.notes)
                })
            }
        })
        put("contentDrafts", JSONArray().apply {
            contentDrafts.forEach { draft ->
                put(JSONObject().apply {
                    put("id", draft.id); put("kind", draft.kind); put("status", draft.status); put("name", draft.name); put("rank", draft.rank); put("actions", draft.actions)
                    put("isCantrip", draft.isCantrip); put("isFocus", draft.isFocus); put("notes", draft.notes); put("range", draft.range); put("targets", draft.targets); put("checkOrSave", draft.checkOrSave); put("abilityCategory", draft.abilityCategory)
                    put("actionType", draft.actionType); put("usageMode", draft.usageMode); put("maxUses", draft.maxUses); put("attackModifier", draft.attackModifier)
                    put("damage", draft.damage); put("damageType", draft.damageType); put("basicSave", draft.basicSave); put("healing", draft.healing); put("traits", draft.traits); put("prerequisites", draft.prerequisites)
                    put("effectCriticalSuccess", draft.effectCriticalSuccess); put("effectSuccess", draft.effectSuccess); put("effectFailure", draft.effectFailure); put("effectCriticalFailure", draft.effectCriticalFailure); put("resourceMax", draft.resourceMax); put("gmFeedback", draft.gmFeedback)
                    put("sourceEntryId", draft.sourceEntryId ?: JSONObject.NULL); put("submittedAt", draft.submittedAt ?: JSONObject.NULL)
                })
            }
        })
        put("selectedTargetId", selectedTargetId ?: JSONObject.NULL)
        put("conditions", JSONArray().apply {
            conditions.forEach { c -> put(c.toJson()) }
        })
    }

    private fun PlayerCharacter.toPartyJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("accentColor", accentColor)
        put("hp", hp)
        put("maxHp", maxHp)
        put("tempHp", tempHp)
        put("ready", ready)
        put("conditions", JSONArray().apply { conditions.forEach { put(it.toJson()) } })
    }

    private fun Condition.toJson() = JSONObject().apply {
        put("name", name)
        put("value", value ?: JSONObject.NULL)
        put("partyInflicted", partyInflicted)
    }

    private fun LootItem.toPlayerJson(allItems: List<LootItem>) = JSONObject().apply {
        put("id", id)
        put("name", if (identified) name else unidentifiedName)
        put("identified", identified)
        put("category", if (identified) category else "Unidentified")
        put("quantity", quantity)
        put("valueGp", if (identified) valueGp else 0.0)
        put("notes", notes)
        put("level", if (identified) level ?: JSONObject.NULL else JSONObject.NULL)
        put("traits", if (identified) traits else "")
        put("runes", if (identified) runes else "")
        put("bulk", bulk)
        put("carryState", carryState)
        put("consumable", consumable)
        put("charges", charges ?: JSONObject.NULL)
        put("maxCharges", maxCharges ?: JSONObject.NULL)
        put("containerId", containerId ?: JSONObject.NULL)
        put("containerName", containerId?.let { cid -> allItems.firstOrNull { it.id == cid && it.revealedToPlayers }?.let { c -> if (c.identified) c.name else c.unidentifiedName } } ?: JSONObject.NULL)
        put("capacityBulk", capacityBulk ?: JSONObject.NULL)
    }

    private fun EncounterState.toPlayerJson(pcId: String) = JSONObject().apply {
        val current = currentCombatant()
        val own = combatants.firstOrNull { it.pcId == pcId }
        put("id", id)
        put("name", name)
        put("active", active)
        put("ended", ended)
        put("round", round)
        put("currentCombatantId", current?.id ?: JSONObject.NULL)
        put("currentName", current?.name ?: JSONObject.NULL)
        put("currentIsYou", current?.pcId == pcId)
        put("yourInitiative", own?.initiative ?: JSONObject.NULL)
        put("endTurnRequested", pcId in endTurnRequests)
        put("initiative", JSONArray().apply {
            combatants.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("kind", c.kind)
                    put("isYou", c.pcId == pcId)
                    put("current", c.id == current?.id)
                    put("delayed", c.delayed)
                    put("defeated", c.defeated)
                })
            }
        })
        put("enemies", JSONArray().apply {
            combatants.filter { it.kind != "pc" }.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("health", healthState(c))
                    put("defeated", c.defeated)
                    put("publicNote", c.publicNote)
                    put("conditions", JSONArray().apply {
                        c.conditions.filter { it.publicToPlayers || it.partyInflicted }.forEach { put(it.toJson()) }
                    })
                })
            }
        })
        put("rules", JSONArray().apply {
            ruleRequests.filter { it.actorPcId == pcId }.takeLast(10).forEach { request ->
                put(JSONObject().apply {
                    put("id", request.id)
                    put("type", request.type)
                    put("label", request.label)
                    put("targetName", request.targetName ?: JSONObject.NULL)
                    put("secret", request.secret)
                    put("status", request.status)
                    put("outcome", if (request.secret && request.status == RuleRequestStatus.RESOLVED) JSONObject.NULL else request.outcome ?: JSONObject.NULL)
                    put("roll", if (request.secret) JSONObject.NULL else request.roll ?: JSONObject.NULL)
                    put("modifier", if (request.secret) JSONObject.NULL else request.modifier ?: JSONObject.NULL)
                    put("mapPenalty", request.mapPenalty)
                    put("total", if (request.secret) JSONObject.NULL else request.total ?: JSONObject.NULL)
                    put("canPlayerRoll", request.status == RuleRequestStatus.PENDING && request.type == RuleRequestType.ATTACK && request.total == null && request.modifier != null)
                    put("damageType", request.damageType); put("rolledDamage", request.rolledDamage ?: JSONObject.NULL); put("proposedAmount", request.proposedAmount ?: JSONObject.NULL); put("consequenceApplied", request.consequenceApplied)
                })
            }
        })
        put("loot", if (loot.revealed) JSONObject().apply {
            put("coinsGp", loot.coinsGp)
            put("items", JSONArray().apply {
                loot.items.filter { it.revealedToPlayers }.forEach { item ->
                    put(JSONObject().apply {
                        put("name", if (item.identified) item.name else item.unidentifiedName)
                        put("category", if (item.identified) item.category else "Unidentified")
                        put("quantity", item.quantity)
                        put("notes", item.notes)
                    })
                }
            })
        } else JSONObject.NULL)
    }

    private fun healthState(c: Combatant): String {
        if (c.defeated || c.hp <= 0) return "Defeated"
        val ratio = c.hp.toDouble() / c.maxHp.coerceAtLeast(1).toDouble()
        return when {
            ratio > 0.75 -> "Healthy"
            ratio > 0.50 -> "Hurt"
            ratio > 0.25 -> "Badly Hurt"
            else -> "Near Death"
        }
    }

    private fun formatGp(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
}
