package com.drew.tthelper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.LibraryKind
import com.drew.tthelper.model.rulesLibraryEntries
import com.drew.tthelper.server.HostRuntime

@Composable
fun LibraryScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("ALL") }
    var homebrewOnly by remember { mutableStateOf(false) }
    val kinds = listOf("ALL", LibraryKind.SKILL, LibraryKind.ACTION, LibraryKind.ABILITY, LibraryKind.FEAT, LibraryKind.SPELL, LibraryKind.TRAIT, LibraryKind.CONDITION)
    val filtered = remember(query, kind, homebrewOnly) {
        val q = query.trim().lowercase()
        rulesLibraryEntries.filter { entry ->
            (kind == "ALL" || entry.kind == kind) &&
                (!homebrewOnly || entry.homebrew) &&
                (q.isBlank() || listOf(entry.name, entry.category, entry.summary, entry.prerequisites, entry.traits.joinToString(" "), entry.classes.joinToString(" "), entry.traditions.joinToString(" ")).joinToString(" ").lowercase().contains(q))
        }
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Character & Rules Library", fontSize = 26.sp)
        Text("${rulesLibraryEntries.size} starter entries • shared by Android, Windows, and player browsers", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(query, { query = it.take(80) }, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            kinds.forEach { value ->
                FilterChip(selected = kind == value, onClick = { kind = value }, label = { Text(if (value == "ALL") "All" else value.lowercase().replaceFirstChar { it.uppercase() }) })
            }
            FilterChip(selected = homebrewOnly, onClick = { homebrewOnly = !homebrewOnly }, label = { Text("Campaign homebrew") })
        }
        Text("Showing ${filtered.size} • ${state.pcs.size} characters in campaign", style = MaterialTheme.typography.bodySmall)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { entry ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(entry.name, style = MaterialTheme.typography.titleMedium)
                            Text(entry.kind, style = MaterialTheme.typography.labelSmall)
                        }
                        val meta = buildList {
                            if (entry.category.isNotBlank()) add(entry.category)
                            entry.level?.let { add(if (it == 0) "Cantrip" else "Level $it") }
                            entry.actions?.let { add(if (it == 0) "Passive / free" else "$it action${if (it == 1) "" else "s"}") }
                            if (entry.homebrew) add("Homebrew")
                        }.joinToString(" • ")
                        if (meta.isNotBlank()) Text(meta, style = MaterialTheme.typography.bodySmall)
                        if (entry.summary.isNotBlank()) Text(entry.summary)
                        if (entry.traits.isNotEmpty()) Text("Traits: ${entry.traits.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                        if (entry.prerequisites.isNotBlank()) Text("Prerequisites: ${entry.prerequisites}", style = MaterialTheme.typography.bodySmall)
                        if (entry.classes.isNotEmpty()) Text("Classes: ${entry.classes.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                        if (entry.traditions.isNotEmpty()) Text("Traditions: ${entry.traditions.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
