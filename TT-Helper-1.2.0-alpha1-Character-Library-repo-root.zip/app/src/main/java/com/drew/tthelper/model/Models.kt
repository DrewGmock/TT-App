package com.drew.tthelper.model

import java.util.UUID

object EffectAnchor {
    const val TARGET = "TARGET"
    const val SOURCE = "SOURCE"
}

object EffectPhase {
    const val MANUAL = "MANUAL"
    const val START = "START"
    const val END = "END"
}

object EffectTriggerAction {
    const val NONE = "NONE"
    const val REMOVE = "REMOVE"
    const val DECREMENT_VALUE = "DECREMENT_VALUE"
    const val CHECK = "CHECK"
}

object EffectOutcomeAction {
    const val KEEP = "KEEP"
    const val REMOVE = "REMOVE"
    const val DECREMENT = "DECREMENT"
    const val DECREMENT_2 = "DECREMENT_2"
    const val INCREMENT = "INCREMENT"
    const val INCREMENT_2 = "INCREMENT_2"
}

object EffectCheckType {
    const val SKILL = "Skill check"
    const val SAVE = "Saving throw"
    const val FLAT = "Flat check"
    const val RECOVERY = "Recovery check"
    const val CUSTOM = "Custom roll"
}

data class Condition(
    val name: String,
    val value: Int? = null,
    val publicToPlayers: Boolean = true,
    val partyInflicted: Boolean = false,
    val id: String = UUID.randomUUID().toString(),
    val sourceCombatantId: String? = null,
    val timingAnchor: String = EffectAnchor.TARGET,
    val timingPhase: String = EffectPhase.MANUAL,
    val remainingTriggers: Int? = null,
    val triggerAction: String = EffectTriggerAction.NONE,
    val checkType: String? = null,
    val checkLabel: String = "",
    val checkDc: Int? = null,
    val checkSuccessAction: String = EffectOutcomeAction.REMOVE,
    val checkFailureAction: String = EffectOutcomeAction.KEEP,
    val checkCriticalSuccessAction: String = EffectOutcomeAction.REMOVE,
    val checkCriticalFailureAction: String = EffectOutcomeAction.KEEP,
    val repeatCheck: Boolean = true,
)

data class EffectCheckPrompt(
    val id: String = UUID.randomUUID().toString(),
    val effectId: String,
    val targetCombatantId: String,
    val targetName: String,
    val effectName: String,
    val checkType: String,
    val checkLabel: String = "",
    val dc: Int? = null,
    val timingText: String = "",
    val successAction: String = EffectOutcomeAction.REMOVE,
    val failureAction: String = EffectOutcomeAction.KEEP,
    val criticalSuccessAction: String = EffectOutcomeAction.REMOVE,
    val criticalFailureAction: String = EffectOutcomeAction.KEEP,
    val repeatCheck: Boolean = true,
)

data class EffectPreset(
    val name: String,
    val category: String,
    val defaultValue: Int? = null,
    val timingAnchor: String = EffectAnchor.TARGET,
    val timingPhase: String = EffectPhase.MANUAL,
    val triggerAction: String = EffectTriggerAction.NONE,
    val checkType: String? = null,
    val checkLabel: String = "",
    val checkDc: Int? = null,
    val successAction: String = EffectOutcomeAction.REMOVE,
    val failureAction: String = EffectOutcomeAction.KEEP,
    val criticalSuccessAction: String = EffectOutcomeAction.REMOVE,
    val criticalFailureAction: String = EffectOutcomeAction.KEEP,
)


object RuleRequestType {
    const val ATTACK = "ATTACK"
    const val SAVE = "SAVE"
    const val SKILL = "SKILL"
    const val SECRET = "SECRET"
}

object RuleRequestStatus {
    const val PENDING = "PENDING"
    const val RESOLVED = "RESOLVED"
    const val DISMISSED = "DISMISSED"
}

object DegreeOfSuccess {
    const val CRITICAL_SUCCESS = "Critical Success"
    const val SUCCESS = "Success"
    const val FAILURE = "Failure"
    const val CRITICAL_FAILURE = "Critical Failure"
}

data class RuleRequest(
    val id: String = UUID.randomUUID().toString(),
    val actorPcId: String? = null,
    val actorName: String,
    val targetCombatantId: String? = null,
    val targetName: String? = null,
    val type: String = RuleRequestType.SKILL,
    val label: String,
    val secret: Boolean = false,
    val roll: Int? = null,
    val modifier: Int? = null,
    val mapPenalty: Int = 0,
    val total: Int? = null,
    val dc: Int? = null,
    val dcLabel: String = "DC",
    val suggestedOutcome: String? = null,
    val status: String = RuleRequestStatus.PENDING,
    val outcome: String? = null,
    val notes: String = "",
    val damageFormula: String = "",
    val damageType: String = "",
    val basicSave: Boolean = false,
    val healing: Boolean = false,
    val effectCriticalSuccess: String = "",
    val effectSuccess: String = "",
    val effectFailure: String = "",
    val effectCriticalFailure: String = "",
    val rolledDamage: Int? = null,
    val proposedAmount: Int? = null,
    val consequenceApplied: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
)


val standardSkillNames = listOf(
    "Acrobatics", "Arcana", "Athletics", "Crafting", "Deception", "Diplomacy",
    "Intimidation", "Medicine", "Nature", "Occultism", "Performance", "Religion",
    "Society", "Stealth", "Survival", "Thievery"
)

data class LoreSkill(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val modifier: Int = 0,
    val proficiency: String = "Untrained",
)

data class CharacterStats(
    val size: String = "Medium",
    val speed: Int = 25,
    val languages: String = "",
    val senses: String = "",
    val strength: Int = 0,
    val dexterity: Int = 0,
    val constitution: Int = 0,
    val intelligence: Int = 0,
    val wisdom: Int = 0,
    val charisma: Int = 0,
    val armorClass: Int = 10,
    val perception: Int = 0,
    val fortitude: Int = 0,
    val reflex: Int = 0,
    val will: Int = 0,
    val classDc: Int = 0,
    val skillModifiers: Map<String, Int> = standardSkillNames.associateWith { 0 },
    val skillProficiencies: Map<String, String> = standardSkillNames.associateWith { "Untrained" },
    val skillItemBonuses: Map<String, Int> = standardSkillNames.associateWith { 0 },
    val skillAbilityOverrides: Map<String, String> = emptyMap(),
    val skillManualOverrides: Map<String, Int> = emptyMap(),
    val autoCalculateSkills: Boolean = true,
    val loreSkills: List<LoreSkill> = emptyList(),
    val weaponProficiency: String = "",
    val armorProficiency: String = "",
    val immunities: String = "",
    val resistances: String = "",
    val weaknesses: String = "",
)

object CastingMode {
    const val PREPARED = "PREPARED"
    const val SPONTANEOUS = "SPONTANEOUS"
}


object ContentKind {
    const val SPELL = "SPELL"
    const val ABILITY = "ABILITY"
    const val STRIKE = "STRIKE"
    const val RESOURCE = "RESOURCE"
    const val FEAT = "FEAT"
}

object ContentStatus {
    const val DRAFT = "DRAFT"
    const val PENDING = "PENDING"
    const val APPROVED_HISTORY = "APPROVED_HISTORY"
}

object AbilityActionType {
    const val ACTION = "ACTION"
    const val REACTION = "REACTION"
    const val FREE = "FREE"
    const val PASSIVE = "PASSIVE"
}

object UsageMode {
    const val UNLIMITED = "UNLIMITED"
    const val ONCE_PER_TURN = "ONCE_PER_TURN"
    const val ENCOUNTER = "ENCOUNTER"
    const val DAILY = "DAILY"
    const val CUSTOM = "CUSTOM"
}

data class AbilityEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = "Ability",
    val actionType: String = AbilityActionType.ACTION,
    val actions: Int = 1,
    val usageMode: String = UsageMode.UNLIMITED,
    val maxUses: Int = 0,
    val remainingUses: Int = 0,
    val range: String = "",
    val targets: String = "",
    val checkOrSave: String = "",
    val damage: String = "",
    val damageType: String = "",
    val basicSave: Boolean = false,
    val healing: Boolean = false,
    val traits: String = "",
    val effectCriticalSuccess: String = "",
    val effectSuccess: String = "",
    val effectFailure: String = "",
    val effectCriticalFailure: String = "",
    val notes: String = "",
    val pinned: Boolean = false,
)

data class StrikeEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val actions: Int = 1,
    val attackModifier: Int = 0,
    val damage: String = "",
    val damageType: String = "",
    val healing: Boolean = false,
    val traits: String = "",
    val effectCriticalSuccess: String = "",
    val effectSuccess: String = "",
    val notes: String = "",
    val pinned: Boolean = false,
)

data class CharacterResource(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val current: Int = 0,
    val max: Int = 0,
    val notes: String = "",
    val pinned: Boolean = false,
)

data class PlayerContentDraft(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = ContentKind.ABILITY,
    val status: String = ContentStatus.DRAFT,
    val name: String = "",
    val rank: Int = 1,
    val actions: Int = 1,
    val isCantrip: Boolean = false,
    val isFocus: Boolean = false,
    val notes: String = "",
    val range: String = "",
    val targets: String = "",
    val checkOrSave: String = "",
    val abilityCategory: String = "Ability",
    val actionType: String = AbilityActionType.ACTION,
    val usageMode: String = UsageMode.UNLIMITED,
    val maxUses: Int = 0,
    val attackModifier: Int = 0,
    val damage: String = "",
    val damageType: String = "",
    val basicSave: Boolean = false,
    val healing: Boolean = false,
    val traits: String = "",
    val prerequisites: String = "",
    val effectCriticalSuccess: String = "",
    val effectSuccess: String = "",
    val effectFailure: String = "",
    val effectCriticalFailure: String = "",
    val resourceMax: Int = 0,
    val gmFeedback: String = "",
    val sourceEntryId: String? = null,
    val submittedAt: Long? = null,
)

data class SpellSlotPool(
    val rank: Int,
    val total: Int = 0,
    val remaining: Int = 0,
)

data class SpellEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val rank: Int = 0,
    val actions: Int = 2,
    val isCantrip: Boolean = false,
    val isFocus: Boolean = false,
    val expended: Boolean = false,
    val notes: String = "",
    val range: String = "",
    val targets: String = "",
    val checkOrSave: String = "",
    val damage: String = "",
    val damageType: String = "",
    val basicSave: Boolean = false,
    val healing: Boolean = false,
    val traits: String = "",
    val effectCriticalSuccess: String = "",
    val effectSuccess: String = "",
    val effectFailure: String = "",
    val effectCriticalFailure: String = "",
    val pinned: Boolean = false,
)

data class SpellcastingState(
    val enabled: Boolean = false,
    val tradition: String = "",
    val castingMode: String = CastingMode.PREPARED,
    val focusPoints: Int = 0,
    val maxFocusPoints: Int = 0,
    val spellDc: Int = 0,
    val spellAttackModifier: Int = 0,
    val slots: List<SpellSlotPool> = emptyList(),
    val spells: List<SpellEntry> = emptyList(),
)

data class ActionEconomy(
    val baseActions: Int = 3,
    val actionsRemaining: Int = 3,
    val reactionAvailable: Boolean = true,
    val attacksThisTurn: Int = 0,
)

data class FeatEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: String = "General Feat",
    val level: Int? = null,
    val traits: String = "",
    val prerequisites: String = "",
    val notes: String = "",
)

data class CharacterCreationRequest(
    val id: String = UUID.randomUUID().toString(),
    val playerName: String = "Player",
    val characterName: String,
    val ancestry: String = "",
    val heritage: String = "",
    val background: String = "",
    val characterClass: String = "",
    val level: Int? = null,
    val notes: String = "",
    val submittedAt: Long = System.currentTimeMillis(),
)

data class PlayerCharacter(
    val id: String,
    val name: String,
    val ancestry: String,
    val heritage: String = "",
    val background: String = "",
    val characterClass: String,
    val level: Int? = null,
    val hp: Int = 10,
    val maxHp: Int = 10,
    val tempHp: Int = 0,
    val heroPoints: Int = 1,
    val ready: Boolean = false,
    val conditions: List<Condition> = emptyList(),
    val publicNote: String = "",
    val gmNote: String = "",
    val spellcasting: SpellcastingState = SpellcastingState(),
    val actionEconomy: ActionEconomy = ActionEconomy(),
    val abilities: List<AbilityEntry> = emptyList(),
    val strikes: List<StrikeEntry> = emptyList(),
    val resources: List<CharacterResource> = emptyList(),
    val contentDrafts: List<PlayerContentDraft> = emptyList(),
    val feats: List<FeatEntry> = emptyList(),
    val stats: CharacterStats = CharacterStats(),
    val selectedTargetId: String? = null,
    val accentColor: String = "blue",
)

object PrepEntryKind {
    const val CREATURE = "Creature"
    const val NPC = "NPC"
    const val HAZARD = "Hazard"
}

object EncounterAdjustment {
    const val WEAK = "Weak"
    const val NORMAL = "Normal"
    const val ELITE = "Elite"
}

object HazardComplexity {
    const val SIMPLE = "Simple"
    const val COMPLEX = "Complex"
}

data class PreparedEnemy(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val level: Int? = null,
    val maxHp: Int = 10,
    val armorClass: Int? = null,
    val fortitude: Int? = null,
    val reflex: Int? = null,
    val will: Int? = null,
    val initiativeModifier: Int = 0,
    val gmNotes: String = "",
    val publicNotes: String = "",
    val quantity: Int = 1,
    val kind: String = PrepEntryKind.CREATURE,
    val adjustment: String = EncounterAdjustment.NORMAL,
    val hazardComplexity: String = HazardComplexity.COMPLEX,
    val role: String = "",
    val traits: String = "",
    val tags: String = "",
)

data class PreparedEncounter(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val gmNotes: String = "",
    val startingNotes: String = "",
    val enemies: List<PreparedEnemy> = emptyList(),
    val partyLevel: Int = 1,
    val partySize: Int = 4,
    val templateTag: String = "",
)

data class SessionPrep(
    val sessionTitle: String = "Next Session",
    val openingScene: String = "",
    val objectives: String = "",
    val locations: String = "",
    val referenceNotes: String = "",
    val lootSuggestions: String = "",
    val gmNotes: String = "",
    val encounterNotes: String = "",
    val enemyLibrary: List<PreparedEnemy> = emptyList(),
    val preparedEncounters: List<PreparedEncounter> = emptyList(),
    val pinnedPrepKeys: List<String> = emptyList(),
)

data class EncounterHistoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val encounterId: String,
    val name: String,
    val endedAt: Long = System.currentTimeMillis(),
    val rounds: Int = 1,
    val partyLevel: Int = 1,
    val partySize: Int = 4,
    val totalXp: Int = 0,
    val difficulty: String = "Unknown",
    val defeatedCount: Int = 0,
    val combatantCount: Int = 0,
    val history: List<String> = emptyList(),
)

data class Combatant(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String,
    val pcId: String? = null,
    val level: Int? = null,
    val initiative: Int? = null,
    val initiativeModifier: Int = 0,
    val initiativeSource: String? = null,
    val hp: Int = 10,
    val maxHp: Int = 10,
    val tempHp: Int = 0,
    val armorClass: Int? = null,
    val fortitude: Int? = null,
    val reflex: Int? = null,
    val will: Int? = null,
    val conditions: List<Condition> = emptyList(),
    val gmNote: String = "",
    val publicNote: String = "",
    val groupKey: String? = null,
    val defeated: Boolean = false,
    val delayed: Boolean = false,
    val readyAction: String = "",
    val readyTrigger: String = "",
)

data class CombatLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val label: String,
)

object ItemCarryState {
    const val STOWED = "Stowed"
    const val WORN = "Worn"
    const val HELD = "Held"
    const val EQUIPPED = "Equipped"
}

data class LootItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = "Treasure",
    val quantity: Int = 1,
    val valueGp: Double = 0.0,
    val notes: String = "",
    val assignedToPcId: String? = null,
    val revealedToPlayers: Boolean = true,
    val identified: Boolean = true,
    val unidentifiedName: String = "Unidentified item",
    val level: Int? = null,
    val traits: String = "",
    val runes: String = "",
    val bulk: Double = 0.0,
    val carryState: String = ItemCarryState.STOWED,
    val consumable: Boolean = false,
    val charges: Int? = null,
    val maxCharges: Int? = null,
    val containerId: String? = null,
    val capacityBulk: Double? = null,
    val gmNotes: String = "",
)

data class EncounterLoot(
    val generatedAt: Long? = null,
    val revealed: Boolean = false,
    val movedToParty: Boolean = false,
    val coinsGp: Double = 0.0,
    val items: List<LootItem> = emptyList(),
)

data class EncounterState(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val gmNotes: String = "",
    val startingNotes: String = "",
    val active: Boolean = true,
    val ended: Boolean = false,
    val round: Int = 1,
    val turnIndex: Int = 0,
    val combatants: List<Combatant> = emptyList(),
    val endTurnRequests: List<String> = emptyList(),
    val pendingEffectChecks: List<EffectCheckPrompt> = emptyList(),
    val ruleRequests: List<RuleRequest> = emptyList(),
    val pendingTurnAdvance: Boolean = false,
    val history: List<CombatLogEntry> = emptyList(),
    val loot: EncounterLoot = EncounterLoot(),
    val partyLevel: Int = 1,
    val partySize: Int = 4,
    val sourcePreparedEncounterId: String? = null,
)

data class SessionState(
    val revision: Long = 0,
    val campaignName: String = "Cube-Borne",
    val sceneName: String = "Between Sessions",
    val pcs: List<PlayerCharacter> = defaultCharacters(),
    val prep: SessionPrep = SessionPrep(),
    val encounter: EncounterState? = null,
    val partyLoot: List<LootItem> = emptyList(),
    val characterRequests: List<CharacterCreationRequest> = emptyList(),
    val completedEncounters: List<EncounterHistoryEntry> = emptyList(),
    val lastEventLabel: String? = null,
)

data class StateSnapshot(
    val state: SessionState,
    val label: String,
)

fun EncounterState.currentCombatant(): Combatant? = combatants.getOrNull(turnIndex.coerceIn(0, (combatants.size - 1).coerceAtLeast(0)))

fun defaultCharacters() = listOf(
    PlayerCharacter(
        id = "morrow",
        name = "Captain Morrow Vain",
        ancestry = "Skeleton",
        characterClass = "Swashbuckler",
        hp = 10,
        maxHp = 10,
    ),
    PlayerCharacter(
        id = "everleaf",
        name = "Everleaf",
        ancestry = "Human",
        characterClass = "Druid",
        hp = 10,
        spellcasting = SpellcastingState(enabled = true, tradition = "Primal", castingMode = CastingMode.PREPARED, maxFocusPoints = 1, focusPoints = 1),
        maxHp = 10,
    ),
    PlayerCharacter(
        id = "rufus",
        name = "Rufus",
        ancestry = "Orc",
        characterClass = "Barbarian",
        hp = 10,
        maxHp = 10,
    ),
    PlayerCharacter(
        id = "yorik",
        name = "Yorik",
        ancestry = "Vampire",
        characterClass = "Wizard (Necromancer)",
        hp = 10,
        spellcasting = SpellcastingState(enabled = true, tradition = "Arcane", castingMode = CastingMode.PREPARED, maxFocusPoints = 1, focusPoints = 1),
        maxHp = 10,
    ),
)

val commonConditions = listOf(
    "Clumsy", "Doomed", "Drained", "Dying", "Enfeebled", "Frightened",
    "Grabbed", "Immobilized", "Off-Guard", "Persistent Damage", "Prone",
    "Sickened", "Slowed", "Stunned", "Stupefied", "Wounded"
)

val valuedConditions = setOf(
    "Clumsy", "Doomed", "Drained", "Dying", "Enfeebled", "Frightened",
    "Sickened", "Slowed", "Stunned", "Stupefied", "Wounded"
)

val obviousEnemyConditions = setOf(
    "Dying", "Frightened", "Grabbed", "Immobilized", "Persistent Damage",
    "Prone", "Sickened", "Slowed", "Stunned", "Wounded"
)

val homebrewEffects = listOf(
    "Chaos Aura",
    "Cube's Favorite Mistake",
    "Thorn-Crowned Rage",
    "Borrowed Pulse",
    "The Duel That Already Happened",
    "Beast Out of Time",
)

val effectPresets: List<EffectPreset> = buildList {
    commonConditions.forEach { name ->
        add(
            when (name) {
                "Frightened" -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    defaultValue = 1,
                    timingAnchor = EffectAnchor.TARGET,
                    timingPhase = EffectPhase.END,
                    triggerAction = EffectTriggerAction.DECREMENT_VALUE,
                )
                "Persistent Damage" -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    timingAnchor = EffectAnchor.TARGET,
                    timingPhase = EffectPhase.END,
                    triggerAction = EffectTriggerAction.CHECK,
                    checkType = EffectCheckType.FLAT,
                    checkLabel = "Resolve persistent damage, then make the recovery flat check",
                    checkDc = 15,
                    successAction = EffectOutcomeAction.REMOVE,
                    failureAction = EffectOutcomeAction.KEEP,
                )
                "Dying" -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    defaultValue = 1,
                    timingAnchor = EffectAnchor.TARGET,
                    timingPhase = EffectPhase.START,
                    triggerAction = EffectTriggerAction.CHECK,
                    checkType = EffectCheckType.RECOVERY,
                    checkLabel = "Recovery check",
                    checkDc = 10,
                    criticalSuccessAction = EffectOutcomeAction.DECREMENT_2,
                    successAction = EffectOutcomeAction.DECREMENT,
                    failureAction = EffectOutcomeAction.INCREMENT,
                    criticalFailureAction = EffectOutcomeAction.INCREMENT_2,
                )
                else -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    defaultValue = if (name in valuedConditions) 1 else null,
                )
            }
        )
    }
    homebrewEffects.forEach { add(EffectPreset(it, "Cubeborne / homebrew")) }
}
