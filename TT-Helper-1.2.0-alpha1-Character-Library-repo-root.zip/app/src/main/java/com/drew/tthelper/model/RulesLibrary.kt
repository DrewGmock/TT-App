package com.drew.tthelper.model

object LibraryKind {
    const val SKILL = "SKILL"
    const val ACTION = "ACTION"
    const val ABILITY = "ABILITY"
    const val FEAT = "FEAT"
    const val SPELL = "SPELL"
    const val TRAIT = "TRAIT"
    const val CONDITION = "CONDITION"
}

data class LibraryEntry(
    val id: String,
    val name: String,
    val kind: String,
    val category: String = "",
    val level: Int? = null,
    val actions: Int? = null,
    val governingAbility: String = "",
    val traditions: List<String> = emptyList(),
    val classes: List<String> = emptyList(),
    val traits: List<String> = emptyList(),
    val prerequisites: String = "",
    val range: String = "",
    val targets: String = "",
    val checkOrSave: String = "",
    val damage: String = "",
    val damageType: String = "",
    val basicSave: Boolean = false,
    val healing: Boolean = false,
    val summary: String = "",
    val sourceLabel: String = "TT Helper starter library",
    val homebrew: Boolean = false,
)

private fun lib(
    id: String, name: String, kind: String, category: String = "", level: Int? = null,
    actions: Int? = null, governingAbility: String = "", traditions: List<String> = emptyList(),
    classes: List<String> = emptyList(), traits: List<String> = emptyList(), prerequisites: String = "",
    range: String = "", targets: String = "", checkOrSave: String = "", damage: String = "",
    damageType: String = "", basicSave: Boolean = false, healing: Boolean = false, summary: String = "",
    sourceLabel: String = "TT Helper starter library", homebrew: Boolean = false,
) = LibraryEntry(id, name, kind, category, level, actions, governingAbility, traditions, classes, traits,
    prerequisites, range, targets, checkOrSave, damage, damageType, basicSave, healing, summary, sourceLabel, homebrew)

val rulesLibraryEntries: List<LibraryEntry> = buildList {
    standardSkillAbilities.forEach { (name, ability) ->
        add(lib("skill-${name.lowercase().replace(" ", "-")}", name, LibraryKind.SKILL, "Skill", governingAbility = ability,
            summary = "Standard skill. TT Helper can calculate this from $ability, proficiency rank, level, and item bonuses."))
    }

    addAll(listOf(
        lib("action-aid", "Aid", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Concentrate"), summary = "Prepare to help an ally with a check; resolve the reaction when the trigger occurs."),
        lib("action-crawl", "Crawl", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Move"), summary = "Move a short distance while prone."),
        lib("action-delay", "Delay", LibraryKind.ACTION, "Encounter Action", actions = 0, summary = "Change your place in initiative to act later."),
        lib("action-drop-prone", "Drop Prone", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Move"), summary = "Become prone intentionally."),
        lib("action-escape", "Escape", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Attack"), governingAbility = "ATH/ACR", summary = "Attempt to escape a grab, restraint, or similar effect."),
        lib("action-interact", "Interact", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Manipulate"), summary = "Manipulate an object or perform a simple physical interaction."),
        lib("action-leap", "Leap", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Move"), summary = "Make a basic horizontal or vertical jump."),
        lib("action-ready", "Ready", LibraryKind.ACTION, "Encounter Action", actions = 2, traits = listOf("Concentrate"), summary = "Prepare a single action to use as a reaction when your trigger occurs."),
        lib("action-release", "Release", LibraryKind.ACTION, "Common Action", actions = 0, summary = "Release something you are holding."),
        lib("action-seek", "Seek", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Concentrate", "Secret"), governingAbility = "WIS", summary = "Search an area for creatures, objects, or clues that are difficult to notice."),
        lib("action-sense-motive", "Sense Motive", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Concentrate", "Secret"), governingAbility = "WIS", summary = "Judge whether another creature may be behaving deceptively."),
        lib("action-stand", "Stand", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Move"), summary = "Stand up from prone."),
        lib("action-step", "Step", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Move"), summary = "Move carefully a short distance without using a Stride."),
        lib("action-stride", "Stride", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Move"), summary = "Move up to your Speed."),
        lib("action-strike", "Strike", LibraryKind.ACTION, "Common Action", actions = 1, traits = listOf("Attack"), summary = "Make a weapon or unarmed attack."),
        lib("action-take-cover", "Take Cover", LibraryKind.ACTION, "Common Action", actions = 1, summary = "Improve the defensive benefit of cover when your position allows it."),
        lib("action-recall-knowledge", "Recall Knowledge", LibraryKind.ACTION, "Skill Action", actions = 1, traits = listOf("Concentrate", "Secret"), summary = "Use an appropriate knowledge skill to identify or remember useful information."),
        lib("action-demoralize", "Demoralize", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "CHA", traits = listOf("Auditory", "Emotion", "Fear", "Mental"), checkOrSave = "Intimidation vs Will DC", summary = "Use Intimidation to frighten a foe."),
        lib("action-feint", "Feint", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "CHA", traits = listOf("Mental"), checkOrSave = "Deception vs Perception DC", summary = "Mislead a foe to create an opening."),
        lib("action-grapple", "Grapple", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "STR", traits = listOf("Attack"), checkOrSave = "Athletics vs Fortitude DC", summary = "Use Athletics to grab and hold a target."),
        lib("action-shove", "Shove", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "STR", traits = listOf("Attack"), checkOrSave = "Athletics vs Fortitude DC", summary = "Use Athletics to force a target away."),
        lib("action-trip", "Trip", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "STR", traits = listOf("Attack"), checkOrSave = "Athletics vs Reflex DC", summary = "Use Athletics to knock a target prone."),
        lib("action-tumble-through", "Tumble Through", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "DEX", traits = listOf("Move"), checkOrSave = "Acrobatics vs Reflex DC", summary = "Move through an enemy's space using Acrobatics."),
        lib("action-treat-wounds", "Treat Wounds", LibraryKind.ACTION, "Skill Action", governingAbility = "WIS", traits = listOf("Exploration", "Healing", "Manipulate"), checkOrSave = "Medicine", healing = true, summary = "Use Medicine during downtime/exploration to restore Hit Points."),
        lib("action-battle-medicine", "Battle Medicine", LibraryKind.FEAT, "Skill Feat", level = 1, actions = 1, governingAbility = "WIS", traits = listOf("General", "Healing", "Manipulate", "Skill"), prerequisites = "Trained in Medicine", classes = emptyList(), healing = true, summary = "Use Medicine quickly during encounter mode to restore Hit Points."),
        lib("action-hide", "Hide", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "DEX", traits = listOf("Secret"), checkOrSave = "Stealth vs Perception DC", summary = "Use Stealth while you have cover or concealment to become hidden."),
        lib("action-sneak", "Sneak", LibraryKind.ACTION, "Skill Action", actions = 1, governingAbility = "DEX", traits = listOf("Move", "Secret"), checkOrSave = "Stealth vs Perception DC", summary = "Move while attempting to remain undetected."),
        lib("action-pick-lock", "Pick a Lock", LibraryKind.ACTION, "Skill Action", governingAbility = "DEX", traits = listOf("Manipulate"), prerequisites = "Trained in Thievery; thieves' tools", checkOrSave = "Thievery", summary = "Use Thievery and tools to open a lock."),
    ))

    addAll(listOf(
        "Agile" to "Reduces the normal multiple attack penalty for later attacks with the weapon.",
        "Attack" to "Marks an action that contributes to multiple attack penalty.",
        "Auditory" to "Depends on sound being heard.",
        "Concentrate" to "Requires mental focus.",
        "Emotion" to "Changes or depends on emotional state.",
        "Fear" to "Creates or manipulates fear.",
        "Flourish" to "A special technique normally limited in how often it can be used in a turn.",
        "Fortune" to "Lets a creature improve or alter a roll through favorable fate.",
        "Healing" to "Restores Hit Points or otherwise improves a creature's condition.",
        "Incapacitation" to "Uses special degree-of-success protection against effects that can completely disable stronger creatures.",
        "Manipulate" to "Requires physical manipulation and can interact with reactions or restrictions.",
        "Mental" to "Affects the mind.",
        "Move" to "Involves movement or changing position.",
        "Press" to "An attack technique intended for later attacks in a turn.",
        "Rage" to "Used by abilities that function during barbarian Rage.",
        "Secret" to "The GM may roll the check privately.",
        "Stance" to "Enters a persistent combat stance until its ending condition is met.",
        "Sustain" to "Requires continuing attention to maintain an ongoing effect.",
    ).map { (name, summary) -> lib("trait-${name.lowercase()}", name, LibraryKind.TRAIT, "Trait", summary = summary) })

    addAll(listOf(
        "Blinded" to "You cannot see and must rely on other senses.",
        "Clumsy" to "Applies a status penalty to Dexterity-based checks and DCs.",
        "Concealed" to "You are harder to target because vision is partially obscured.",
        "Dazzled" to "Your vision is impaired.",
        "Doomed" to "Reduces how much Dying you can withstand before death.",
        "Drained" to "Weakens Constitution-related durability and reduces maximum Hit Points.",
        "Dying" to "Tracks how close a creature is to death after being knocked out.",
        "Enfeebled" to "Applies a status penalty to Strength-based checks and DCs.",
        "Frightened" to "Applies a status penalty to checks and DCs and normally decreases over time.",
        "Grabbed" to "Restricts movement and makes the creature off-guard.",
        "Off-Guard" to "Reduces Armor Class against attacks.",
        "Persistent Damage" to "Deals repeating damage and normally prompts a recovery flat check.",
        "Prone" to "You are on the ground, affecting movement and defenses.",
        "Quickened" to "Grants an additional action with restrictions defined by the effect.",
        "Restrained" to "Severely restricts movement and many actions.",
        "Sickened" to "Applies a status penalty and can usually be reduced by retching.",
        "Slowed" to "Reduces the actions you regain at the start of your turn.",
        "Stunned" to "Consumes actions when you regain actions.",
        "Stupefied" to "Applies a status penalty to mental checks/DCs and interferes with spellcasting.",
        "Wounded" to "Makes future Dying episodes more dangerous.",
    ).map { (name, summary) -> lib("condition-${name.lowercase().replace(" ", "-")}", name, LibraryKind.CONDITION, "Condition", summary = summary) })

    addAll(listOf(
        lib("spell-detect-magic", "Detect Magic", LibraryKind.SPELL, "Cantrip", level = 0, actions = 2, traditions = listOf("Arcane", "Divine", "Occult", "Primal"), traits = listOf("Cantrip", "Concentrate"), summary = "Sense the presence of magic in your surroundings."),
        lib("spell-electric-arc", "Electric Arc", LibraryKind.SPELL, "Cantrip", level = 0, actions = 2, traditions = listOf("Arcane", "Primal"), targets = "Up to 2 creatures", checkOrSave = "Reflex", damage = "1d4", damageType = "electricity", basicSave = true, summary = "Arc electricity between nearby targets; heighten damage with spell rank."),
        lib("spell-guidance", "Guidance", LibraryKind.SPELL, "Cantrip", level = 0, actions = 1, traditions = listOf("Divine", "Occult", "Primal"), targets = "1 creature", summary = "Grant a brief bonus to a creature's next relevant check."),
        lib("spell-light", "Light", LibraryKind.SPELL, "Cantrip", level = 0, actions = 2, traditions = listOf("Arcane", "Divine", "Occult", "Primal"), summary = "Create magical illumination."),
        lib("spell-message", "Message", LibraryKind.SPELL, "Cantrip", level = 0, actions = 1, traditions = listOf("Arcane", "Divine", "Occult"), targets = "1 creature", summary = "Send a quiet magical message to a nearby creature."),
        lib("spell-prestidigitation", "Prestidigitation", LibraryKind.SPELL, "Cantrip", level = 0, actions = 2, traditions = listOf("Arcane", "Divine", "Occult", "Primal"), summary = "Produce small harmless magical effects useful for utility and flavor."),
        lib("spell-shield", "Shield", LibraryKind.SPELL, "Cantrip", level = 0, actions = 1, traditions = listOf("Arcane", "Divine", "Occult"), summary = "Create a brief magical shield that improves defense and may absorb damage."),
        lib("spell-telekinetic-projectile", "Telekinetic Projectile", LibraryKind.SPELL, "Cantrip", level = 0, actions = 2, traditions = listOf("Arcane", "Occult"), checkOrSave = "Spell attack", damage = "1d6", summary = "Hurl a nearby unattended object or debris with telekinetic force."),
        lib("spell-fear", "Fear", LibraryKind.SPELL, "Spell", level = 1, actions = 2, traditions = listOf("Arcane", "Divine", "Occult", "Primal"), targets = "1 creature", checkOrSave = "Will", traits = listOf("Emotion", "Fear", "Mental"), summary = "Inflict fear; the severity depends on the target's Will save."),
        lib("spell-heal", "Heal", LibraryKind.SPELL, "Spell", level = 1, actions = 1, traditions = listOf("Divine", "Primal"), healing = true, damage = "1d8", summary = "Channel vitality to restore Hit Points; action count changes its range/effect."),
        lib("spell-harm", "Harm", LibraryKind.SPELL, "Spell", level = 1, actions = 1, traditions = listOf("Divine"), damage = "1d8", damageType = "void", checkOrSave = "Fortitude", summary = "Channel void energy; action count changes its range/effect."),
        lib("spell-force-barrage", "Force Barrage", LibraryKind.SPELL, "Spell", level = 1, actions = 1, traditions = listOf("Arcane", "Occult"), damage = "1d4+1", damageType = "force", summary = "Create force projectiles that automatically hit valid targets; more actions create more projectiles."),
        lib("spell-grease", "Grease", LibraryKind.SPELL, "Spell", level = 1, actions = 2, traditions = listOf("Arcane", "Primal"), checkOrSave = "Reflex", summary = "Coat a surface or object in slippery magical grease."),
        lib("spell-mystic-armor", "Mystic Armor", LibraryKind.SPELL, "Spell", level = 1, actions = 2, traditions = listOf("Arcane", "Occult"), summary = "Create protective magical armor for an unarmored creature."),
        lib("spell-runic-weapon", "Runic Weapon", LibraryKind.SPELL, "Spell", level = 1, actions = 2, traditions = listOf("Arcane", "Divine", "Occult", "Primal"), targets = "1 weapon", summary = "Temporarily empower a weapon's fundamental striking power."),
        lib("spell-summon-animal", "Summon Animal", LibraryKind.SPELL, "Spell", level = 1, actions = 3, traditions = listOf("Arcane", "Primal"), traits = listOf("Concentrate", "Summon"), summary = "Summon an animal creature appropriate to the spell rank and sustain the summon."),
        lib("spell-summon-undead", "Summon Undead", LibraryKind.SPELL, "Spell", level = 1, actions = 3, traditions = listOf("Arcane", "Divine", "Occult"), traits = listOf("Concentrate", "Summon"), summary = "Summon an undead creature appropriate to the spell rank and sustain the summon."),
        lib("spell-grim-tendrils", "Grim Tendrils", LibraryKind.SPELL, "Spell", level = 1, actions = 2, traditions = listOf("Arcane", "Occult"), checkOrSave = "Fortitude", damage = "2d4", damageType = "void", summary = "Send a line of dark tendrils through creatures, dealing void damage and possibly persistent bleed damage."),
    ))

    addAll(listOf(
        lib("ability-rage", "Rage", LibraryKind.ABILITY, "Class Ability", actions = 1, classes = listOf("Barbarian"), traits = listOf("Rage"), summary = "Enter a powerful combat state that improves offense while applying its class restrictions."),
        lib("feat-sudden-charge", "Sudden Charge", LibraryKind.FEAT, "Class Feat", level = 1, actions = 2, classes = listOf("Barbarian"), traits = listOf("Flourish", "Move"), summary = "Close distance quickly and make a Strike as one activity."),
        lib("ability-panache", "Panache", LibraryKind.ABILITY, "Class Ability", classes = listOf("Swashbuckler"), summary = "Tracks the swashbuckler's momentum and enables class techniques and finishers."),
        lib("ability-finisher", "Finisher", LibraryKind.ABILITY, "Class Ability", classes = listOf("Swashbuckler"), traits = listOf("Finisher"), summary = "A decisive swashbuckler attack that uses panache and follows finisher restrictions."),
        lib("ability-druid-spellcasting", "Primal Spellcasting", LibraryKind.ABILITY, "Class Ability", classes = listOf("Druid"), summary = "Druid spellcasting using the primal tradition."),
        lib("ability-wild-shape", "Untamed Form / Wild Shape", LibraryKind.ABILITY, "Class Ability", classes = listOf("Druid"), summary = "Transform into battle forms using the druid's shape-changing magic; exact name/options depend on rules version."),
        lib("ability-arcane-spellcasting", "Arcane Spellcasting", LibraryKind.ABILITY, "Class Ability", classes = listOf("Wizard"), summary = "Wizard spellcasting using the arcane tradition and prepared spell slots."),
        lib("ability-drain-bonded-item", "Drain Bonded Item", LibraryKind.ABILITY, "Class Ability", classes = listOf("Wizard"), summary = "Use a bonded item to recover access to a prepared spell according to the wizard class feature."),
        lib("feat-toughness", "Toughness", LibraryKind.FEAT, "General Feat", level = 1, summary = "Improve durability and recovery from dying."),
        lib("feat-diehard", "Diehard", LibraryKind.FEAT, "General Feat", level = 1, summary = "Increase how much Dying you can withstand before death."),
    ))

    addAll(listOf(
        lib("homebrew-chaos-aura", "Chaos Aura", LibraryKind.ABILITY, "Cube-Borne", classes = listOf("Barbarian"), traits = listOf("Aura", "Cube-Borne"), summary = "Campaign homebrew Cube-Borne chaos aura. Configure exact mechanical text with the GM.", sourceLabel = "Campaign homebrew", homebrew = true),
        lib("homebrew-cubes-favorite-mistake", "Cube's Favorite Mistake", LibraryKind.ABILITY, "Cube-Borne", classes = listOf("Barbarian"), traits = listOf("Cube-Borne"), summary = "Campaign homebrew Cube-Borne barbarian power. Configure the current tier with the GM.", sourceLabel = "Campaign homebrew", homebrew = true),
        lib("homebrew-thorn-crown-rage", "Thorn Crown Rage", LibraryKind.ABILITY, "Cube-Borne", classes = listOf("Barbarian"), traits = listOf("Rage", "Cube-Borne"), summary = "Campaign homebrew rage evolution tied to the Cube-Borne progression.", sourceLabel = "Campaign homebrew", homebrew = true),
        lib("homebrew-borrowed-pulse", "Borrowed Pulse", LibraryKind.ABILITY, "Cube-Borne", traits = listOf("Cube-Borne"), summary = "Campaign homebrew that temporarily steals vitality from an enemy; configure the unlocked tier with the GM.", sourceLabel = "Campaign homebrew", homebrew = true),
        lib("homebrew-duel-already-happened", "The Duel That Already Happened", LibraryKind.ABILITY, "Cube-Borne", traits = listOf("Cube-Borne"), summary = "Campaign homebrew temporal dueling power; configure the unlocked tier with the GM.", sourceLabel = "Campaign homebrew", homebrew = true),
        lib("homebrew-beast-out-of-time", "Beast Out of Time", LibraryKind.ABILITY, "Cube-Borne", traits = listOf("Cube-Borne"), summary = "Campaign homebrew time-displaced beast power; configure the unlocked tier with the GM.", sourceLabel = "Campaign homebrew", homebrew = true),
    ))
}.sortedWith(compareBy({ it.kind }, { it.name }))
