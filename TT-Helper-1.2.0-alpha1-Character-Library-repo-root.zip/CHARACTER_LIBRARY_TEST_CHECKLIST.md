# TT Helper 1.2.0 Alpha 1 — Character Intelligence & Library Test

1. Install/update Android build and confirm version 20 / 1.2.0-alpha1.
2. Open a character and enter a negative ability modifier such as STR -1; save and confirm it persists.
3. Set a level, ability modifier, and skill proficiency. Confirm a standard skill recalculates using ability + level/rank proficiency.
4. Add an item/permanent skill bonus and confirm the displayed result changes.
5. Enter a manual skill override, save, refresh, and confirm the override wins.
6. On iPhone player browser, confirm signed fields allow `-1` and no longer depend on the number-only keypad.
7. Open Player → Library; search for `Fear`, `Athletics`, `Rage`, and `Agile`.
8. Filter Library → Available to me and Campaign homebrew.
9. Add a spell/ability/feat from Library to Drafts; submit it; approve it on the GM host.
10. Confirm approved spell/ability/feat appears in the appropriate character area.
11. Repeat library test from Windows GM host and confirm the player browser behaves the same.
12. Load an older campaign backup and confirm it opens without losing character data.
