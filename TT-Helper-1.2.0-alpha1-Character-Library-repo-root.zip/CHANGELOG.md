# Changelog

## 1.2.0 Alpha 1
- Added automatic PF2e standard-skill math and negative modifier support.
- Added per-skill ability, proficiency, item/permanent bonus, and manual override controls.
- Added shared searchable Character & Rules Library for Android GM, Windows GM, and player browsers.
- Added player library filters: type, available-to-me, campaign homebrew, and text search.
- Added one-tap Library → Drafts flow for spells, abilities, actions, and feats.
- Added FEAT as a moderated player content draft/approval type.
- Added starter rules data for skills, actions, traits, conditions, common spells, current-party class options, and Cube-Borne entries.
- Advanced save schema to 10 while preserving older save compatibility.
- Android versionCode 20 / versionName 1.2.0-alpha1; Windows package 1.2.0.

## 1.1.0 Alpha 1
- Added Windows GM host foundation using Compose Desktop and the same local LAN player protocol.
