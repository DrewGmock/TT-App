import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    id("org.jetbrains.kotlin.jvm")
    id("org.jetbrains.compose")
    id("org.jetbrains.kotlin.plugin.compose")
}

group = "com.drew.tthelper"
version = "1.2.0-alpha1"

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation(compose.components.resources)

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")

    implementation("io.ktor:ktor-server-core-jvm:3.6.0")
    implementation("io.ktor:ktor-server-cio-jvm:3.6.0")
    implementation("io.ktor:ktor-server-websockets-jvm:3.6.0")
    implementation("org.json:json:20250517")
    implementation("org.slf4j:slf4j-simple:2.0.17")
}

compose.desktop {
    application {
        mainClass = "com.drew.tthelper.desktop.DesktopMainKt"
        jvmArgs += listOf("-Dfile.encoding=UTF-8")

        nativeDistributions {
            targetFormats(TargetFormat.Msi, TargetFormat.Exe)
            packageName = "TT Helper"
            packageVersion = "1.2.0"
            description = "TT Helper Pathfinder 2e local-first GM host"
            vendor = "TT Helper"
            windows {
                menuGroup = "TT Helper"
                shortcut = true
                dirChooser = true
                perUserInstall = true
                upgradeUuid = "2c99f7a4-55c0-4b57-bdb8-9c35bb49f161"
            }
        }
    }
}
