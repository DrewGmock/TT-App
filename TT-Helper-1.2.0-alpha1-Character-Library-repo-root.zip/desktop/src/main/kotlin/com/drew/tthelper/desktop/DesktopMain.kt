package com.drew.tthelper.desktop

import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowState
import androidx.compose.ui.window.application
import com.drew.tthelper.server.HostRuntime
import com.drew.tthelper.ui.DesktopTTHelperApp
import com.drew.tthelper.ui.loadDesktopPreferences
import java.io.File

fun main() {
    val dataDir = defaultDataDir().also { it.mkdirs() }
    val runtime = HostRuntime(dataDir)
    val preferences = loadDesktopPreferences(dataDir)
    if (preferences.autoStartHost) runtime.requestStart()

    application {
        Window(
            onCloseRequest = {
                runtime.close()
                exitApplication()
            },
            title = "TT Helper — Windows GM",
            state = WindowState(size = DpSize(1500.dp, 940.dp)),
        ) {
            DesktopTTHelperApp(runtime, dataDir)
        }
    }
}

private fun defaultDataDir(): File {
    val windowsAppData = System.getenv("APPDATA")?.takeIf { it.isNotBlank() }
    return if (windowsAppData != null) {
        File(windowsAppData, "TT Helper")
    } else {
        File(System.getProperty("user.home"), ".tt-helper")
    }
}
