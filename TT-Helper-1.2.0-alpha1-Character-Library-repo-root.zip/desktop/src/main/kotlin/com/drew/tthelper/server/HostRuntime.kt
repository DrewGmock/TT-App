package com.drew.tthelper.server

import com.drew.tthelper.network.NetworkUtils
import com.drew.tthelper.state.SessionStore
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class HostStatus(
    val running: Boolean = false,
    val address: String? = null,
    val port: Int = 8787,
    val error: String? = null,
)

class HostRuntime(
    dataDir: File,
    val store: SessionStore = SessionStore(dataDir),
    val registry: PlayerRegistry = PlayerRegistry(dataDir),
    private val port: Int = 8787,
) : AutoCloseable {
    private val _status = MutableStateFlow(HostStatus(port = port))
    val status: StateFlow<HostStatus> = _status.asStateFlow()
    private var server: HostServer? = null

    @Synchronized
    fun requestStart() {
        if (_status.value.running) return
        runCatching {
            HostServer(store = store, registry = registry, port = port).also {
                it.start()
                server = it
            }
        }.onSuccess {
            _status.value = HostStatus(
                running = true,
                address = NetworkUtils.localIpv4Address(),
                port = port,
            )
        }.onFailure { error ->
            server?.close()
            server = null
            _status.value = HostStatus(
                running = false,
                port = port,
                error = error.message ?: "Unable to start the Windows host",
            )
        }
    }

    @Synchronized
    fun requestStop() {
        server?.close()
        server = null
        _status.value = HostStatus(running = false, port = port)
    }

    fun refreshAddress() {
        if (_status.value.running) {
            _status.value = _status.value.copy(address = NetworkUtils.localIpv4Address())
        }
    }

    fun joinUrl(): String? {
        val current = _status.value
        val ip = current.address ?: return null
        if (!current.running) return null
        return "http://$ip:${current.port}/?pin=${registry.pin.value}"
    }

    fun displayUrl(): String? {
        val current = _status.value
        val ip = current.address ?: return null
        if (!current.running) return null
        return "http://$ip:${current.port}/display"
    }

    override fun close() {
        requestStop()
    }
}
