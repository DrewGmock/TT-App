package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime
import java.awt.Desktop
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection
import java.net.URI

@Composable
fun ConnectionsScreen(runtime: HostRuntime) {
    val status by runtime.status.collectAsState()
    val clients by runtime.registry.clients.collectAsState()
    val pin by runtime.registry.pin.collectAsState()
    var message by remember { mutableStateOf("") }

    val joinUrl = runtime.joinUrl()
    val displayUrl = runtime.displayUrl()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Player Connections", fontSize = 28.sp)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (status.running) "Windows host online" else "Windows host offline", fontSize = 20.sp)
                if (status.running && joinUrl != null) {
                    Text("PIN $pin", fontSize = 30.sp)
                    Text(joinUrl)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            copyText(joinUrl)
                            message = "Join address copied ✓"
                        }) { Text("Copy join address") }
                        OutlinedButton(onClick = {
                            openBrowser(joinUrl)
                        }) { Text("Open player page") }
                        OutlinedButton(onClick = {
                            runtime.registry.rotatePin()
                            message = "PIN rotated"
                        }) { Text("Rotate PIN") }
                        OutlinedButton(onClick = {
                            runtime.refreshAddress()
                            message = "Network address refreshed"
                        }) { Text("Refresh address") }
                    }
                    Text("Players use Safari/Chrome on the same private Wi-Fi/LAN. Windows may ask you to allow TT Helper through the firewall the first time you host.")
                } else {
                    Text("Start the host from the top bar to create a player join address and PIN.")
                }
                if (message.isNotBlank()) Text(message)
            }
        }

        if (displayUrl != null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Second-screen / TV mode", fontSize = 20.sp)
                    Text(displayUrl)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilledTonalButton(onClick = { openBrowser(displayUrl) }) { Text("Open display") }
                        OutlinedButton(onClick = {
                            copyText(displayUrl)
                            message = "Display address copied ✓"
                        }) { Text("Copy display address") }
                    }
                    Text("This page only exposes player-safe encounter information.")
                }
            }
        }

        Text("Assignments", fontSize = 21.sp)
        if (clients.isEmpty()) Text("No characters assigned yet.")
        clients.forEach { client ->
            val pcName = runtime.store.state.value.pcs.firstOrNull { it.id == client.pcId }?.name ?: client.pcId
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("$pcName • ${client.displayName}")
                        Text(if (client.connected) "Connected" else "Assigned, offline")
                    }
                    Button(onClick = { runtime.registry.releasePc(client.pcId) }) { Text("Release") }
                }
            }
        }
    }
}

private fun copyText(value: String) {
    runCatching {
        Toolkit.getDefaultToolkit().systemClipboard.setContents(StringSelection(value), null)
    }
}

private fun openBrowser(url: String) {
    runCatching {
        if (Desktop.isDesktopSupported()) Desktop.getDesktop().browse(URI(url))
    }
}
