package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime
import java.awt.Desktop
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.swing.JFileChooser

@Composable
fun SettingsScreen(
    runtime: HostRuntime,
    dataDir: File,
    preferences: DesktopUiPreferences,
    onPreferencesChanged: (DesktopUiPreferences) -> Unit,
) {
    val status by runtime.status.collectAsState()
    val state by runtime.store.state.collectAsState()
    var message by remember { mutableStateOf("") }
    val diagnostics = runtime.store.diagnostics()
    val backups = runtime.store.backupSummaries().take(8)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Windows Settings", fontSize = 28.sp)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Appearance", fontSize = 20.sp)
                Text("Theme")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (value, label) ->
                        FilterChip(selected = preferences.themeMode == value, onClick = { onPreferencesChanged(preferences.copy(themeMode = value)) }, label = { Text(label) })
                    }
                }
                Text("Accent")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("blue" to "Blue", "purple" to "Purple", "ember" to "Ember", "orange" to "Orange", "forest" to "Forest", "teal" to "Teal", "gold" to "Gold", "steel" to "Steel").forEach { (value, label) ->
                        FilterChip(selected = preferences.accentColor == value, onClick = { onPreferencesChanged(preferences.copy(accentColor = value)) }, label = { Text(label) })
                    }
                }
                Text("Text size")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(.9f to "Small", 1f to "Normal", 1.15f to "Large", 1.3f to "Extra Large").forEach { (value, label) ->
                        FilterChip(selected = kotlin.math.abs(preferences.fontScale - value) < .02f, onClick = { onPreferencesChanged(preferences.copy(fontScale = value)) }, label = { Text(label) })
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToggleSetting("High contrast", preferences.highContrast) { onPreferencesChanged(preferences.copy(highContrast = it)) }
                    ToggleSetting("GM Quick Bar", preferences.quickBar) { onPreferencesChanged(preferences.copy(quickBar = it)) }
                    ToggleSetting("Auto-start host", preferences.autoStartHost) { onPreferencesChanged(preferences.copy(autoStartHost = it)) }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Windows Host", fontSize = 20.sp)
                Text(if (status.running) "Online • ${status.address ?: "finding address"}:${status.port}" else "Offline")
                status.error?.takeIf { it.isNotBlank() }?.let { Text("Host error: $it") }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { if (status.running) runtime.requestStop() else runtime.requestStart() }) { Text(if (status.running) "Stop host" else "Start host") }
                    OutlinedButton(onClick = { runtime.refreshAddress(); message = "Network address refreshed" }) { Text("Refresh network") }
                }
                Text("The first time Windows hosts, allow TT Helper on Private networks if Windows Defender Firewall asks. Public-network access is not required for normal home/LAN play.")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Campaign Health", fontSize = 20.sp)
                Text("Save: ${if (diagnostics.saveHealthy) "Healthy ✓" else "Needs attention"}")
                Text("Revision ${diagnostics.sessionRevision} • Schema ${diagnostics.schemaVersion}")
                Text("Backups: ${diagnostics.backupCount} • Last save: ${formatTime(diagnostics.lastPersistAt)}")
                diagnostics.recoveryMessage?.let { Text(it) }
                diagnostics.lastPersistenceError?.let { Text("Last storage error: $it") }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        val file = runtime.store.exportBackup()
                        message = "Safety backup created: ${file.name}"
                    }) { Text("Backup Now") }
                    OutlinedButton(onClick = { message = if (runtime.store.runIntegrityCheck()) "Integrity check passed ✓" else "Integrity check failed" }) { Text("Run integrity check") }
                    OutlinedButton(onClick = { message = if (runtime.store.recoverLastKnownGood()) "Recovered last known-good save" else "No last-known-good save available" }) { Text("Recover last good") }
                }
                if (backups.isNotEmpty()) {
                    Text("Recent backups")
                    backups.forEach { backup ->
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${backup.fileName} • rev ${backup.revision} • ${if (backup.valid) "valid" else "unreadable"}")
                            OutlinedButton(enabled = backup.valid, onClick = {
                                message = if (runtime.store.restoreBackupByName(backup.fileName)) "Restored ${backup.fileName}" else "Restore failed"
                            }) { Text("Restore") }
                        }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Full Campaign Portability", fontSize = 20.sp)
                Text("Move a complete campaign between Windows and Android without re-entering PCs, inventory, prep, history, or active state.")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        val file = chooseSaveFile("TT-Helper-Full-Campaign.ttcampaign")
                        if (file != null) {
                            runCatching { file.writeText(runtime.store.fullCampaignJson()) }
                                .onSuccess { message = "Full campaign exported: ${file.name}" }
                                .onFailure { message = "Export failed: ${it.message}" }
                        }
                    }) { Text("Export full campaign") }
                    OutlinedButton(onClick = {
                        val file = chooseOpenFile("Restore TT Helper campaign")
                        if (file != null) {
                            message = if (runtime.store.restoreFullCampaign(file.readText())) "Full campaign restored ✓" else "Restore failed"
                        }
                    }) { Text("Restore full campaign") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Desktop Data", fontSize = 20.sp)
                Text(dataDir.absolutePath)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { runCatching { if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(dataDir) } }) { Text("Open data folder") }
                }
                Text("TT Helper 1.2.0 Alpha 1 • Character Intelligence & Library")
                Text("Current campaign: ${state.campaignName} • ${state.pcs.size} PCs")
            }
        }

        if (message.isNotBlank()) Text(message)
    }
}

@Composable
private fun ToggleSetting(label: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Switch(checked = checked, onCheckedChange = onChanged)
        Text(label)
    }
}

private fun chooseOpenFile(title: String): File? {
    val chooser = JFileChooser().apply { dialogTitle = title }
    return if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) chooser.selectedFile else null
}

private fun chooseSaveFile(defaultName: String): File? {
    val chooser = JFileChooser().apply {
        dialogTitle = "Save TT Helper campaign"
        selectedFile = File(defaultName)
    }
    return if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) chooser.selectedFile else null
}

private fun formatTime(epochMillis: Long): String {
    if (epochMillis <= 0L) return "never"
    return runCatching { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(epochMillis)) }.getOrDefault("unknown")
}
