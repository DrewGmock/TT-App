package com.drew.tthelper.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.RuleRequestStatus
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.server.HostRuntime
import java.io.File

private enum class DesktopPage(val label: String, val group: String) {
    LIVE("Live", "Play"),
    RULES("Rules", "Play"),
    PLAYERS("Players", "Play"),
    CHARACTERS("Characters", "Campaign"),
    SPELLS("Spells", "Campaign"),
    LIBRARY("Library", "Campaign"),
    APPROVALS("Approvals", "Campaign"),
    INVENTORY("Loot & Inventory", "Campaign"),
    PREP("Session Prep", "Prep"),
    IMPORT_EXPORT("Import / Export", "Prep"),
    HISTORY("History", "Prep"),
    SETTINGS("Settings", "System"),
}

@Composable
fun DesktopTTHelperApp(runtime: HostRuntime, dataDir: File) {
    val status by runtime.status.collectAsState()
    val state by runtime.store.state.collectAsState()
    var page by remember { mutableStateOf(DesktopPage.LIVE) }
    var sidebarCollapsed by remember { mutableStateOf(false) }
    var preferences by remember { mutableStateOf(loadDesktopPreferences(dataDir)) }

    val systemDark = isSystemInDarkTheme()
    val useDark = when (preferences.themeMode) {
        "light" -> false
        "dark" -> true
        else -> systemDark
    }
    val accent = desktopAccentColor(preferences.accentColor, useDark)
    val scheme = when {
        preferences.highContrast && useDark -> darkColorScheme(
            primary = Color.White,
            onPrimary = Color.Black,
            secondary = accent,
            background = Color.Black,
            surface = Color.Black,
            onSurface = Color.White,
        )
        preferences.highContrast && !useDark -> lightColorScheme(
            primary = Color.Black,
            onPrimary = Color.White,
            secondary = accent,
            background = Color.White,
            surface = Color.White,
            onSurface = Color.Black,
        )
        useDark -> darkColorScheme(primary = accent, secondary = accent.copy(alpha = .82f), tertiary = accent.copy(alpha = .68f))
        else -> lightColorScheme(primary = accent, secondary = accent.copy(alpha = .82f), tertiary = accent.copy(alpha = .68f))
    }

    val baseDensity = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(baseDensity.density, preferences.fontScale)) {
        MaterialTheme(colorScheme = scheme) {
            Row(Modifier.fillMaxSize()) {
                DesktopSidebar(
                    page = page,
                    collapsed = sidebarCollapsed,
                    onToggle = { sidebarCollapsed = !sidebarCollapsed },
                    onSelect = { page = it },
                )
                Column(Modifier.fillMaxSize()) {
                    DesktopHostBar(
                        runtime = runtime,
                        running = status.running,
                        address = status.address,
                        port = status.port,
                    )
                    status.error?.takeIf { it.isNotBlank() }?.let { error ->
                        Card(
                            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        ) {
                            Text("Host error: $error", Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                    if (preferences.quickBar) {
                        DesktopQuickBar(runtime, onNavigate = { page = it })
                    }
                    Box(Modifier.fillMaxSize()) {
                        when (page) {
                            DesktopPage.LIVE -> LiveSessionScreen(runtime, tablet = true)
                            DesktopPage.RULES -> RulesScreen(runtime)
                            DesktopPage.PLAYERS -> ConnectionsScreen(runtime)
                            DesktopPage.CHARACTERS -> CharacterManagementScreen(runtime)
                            DesktopPage.SPELLS -> GmSpellScreen(runtime)
                            DesktopPage.LIBRARY -> LibraryScreen(runtime)
                            DesktopPage.APPROVALS -> ApprovalInboxScreen(runtime)
                            DesktopPage.INVENTORY -> InventoryScreen(runtime)
                            DesktopPage.PREP -> SessionPrepScreen(runtime)
                            DesktopPage.IMPORT_EXPORT -> ImportExportScreen(runtime)
                            DesktopPage.HISTORY -> HistoryScreen(runtime)
                            DesktopPage.SETTINGS -> SettingsScreen(
                                runtime = runtime,
                                dataDir = dataDir,
                                preferences = preferences,
                                onPreferencesChanged = { next ->
                                    preferences = next
                                    saveDesktopPreferences(dataDir, next)
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DesktopSidebar(
    page: DesktopPage,
    collapsed: Boolean,
    onToggle: () -> Unit,
    onSelect: (DesktopPage) -> Unit,
) {
    val width = if (collapsed) 76.dp else 210.dp
    Column(
        Modifier.width(width).fillMaxHeight().verticalScroll(rememberScrollState()).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text("TT", fontSize = 24.sp)
        TextButton(onClick = onToggle) { Text(if (collapsed) ">>" else "Collapse") }
        HorizontalDivider()
        DesktopPage.entries.groupBy { it.group }.forEach { (group, pages) ->
            if (!collapsed) Text(group.uppercase(), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
            pages.forEach { item ->
                val label = if (collapsed) shortLabel(item) else item.label
                if (item == page) {
                    FilledTonalButton(onClick = { onSelect(item) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                } else {
                    TextButton(onClick = { onSelect(item) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                }
            }
        }
    }
}

private fun shortLabel(page: DesktopPage): String = when (page) {
    DesktopPage.LIVE -> "Live"
    DesktopPage.RULES -> "Rule"
    DesktopPage.PLAYERS -> "Plyr"
    DesktopPage.CHARACTERS -> "Char"
    DesktopPage.SPELLS -> "Spl"
    DesktopPage.LIBRARY -> "Lib"
    DesktopPage.APPROVALS -> "Appr"
    DesktopPage.INVENTORY -> "Loot"
    DesktopPage.PREP -> "Prep"
    DesktopPage.IMPORT_EXPORT -> "I/E"
    DesktopPage.HISTORY -> "Hist"
    DesktopPage.SETTINGS -> "Set"
}

@Composable
private fun DesktopHostBar(runtime: HostRuntime, running: Boolean, address: String?, port: Int) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.width(310.dp)) {
            Text("TT Helper — Windows GM", fontSize = 22.sp)
            Text("1.2.0 Alpha 1 • ${if (running) "Hosting ${address ?: "finding IP"}:$port" else "Host offline"}", fontSize = 12.sp)
        }
        OutlinedButton(onClick = { runtime.store.undo() }) { Text("Undo") }
        Button(onClick = { if (running) runtime.requestStop() else runtime.requestStart() }) {
            Text(if (running) "Stop host" else "Start host")
        }
    }
}

@Composable
private fun DesktopQuickBar(runtime: HostRuntime, onNavigate: (DesktopPage) -> Unit) {
    val state by runtime.store.state.collectAsState()
    val encounter = state.encounter
    val current = encounter?.currentCombatant()
    val playerRequests = encounter?.endTurnRequests?.size ?: 0
    val rules = encounter?.ruleRequests?.count { it.status == RuleRequestStatus.PENDING } ?: 0
    val approvals = state.pcs.sumOf { pc -> pc.contentDrafts.count { it.status == "PENDING" } } + state.characterRequests.size
    val checks = encounter?.pendingEffectChecks?.size ?: 0

    FlowRow(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Text(if (encounter?.active == true) "Round ${encounter.round} • ${current?.name ?: "Awaiting turn"}" else "Between encounters")
        if (encounter?.active == true) Button(onClick = { runtime.store.nextTurn() }) { Text("Next Turn") }
        OutlinedButton(onClick = { runtime.store.undo() }) { Text("Undo") }
        if (rules > 0) FilledTonalButton(onClick = { onNavigate(DesktopPage.RULES) }) { Text("Rules $rules") }
        if (approvals > 0) FilledTonalButton(onClick = { onNavigate(DesktopPage.APPROVALS) }) { Text("Approvals $approvals") }
        if (playerRequests > 0) FilledTonalButton(onClick = { onNavigate(DesktopPage.PLAYERS) }) { Text("Players $playerRequests") }
        if (checks > 0) FilledTonalButton(onClick = { onNavigate(DesktopPage.LIVE) }) { Text("Checks $checks") }
        TextButton(onClick = { onNavigate(DesktopPage.PREP) }) { Text("Prep") }
    }
}
