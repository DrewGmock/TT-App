package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime
import com.drew.tthelper.state.ContentPackageCodec
import com.drew.tthelper.state.ContentPackageType
import com.drew.tthelper.state.ImportStrategy
import com.drew.tthelper.state.ImportedContentPackage
import java.io.File
import javax.swing.JFileChooser

@Composable
fun ImportExportScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var imported by remember { mutableStateOf<ImportedContentPackage?>(null) }
    var status by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Import / Export", fontSize = 28.sp)
        Text("Windows uses the same TT Helper package formats as Android, so prep can move between both GM hosts.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Content Library", fontSize = 20.sp)
                Text("${state.prep.preparedEncounters.size} prepared encounters • ${state.prep.enemyLibrary.size} creatures/NPCs/hazards • ${state.partyLoot.size} loot items")
                Text("Supported: .ttsession, .ttenemy, .ttenemypack, .ttloot, .ttlootpack")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Import", fontSize = 20.sp)
                Button(onClick = {
                    val file = chooseOpenFile()
                    if (file != null) {
                        runCatching { ContentPackageCodec.decode(file.readText()) }
                            .onSuccess {
                                imported = it
                                status = "Loaded ${it.name}. Review it below."
                            }
                            .onFailure {
                                imported = null
                                status = "Import failed: ${it.message ?: "Unknown package error"}"
                            }
                    }
                }) { Text("Choose TT Helper package") }
                if (status.isNotBlank()) Text(status)
            }
        }

        imported?.let { pkg ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("IMPORT PREVIEW", fontSize = 20.sp)
                    Text(pkg.name, fontSize = 18.sp)
                    Text("Type: ${pkg.type} • Schema ${pkg.schemaVersion}")
                    pkg.sessionPrep?.let { Text("${it.preparedEncounters.size} encounters • ${it.enemyLibrary.size} library entries") }
                    if (pkg.enemies.isNotEmpty()) Text("${pkg.enemies.size} creatures/NPCs/hazards")
                    if (pkg.loot.isNotEmpty()) Text("${pkg.loot.size} loot/inventory entries")
                    pkg.warnings.forEach { Text("Warning: $it") }
                    Text("Choose how name conflicts should be handled. The live campaign is not changed until you select an option.")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { applyImport(runtime, pkg, ImportStrategy.KEEP_EXISTING); status = "Imported ${pkg.name} ✓"; imported = null }) { Text("Keep Existing") }
                        Button(onClick = { applyImport(runtime, pkg, ImportStrategy.MERGE); status = "Imported ${pkg.name} ✓"; imported = null }) { Text("Merge") }
                        OutlinedButton(onClick = { applyImport(runtime, pkg, ImportStrategy.REPLACE); status = "Imported ${pkg.name} ✓"; imported = null }) { Text("Replace") }
                        OutlinedButton(onClick = { applyImport(runtime, pkg, ImportStrategy.COPY); status = "Imported ${pkg.name} ✓"; imported = null }) { Text("Import as Copies") }
                        TextButton(onClick = { imported = null; status = "Import cancelled" }) { Text("Cancel") }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Export for Android / ChatGPT", fontSize = 20.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = {
                        saveTextFile(safeFileName(state.prep.sessionTitle.ifBlank { "TT-Helper-Session" }, ".ttsession"), ContentPackageCodec.encodeSession(state.prep))
                            ?.let { status = "Saved ${it.name} ✓" }
                    }) { Text("Session Prep") }
                    OutlinedButton(
                        enabled = state.prep.enemyLibrary.isNotEmpty(),
                        onClick = {
                            saveTextFile("TT-Helper-Enemy-Pack.ttenemypack", ContentPackageCodec.encodeEnemies(state.prep.enemyLibrary, "TT Helper Enemy Library"))
                                ?.let { status = "Saved ${it.name} ✓" }
                        },
                    ) { Text("Enemy Library") }
                    OutlinedButton(
                        enabled = state.partyLoot.isNotEmpty(),
                        onClick = {
                            saveTextFile("TT-Helper-Loot-Pack.ttlootpack", ContentPackageCodec.encodeLoot(state.partyLoot, "TT Helper Loot & Inventory"))
                                ?.let { status = "Saved ${it.name} ✓" }
                        },
                    ) { Text("Loot & Inventory") }
                }
                Text("These files use the same schema as the Android GM app.")
            }
        }
    }
}

private fun applyImport(runtime: HostRuntime, pkg: ImportedContentPackage, strategy: String) {
    when (pkg.type) {
        ContentPackageType.SESSION -> pkg.sessionPrep?.let { runtime.store.importSessionPrep(it, strategy) }
        ContentPackageType.ENEMY, ContentPackageType.ENEMY_PACK -> runtime.store.importEnemies(pkg.enemies, strategy)
        ContentPackageType.LOOT, ContentPackageType.LOOT_PACK -> runtime.store.importLoot(pkg.loot, strategy)
    }
}

private fun chooseOpenFile(): File? {
    val chooser = JFileChooser().apply { dialogTitle = "Open TT Helper package" }
    return if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) chooser.selectedFile else null
}

private fun saveTextFile(defaultName: String, content: String): File? {
    val chooser = JFileChooser().apply {
        dialogTitle = "Save TT Helper package"
        selectedFile = File(defaultName)
    }
    if (chooser.showSaveDialog(null) != JFileChooser.APPROVE_OPTION) return null
    return runCatching { chooser.selectedFile.apply { writeText(content) } }.getOrNull()
}

private fun safeFileName(value: String, extension: String): String {
    val base = value.trim().ifBlank { "TT-Helper" }
        .replace(Regex("[^A-Za-z0-9._ -]+"), "-")
        .replace(Regex("\\s+"), "-")
        .trim('-', '.')
        .take(80)
    return if (base.lowercase().endsWith(extension.lowercase())) base else base + extension
}
