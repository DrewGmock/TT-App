package com.drew.tthelper.ui

import androidx.compose.ui.graphics.Color
import java.io.File
import org.json.JSONObject

data class DesktopUiPreferences(
    val themeMode: String = "dark",
    val accentColor: String = "blue",
    val fontScale: Float = 1f,
    val densityMode: String = "comfortable",
    val highContrast: Boolean = false,
    val quickBar: Boolean = true,
    val autoStartHost: Boolean = true,
)

fun loadDesktopPreferences(dataDir: File): DesktopUiPreferences {
    val file = File(dataDir, "desktop-ui-preferences.json")
    return runCatching {
        val json = JSONObject(file.readText())
        DesktopUiPreferences(
            themeMode = json.optString("themeMode", "dark"),
            accentColor = json.optString("accentColor", "blue"),
            fontScale = json.optDouble("fontScale", 1.0).toFloat().coerceIn(.85f, 1.45f),
            densityMode = json.optString("densityMode", "comfortable"),
            highContrast = json.optBoolean("highContrast", false),
            quickBar = json.optBoolean("quickBar", true),
            autoStartHost = json.optBoolean("autoStartHost", true),
        )
    }.getOrDefault(DesktopUiPreferences())
}

fun saveDesktopPreferences(dataDir: File, value: DesktopUiPreferences) {
    runCatching {
        dataDir.mkdirs()
        File(dataDir, "desktop-ui-preferences.json").writeText(JSONObject().apply {
            put("themeMode", value.themeMode)
            put("accentColor", value.accentColor)
            put("fontScale", value.fontScale)
            put("densityMode", value.densityMode)
            put("highContrast", value.highContrast)
            put("quickBar", value.quickBar)
            put("autoStartHost", value.autoStartHost)
        }.toString(2))
    }
}

fun desktopAccentColor(name: String, dark: Boolean): Color = when (name.lowercase()) {
    "purple" -> if (dark) Color(0xFFB69CFF) else Color(0xFF6542B5)
    "ember" -> if (dark) Color(0xFFFF8A70) else Color(0xFFB33827)
    "orange" -> if (dark) Color(0xFFFFB36A) else Color(0xFFB85C00)
    "forest" -> if (dark) Color(0xFF7ED99A) else Color(0xFF237A43)
    "teal" -> if (dark) Color(0xFF70D8D0) else Color(0xFF147A73)
    "gold" -> if (dark) Color(0xFFFFCC66) else Color(0xFF9A6500)
    "steel" -> if (dark) Color(0xFFB7C7D9) else Color(0xFF50687F)
    else -> if (dark) Color(0xFF8FB7FF) else Color(0xFF3567B7)
}
