# TT Helper 1.1.0 Alpha 1 — Windows Test Checklist

## Install / launch
- [ ] Build workflow produces an MSI and/or EXE artifact.
- [ ] Installer completes on Windows 10/11 x64.
- [ ] TT Helper launches into the Windows GM window.
- [ ] Closing the GM window cleanly stops the local host.

## LAN host
- [ ] Host starts on port 8787.
- [ ] Windows firewall prompt is handled for Private networks.
- [ ] Players page shows a LAN IP, PIN, and join address.
- [ ] Android/iPhone browser can join over the same Wi-Fi.
- [ ] Player reconnect works after browser refresh / brief Wi-Fi interruption.
- [ ] `/display` opens on a second browser/monitor and shows only player-safe data.

## GM parity
- [ ] Live encounter starts and advances turns.
- [ ] HP, conditions/effects, initiative, Delay/Ready, requests, and Undo work.
- [ ] Rules requests resolve correctly.
- [ ] Characters / Spells / Approvals load and edit.
- [ ] Loot & Inventory loads, edits, assigns, and uses items.
- [ ] Session Prep collapsible sections and pinned prep work.
- [ ] Encounter History recap copies to Windows clipboard.

## Portability / safety
- [ ] Android `.ttsession` imports into Windows.
- [ ] Windows `.ttsession` imports back into Android.
- [ ] Enemy and loot packs move both directions.
- [ ] Full campaign export from Android restores on Windows.
- [ ] Full campaign export from Windows restores on Android.
- [ ] Backup Now creates a backup.
- [ ] Integrity check passes.
- [ ] Restore recent backup works.

## Desktop UX
- [ ] Sidebar can collapse and every page remains reachable.
- [ ] Window resizing does not hide critical controls.
- [ ] Dark/light/system themes work.
- [ ] Accent colors work.
- [ ] High contrast and font sizing work.
