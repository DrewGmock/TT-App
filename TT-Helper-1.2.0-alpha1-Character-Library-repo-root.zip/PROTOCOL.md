# TT Helper LAN Protocol — 1.2 notes

The existing local-first join/resume/WebSocket protocol is unchanged.

## Snapshot additions
Player snapshots now include:
- expanded character skill-math fields (`skillItemBonuses`, `skillAbilityOverrides`, `skillManualOverrides`, `autoCalculateSkills`)
- a read-only starter `library` array with availability hints for the assigned character
- draft `prerequisites`

## Player action addition
`addLibraryDraft` with `{ "libraryId": "..." }` creates or refreshes a local player draft from an eligible library entry. Reference-only entries such as traits, conditions, and skills are not converted into drafts.

The normal `saveContentDraft`, `submitContentDraft`, approve/decline flow remains authoritative.
