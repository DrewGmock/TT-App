# TT Helper 1.2.0 Alpha 1 — Character Intelligence & Library

TT Helper remains a local-first PF2e table companion with Android and Windows GM hosts and browser-based player clients.

## New in 1.2 Alpha 1
- Standard skill auto-calculation: ability modifier + proficiency (level + rank) + item/permanent bonus.
- Per-skill governing ability override and manual final-value override.
- Signed/negative modifier entry is supported in the player browser, including iPhone-friendly text entry.
- New shared Character & Rules Library available to GM and player clients.
- Starter library includes standard skills, common actions, traits, conditions, common spells, class options relevant to the current party, and Cube-Borne campaign entries.
- Players can filter the library by type, availability, or homebrew and add spells/abilities/feats/actions to their existing Drafts → GM Approval workflow.
- Feats are now a supported approval draft type.
- Library availability hints use level, class, and spell tradition when that information is known; the GM can still approve exceptions/homebrew.
- Campaign schema advanced to 10; older saves remain readable with defaults for new character-math fields.

## Versions
- Android: `versionCode = 20`, `versionName = "1.2.0-alpha1"`
- Desktop source: `1.2.0-alpha1`
- Windows installer package version: `1.2.0`

## Build
Use the existing GitHub ZIP extraction workflows. Android builds from `:app`; Windows builds from `:desktop`.

## Content note
The built-in library is intentionally a compact starter/reference dataset using short original summaries and structured mechanics rather than copied source-book text. The library infrastructure is designed to grow through future packs and campaign homebrew.
