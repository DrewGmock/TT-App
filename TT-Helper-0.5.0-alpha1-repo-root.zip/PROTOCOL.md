# TT Helper LAN Protocol Notes — 0.5.0-alpha1

The GM Android app remains the authoritative state owner. Players connect through the embedded LAN web client and receive filtered snapshots.

## Inventory security boundary

Inventory data is stored in the GM session state. A player's snapshot receives only:

- items assigned to that PC that are marked `revealedToPlayers`
- shared-stash items marked `revealedToPlayers`
- player-safe fields only

GM-only notes and hidden items are never sent to player clients. Unidentified items are sent using their unidentified display name and do not expose true category/value/traits/runes/level.

## Player inventory actions

Ownership is derived from the authenticated player token. Player actions may:

- consume/use an assigned consumable
- change carry state on an assigned item
- move an assigned item into/out of one of that same PC's containers

A player cannot mutate another PC's inventory because the server validates the authenticated PC id against `assignedToPcId`.

## Rules requests

The Rules UI now labels the roller and opposing DC/defense explicitly. Saving throws use the target's save modifier against the actor/caster DC; attacks use the actor's attack modifier against the target AC. Natural 1/20 degree shifts are displayed separately from the base result.
