package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.server.HostRuntime
import org.json.JSONObject

private val carryStates = listOf("Stowed", "Worn", "Held", "Equipped")
private val itemCategories = listOf("Gear", "Weapon", "Armor", "Consumable", "Treasure", "Container", "Coins", "Other")

@Composable
fun InventoryScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var ownerFilter by remember { mutableStateOf<String?>("ALL") }
    var addOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<LootItem?>(null) }
    val hiddenCount = state.partyLoot.count { !it.revealedToPlayers }
    val totalBulk = state.partyLoot.filter { it.assignedToPcId != null }.sumOf { it.bulk * it.quantity }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Loot & Inventory", fontSize = 26.sp)
        Text("Manage encounter treasure, the shared stash, PC inventories, equipment states, consumables, containers, identification, bulk, and hidden loot.")

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("Items", state.partyLoot.sumOf { it.quantity }.toString())
            SummaryCard("Carried bulk", formatBulk(totalBulk))
            SummaryCard("GM-hidden", hiddenCount.toString())
            SummaryCard("Shared", state.partyLoot.count { it.assignedToPcId == null }.toString())
        }

        state.encounter?.let { encounter ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Encounter loot • ${encounter.name}", fontSize = 19.sp)
                    val loot = encounter.loot
                    Text(when {
                        loot.generatedAt == null -> "No loot draft generated yet."
                        loot.movedToParty -> "Moved to Loot & Inventory."
                        loot.revealed -> "Revealed to players; ready to move to the party stash."
                        else -> "GM-only draft. Players cannot see it yet."
                    })
                    if (loot.generatedAt != null) {
                        Text("${formatGp(loot.coinsGp)} gp • ${loot.items.size} item${if (loot.items.size == 1) "" else "s"}")
                        loot.items.forEach { Text("• ${it.quantity}× ${it.name} (${it.category})") }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        OutlinedButton(onClick = { runtime.store.generateLoot() }) { Text(if (loot.generatedAt == null) "Generate loot" else "Reroll loot") }
                        if (loot.generatedAt != null && !loot.revealed) Button(onClick = { runtime.store.revealLoot() }) { Text("Reveal loot") }
                        if (loot.revealed && !loot.movedToParty) Button(onClick = { runtime.store.moveLootToParty() }) { Text("Move to inventory") }
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Inventory manager", fontSize = 20.sp)
                    Button(onClick = { addOpen = !addOpen }) { Text(if (addOpen) "Close" else "+ Add item") }
                }
                if (addOpen) AddInventoryItemForm(runtime, state.pcs.map { it.id to it.name }) { addOpen = false }
            }
        }

        Text("View", fontSize = 18.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterButton(ownerFilter == "ALL", "All") { ownerFilter = "ALL" }
            FilterButton(ownerFilter == null, "Shared stash") { ownerFilter = null }
            state.pcs.forEach { pc -> FilterButton(ownerFilter == pc.id, pc.name.substringBefore(' ')) { ownerFilter = pc.id } }
        }

        val shown = state.partyLoot.filter { ownerFilter == "ALL" || it.assignedToPcId == ownerFilter }
        if (shown.isEmpty()) Text("No items in this view.")
        shown.sortedWith(compareBy<LootItem>({ it.assignedToPcId ?: "" }, { it.category }, { it.name })).forEach { item ->
            InventoryItemCard(
                runtime = runtime,
                item = item,
                allItems = state.partyLoot,
                pcs = state.pcs.map { it.id to it.name },
                onEdit = { editing = item },
            )
        }
    }

    editing?.let { item ->
        InventoryEditDialog(runtime, item, onDismiss = { editing = null })
    }
}

@Composable
private fun SummaryCard(label: String, value: String) {
    Card { Column(Modifier.padding(horizontal = 14.dp, vertical = 9.dp)) { Text(label, fontSize = 12.sp); Text(value, fontSize = 20.sp) } }
}

@Composable
private fun FilterButton(selected: Boolean, label: String, onClick: () -> Unit) {
    if (selected) FilledTonalButton(onClick = onClick) { Text(label) } else OutlinedButton(onClick = onClick) { Text(label) }
}

@Composable
private fun AddInventoryItemForm(runtime: HostRuntime, pcs: List<Pair<String, String>>, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Gear") }
    var quantity by remember { mutableStateOf("1") }
    var value by remember { mutableStateOf("0") }
    var bulk by remember { mutableStateOf("0") }
    var traits by remember { mutableStateOf("") }
    var runes by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var gmNotes by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf<String?>(null) }
    var consumable by remember { mutableStateOf(false) }
    var charges by remember { mutableStateOf("1") }
    var identified by remember { mutableStateOf(true) }
    var revealed by remember { mutableStateOf(true) }
    var unidentifiedName by remember { mutableStateOf("Unidentified item") }
    var capacity by remember { mutableStateOf("") }

    HorizontalDivider()
    OutlinedTextField(name, { name = it.take(100) }, label = { Text("Item name") }, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SimpleMenu(category, itemCategories, "Category", Modifier.weight(1f)) { category = it }
        OutlinedTextField(quantity, { quantity = digits(it, 3) }, label = { Text("Quantity") }, modifier = Modifier.width(110.dp))
        OutlinedTextField(value, { value = decimal(it) }, label = { Text("Value gp") }, modifier = Modifier.width(120.dp))
        OutlinedTextField(bulk, { bulk = decimal(it) }, label = { Text("Bulk") }, modifier = Modifier.width(110.dp))
    }
    OwnerMenu(owner, pcs) { owner = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(level, { level = digits(it, 2) }, label = { Text("Level") }, modifier = Modifier.width(110.dp))
        OutlinedTextField(traits, { traits = it.take(300) }, label = { Text("Traits") }, modifier = Modifier.weight(1f))
    }
    OutlinedTextField(runes, { runes = it.take(500) }, label = { Text("Runes / upgrades") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(notes, { notes = it.take(1200) }, label = { Text("Player-visible notes") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(gmNotes, { gmNotes = it.take(1200) }, label = { Text("GM-only notes") }, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        ToggleLine("Consumable", consumable) { consumable = it }
        ToggleLine("Identified", identified) { identified = it }
        ToggleLine("Visible to players", revealed) { revealed = it }
    }
    if (consumable) OutlinedTextField(charges, { charges = digits(it, 3) }, label = { Text("Charges / uses") }, modifier = Modifier.width(160.dp))
    if (!identified) OutlinedTextField(unidentifiedName, { unidentifiedName = it.take(100) }, label = { Text("What players see") }, modifier = Modifier.fillMaxWidth())
    if (category == "Container") OutlinedTextField(capacity, { capacity = decimal(it) }, label = { Text("Capacity (bulk)") }, modifier = Modifier.width(180.dp))
    Button(onClick = {
        runtime.store.addInventoryItem(
            name = name,
            category = category,
            quantity = quantity.toIntOrNull() ?: 1,
            valueGp = value.toDoubleOrNull() ?: 0.0,
            assignedToPcId = owner,
            bulk = bulk.toDoubleOrNull() ?: 0.0,
            consumable = consumable,
            charges = if (consumable) charges.toIntOrNull() ?: 1 else null,
            traits = traits,
            runes = runes,
            level = level.toIntOrNull(),
            notes = notes,
            gmNotes = gmNotes,
            identified = identified,
            revealedToPlayers = revealed,
            unidentifiedName = unidentifiedName,
            capacityBulk = capacity.toDoubleOrNull(),
        )
        onDone()
    }, enabled = name.isNotBlank()) { Text("Add item") }
}

@Composable
private fun InventoryItemCard(
    runtime: HostRuntime,
    item: LootItem,
    allItems: List<LootItem>,
    pcs: List<Pair<String, String>>,
    onEdit: () -> Unit,
) {
    val ownerName = item.assignedToPcId?.let { id -> pcs.firstOrNull { it.first == id }?.second } ?: "Shared stash"
    val containerName = item.containerId?.let { id -> allItems.firstOrNull { it.id == id }?.name }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("${if (item.quantity > 1) "${item.quantity}× " else ""}${item.name}", fontSize = 18.sp)
                    Text("${item.category} • $ownerName${item.level?.let { " • Lv $it" } ?: ""}")
                }
                Text(if (!item.revealedToPlayers) "GM HIDDEN" else if (!item.identified) "UNIDENTIFIED" else item.carryState)
            }
            val detail = buildList {
                if (item.bulk > 0) add("Bulk ${formatBulk(item.bulk * item.quantity)}")
                if (item.valueGp > 0) add("${formatGp(item.valueGp)} gp each")
                if (item.consumable) add("Uses ${item.charges ?: 0}/${item.maxCharges ?: item.charges ?: 0}")
                containerName?.let { add("in $it") }
            }.joinToString(" • ")
            if (detail.isNotBlank()) Text(detail)
            if (item.traits.isNotBlank()) Text("Traits: ${item.traits}", fontSize = 12.sp)
            if (item.runes.isNotBlank()) Text("Runes: ${item.runes}", fontSize = 12.sp)
            if (item.notes.isNotBlank()) Text(item.notes)
            if (item.gmNotes.isNotBlank()) Text("GM: ${item.gmNotes}", fontSize = 12.sp)

            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OwnerMenu(item.assignedToPcId, pcs) { runtime.store.assignPartyLoot(item.id, it) }
                if (item.assignedToPcId != null) SimpleMenu(item.carryState, carryStates, "State") { runtime.store.setInventoryCarryState(item.id, item.assignedToPcId, it) }
                val containers = allItems.filter { it.id != item.id && it.category.equals("Container", true) && it.assignedToPcId == item.assignedToPcId }
                if (item.assignedToPcId != null && containers.isNotEmpty()) ContainerMenu(item.containerId, containers) { runtime.store.setInventoryContainer(item.id, item.assignedToPcId, it) }
                if (item.consumable && item.assignedToPcId != null) FilledTonalButton(onClick = { runtime.store.useInventoryItem(item.id, item.assignedToPcId) }) { Text("Use") }
                OutlinedButton(onClick = { runtime.store.toggleInventoryReveal(item.id) }) { Text(if (item.revealedToPlayers) "Hide" else "Reveal") }
                OutlinedButton(onClick = { runtime.store.toggleInventoryIdentified(item.id) }) { Text(if (item.identified) "Unidentify" else "Identify") }
                OutlinedButton(onClick = onEdit) { Text("Edit") }
                TextButton(onClick = { runtime.store.removePartyLoot(item.id) }) { Text("Remove") }
            }
        }
    }
}

@Composable
private fun InventoryEditDialog(runtime: HostRuntime, item: LootItem, onDismiss: () -> Unit) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    var category by remember(item.id) { mutableStateOf(item.category) }
    var quantity by remember(item.id) { mutableStateOf(item.quantity.toString()) }
    var value by remember(item.id) { mutableStateOf(item.valueGp.toString()) }
    var bulk by remember(item.id) { mutableStateOf(item.bulk.toString()) }
    var traits by remember(item.id) { mutableStateOf(item.traits) }
    var runes by remember(item.id) { mutableStateOf(item.runes) }
    var level by remember(item.id) { mutableStateOf(item.level?.toString().orEmpty()) }
    var notes by remember(item.id) { mutableStateOf(item.notes) }
    var gmNotes by remember(item.id) { mutableStateOf(item.gmNotes) }
    var unidentifiedName by remember(item.id) { mutableStateOf(item.unidentifiedName) }
    var charges by remember(item.id) { mutableStateOf((item.charges ?: 0).toString()) }
    var maxCharges by remember(item.id) { mutableStateOf((item.maxCharges ?: item.charges ?: 0).toString()) }
    var capacity by remember(item.id) { mutableStateOf(item.capacityBulk?.toString().orEmpty()) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit inventory item") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it.take(100) }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                SimpleMenu(category, itemCategories, "Category") { category = it }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(quantity, { quantity = digits(it, 3) }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value, { value = decimal(it) }, label = { Text("gp") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(bulk, { bulk = decimal(it) }, label = { Text("Bulk") }, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(level, { level = digits(it, 2) }, label = { Text("Level") }, modifier = Modifier.width(100.dp))
                    OutlinedTextField(traits, { traits = it.take(300) }, label = { Text("Traits") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(runes, { runes = it.take(500) }, label = { Text("Runes / upgrades") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it.take(1200) }, label = { Text("Player notes") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(gmNotes, { gmNotes = it.take(1200) }, label = { Text("GM-only notes") }, modifier = Modifier.fillMaxWidth())
                if (!item.identified) OutlinedTextField(unidentifiedName, { unidentifiedName = it.take(100) }, label = { Text("Unidentified display name") }, modifier = Modifier.fillMaxWidth())
                if (item.consumable) Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(charges, { charges = digits(it, 3) }, label = { Text("Uses left") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(maxCharges, { maxCharges = digits(it, 3) }, label = { Text("Max uses") }, modifier = Modifier.weight(1f))
                }
                if (category == "Container") OutlinedTextField(capacity, { capacity = decimal(it) }, label = { Text("Capacity bulk") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = {
                runtime.store.updateInventoryItem(item.id, JSONObject().apply {
                    put("name", name); put("category", category); put("quantity", quantity.toIntOrNull() ?: item.quantity); put("valueGp", value.toDoubleOrNull() ?: item.valueGp)
                    put("bulk", bulk.toDoubleOrNull() ?: item.bulk); put("traits", traits); put("runes", runes); level.toIntOrNull()?.let { put("level", it) }; put("notes", notes); put("gmNotes", gmNotes); put("unidentifiedName", unidentifiedName)
                    if (item.consumable) { put("charges", charges.toIntOrNull() ?: 0); put("maxCharges", maxCharges.toIntOrNull() ?: 0) }
                    capacity.toDoubleOrNull()?.let { put("capacityBulk", it) }
                })
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ToggleLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Switch(checked, onChange); Text(label, modifier = Modifier.padding(top = 11.dp)) }
}

@Composable
private fun OwnerMenu(value: String?, pcs: List<Pair<String, String>>, onChange: (String?) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = value?.let { id -> pcs.firstOrNull { it.first == id }?.second } ?: "Shared stash"
    Box {
        OutlinedButton(onClick = { open = true }) { Text(label) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Shared stash") }, onClick = { onChange(null); open = false })
            pcs.forEach { (id, name) -> DropdownMenuItem(text = { Text(name) }, onClick = { onChange(id); open = false }) }
        }
    }
}

@Composable
private fun ContainerMenu(value: String?, containers: List<LootItem>, onChange: (String?) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = value?.let { id -> containers.firstOrNull { it.id == id }?.name } ?: "No container"
    Box {
        OutlinedButton(onClick = { open = true }) { Text(label) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("No container") }, onClick = { onChange(null); open = false })
            containers.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = { onChange(item.id); open = false }) }
        }
    }
}

@Composable
private fun SimpleMenu(value: String, options: List<String>, label: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: $value") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onChange(option); open = false }) }
        }
    }
}

private fun digits(value: String, max: Int) = value.filter(Char::isDigit).take(max)
private fun decimal(value: String): String {
    val out = StringBuilder()
    var seenDot = false
    value.forEach { ch ->
        if (ch.isDigit()) out.append(ch)
        else if (ch == '.' && !seenDot) { out.append(ch); seenDot = true }
    }
    return out.toString().take(8)
}
private fun formatBulk(value: Double): String = when {
    value <= 0 -> "—"
    value < 1 -> { val lights = (value * 10).toInt().coerceAtLeast(1); if (lights == 1) "L" else "${lights}L" }
    value % 1.0 == 0.0 -> value.toInt().toString()
    else -> "%.1f".format(value)
}
private fun formatGp(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
