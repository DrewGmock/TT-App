# TT Helper Changelog

## 0.4.1-alpha1
- Reworked the player Builder with common-option dropdowns for range, targets, checks/saves, damage type, traits, and outcome effects, while preserving Custom entries for homebrew.
- Added damage/healing formulas to spells, abilities, and strikes.
- Added damage type, basic-save handling, and optional success/failure/critical outcome effects.
- Rules & Resolution now rolls a configured damage formula after the GM resolves the degree of success and proposes the resulting damage/healing amount.
- Added GM controls to reroll proposed damage or apply the proposed HP/effect consequences.
- Applied consequences can damage/heal a target and attach the configured outcome condition/effect.
- Added a full character-sheet data model: ability modifiers, AC, saves, Perception, Class DC, size, speed, skills, proficiencies, languages, senses, immunities, resistances, weaknesses, weapon/armor proficiencies, and Lore storage.
- Added full character-sheet editing on both the GM Characters screen and the player Character screen.
- Character-sheet values are available to the rules engine; Class DC can be used for ability-save requests.
- Expanded approved spells/abilities/strikes and draft persistence so builder mechanics survive GM approval and future edits.
- Existing 0.4.0 saves migrate forward with defaults for every new field.

## 0.4.0-alpha1
- Added GM Rules & Resolution queue.
- Added player target selection without exposing enemy defenses.
- Added automatic PF2e Multiple Attack Penalty tracking, including Agile progression.
- Strikes support digital/physical d20 results and GM resolution requests.
- Added PF2e degree-of-success suggestions including natural 20 / natural 1 shifts.
- Added enemy AC, Fortitude, Reflex, and Will fields.
- Added Spell DC / Spell Attack and target-aware spell checks.
- Added secret-check routing for Recall Knowledge and Seek.
