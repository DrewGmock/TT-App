# TT Helper LAN protocol notes — 0.4.1 alpha 1

The Samsung tablet remains authoritative. Player browsers receive filtered snapshots and submit actions over WebSocket.

## New / expanded player action
- `saveCharacterSheet` — updates the assigned PC's final sheet values. The host clamps numeric values and stores the authoritative copy.
- `saveContentDraft` now accepts damage/healing and outcome fields in addition to the previous builder fields.

## Builder payload additions
- `damage`
- `damageType`
- `basicSave`
- `healing`
- `traits`
- `effectCriticalSuccess`
- `effectSuccess`
- `effectFailure`
- `effectCriticalFailure`

## Character snapshot additions
`you.stats` now includes final character-sheet values and standard skill modifiers/proficiency ranks. Enemy defenses remain filtered from player enemy snapshots.

## Rules request additions
Rule requests may now carry damage formula/type, basic-save behavior, healing flag, outcome effects, rolled base damage, proposed amount, and whether consequences were applied.

## Save migration
All 0.4.1 fields have defaults. Existing 0.4.0 / 0.3.x saves should load without reset.
