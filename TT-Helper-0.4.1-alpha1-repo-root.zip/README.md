# TT Helper 0.4.1 Alpha 1

0.4.1 builds on the working 0.4 Rules Intelligence layer with a structured Builder, full character-sheet inputs, and the first damage/effect consequence pipeline.

## Builder overhaul
Players still create drafts and submit them for GM approval, but common mechanics no longer require typing everything manually.

The Builder now provides common choices for:
- Range
- Targets and areas
- Check / save type
- Damage type
- Common traits
- Outcome effects

Every menu still supports custom/homebrew values where needed.

Spells, abilities, and strikes can now store a damage/healing formula such as `2d6+4`, a damage type, optional basic-save behavior, and optional effects for critical success / success / failure / critical failure.

## Damage & consequence resolution
When a Rules request is resolved, TT Helper can roll the configured formula and calculate a proposed amount.

- Attack-style result: Success = full, Critical Success = double.
- Basic save: Critical Success = none, Success = half, Failure = full, Critical Failure = double.
- Healing entries use the same proposal pipeline but restore HP instead of dealing damage.
- The GM can reroll the proposal or press **Apply consequences**.
- Configured outcome effects are applied through the existing effect engine.

The GM remains authoritative; TT Helper proposes consequences before changing HP/effects.

## Full character sheet
The Character section now supports final values from the player's paper sheet:
- STR / DEX / CON / INT / WIS / CHA modifiers
- HP / Max HP / Temp HP
- AC
- Perception
- Fortitude / Reflex / Will
- Class DC
- Spell DC / Spell Attack
- Size / Speed
- All standard skills and proficiency ranks
- Lore storage in the data model
- Languages / senses
- Weapon / armor proficiency notes
- Immunities / resistances / weaknesses

Both the GM Characters screen and the player's Character screen can edit sheet values.

## Version
- versionCode: 9
- versionName: 0.4.1-alpha1
