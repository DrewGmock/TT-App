package com.drew.tthelper.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime
@Composable fun InventoryScreen(runtime: HostRuntime){
 val state by runtime.store.state.collectAsState()
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text("Inventory & Party Loot",fontSize=26.sp); if(state.partyLoot.isEmpty()) Text("No party loot yet.")
  state.partyLoot.forEach{item-> Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("${if(item.quantity>1)"${item.quantity}× " else ""}${item.name}"); val assigned=item.assignedToPcId?.let{id->state.pcs.firstOrNull{it.id==id}?.name}?:"Shared stash"; Text("${item.category} • $assigned"); FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={runtime.store.assignPartyLoot(item.id,null)}){Text("Shared")}; state.pcs.forEach{pc->OutlinedButton(onClick={runtime.store.assignPartyLoot(item.id,pc.id)}){Text(pc.name.substringBefore(' '))}}; OutlinedButton(onClick={runtime.store.removePartyLoot(item.id)}){Text("Remove")}} }}}
 }
}
