# TT Helper 0.3.1 Alpha 1

This build reorganizes both the player and GM experiences around separate jobs instead of one long screen.

## Player sections
- Combat — HP, conditions, actions, reactions, pinned options, abilities, strikes, encounter info.
- Character — ancestry, heritage, background, class, level, feats.
- Inventory — items assigned from Party Loot plus shared loot.
- Spells — spellcasting dashboard only.
- Builder — spell / ability / strike / resource drafts and GM submissions.

Common combat actions are now collapsed behind a menu instead of always taking screen space.

The player connection badge now reflects the WebSocket connection directly and should show Connected while the GM tablet sees the player connected.

## GM sections
The tablet navigation rail is now split into Live, Characters, Spells, Approvals, Inventory, Session Prep, and Players.

Character editing supports ancestry, heritage, background, class, level, and typed feats (Ancestry, Class, Skill, General, Archetype, or custom).

## New character requests
The player character-selection page includes Request a new character. Requests require the current session PIN and enter the GM Approval Inbox. Approval creates the new PC; decline removes the request.

## Version
- versionCode: 7
- versionName: 0.3.1-alpha1
