# TT Helper Changelog

## 0.3.1-alpha1
- Player UI split into Combat, Character, Inventory, Spells, and Builder sections.
- Common combat actions moved into a collapsible menu.
- Fixed player connection badge so a live WebSocket shows Connected instead of Offline.
- Character profiles now include ancestry, heritage, background, class, level, and typed feats.
- Added GM Character and Spellcasting tabs plus dedicated Inventory/Party Loot tab.
- Added new-character requests from the player character-selection screen with GM approve/decline flow.
- Assigned loot now appears on the player's Inventory page; shared loot is shown separately.
- Live GM screen stays combat-focused instead of mixing character-building tools into combat.
- Preserves the 0.3 draft/approval behavior: declined player content returns to Drafts with progress intact.
