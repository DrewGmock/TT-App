package com.drew.tthelper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.server.HostRuntime

@Composable
fun CharacterManagementScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var selectedId by remember { mutableStateOf(state.pcs.firstOrNull()?.id) }
    val pc = state.pcs.firstOrNull { it.id == selectedId } ?: state.pcs.firstOrNull()
    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.width(250.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Characters", fontSize = 24.sp)
            state.pcs.forEach { candidate ->
                OutlinedButton(onClick = { selectedId = candidate.id }, modifier = Modifier.fillMaxWidth()) { Text(candidate.name) }
            }
        }
        if (pc != null) CharacterEditor(runtime, pc, Modifier.weight(1f))
    }
}

@Composable
private fun CharacterEditor(runtime: HostRuntime, pc: PlayerCharacter, modifier: Modifier) {
    var name by remember(pc.id, pc.name) { mutableStateOf(pc.name) }
    var ancestry by remember(pc.id, pc.ancestry) { mutableStateOf(pc.ancestry) }
    var heritage by remember(pc.id, pc.heritage) { mutableStateOf(pc.heritage) }
    var background by remember(pc.id, pc.background) { mutableStateOf(pc.background) }
    var cls by remember(pc.id, pc.characterClass) { mutableStateOf(pc.characterClass) }
    var level by remember(pc.id, pc.level) { mutableStateOf(pc.level?.toString().orEmpty()) }
    var featName by remember(pc.id) { mutableStateOf("") }
    var featType by remember(pc.id) { mutableStateOf("Class Feat") }
    var featLevel by remember(pc.id) { mutableStateOf("") }
    var featTraits by remember(pc.id) { mutableStateOf("") }
    var featPrereq by remember(pc.id) { mutableStateOf("") }
    var featNotes by remember(pc.id) { mutableStateOf("") }
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(pc.name, fontSize = 26.sp)
        OutlinedTextField(name, { name = it.take(60) }, label={Text("Name")}, modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(ancestry,{ancestry=it.take(60)},label={Text("Ancestry")},modifier=Modifier.weight(1f))
            OutlinedTextField(heritage,{heritage=it.take(80)},label={Text("Heritage")},modifier=Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(background,{background=it.take(80)},label={Text("Background")},modifier=Modifier.weight(1f))
            OutlinedTextField(cls,{cls=it.take(80)},label={Text("Class")},modifier=Modifier.weight(1f))
            OutlinedTextField(level,{level=it.filter(Char::isDigit).take(2)},label={Text("Level")},modifier=Modifier.width(100.dp))
        }
        Button(onClick={runtime.store.updateCharacterProfile(pc.id,name,ancestry,heritage,background,cls,level.toIntOrNull())}) { Text("Save profile") }
        HorizontalDivider()
        Text("Feats", fontSize=20.sp)
        pc.feats.sortedWith(compareBy({it.type},{it.level ?: 0},{it.name})).forEach { feat ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) { Text(feat.name); Text("${feat.type}${feat.level?.let { " • Level $it" } ?: ""}", fontSize=12.sp); if(feat.traits.isNotBlank()) Text("Traits: ${feat.traits}",fontSize=12.sp); if(feat.notes.isNotBlank()) Text(feat.notes,fontSize=12.sp) }
                OutlinedButton(onClick={runtime.store.removeFeat(pc.id, feat.id)}) { Text("Remove") }
            } }
        }
        OutlinedTextField(featName,{featName=it.take(80)},label={Text("Feat name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(featType,{featType=it.take(50)},label={Text("Feat type")},modifier=Modifier.fillMaxWidth())
        FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("Ancestry Feat","Class Feat","Skill Feat","General Feat","Archetype Feat").forEach { t -> TextButton(onClick={featType=t}){Text(t)} } }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(featLevel,{featLevel=it.filter(Char::isDigit).take(2)},label={Text("Feat level")},modifier=Modifier.width(120.dp)); OutlinedTextField(featTraits,{featTraits=it.take(180)},label={Text("Traits")},modifier=Modifier.weight(1f)) }
        OutlinedTextField(featPrereq,{featPrereq=it.take(240)},label={Text("Prerequisites")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(featNotes,{featNotes=it.take(600)},label={Text("Notes")},modifier=Modifier.fillMaxWidth())
        Button(onClick={ runtime.store.addFeat(pc.id,featName,featType,featLevel.toIntOrNull(),featTraits,featPrereq,featNotes); featName=""; featNotes="" }) { Text("Add feat") }
    }
}
