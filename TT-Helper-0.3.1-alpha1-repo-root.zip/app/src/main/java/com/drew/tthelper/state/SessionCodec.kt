package com.drew.tthelper.state

import com.drew.tthelper.model.ActionEconomy
import com.drew.tthelper.model.AbilityEntry
import com.drew.tthelper.model.CharacterResource
import com.drew.tthelper.model.CharacterCreationRequest
import com.drew.tthelper.model.FeatEntry
import com.drew.tthelper.model.PlayerContentDraft
import com.drew.tthelper.model.StrikeEntry
import com.drew.tthelper.model.SpellEntry
import com.drew.tthelper.model.SpellSlotPool
import com.drew.tthelper.model.SpellcastingState
import com.drew.tthelper.model.CombatLogEntry
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.Condition
import com.drew.tthelper.model.EncounterLoot
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.SessionPrep
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.defaultCharacters
import org.json.JSONArray
import org.json.JSONObject

object SessionCodec {
    fun encode(state: SessionState): String = JSONObject().apply {
        put("revision", state.revision)
        put("campaignName", state.campaignName)
        put("sceneName", state.sceneName)
        put("lastEventLabel", state.lastEventLabel ?: JSONObject.NULL)
        put("prep", prepToJson(state.prep))
        put("pcs", JSONArray().apply { state.pcs.forEach { put(pcToJson(it)) } })
        put("encounter", state.encounter?.let(::encounterToJson) ?: JSONObject.NULL)
        put("partyLoot", JSONArray().apply { state.partyLoot.forEach { put(lootItemToJson(it)) } })
        put("characterRequests", JSONArray().apply { state.characterRequests.forEach { put(characterRequestToJson(it)) } })
    }.toString()

    fun decode(raw: String): SessionState {
        val root = JSONObject(raw)
        val pcs = root.optJSONArray("pcs").toObjectList(::pcFromJson).ifEmpty { defaultCharacters() }
        return SessionState(
            revision = root.optLong("revision", 0),
            campaignName = root.optString("campaignName", "Cube-Borne"),
            sceneName = root.optString("sceneName", "Between Sessions"),
            pcs = pcs,
            prep = prepFromJson(root.optJSONObject("prep") ?: JSONObject()),
            encounter = root.optJSONObject("encounter")?.let(::encounterFromJson),
            partyLoot = root.optJSONArray("partyLoot").toObjectList(::lootItemFromJson),
            characterRequests = root.optJSONArray("characterRequests").toObjectList(::characterRequestFromJson),
            lastEventLabel = root.optNullableString("lastEventLabel"),
        )
    }

    private fun prepToJson(prep: SessionPrep) = JSONObject().apply {
        put("sessionTitle", prep.sessionTitle)
        put("openingScene", prep.openingScene)
        put("gmNotes", prep.gmNotes)
        put("encounterNotes", prep.encounterNotes)
        put("enemyLibrary", JSONArray().apply { prep.enemyLibrary.forEach { put(preparedEnemyToJson(it)) } })
        put("preparedEncounters", JSONArray().apply { prep.preparedEncounters.forEach { put(preparedEncounterToJson(it)) } })
    }

    private fun prepFromJson(json: JSONObject) = SessionPrep(
        sessionTitle = json.optString("sessionTitle", "Next Session"),
        openingScene = json.optString("openingScene"),
        gmNotes = json.optString("gmNotes"),
        encounterNotes = json.optString("encounterNotes"),
        enemyLibrary = json.optJSONArray("enemyLibrary").toObjectList(::preparedEnemyFromJson),
        preparedEncounters = json.optJSONArray("preparedEncounters").toObjectList(::preparedEncounterFromJson),
    )

    private fun preparedEnemyToJson(enemy: PreparedEnemy) = JSONObject().apply {
        put("id", enemy.id)
        put("name", enemy.name)
        put("level", enemy.level ?: JSONObject.NULL)
        put("maxHp", enemy.maxHp)
        put("initiativeModifier", enemy.initiativeModifier)
        put("gmNotes", enemy.gmNotes)
        put("publicNotes", enemy.publicNotes)
        put("quantity", enemy.quantity)
    }

    private fun preparedEnemyFromJson(json: JSONObject) = PreparedEnemy(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Enemy"),
        level = json.optNullableInt("level"),
        maxHp = json.optInt("maxHp", 10).coerceAtLeast(1),
        initiativeModifier = json.optInt("initiativeModifier", 0),
        gmNotes = json.optString("gmNotes"),
        publicNotes = json.optString("publicNotes"),
        quantity = json.optInt("quantity", 1).coerceAtLeast(1),
    )

    private fun preparedEncounterToJson(encounter: PreparedEncounter) = JSONObject().apply {
        put("id", encounter.id)
        put("name", encounter.name)
        put("gmNotes", encounter.gmNotes)
        put("startingNotes", encounter.startingNotes)
        put("enemies", JSONArray().apply { encounter.enemies.forEach { put(preparedEnemyToJson(it)) } })
    }

    private fun preparedEncounterFromJson(json: JSONObject) = PreparedEncounter(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Prepared Encounter"),
        gmNotes = json.optString("gmNotes"),
        startingNotes = json.optString("startingNotes"),
        enemies = json.optJSONArray("enemies").toObjectList(::preparedEnemyFromJson),
    )

    private fun pcToJson(pc: PlayerCharacter) = JSONObject().apply {
        put("id", pc.id)
        put("name", pc.name)
        put("ancestry", pc.ancestry)
        put("heritage", pc.heritage)
        put("background", pc.background)
        put("characterClass", pc.characterClass)
        put("level", pc.level ?: JSONObject.NULL)
        put("hp", pc.hp)
        put("maxHp", pc.maxHp)
        put("tempHp", pc.tempHp)
        put("heroPoints", pc.heroPoints)
        put("ready", pc.ready)
        put("publicNote", pc.publicNote)
        put("gmNote", pc.gmNote)
        put("spellcasting", spellcastingToJson(pc.spellcasting))
        put("actionEconomy", actionEconomyToJson(pc.actionEconomy))
        put("abilities", JSONArray().apply { pc.abilities.forEach { put(abilityToJson(it)) } })
        put("strikes", JSONArray().apply { pc.strikes.forEach { put(strikeToJson(it)) } })
        put("resources", JSONArray().apply { pc.resources.forEach { put(resourceToJson(it)) } })
        put("contentDrafts", JSONArray().apply { pc.contentDrafts.forEach { put(contentDraftToJson(it)) } })
        put("feats", JSONArray().apply { pc.feats.forEach { put(featToJson(it)) } })
        put("conditions", JSONArray().apply { pc.conditions.forEach { put(conditionToJson(it)) } })
    }

    private fun pcFromJson(json: JSONObject): PlayerCharacter {
        val id = json.getString("id")
        val defaultPc = defaultCharacters().firstOrNull { it.id == id }
        return PlayerCharacter(
            id = id,
            name = json.getString("name"),
            ancestry = json.optString("ancestry"),
            heritage = json.optString("heritage"),
            background = json.optString("background"),
            characterClass = json.optString("characterClass"),
            level = json.optNullableInt("level"),
            hp = json.optInt("hp", 10),
            maxHp = json.optInt("maxHp", 10).coerceAtLeast(1),
            tempHp = json.optInt("tempHp", 0).coerceAtLeast(0),
            heroPoints = json.optInt("heroPoints", 1),
            ready = json.optBoolean("ready", false),
            conditions = json.optJSONArray("conditions").toObjectList(::conditionFromJson),
            publicNote = json.optString("publicNote"),
            gmNote = json.optString("gmNote"),
            spellcasting = json.optJSONObject("spellcasting")?.let(::spellcastingFromJson)
                ?: defaultPc?.spellcasting ?: SpellcastingState(),
            actionEconomy = json.optJSONObject("actionEconomy")?.let(::actionEconomyFromJson)
                ?: ActionEconomy(),
            abilities = json.optJSONArray("abilities").toObjectList(::abilityFromJson),
            strikes = json.optJSONArray("strikes").toObjectList(::strikeFromJson),
            resources = json.optJSONArray("resources").toObjectList(::resourceFromJson),
            contentDrafts = json.optJSONArray("contentDrafts").toObjectList(::contentDraftFromJson),
            feats = json.optJSONArray("feats").toObjectList(::featFromJson),
        )
    }

    private fun featToJson(feat: FeatEntry) = JSONObject().apply {
        put("id", feat.id)
        put("name", feat.name)
        put("type", feat.type)
        put("level", feat.level ?: JSONObject.NULL)
        put("traits", feat.traits)
        put("prerequisites", feat.prerequisites)
        put("notes", feat.notes)
    }

    private fun featFromJson(json: JSONObject) = FeatEntry(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Feat"),
        type = json.optString("type", "General Feat"),
        level = json.optNullableInt("level"),
        traits = json.optString("traits"),
        prerequisites = json.optString("prerequisites"),
        notes = json.optString("notes"),
    )

    private fun characterRequestToJson(request: CharacterCreationRequest) = JSONObject().apply {
        put("id", request.id)
        put("playerName", request.playerName)
        put("characterName", request.characterName)
        put("ancestry", request.ancestry)
        put("heritage", request.heritage)
        put("background", request.background)
        put("characterClass", request.characterClass)
        put("level", request.level ?: JSONObject.NULL)
        put("notes", request.notes)
        put("submittedAt", request.submittedAt)
    }

    private fun characterRequestFromJson(json: JSONObject) = CharacterCreationRequest(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        playerName = json.optString("playerName", "Player"),
        characterName = json.optString("characterName", "New Character"),
        ancestry = json.optString("ancestry"),
        heritage = json.optString("heritage"),
        background = json.optString("background"),
        characterClass = json.optString("characterClass"),
        level = json.optNullableInt("level"),
        notes = json.optString("notes"),
        submittedAt = json.optLong("submittedAt", System.currentTimeMillis()),
    )

    private fun spellcastingToJson(spellcasting: SpellcastingState) = JSONObject().apply {
        put("enabled", spellcasting.enabled)
        put("tradition", spellcasting.tradition)
        put("castingMode", spellcasting.castingMode)
        put("focusPoints", spellcasting.focusPoints)
        put("maxFocusPoints", spellcasting.maxFocusPoints)
        put("slots", JSONArray().apply { spellcasting.slots.forEach { slot ->
            put(JSONObject().apply {
                put("rank", slot.rank)
                put("total", slot.total)
                put("remaining", slot.remaining)
            })
        } })
        put("spells", JSONArray().apply { spellcasting.spells.forEach { spell ->
            put(JSONObject().apply {
                put("id", spell.id)
                put("name", spell.name)
                put("rank", spell.rank)
                put("actions", spell.actions)
                put("isCantrip", spell.isCantrip)
                put("isFocus", spell.isFocus)
                put("expended", spell.expended)
                put("notes", spell.notes)
                put("range", spell.range)
                put("targets", spell.targets)
                put("checkOrSave", spell.checkOrSave)
                put("pinned", spell.pinned)
            })
        } })
    }

    private fun spellcastingFromJson(json: JSONObject) = SpellcastingState(
        enabled = json.optBoolean("enabled", false),
        tradition = json.optString("tradition"),
        castingMode = json.optString("castingMode", "PREPARED"),
        focusPoints = json.optInt("focusPoints", 0).coerceAtLeast(0),
        maxFocusPoints = json.optInt("maxFocusPoints", 0).coerceAtLeast(0),
        slots = json.optJSONArray("slots").toObjectList { slot ->
            val total = slot.optInt("total", 0).coerceAtLeast(0)
            SpellSlotPool(
                rank = slot.optInt("rank", 1).coerceAtLeast(1),
                total = total,
                remaining = slot.optInt("remaining", total).coerceIn(0, total),
            )
        },
        spells = json.optJSONArray("spells").toObjectList { spell ->
            SpellEntry(
                id = spell.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                name = spell.optString("name", "Spell"),
                rank = spell.optInt("rank", 0).coerceAtLeast(0),
                actions = spell.optInt("actions", 2).coerceIn(0, 3),
                isCantrip = spell.optBoolean("isCantrip", false),
                isFocus = spell.optBoolean("isFocus", false),
                expended = spell.optBoolean("expended", false),
                notes = spell.optString("notes"),
                range = spell.optString("range"),
                targets = spell.optString("targets"),
                checkOrSave = spell.optString("checkOrSave"),
                pinned = spell.optBoolean("pinned", false),
            )
        },
    )

    private fun abilityToJson(entry: AbilityEntry) = JSONObject().apply {
        put("id", entry.id); put("name", entry.name); put("category", entry.category)
        put("actionType", entry.actionType); put("actions", entry.actions); put("usageMode", entry.usageMode)
        put("maxUses", entry.maxUses); put("remainingUses", entry.remainingUses); put("notes", entry.notes); put("pinned", entry.pinned)
    }

    private fun abilityFromJson(json: JSONObject) = AbilityEntry(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Ability"), category = json.optString("category", "Ability"),
        actionType = json.optString("actionType", "ACTION"), actions = json.optInt("actions", 1).coerceIn(0, 3),
        usageMode = json.optString("usageMode", "UNLIMITED"), maxUses = json.optInt("maxUses", 0).coerceAtLeast(0),
        remainingUses = json.optInt("remainingUses", json.optInt("maxUses", 0)).coerceAtLeast(0), notes = json.optString("notes"),
        pinned = json.optBoolean("pinned", false),
    )

    private fun strikeToJson(entry: StrikeEntry) = JSONObject().apply {
        put("id", entry.id); put("name", entry.name); put("actions", entry.actions); put("attackModifier", entry.attackModifier)
        put("damage", entry.damage); put("traits", entry.traits); put("notes", entry.notes); put("pinned", entry.pinned)
    }

    private fun strikeFromJson(json: JSONObject) = StrikeEntry(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, name = json.optString("name", "Strike"),
        actions = json.optInt("actions", 1).coerceIn(0, 3), attackModifier = json.optInt("attackModifier", 0),
        damage = json.optString("damage"), traits = json.optString("traits"), notes = json.optString("notes"),
        pinned = json.optBoolean("pinned", false),
    )

    private fun resourceToJson(entry: CharacterResource) = JSONObject().apply {
        put("id", entry.id); put("name", entry.name); put("current", entry.current); put("max", entry.max); put("notes", entry.notes); put("pinned", entry.pinned)
    }

    private fun resourceFromJson(json: JSONObject) = CharacterResource(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, name = json.optString("name", "Resource"),
        current = json.optInt("current", 0).coerceAtLeast(0), max = json.optInt("max", 0).coerceAtLeast(0), notes = json.optString("notes"),
        pinned = json.optBoolean("pinned", false),
    )

    private fun contentDraftToJson(entry: PlayerContentDraft) = JSONObject().apply {
        put("id", entry.id); put("kind", entry.kind); put("status", entry.status); put("name", entry.name); put("rank", entry.rank)
        put("actions", entry.actions); put("isCantrip", entry.isCantrip); put("isFocus", entry.isFocus); put("notes", entry.notes)
        put("range", entry.range); put("targets", entry.targets); put("checkOrSave", entry.checkOrSave)
        put("abilityCategory", entry.abilityCategory); put("actionType", entry.actionType); put("usageMode", entry.usageMode); put("maxUses", entry.maxUses)
        put("attackModifier", entry.attackModifier); put("damage", entry.damage); put("traits", entry.traits); put("resourceMax", entry.resourceMax)
        put("gmFeedback", entry.gmFeedback); put("sourceEntryId", entry.sourceEntryId ?: JSONObject.NULL); put("submittedAt", entry.submittedAt ?: JSONObject.NULL)
    }

    private fun contentDraftFromJson(json: JSONObject) = PlayerContentDraft(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }, kind = json.optString("kind", "ABILITY"),
        status = json.optString("status", "DRAFT"), name = json.optString("name"), rank = json.optInt("rank", 1).coerceIn(0, 10),
        actions = json.optInt("actions", 1).coerceIn(0, 3), isCantrip = json.optBoolean("isCantrip", false), isFocus = json.optBoolean("isFocus", false),
        notes = json.optString("notes"), range = json.optString("range"), targets = json.optString("targets"), checkOrSave = json.optString("checkOrSave"),
        abilityCategory = json.optString("abilityCategory", "Ability"), actionType = json.optString("actionType", "ACTION"),
        usageMode = json.optString("usageMode", "UNLIMITED"), maxUses = json.optInt("maxUses", 0).coerceAtLeast(0), attackModifier = json.optInt("attackModifier", 0),
        damage = json.optString("damage"), traits = json.optString("traits"), resourceMax = json.optInt("resourceMax", 0).coerceAtLeast(0),
        gmFeedback = json.optString("gmFeedback"), sourceEntryId = json.optNullableString("sourceEntryId"), submittedAt = if (json.isNull("submittedAt")) null else json.optLong("submittedAt"),
    )

    private fun actionEconomyToJson(actionEconomy: ActionEconomy) = JSONObject().apply {
        put("baseActions", actionEconomy.baseActions)
        put("actionsRemaining", actionEconomy.actionsRemaining)
        put("reactionAvailable", actionEconomy.reactionAvailable)
    }

    private fun actionEconomyFromJson(json: JSONObject) = ActionEconomy(
        baseActions = json.optInt("baseActions", 3).coerceIn(0, 6),
        actionsRemaining = json.optInt("actionsRemaining", 3).coerceIn(0, 6),
        reactionAvailable = json.optBoolean("reactionAvailable", true),
    )


    private fun conditionToJson(condition: Condition) = JSONObject().apply {
        put("name", condition.name)
        put("value", condition.value ?: JSONObject.NULL)
        put("publicToPlayers", condition.publicToPlayers)
        put("partyInflicted", condition.partyInflicted)
        put("id", condition.id)
        put("sourceCombatantId", condition.sourceCombatantId ?: JSONObject.NULL)
        put("timingAnchor", condition.timingAnchor)
        put("timingPhase", condition.timingPhase)
        put("remainingTriggers", condition.remainingTriggers ?: JSONObject.NULL)
        put("triggerAction", condition.triggerAction)
        put("checkType", condition.checkType ?: JSONObject.NULL)
        put("checkLabel", condition.checkLabel)
        put("checkDc", condition.checkDc ?: JSONObject.NULL)
        put("checkSuccessAction", condition.checkSuccessAction)
        put("checkFailureAction", condition.checkFailureAction)
        put("checkCriticalSuccessAction", condition.checkCriticalSuccessAction)
        put("checkCriticalFailureAction", condition.checkCriticalFailureAction)
        put("repeatCheck", condition.repeatCheck)
    }

    private fun conditionFromJson(json: JSONObject) = Condition(
        name = json.optString("name"),
        value = json.optNullableInt("value"),
        publicToPlayers = json.optBoolean("publicToPlayers", true),
        partyInflicted = json.optBoolean("partyInflicted", false),
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        sourceCombatantId = json.optNullableString("sourceCombatantId"),
        timingAnchor = json.optString("timingAnchor", "TARGET"),
        timingPhase = json.optString("timingPhase", "MANUAL"),
        remainingTriggers = json.optNullableInt("remainingTriggers"),
        triggerAction = json.optString("triggerAction", "NONE"),
        checkType = json.optNullableString("checkType"),
        checkLabel = json.optString("checkLabel"),
        checkDc = json.optNullableInt("checkDc"),
        checkSuccessAction = json.optString("checkSuccessAction", "REMOVE"),
        checkFailureAction = json.optString("checkFailureAction", "KEEP"),
        checkCriticalSuccessAction = json.optString("checkCriticalSuccessAction", "REMOVE"),
        checkCriticalFailureAction = json.optString("checkCriticalFailureAction", "KEEP"),
        repeatCheck = json.optBoolean("repeatCheck", true),
    )

    private fun effectCheckToJson(prompt: EffectCheckPrompt) = JSONObject().apply {
        put("id", prompt.id)
        put("effectId", prompt.effectId)
        put("targetCombatantId", prompt.targetCombatantId)
        put("targetName", prompt.targetName)
        put("effectName", prompt.effectName)
        put("checkType", prompt.checkType)
        put("checkLabel", prompt.checkLabel)
        put("dc", prompt.dc ?: JSONObject.NULL)
        put("timingText", prompt.timingText)
        put("successAction", prompt.successAction)
        put("failureAction", prompt.failureAction)
        put("criticalSuccessAction", prompt.criticalSuccessAction)
        put("criticalFailureAction", prompt.criticalFailureAction)
        put("repeatCheck", prompt.repeatCheck)
    }

    private fun effectCheckFromJson(json: JSONObject) = EffectCheckPrompt(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        effectId = json.optString("effectId"),
        targetCombatantId = json.optString("targetCombatantId"),
        targetName = json.optString("targetName"),
        effectName = json.optString("effectName"),
        checkType = json.optString("checkType", "Custom roll"),
        checkLabel = json.optString("checkLabel"),
        dc = json.optNullableInt("dc"),
        timingText = json.optString("timingText"),
        successAction = json.optString("successAction", "REMOVE"),
        failureAction = json.optString("failureAction", "KEEP"),
        criticalSuccessAction = json.optString("criticalSuccessAction", "REMOVE"),
        criticalFailureAction = json.optString("criticalFailureAction", "KEEP"),
        repeatCheck = json.optBoolean("repeatCheck", true),
    )

    private fun combatantToJson(combatant: Combatant) = JSONObject().apply {
        put("id", combatant.id)
        put("name", combatant.name)
        put("kind", combatant.kind)
        put("pcId", combatant.pcId ?: JSONObject.NULL)
        put("level", combatant.level ?: JSONObject.NULL)
        put("initiative", combatant.initiative ?: JSONObject.NULL)
        put("initiativeModifier", combatant.initiativeModifier)
        put("initiativeSource", combatant.initiativeSource ?: JSONObject.NULL)
        put("hp", combatant.hp)
        put("maxHp", combatant.maxHp)
        put("tempHp", combatant.tempHp)
        put("conditions", JSONArray().apply { combatant.conditions.forEach { put(conditionToJson(it)) } })
        put("gmNote", combatant.gmNote)
        put("publicNote", combatant.publicNote)
        put("groupKey", combatant.groupKey ?: JSONObject.NULL)
        put("defeated", combatant.defeated)
        put("delayed", combatant.delayed)
        put("readyAction", combatant.readyAction)
        put("readyTrigger", combatant.readyTrigger)
    }

    private fun combatantFromJson(json: JSONObject) = Combatant(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Combatant"),
        kind = json.optString("kind", "enemy"),
        pcId = json.optNullableString("pcId"),
        level = json.optNullableInt("level"),
        initiative = json.optNullableInt("initiative"),
        initiativeModifier = json.optInt("initiativeModifier", 0),
        initiativeSource = json.optNullableString("initiativeSource"),
        hp = json.optInt("hp", 10),
        maxHp = json.optInt("maxHp", 10).coerceAtLeast(1),
        tempHp = json.optInt("tempHp", 0).coerceAtLeast(0),
        conditions = json.optJSONArray("conditions").toObjectList(::conditionFromJson),
        gmNote = json.optString("gmNote"),
        publicNote = json.optString("publicNote"),
        groupKey = json.optNullableString("groupKey"),
        defeated = json.optBoolean("defeated", false),
        delayed = json.optBoolean("delayed", false),
        readyAction = json.optString("readyAction"),
        readyTrigger = json.optString("readyTrigger"),
    )

    private fun logToJson(entry: CombatLogEntry) = JSONObject().apply {
        put("id", entry.id)
        put("timestamp", entry.timestamp)
        put("label", entry.label)
    }

    private fun logFromJson(json: JSONObject) = CombatLogEntry(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        timestamp = json.optLong("timestamp", System.currentTimeMillis()),
        label = json.optString("label"),
    )

    private fun lootItemToJson(item: LootItem) = JSONObject().apply {
        put("id", item.id)
        put("name", item.name)
        put("category", item.category)
        put("quantity", item.quantity)
        put("valueGp", item.valueGp)
        put("notes", item.notes)
        put("assignedToPcId", item.assignedToPcId ?: JSONObject.NULL)
    }

    private fun lootItemFromJson(json: JSONObject) = LootItem(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Treasure"),
        category = json.optString("category", "Treasure"),
        quantity = json.optInt("quantity", 1).coerceAtLeast(1),
        valueGp = json.optDouble("valueGp", 0.0),
        notes = json.optString("notes"),
        assignedToPcId = json.optNullableString("assignedToPcId"),
    )

    private fun encounterToJson(encounter: EncounterState) = JSONObject().apply {
        put("id", encounter.id)
        put("name", encounter.name)
        put("gmNotes", encounter.gmNotes)
        put("startingNotes", encounter.startingNotes)
        put("active", encounter.active)
        put("ended", encounter.ended)
        put("round", encounter.round)
        put("turnIndex", encounter.turnIndex)
        put("combatants", JSONArray().apply { encounter.combatants.forEach { put(combatantToJson(it)) } })
        put("endTurnRequests", JSONArray().apply { encounter.endTurnRequests.forEach { put(it) } })
        put("pendingEffectChecks", JSONArray().apply { encounter.pendingEffectChecks.forEach { put(effectCheckToJson(it)) } })
        put("pendingTurnAdvance", encounter.pendingTurnAdvance)
        put("history", JSONArray().apply { encounter.history.forEach { put(logToJson(it)) } })
        put("loot", JSONObject().apply {
            put("generatedAt", encounter.loot.generatedAt ?: JSONObject.NULL)
            put("revealed", encounter.loot.revealed)
            put("movedToParty", encounter.loot.movedToParty)
            put("coinsGp", encounter.loot.coinsGp)
            put("items", JSONArray().apply { encounter.loot.items.forEach { put(lootItemToJson(it)) } })
        })
    }

    private fun encounterFromJson(json: JSONObject): EncounterState {
        val lootJson = json.optJSONObject("loot") ?: JSONObject()
        return EncounterState(
            id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
            name = json.optString("name", "Encounter"),
            gmNotes = json.optString("gmNotes"),
            startingNotes = json.optString("startingNotes"),
            active = json.optBoolean("active", true),
            ended = json.optBoolean("ended", false),
            round = json.optInt("round", 1).coerceAtLeast(1),
            turnIndex = json.optInt("turnIndex", 0).coerceAtLeast(0),
            combatants = json.optJSONArray("combatants").toObjectList(::combatantFromJson),
            endTurnRequests = json.optJSONArray("endTurnRequests").toStringList(),
            pendingEffectChecks = json.optJSONArray("pendingEffectChecks").toObjectList(::effectCheckFromJson),
            pendingTurnAdvance = json.optBoolean("pendingTurnAdvance", false),
            history = json.optJSONArray("history").toObjectList(::logFromJson),
            loot = EncounterLoot(
                generatedAt = lootJson.optNullableLong("generatedAt"),
                revealed = lootJson.optBoolean("revealed", false),
                movedToParty = lootJson.optBoolean("movedToParty", false),
                coinsGp = lootJson.optDouble("coinsGp", 0.0),
                items = lootJson.optJSONArray("items").toObjectList(::lootItemFromJson),
            ),
        )
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

    private fun JSONObject.optNullableInt(key: String): Int? =
        if (!has(key) || isNull(key)) null else optInt(key)

    private fun JSONObject.optNullableLong(key: String): Long? =
        if (!has(key) || isNull(key)) null else optLong(key)

    private fun <T> JSONArray?.toObjectList(transform: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) {
                optJSONObject(i)?.let { add(transform(it)) }
            }
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) optString(i).takeIf { it.isNotBlank() }?.let(::add)
        }
    }
}
