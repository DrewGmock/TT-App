package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.ContentStatus
import com.drew.tthelper.model.PlayerContentDraft
import com.drew.tthelper.server.HostRuntime

@Composable
fun ApprovalInboxScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    val pending = state.pcs.flatMap { pc ->
        pc.contentDrafts.filter { it.status == ContentStatus.PENDING }.map { pc to it }
    }.sortedBy { it.second.submittedAt ?: Long.MAX_VALUE }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Approval Inbox", fontSize = 26.sp)
        Text("Review player-created content and new-character requests. Nothing becomes authoritative until you approve it.")
        if (state.characterRequests.isNotEmpty()) {
            Text("New character requests", fontSize = 20.sp)
            state.characterRequests.sortedBy { it.submittedAt }.forEach { request ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(request.characterName, fontSize = 20.sp)
                        Text("Requested by ${request.playerName}")
                        Text(listOf(request.ancestry, request.heritage, request.background, request.characterClass, request.level?.let { "Level $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" • "))
                        if (request.notes.isNotBlank()) Text(request.notes)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { runtime.store.approveCharacterRequest(request.id) }) { Text("Approve character") }
                            OutlinedButton(onClick = { runtime.store.declineCharacterRequest(request.id) }) { Text("Decline") }
                        }
                    }
                }
            }
            HorizontalDivider()
        }
        if (pending.isEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("No pending submissions", fontSize = 19.sp)
                    Text("Rejected entries return to the player's Drafts with your feedback intact.")
                }
            }
        } else {
            Text("${pending.size} pending", fontSize = 18.sp)
            pending.forEach { (pc, draft) ->
                SubmissionReviewCard(runtime, pc.id, pc.name, draft)
            }
        }

        HorizontalDivider()
        Text("Player draft status", fontSize = 20.sp)
        state.pcs.forEach { pc ->
            val drafts = pc.contentDrafts.count { it.status == ContentStatus.DRAFT }
            val waiting = pc.contentDrafts.count { it.status == ContentStatus.PENDING }
            val approved = pc.contentDrafts.count { it.status == ContentStatus.APPROVED_HISTORY }
            Text("${pc.name}: $drafts drafts • $waiting pending • $approved approved submissions")
        }
    }
}

@Composable
private fun SubmissionReviewCard(runtime: HostRuntime, pcId: String, pcName: String, draft: PlayerContentDraft) {
    var editName by remember(draft.id, draft.name) { mutableStateOf(draft.name) }
    var editActions by remember(draft.id, draft.actions) { mutableStateOf(draft.actions.toString()) }
    var editNotes by remember(draft.id, draft.notes) { mutableStateOf(draft.notes) }
    var declineReason by remember(draft.id) { mutableStateOf("") }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(draft.name, fontSize = 20.sp)
                    Text("$pcName • ${draft.kind}")
                }
                Text(actionSummary(draft))
            }
            submissionDetails(draft).forEach { Text(it, fontSize = 13.sp) }
            if (draft.notes.isNotBlank()) Text(draft.notes)

            HorizontalDivider()
            Text("GM review / optional edits", fontSize = 16.sp)
            OutlinedTextField(
                value = editName,
                onValueChange = { editName = it.take(60) },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = editActions,
                onValueChange = { editActions = it.filter { ch -> ch.isDigit() }.take(1) },
                label = { Text("Actions (0–3)") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = editNotes,
                onValueChange = { editNotes = it.take(500) },
                label = { Text("Notes") },
                modifier = Modifier.fillMaxWidth(),
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { runtime.store.approveContentDraft(pcId, draft.id) }) { Text("Approve as submitted") }
                FilledTonalButton(onClick = {
                    runtime.store.approveContentDraft(
                        pcId = pcId,
                        draftId = draft.id,
                        nameOverride = editName,
                        actionsOverride = editActions.toIntOrNull(),
                        notesOverride = editNotes,
                    )
                }) { Text("Edit & approve") }
            }

            OutlinedTextField(
                value = declineReason,
                onValueChange = { declineReason = it.take(500) },
                label = { Text("Return-to-draft feedback") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(onClick = {
                runtime.store.declineContentDraft(pcId, draft.id, declineReason.ifBlank { "Returned to your drafts for changes." })
            }) { Text("Decline → return to Drafts") }
        }
    }
}

private fun actionSummary(draft: PlayerContentDraft): String = when (draft.actionType) {
    "REACTION" -> "Reaction"
    "FREE" -> "Free"
    "PASSIVE" -> "Passive"
    else -> if (draft.actions == 1) "1 action" else "${draft.actions} actions"
}

private fun submissionDetails(draft: PlayerContentDraft): List<String> = buildList {
    when (draft.kind) {
        "SPELL" -> {
            add(if (draft.isCantrip) "Cantrip" else if (draft.isFocus) "Focus spell • Rank ${draft.rank}" else "Rank ${draft.rank} spell")
            if (draft.range.isNotBlank()) add("Range: ${draft.range}")
            if (draft.targets.isNotBlank()) add("Targets: ${draft.targets}")
            if (draft.checkOrSave.isNotBlank()) add("Check/Save: ${draft.checkOrSave}")
        }
        "ABILITY" -> add("${draft.abilityCategory} • ${draft.usageMode.replace('_', ' ').lowercase()}")
        "STRIKE" -> add("Attack ${if (draft.attackModifier >= 0) "+" else ""}${draft.attackModifier} • ${draft.damage.ifBlank { "damage not entered" }}")
        "RESOURCE" -> add("Resource maximum ${draft.resourceMax}")
    }
    if (draft.traits.isNotBlank()) add("Traits: ${draft.traits}")
}
