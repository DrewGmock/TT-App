# TT Helper LAN protocol notes — 0.3.1 alpha 1

The Samsung tablet remains authoritative. Player browsers receive filtered snapshots over WebSocket and submit actions/requests to the host.

New in 0.3.1:
- `POST /api/request-character` accepts a PIN-protected character request before a player is assigned.
- Player snapshot adds `you.heritage`, `you.background`, `you.feats`, `inventory`, and `sharedLoot`.
- Character creation requests are stored in session state and persist in backups until approved or declined.
- Existing spell/ability/strike/resource draft approval behavior is unchanged; declined content returns to player Drafts.
