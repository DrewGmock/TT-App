(() => {
  const $ = id => document.getElementById(id);
  const quickConditions = ['Frightened','Prone','Off-Guard','Dying','Wounded','Sickened','Slowed','Stunned','Chaos Aura','Thorn-Crowned Rage'];
  const state = { token: localStorage.getItem('tthelper.token'), ws: null, snapshot: null, reconnectTimer: null };

  async function loadLobby() {
    const response = await fetch('/api/public', { cache: 'no-store' });
    if (!response.ok) throw new Error(`Host returned ${response.status}`);
    const lobby = await response.json();
    $('campaign-title').textContent = lobby.campaignName || 'TT Helper';
    const select = $('pc-select'); select.innerHTML = '';
    (lobby.pcs || []).forEach(pc => {
      const option = document.createElement('option');
      option.value = pc.id;
      option.textContent = `${pc.name} — ${pc.characterClass}`;
      select.appendChild(option);
    });
  }

  async function join() {
    $('join-error').textContent = '';
    const response = await fetch('/api/join', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ pin:$('pin').value.trim(), displayName:$('display-name').value.trim(), pcId:$('pc-select').value })
    });
    const result = await response.json();
    if (!response.ok || !result.ok) { $('join-error').textContent = result.error || 'Could not join.'; return; }
    state.token = result.token;
    localStorage.setItem('tthelper.token', state.token);
    showGame();
    connect();
  }

  async function tryResume() {
    if (!state.token) return false;
    const response = await fetch(`/api/resume?token=${encodeURIComponent(state.token)}`, {cache:'no-store'});
    if (response.ok) { showGame(); connect(); return true; }
    localStorage.removeItem('tthelper.token');
    state.token = null;
    return false;
  }

  function showGame() { $('join-view').classList.add('hidden'); $('game-view').classList.remove('hidden'); }
  function showJoin() { $('game-view').classList.add('hidden'); $('join-view').classList.remove('hidden'); setOnline(false); }

  function connect() {
    if (!state.token) return;
    clearTimeout(state.reconnectTimer);
    const scheme = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${scheme}://${location.host}/ws?token=${encodeURIComponent(state.token)}`);
    state.ws = ws;
    ws.onopen = () => setOnline(true);
    ws.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.type === 'snapshot') { state.snapshot = message; render(message); cacheSnapshot(message); }
    };
    ws.onclose = () => {
      setOnline(false);
      if (state.token) state.reconnectTimer = setTimeout(connect, 1500);
    };
    ws.onerror = () => ws.close();
  }

  function action(actionName, payload = {}) {
    if (!state.ws || state.ws.readyState !== WebSocket.OPEN) return false;
    const requestId = (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`);
    state.ws.send(JSON.stringify({ type:'action', requestId, action:actionName, payload }));
    return true;
  }

  function render(snapshot) {
    $('campaign-title').textContent = snapshot.campaignName || 'TT Helper';
    $('scene-name').textContent = snapshot.sceneName || '—';
    const pc = snapshot.you;
    if (!pc) return;
    $('pc-name').textContent = pc.name;
    $('pc-meta').textContent = `${pc.ancestry} • ${pc.characterClass} • ${pc.level == null ? 'Level not set' : `Level ${pc.level}`}`;
    $('hp').textContent = pc.hp;
    $('max-hp').textContent = pc.maxHp;
    $('temp-hp').textContent = pc.tempHp > 0 ? `+${pc.tempHp} temporary HP` : '';
    $('ready-button').textContent = pc.ready ? 'Ready ✓' : 'Ready';

    $('conditions').innerHTML = '';
    (pc.conditions || []).forEach(c => $('conditions').appendChild(chip(conditionText(c), () => action('toggleCondition', { name:c.name }))));

    $('party-list').innerHTML = '';
    (snapshot.party || []).forEach(member => {
      const row = document.createElement('div'); row.className = 'party-row';
      const left = document.createElement('div');
      const conditionTextValue = member.conditions?.length ? ` • ${member.conditions.map(conditionText).map(escapeHtml).join(', ')}` : '';
      left.innerHTML = `<strong>${escapeHtml(member.name)}</strong><div class="muted">${member.ready ? 'Ready' : 'Not ready'}${conditionTextValue}</div>`;
      const right = document.createElement('strong'); right.textContent = `${member.hp}/${member.maxHp}`;
      row.append(left, right); $('party-list').appendChild(row);
    });

    renderEncounter(snapshot.encounter);
  }

  function renderEncounter(encounter) {
    const panel = $('encounter-panel');
    if (!encounter) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    $('encounter-name').textContent = encounter.name || 'Encounter';
    $('encounter-round').textContent = `Round ${encounter.round}${encounter.ended ? ' • Encounter ended' : ''}`;
    $('current-turn').textContent = encounter.currentName ? `Current turn: ${encounter.currentName}` : 'Waiting for combatants';
    $('turn-pill').textContent = encounter.currentIsYou ? 'YOUR TURN' : (encounter.active ? 'Live' : 'Ended');
    $('turn-pill').classList.toggle('your-turn', !!encounter.currentIsYou);

    const initiativeEntry = $('initiative-entry');
    if (encounter.active && encounter.yourInitiative == null) initiativeEntry.classList.remove('hidden');
    else initiativeEntry.classList.add('hidden');

    const endButton = $('end-turn-button');
    if (encounter.active) {
      endButton.classList.remove('hidden');
      endButton.disabled = !encounter.currentIsYou || encounter.endTurnRequested;
      endButton.textContent = encounter.endTurnRequested ? 'End Turn Requested ✓' : (encounter.currentIsYou ? 'Request End Turn' : 'Wait for your turn');
    } else {
      endButton.classList.add('hidden');
    }

    $('initiative-list').innerHTML = '';
    (encounter.initiative || []).forEach(entry => {
      const row = document.createElement('div');
      row.className = `initiative-row${entry.current ? ' current' : ''}${entry.isYou ? ' you' : ''}`;
      const flags = [entry.isYou ? 'You' : '', entry.delayed ? 'Delayed' : '', entry.defeated ? 'Defeated' : ''].filter(Boolean).join(' • ');
      row.innerHTML = `<strong>${escapeHtml(entry.name)}</strong><span class="muted">${escapeHtml(flags)}</span>`;
      $('initiative-list').appendChild(row);
    });

    const enemies = encounter.enemies || [];
    $('enemy-heading').classList.toggle('hidden', enemies.length === 0);
    $('enemy-list').innerHTML = '';
    enemies.forEach(enemy => {
      const card = document.createElement('div'); card.className = 'enemy-card';
      const conditionHtml = (enemy.conditions || []).map(c => `<span class="mini-chip">${escapeHtml(conditionText(c))}</span>`).join('');
      const note = enemy.publicNote ? `<div class="muted">${escapeHtml(enemy.publicNote)}</div>` : '';
      card.innerHTML = `<div class="row split"><strong>${escapeHtml(enemy.name)}</strong><span>${escapeHtml(enemy.health)}</span></div>${note}<div class="mini-chips">${conditionHtml}</div>`;
      $('enemy-list').appendChild(card);
    });

    const loot = encounter.loot;
    if (loot) {
      $('revealed-loot').classList.remove('hidden');
      $('loot-coins').textContent = loot.coinsGp > 0 ? `${formatGp(loot.coinsGp)} gp` : 'No coins';
      $('loot-items').innerHTML = '';
      (loot.items || []).forEach(item => {
        const row = document.createElement('div'); row.className = 'loot-row';
        row.textContent = `${item.quantity > 1 ? `${item.quantity}× ` : ''}${item.name}${item.category ? ` • ${item.category}` : ''}`;
        $('loot-items').appendChild(row);
      });
    } else {
      $('revealed-loot').classList.add('hidden');
    }
  }

  function cacheSnapshot(snapshot) {
    try { localStorage.setItem('tthelper.snapshot', JSON.stringify(snapshot)); } catch (_) {}
  }

  function renderCached() {
    try { const cached = JSON.parse(localStorage.getItem('tthelper.snapshot')); if (cached) { state.snapshot = cached; render(cached); } } catch (_) {}
  }

  function chip(text, onClick) {
    const button = document.createElement('button'); button.className = 'chip'; button.textContent = text; button.onclick = onClick; return button;
  }

  function conditionText(condition) {
    return condition.value == null ? condition.name : `${condition.name} ${condition.value}`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }

  function formatGp(value) {
    const number = Number(value || 0);
    return Number.isInteger(number) ? String(number) : number.toFixed(1);
  }

  function setupQuickConditions() {
    const select = $('condition-select');
    select.innerHTML = '';
    quickConditions.forEach(name => {
      const option = document.createElement('option');
      option.value = name; option.textContent = name; select.appendChild(option);
    });
    $('add-condition').onclick = () => {
      if (select.value) action('toggleCondition', { name:select.value });
    };
  }

  $('join-button').onclick = join;
  $('ready-button').onclick = () => action('toggleReady');
  document.querySelectorAll('[data-hp]').forEach(button => button.onclick = () => action('hpDelta', { delta:Number(button.dataset.hp) }));
  $('d20-button').onclick = () => {
    const result = 1 + Math.floor(Math.random() * 20);
    $('roll-result').textContent = `d20 → ${result}`;
    action('recordRoll', { label:'d20', result });
  };
  $('submit-initiative').onclick = () => {
    const value = Number.parseInt($('initiative-result').value, 10);
    if (Number.isFinite(value)) {
      action('submitInitiative', { value, source:'Physical result' });
      $('initiative-roll-result').textContent = `Submitted ${value}`;
    }
  };
  $('roll-initiative').onclick = () => {
    const modifier = Number.parseInt($('initiative-modifier').value || '0', 10) || 0;
    const die = 1 + Math.floor(Math.random() * 20);
    const result = die + modifier;
    action('submitInitiative', { value:result, source:'Player digital' });
    action('recordRoll', { label:`initiative d20 (${die}) ${modifier >= 0 ? '+' : ''}${modifier}`, result });
    $('initiative-roll-result').textContent = `${die} ${modifier >= 0 ? '+' : '−'} ${Math.abs(modifier)} = ${result}`;
  };
  $('end-turn-button').onclick = () => action('requestEndTurn');
  $('forget-button').onclick = () => {
    if (state.ws) state.ws.close();
    state.token = null;
    localStorage.removeItem('tthelper.token');
    localStorage.removeItem('tthelper.snapshot');
    showJoin();
  };

  const pinFromUrl = new URLSearchParams(location.search).get('pin');
  if (pinFromUrl) $('pin').value = pinFromUrl;
  setupQuickConditions();
  renderCached();
  loadLobby().then(tryResume).catch(error => { $('join-error').textContent = `Can't reach GM host: ${error.message}`; });
})();
