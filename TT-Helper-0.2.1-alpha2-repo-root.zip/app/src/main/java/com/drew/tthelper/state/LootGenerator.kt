package com.drew.tthelper.state

import com.drew.tthelper.model.EncounterLoot
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.LootItem
import kotlin.math.max
import kotlin.random.Random

object LootGenerator {
    private val consumables = listOf(
        "Minor restorative draught",
        "Antidote or antiplague dose",
        "Single-use talisman",
        "Smoke or utility consumable",
        "Minor alchemical tool",
        "Scroll or spell consumable",
    )

    private val valuables = listOf(
        "Small gemstone",
        "Silver trade bar",
        "Decorative jewelry",
        "Fine tool or instrument",
        "Useful crafting materials",
        "Odd curio with resale value",
    )

    private val upgrades = listOf(
        "Weapon upgrade material",
        "Armor upgrade material",
        "Durable adventuring gear",
        "Uncommon utility item",
        "Magical component parcel",
    )

    fun generate(encounter: EncounterState, random: Random = Random.Default): EncounterLoot {
        val foes = encounter.combatants.filter { it.kind != "pc" }
        val threat = foes.sumOf { max(1, (it.level ?: 0) + 1) }.coerceAtLeast(1)
        val coins = (threat * random.nextInt(3, 8)).toDouble()
        val itemCount = when {
            foes.size >= 6 -> 4
            foes.size >= 3 -> 3
            foes.size >= 1 -> 2
            else -> 1
        }
        val items = buildList {
            repeat(itemCount) { index ->
                val categoryRoll = random.nextInt(100)
                val (category, name) = when {
                    categoryRoll < 50 -> "Consumable" to consumables.random(random)
                    categoryRoll < 85 -> "Valuable" to valuables.random(random)
                    else -> "Upgrade" to upgrades.random(random)
                }
                add(
                    LootItem(
                        name = name,
                        category = category,
                        quantity = if (category == "Consumable" && random.nextBoolean()) 2 else 1,
                        valueGp = max(1, threat + random.nextInt(1, 7)).toDouble(),
                        notes = if (index == 0) "Generated from the defeated encounter; GM may edit or replace." else "",
                    )
                )
            }
        }
        return EncounterLoot(
            generatedAt = System.currentTimeMillis(),
            revealed = false,
            coinsGp = coins,
            items = items,
        )
    }
}
