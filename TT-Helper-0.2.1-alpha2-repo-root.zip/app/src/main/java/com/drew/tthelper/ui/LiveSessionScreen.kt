package com.drew.tthelper.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.server.HostRuntime

@Composable
fun LiveSessionScreen(runtime: HostRuntime, tablet: Boolean) {
    val state by runtime.store.state.collectAsState()
    val encounter = state.encounter
    if (encounter != null) {
        EncounterScreen(runtime, state, encounter, tablet)
    } else {
        FreePlayScreen(runtime, state, tablet)
    }
}

@Composable
private fun FreePlayScreen(runtime: HostRuntime, state: SessionState, tablet: Boolean) {
    var selectedId by remember { mutableStateOf(state.pcs.firstOrNull()?.id) }
    val selected = state.pcs.firstOrNull { it.id == selectedId } ?: state.pcs.firstOrNull()

    if (tablet && selected != null) {
        Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(
                Modifier.weight(0.85f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                EncounterLauncher(runtime, state)
                PcList(state.pcs, selected.id) { selectedId = it }
                PartyLootPanel(runtime, state)
            }
            PcDetail(runtime, selected, Modifier.weight(1.15f))
        }
    } else {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(state.sceneName, fontSize = 22.sp)
            EncounterLauncher(runtime, state)
            state.pcs.forEach { pc ->
                PcQuickCard(runtime, pc, onOpen = { selectedId = pc.id })
                if (selectedId == pc.id) PcDetail(runtime, pc, Modifier.fillMaxWidth())
            }
            PartyLootPanel(runtime, state)
        }
    }
}

@Composable
private fun EncounterLauncher(runtime: HostRuntime, state: SessionState) {
    var quickName by remember { mutableStateOf("Quick Encounter") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Start encounter", fontSize = 20.sp)
            Text("Live combat is separate from Session Prep; prepared templates stay unchanged.")
            OutlinedTextField(
                value = quickName,
                onValueChange = { quickName = it.take(50) },
                label = { Text("Quick encounter name") },
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = { runtime.store.startQuickEncounter(quickName) }) { Text("Start quick encounter") }
            if (state.prep.preparedEncounters.isNotEmpty()) {
                HorizontalDivider()
                Text("Prepared encounters")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.prep.preparedEncounters.forEach { prepared ->
                        FilledTonalButton(onClick = { runtime.store.startPreparedEncounter(prepared.id) }) {
                            Text("Start ${prepared.name}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PcList(pcs: List<PlayerCharacter>, selectedId: String, onSelect: (String) -> Unit) {
    Text("Party", fontSize = 22.sp)
    pcs.forEach { pc ->
        Card(Modifier.fillMaxWidth().clickable { onSelect(pc.id) }) {
            Column(Modifier.padding(14.dp)) {
                Text(pc.name, fontSize = 18.sp)
                Text("${pc.ancestry} • ${pc.characterClass} • ${pc.level?.let { "Level $it" } ?: "Level not set"}")
                Text("HP ${pc.hp}/${pc.maxHp}${if (pc.tempHp > 0) " +${pc.tempHp} temp" else ""}${if (selectedId == pc.id) " • Selected" else ""}")
            }
        }
    }
}

@Composable
private fun PcQuickCard(runtime: HostRuntime, pc: PlayerCharacter, onOpen: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(pc.name, fontSize = 19.sp)
                    Text("${pc.characterClass} • ${pc.level?.let { "Level $it" } ?: "Level not set"}")
                }
                Text("${pc.hp}/${pc.maxHp} HP")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { runtime.store.hpDelta(pc.id, -1) }) { Text("-1") }
                OutlinedButton(onClick = { runtime.store.hpDelta(pc.id, -5) }) { Text("-5") }
                FilledTonalButton(onClick = { runtime.store.hpDelta(pc.id, 1) }) { Text("+1") }
                FilledTonalButton(onClick = { runtime.store.hpDelta(pc.id, 5) }) { Text("+5") }
            }
        }
    }
}

@Composable
private fun PcDetail(runtime: HostRuntime, pc: PlayerCharacter, modifier: Modifier) {
    var showEffectPicker by remember(pc.id) { mutableStateOf(false) }
    Column(modifier.verticalScroll(rememberScrollState()).padding(4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(pc.name, fontSize = 26.sp)
        Text("${pc.ancestry} ${pc.characterClass} • ${pc.level?.let { "Level $it" } ?: "level intentionally unset"}")
        Text("HP ${pc.hp}/${pc.maxHp} • Temp ${pc.tempHp} • Hero ${pc.heroPoints}")

        Text("Fast HP", fontSize = 18.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(-10, -5, -1, 1, 5, 10).forEach { delta ->
                if (delta < 0) OutlinedButton(onClick = { runtime.store.hpDelta(pc.id, delta) }) { Text(delta.toString()) }
                else FilledTonalButton(onClick = { runtime.store.hpDelta(pc.id, delta) }) { Text("+$delta") }
            }
            OutlinedButton(onClick = { runtime.store.tempHpDelta(pc.id, 5) }) { Text("+5 temp") }
        }

        HorizontalDivider()
        Text("Active conditions", fontSize = 18.sp)
        if (pc.conditions.isEmpty()) Text("None")
        pc.conditions.forEach { condition ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(condition.name + (condition.value?.let { " $it" } ?: ""), modifier = Modifier.weight(1f))
                if (condition.value != null) {
                    OutlinedButton(onClick = { runtime.store.setPcConditionValue(pc.id, condition.name, condition.value - 1) }) { Text("-") }
                    OutlinedButton(onClick = { runtime.store.setPcConditionValue(pc.id, condition.name, condition.value + 1) }) { Text("+") }
                }
                OutlinedButton(onClick = { runtime.store.toggleCondition(pc.id, condition.name) }) { Text("Remove") }
            }
        }

        Button(onClick = { showEffectPicker = true }, modifier = Modifier.fillMaxWidth()) {
            Text("+ Add condition or effect")
        }
        Text("Only active conditions are shown here.")
        if (showEffectPicker) {
            PcEffectPickerDialog(runtime = runtime, pc = pc, onDismiss = { showEffectPicker = false })
        }
    }
}

@Composable
private fun PartyLootPanel(runtime: HostRuntime, state: SessionState) {
    if (state.partyLoot.isEmpty()) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Party Loot", fontSize = 20.sp)
            state.partyLoot.forEach { item ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text("${if (item.quantity > 1) "${item.quantity}× " else ""}${item.name}")
                    val assigned = item.assignedToPcId?.let { id -> state.pcs.firstOrNull { it.id == id }?.name } ?: "Shared stash"
                    Text("${item.category} • $assigned")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { runtime.store.assignPartyLoot(item.id, null) }) { Text("Shared") }
                        state.pcs.forEach { pc ->
                            OutlinedButton(onClick = { runtime.store.assignPartyLoot(item.id, pc.id) }) { Text(pc.name.substringBefore(' ')) }
                        }
                        OutlinedButton(onClick = { runtime.store.removePartyLoot(item.id) }) { Text("Remove") }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}
