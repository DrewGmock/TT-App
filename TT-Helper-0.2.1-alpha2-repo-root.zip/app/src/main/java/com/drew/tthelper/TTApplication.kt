package com.drew.tthelper

import android.app.Application
import com.drew.tthelper.server.HostRuntime
import com.drew.tthelper.server.PlayerRegistry
import com.drew.tthelper.state.SessionStore

class TTApplication : Application() {
    lateinit var runtime: HostRuntime
        private set

    override fun onCreate() {
        super.onCreate()
        runtime = HostRuntime(
            store = SessionStore(this),
            registry = PlayerRegistry(),
        )
    }
}
