package com.drew.tthelper.server

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.drew.tthelper.network.NetworkUtils
import com.drew.tthelper.state.SessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class HostStatus(
    val running: Boolean = false,
    val address: String? = null,
    val port: Int = 8787,
    val error: String? = null,
)

class HostRuntime(
    val store: SessionStore,
    val registry: PlayerRegistry,
) {
    private val _status = MutableStateFlow(HostStatus())
    val status: StateFlow<HostStatus> = _status.asStateFlow()

    fun requestStart(context: Context) {
        val intent = Intent(context, LocalServerService::class.java).setAction(LocalServerService.ACTION_START)
        ContextCompat.startForegroundService(context, intent)
    }

    fun requestStop(context: Context) {
        context.startService(Intent(context, LocalServerService::class.java).setAction(LocalServerService.ACTION_STOP))
    }

    internal fun markRunning(port: Int) {
        _status.value = HostStatus(
            running = true,
            address = NetworkUtils.localIpv4Address(),
            port = port,
        )
    }

    internal fun markStopped(error: String? = null) {
        _status.value = HostStatus(running = false, error = error)
    }

    fun joinUrl(): String? {
        val current = _status.value
        val ip = current.address ?: return null
        if (!current.running) return null
        return "http://$ip:${current.port}/?pin=${registry.pin.value}"
    }
}
