package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.EffectAnchor
import com.drew.tthelper.model.EffectCheckType
import com.drew.tthelper.model.EffectOutcomeAction
import com.drew.tthelper.model.EffectPhase
import com.drew.tthelper.model.EffectPreset
import com.drew.tthelper.model.EffectTriggerAction
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.model.effectPresets
import com.drew.tthelper.model.valuedConditions
import com.drew.tthelper.server.HostRuntime

private val quickEffectNames = listOf(
    "Frightened", "Prone", "Off-Guard", "Grabbed", "Sickened", "Persistent Damage", "Dying", "Wounded"
)

@Composable
fun EffectPickerDialog(
    runtime: HostRuntime,
    combatant: Combatant,
    encounter: EncounterState,
    initialPartyInflicted: Boolean,
    onDismiss: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<EffectPreset?>(null) }
    var valueText by remember { mutableStateOf("") }
    var partyInflicted by remember { mutableStateOf(initialPartyInflicted) }
    var customMode by remember { mutableStateOf(false) }

    if (customMode) {
        CustomEffectDialog(
            runtime = runtime,
            combatant = combatant,
            encounter = encounter,
            initialPartyInflicted = partyInflicted,
            onDismiss = { customMode = false },
            onApplied = onDismiss,
        )
        return
    }

    val all = effectPresets
    val filtered = if (query.isBlank()) all else all.filter {
        it.name.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true)
    }
    val recentNames = encounter.combatants
        .flatMap { it.conditions }
        .asReversed()
        .map { it.name }
        .distinct()
        .take(6)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (selected == null) "Add condition / effect" else selected!!.name) },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (selected == null) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(40) },
                        label = { Text("Search") },
                        modifier = Modifier.fillMaxWidth(),
                    )

                    if (query.isBlank() && recentNames.isNotEmpty()) {
                        Text("Recent / active")
                        EffectChips(recentNames) { name ->
                            selected = all.firstOrNull { it.name == name } ?: EffectPreset(name, "Recent")
                            valueText = selected?.defaultValue?.toString().orEmpty()
                        }
                    }

                    if (query.isBlank()) {
                        Text("Common")
                        EffectChips(quickEffectNames) { name ->
                            selected = all.firstOrNull { it.name == name } ?: EffectPreset(name, "Common")
                            valueText = selected?.defaultValue?.toString().orEmpty()
                        }
                        Text("PF2e conditions")
                        EffectChips(all.filter { it.category == "PF2e conditions" }.map { it.name }) { name ->
                            selected = all.first { it.name == name }
                            valueText = selected?.defaultValue?.toString().orEmpty()
                        }
                        Text("Cubeborne / homebrew")
                        EffectChips(all.filter { it.category == "Cubeborne / homebrew" }.map { it.name }) { name ->
                            selected = all.first { it.name == name }
                            valueText = selected?.defaultValue?.toString().orEmpty()
                        }
                    } else {
                        Text("Search results")
                        EffectChips(filtered.map { it.name }) { name ->
                            selected = filtered.first { it.name == name }
                            valueText = selected?.defaultValue?.toString().orEmpty()
                        }
                    }

                    HorizontalDivider()
                    FilledTonalButton(onClick = { customMode = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Create custom timed effect")
                    }
                } else {
                    val preset = selected!!
                    Text(preset.category)
                    if (preset.name in valuedConditions || preset.defaultValue != null) {
                        OutlinedTextField(
                            value = valueText,
                            onValueChange = { valueText = it.filter(Char::isDigit).take(2) },
                            label = { Text("Value") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Text("Timing: ${presetTimingSummary(preset)}")
                    if (preset.triggerAction == EffectTriggerAction.CHECK) {
                        Text("Reminder: ${preset.checkType ?: "Check"}${preset.checkDc?.let { " vs DC $it" } ?: ""}")
                        if (preset.checkLabel.isNotBlank()) Text(preset.checkLabel)
                    }
                    if (combatant.kind != "pc") {
                        OutlinedButton(onClick = { partyInflicted = !partyInflicted }) {
                            Text(if (partyInflicted) "Visible as party-inflicted effect" else "Normal enemy visibility")
                        }
                    }
                    Text("Source defaults to the creature whose turn is currently active. You can use Custom for source-anchored or unusual timing.")
                }
            }
        },
        confirmButton = {
            if (selected != null) {
                Button(onClick = {
                    val preset = selected!!
                    runtime.store.addCombatantEffect(
                        combatantId = combatant.id,
                        presetName = preset.name,
                        sourceCombatantId = encounter.currentCombatant()?.id,
                        partyInflicted = partyInflicted,
                        valueOverride = valueText.toIntOrNull(),
                    )
                    onDismiss()
                }) { Text("Apply") }
            }
        },
        dismissButton = {
            if (selected == null) TextButton(onClick = onDismiss) { Text("Close") }
            else TextButton(onClick = { selected = null; valueText = "" }) { Text("Back") }
        },
    )
}

@Composable
private fun EffectChips(names: List<String>, onClick: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        names.distinct().forEach { name ->
            AssistChip(onClick = { onClick(name) }, label = { Text(name) })
        }
    }
}

private fun presetTimingSummary(preset: EffectPreset): String {
    if (preset.timingPhase == EffectPhase.MANUAL) return "Manual / condition-specific"
    val anchor = if (preset.timingAnchor == EffectAnchor.SOURCE) "source" else "target"
    val phase = if (preset.timingPhase == EffectPhase.START) "start" else "end"
    val action = when (preset.triggerAction) {
        EffectTriggerAction.REMOVE -> "remove"
        EffectTriggerAction.DECREMENT_VALUE -> "reduce value by 1"
        EffectTriggerAction.CHECK -> "prompt for a check"
        else -> "remind"
    }
    return "$phase of $anchor turn → $action"
}

@Composable
private fun CustomEffectDialog(
    runtime: HostRuntime,
    combatant: Combatant,
    encounter: EncounterState,
    initialPartyInflicted: Boolean,
    onDismiss: () -> Unit,
    onApplied: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var valueText by remember { mutableStateOf("") }
    var partyInflicted by remember { mutableStateOf(initialPartyInflicted) }
    var anchor by remember { mutableStateOf(EffectAnchor.TARGET) }
    var phase by remember { mutableStateOf(EffectPhase.MANUAL) }
    var action by remember { mutableStateOf(EffectTriggerAction.NONE) }
    var triggerCount by remember { mutableStateOf("") }
    var sourceId by remember { mutableStateOf(encounter.currentCombatant()?.id) }
    var checkType by remember { mutableStateOf(EffectCheckType.SKILL) }
    var checkLabel by remember { mutableStateOf("") }
    var dcText by remember { mutableStateOf("") }
    var repeatCheck by remember { mutableStateOf(true) }
    var critSuccess by remember { mutableStateOf(EffectOutcomeAction.REMOVE) }
    var success by remember { mutableStateOf(EffectOutcomeAction.REMOVE) }
    var failure by remember { mutableStateOf(EffectOutcomeAction.KEEP) }
    var critFailure by remember { mutableStateOf(EffectOutcomeAction.KEEP) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom effect") },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 600.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("Effect name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(valueText, { valueText = it.filter(Char::isDigit).take(2) }, label = { Text("Value (optional)") }, modifier = Modifier.fillMaxWidth())

                Text("Turn anchor")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChoiceButton("Target", anchor == EffectAnchor.TARGET) { anchor = EffectAnchor.TARGET }
                    ChoiceButton("Source", anchor == EffectAnchor.SOURCE) { anchor = EffectAnchor.SOURCE }
                }

                if (anchor == EffectAnchor.SOURCE) {
                    Text("Source creature")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        encounter.combatants.forEach { source ->
                            ChoiceButton(source.name, sourceId == source.id) { sourceId = source.id }
                        }
                    }
                }

                Text("When it triggers")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChoiceButton("Manual", phase == EffectPhase.MANUAL) { phase = EffectPhase.MANUAL }
                    ChoiceButton("Start of turn", phase == EffectPhase.START) { phase = EffectPhase.START }
                    ChoiceButton("End of turn", phase == EffectPhase.END) { phase = EffectPhase.END }
                }

                if (phase != EffectPhase.MANUAL) {
                    Text("What happens")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ChoiceButton("No automation", action == EffectTriggerAction.NONE) { action = EffectTriggerAction.NONE }
                        ChoiceButton("Remove", action == EffectTriggerAction.REMOVE) { action = EffectTriggerAction.REMOVE }
                        ChoiceButton("Reduce value", action == EffectTriggerAction.DECREMENT_VALUE) { action = EffectTriggerAction.DECREMENT_VALUE }
                        ChoiceButton("Require check", action == EffectTriggerAction.CHECK) { action = EffectTriggerAction.CHECK }
                    }
                    OutlinedTextField(
                        triggerCount,
                        { triggerCount = it.filter(Char::isDigit).take(2) },
                        label = { Text("Trigger count / rounds (optional)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                if (action == EffectTriggerAction.CHECK) {
                    HorizontalDivider()
                    Text("Required check")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            EffectCheckType.SKILL,
                            EffectCheckType.SAVE,
                            EffectCheckType.FLAT,
                            EffectCheckType.RECOVERY,
                            EffectCheckType.CUSTOM,
                        ).forEach { type -> ChoiceButton(type, checkType == type) { checkType = type } }
                    }
                    OutlinedTextField(checkLabel, { checkLabel = it.take(160) }, label = { Text("Check / reminder text") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(dcText, { dcText = it.filter(Char::isDigit).take(2) }, label = { Text("DC (optional)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { repeatCheck = !repeatCheck }) {
                        Text(if (repeatCheck) "Repeats each trigger ✓" else "One check only")
                    }
                    Text("Outcome actions")
                    OutcomeCycle("Critical success", critSuccess) { critSuccess = nextOutcome(critSuccess) }
                    OutcomeCycle("Success", success) { success = nextOutcome(success) }
                    OutcomeCycle("Failure", failure) { failure = nextOutcome(failure) }
                    OutcomeCycle("Critical failure", critFailure) { critFailure = nextOutcome(critFailure) }
                }

                if (combatant.kind != "pc") {
                    HorizontalDivider()
                    OutlinedButton(onClick = { partyInflicted = !partyInflicted }) {
                        Text(if (partyInflicted) "Party-inflicted / player-visible ✓" else "GM-only unless obvious")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank(),
                onClick = {
                    runtime.store.addCustomEffect(
                        combatantId = combatant.id,
                        name = name,
                        value = valueText.toIntOrNull(),
                        sourceCombatantId = sourceId,
                        partyInflicted = partyInflicted,
                        timingAnchor = anchor,
                        timingPhase = phase,
                        remainingTriggers = triggerCount.toIntOrNull(),
                        triggerAction = if (phase == EffectPhase.MANUAL) EffectTriggerAction.NONE else action,
                        checkType = if (action == EffectTriggerAction.CHECK) checkType else null,
                        checkLabel = checkLabel,
                        checkDc = dcText.toIntOrNull(),
                        successAction = success,
                        failureAction = failure,
                        criticalSuccessAction = critSuccess,
                        criticalFailureAction = critFailure,
                        repeatCheck = repeatCheck,
                    )
                    onApplied()
                },
            ) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Back") } },
    )
}

@Composable
private fun ChoiceButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) FilledTonalButton(onClick = onClick) { Text(label) }
    else OutlinedButton(onClick = onClick) { Text(label) }
}

@Composable
private fun OutcomeCycle(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, modifier = Modifier.padding(top = 10.dp))
        OutlinedButton(onClick = onClick) { Text(outcomeLabel(value)) }
    }
}

private fun nextOutcome(current: String): String {
    val actions = listOf(
        EffectOutcomeAction.KEEP,
        EffectOutcomeAction.REMOVE,
        EffectOutcomeAction.DECREMENT,
        EffectOutcomeAction.DECREMENT_2,
        EffectOutcomeAction.INCREMENT,
        EffectOutcomeAction.INCREMENT_2,
    )
    val index = actions.indexOf(current).takeIf { it >= 0 } ?: 0
    return actions[(index + 1) % actions.size]
}

private fun outcomeLabel(action: String): String = when (action) {
    EffectOutcomeAction.REMOVE -> "Remove effect"
    EffectOutcomeAction.DECREMENT -> "Value −1"
    EffectOutcomeAction.DECREMENT_2 -> "Value −2"
    EffectOutcomeAction.INCREMENT -> "Value +1"
    EffectOutcomeAction.INCREMENT_2 -> "Value +2"
    else -> "Keep effect"
}

@Composable
fun PcEffectPickerDialog(
    runtime: HostRuntime,
    pc: com.drew.tthelper.model.PlayerCharacter,
    onDismiss: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var selectedName by remember { mutableStateOf<String?>(null) }
    var valueText by remember { mutableStateOf("") }
    var customName by remember { mutableStateOf("") }
    val activeNames = pc.conditions.map { it.name.lowercase() }.toSet()
    val options = effectPresets.filter {
        it.name.lowercase() !in activeNames &&
            (query.isBlank() || it.name.contains(query, true) || it.category.contains(query, true))
    }
    val selectedPreset = effectPresets.firstOrNull { it.name == selectedName }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add condition / effect") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(query, { query = it.take(40) }, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                if (selectedName == null) {
                    EffectChips(options.map { it.name }) { name ->
                        selectedName = name
                        valueText = effectPresets.firstOrNull { it.name == name }?.defaultValue?.toString().orEmpty()
                    }
                    HorizontalDivider()
                    Text("Simple custom effect")
                    OutlinedTextField(customName, { customName = it.take(60) }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                    if (customName.isNotBlank()) {
                        FilledTonalButton(onClick = {
                            runtime.store.toggleCondition(pc.id, customName)
                            onDismiss()
                        }) { Text("Add custom") }
                    }
                    Text("Turn-timed custom automation is available once an encounter is running.")
                } else {
                    Text(selectedName ?: "")
                    if (selectedPreset?.defaultValue != null || selectedName in valuedConditions) {
                        OutlinedTextField(
                            valueText,
                            { valueText = it.filter(Char::isDigit).take(2) },
                            label = { Text("Value") },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (selectedName != null) {
                Button(onClick = {
                    runtime.store.toggleCondition(pc.id, selectedName!!, valueText.toIntOrNull())
                    onDismiss()
                }) { Text("Apply") }
            }
        },
        dismissButton = {
            TextButton(onClick = {
                if (selectedName == null) onDismiss() else selectedName = null
            }) { Text(if (selectedName == null) "Close" else "Back") }
        },
    )
}
