package com.drew.tthelper.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.Condition
import com.drew.tthelper.model.EffectAnchor
import com.drew.tthelper.model.EffectPhase
import com.drew.tthelper.model.EffectTriggerAction
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.server.HostRuntime

@Composable
fun EncounterScreen(runtime: HostRuntime, state: SessionState, encounter: EncounterState, tablet: Boolean) {
    var selectedId by remember(encounter.id) { mutableStateOf(encounter.currentCombatant()?.id ?: encounter.combatants.firstOrNull()?.id) }
    val selected = encounter.combatants.firstOrNull { it.id == selectedId }
        ?: encounter.currentCombatant()
        ?: encounter.combatants.firstOrNull()

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        EncounterHeader(runtime, encounter)
        if (tablet) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(
                    Modifier.weight(0.85f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    InitiativePane(runtime, state, encounter, selectedId) { selectedId = it }
                    QuickAddEnemy(runtime, state)
                }
                Column(
                    Modifier.weight(1.15f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (selected != null) CombatantDetail(runtime, selected, encounter)
                    if (encounter.ended) LootPanel(runtime, encounter)
                    CombatHistory(encounter)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                InitiativePane(runtime, state, encounter, selectedId) { selectedId = it }
                QuickAddEnemy(runtime, state)
                if (selected != null) CombatantDetail(runtime, selected, encounter)
                if (encounter.ended) LootPanel(runtime, encounter)
                CombatHistory(encounter)
            }
        }
    }
}

@Composable
private fun EncounterHeader(runtime: HostRuntime, encounter: EncounterState) {
    val current = encounter.currentCombatant()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(encounter.name, fontSize = 24.sp)
                    Text("Round ${encounter.round} • Current: ${current?.name ?: "—"}")
                }
                Text(if (encounter.active) "LIVE" else "ENDED")
            }
            if (encounter.startingNotes.isNotBlank()) Text("Start notes: ${encounter.startingNotes}")
            if (encounter.gmNotes.isNotBlank()) Text("GM notes: ${encounter.gmNotes}")
            if (encounter.active) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { runtime.store.previousTurn() }) { Text("Previous") }
                    val initiativeReady = encounter.combatants.isNotEmpty() && encounter.combatants.none { it.initiative == null }
                    val checksClear = encounter.pendingEffectChecks.isEmpty()
                    Button(
                        enabled = initiativeReady && checksClear,
                        onClick = { runtime.store.nextTurn() },
                    ) { Text("Next Turn") }
                    if (!initiativeReady) Text("Enter initiative for everyone before advancing.")
                    else if (!checksClear) Text("Resolve required effect checks before advancing.")
                    OutlinedButton(onClick = { runtime.store.endEncounter() }) { Text("End Encounter") }
                }
            } else {
                Text("The encounter is preserved for loot, history, and review until you close it.")
            }
        }
    }
}

@Composable
private fun InitiativePane(
    runtime: HostRuntime,
    state: SessionState,
    encounter: EncounterState,
    selectedId: String?,
    onSelect: (String) -> Unit,
) {
    val currentId = encounter.currentCombatant()?.id
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Initiative", fontSize = 20.sp)
            if (encounter.combatants.isEmpty()) Text("No combatants yet.")
            encounter.combatants.forEachIndexed { index, combatant ->
                val tied = combatant.initiative != null && encounter.combatants.count { it.initiative == combatant.initiative } > 1
                val pcRequest = combatant.pcId != null && combatant.pcId in encounter.endTurnRequests
                Card(Modifier.fillMaxWidth().clickable { onSelect(combatant.id) }) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${combatant.initiative?.toString() ?: "—"}  ${combatant.name}")
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (combatant.id == currentId) StatusBadge("TURN")
                            if (combatant.id == selectedId) StatusBadge("SELECTED")
                            if (tied) {
                                val groupSize = combatant.groupKey?.let { key ->
                                    encounter.combatants.count { it.groupKey == key && it.initiative == combatant.initiative }
                                } ?: 0
                                StatusBadge(if (groupSize > 1) "GROUP ×$groupSize" else "TIE")
                            }
                            if (pcRequest) StatusBadge("REQUEST")
                        }
                        val hpText = "HP ${combatant.hp}/${combatant.maxHp}${if (combatant.tempHp > 0) " +${combatant.tempHp}" else ""}"
                        Text("${combatant.kind.uppercase()} • $hpText${if (combatant.defeated) " • Defeated" else ""}${if (combatant.delayed) " • Delayed" else ""}")
                        if (combatant.conditions.isNotEmpty()) {
                            Text(combatant.conditions.joinToString(" • ") { c -> c.name + (c.value?.let { " $it" } ?: "") })
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(enabled = index > 0, onClick = { runtime.store.moveCombatant(combatant.id, -1) }) { Text("↑") }
                            OutlinedButton(enabled = index < encounter.combatants.lastIndex, onClick = { runtime.store.moveCombatant(combatant.id, 1) }) { Text("↓") }
                            if (combatant.delayed) {
                                FilledTonalButton(onClick = { runtime.store.resumeDelayed(combatant.id) }) { Text("Resume here") }
                            }
                        }
                    }
                }
            }
            if (encounter.combatants.any { it.initiative == null }) {
                Text("Initiative can be entered by the GM, submitted from a player phone, or digitally rolled.")
            }
            if (state.pcs.isEmpty()) Text("No PCs loaded.")
        }
    }
}

@Composable
private fun QuickAddEnemy(runtime: HostRuntime, state: SessionState) {
    var name by remember { mutableStateOf("") }
    var hp by remember { mutableStateOf("10") }
    var level by remember { mutableStateOf("") }
    var initMod by remember { mutableStateOf("0") }
    var quantity by remember { mutableStateOf("1") }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Quick Add", fontSize = 18.sp)
            OutlinedTextField(name, { name = it.take(50) }, label = { Text("Enemy / NPC name") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(hp, { hp = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("HP") }, modifier = Modifier.weight(1f))
                OutlinedTextField(level, { level = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Level") }, modifier = Modifier.weight(1f))
                OutlinedTextField(initMod, { initMod = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Init mod") }, modifier = Modifier.weight(1f))
                OutlinedTextField(quantity, { quantity = it.filter { c -> c.isDigit() }.take(2) }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
            }
            Button(onClick = {
                runtime.store.addQuickEnemy(
                    name = name,
                    maxHp = hp.toIntOrNull() ?: 10,
                    level = level.toIntOrNull(),
                    initiativeModifier = initMod.toIntOrNull() ?: 0,
                    quantity = quantity.toIntOrNull() ?: 1,
                )
                name = ""
            }) { Text("Add enemy") }

            if (state.prep.enemyLibrary.isNotEmpty()) {
                HorizontalDivider()
                Text("Add from Library")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    state.prep.enemyLibrary.forEach { enemy ->
                        FilledTonalButton(onClick = { runtime.store.addEnemyFromLibrary(enemy.id) }) {
                            Text(enemy.name)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CombatantDetail(runtime: HostRuntime, combatant: Combatant, encounter: EncounterState) {
    var initiativeText by remember(combatant.id, combatant.initiative) { mutableStateOf(combatant.initiative?.toString() ?: "") }
    var showEffectPicker by remember(combatant.id) { mutableStateOf(false) }
    var partyEffect by remember(combatant.id) { mutableStateOf(false) }
    var readyAction by remember(combatant.id, combatant.readyAction) { mutableStateOf(combatant.readyAction) }
    var readyTrigger by remember(combatant.id, combatant.readyTrigger) { mutableStateOf(combatant.readyTrigger) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(combatant.name, fontSize = 24.sp)
            Text("${combatant.kind.uppercase()} • HP ${combatant.hp}/${combatant.maxHp} • Temp ${combatant.tempHp}${combatant.level?.let { " • Level $it" } ?: ""}")
            if (combatant.gmNote.isNotBlank()) Text("GM: ${combatant.gmNote}")

            Text("Initiative", fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = initiativeText,
                    onValueChange = { initiativeText = it.filter { c -> c.isDigit() || c == '-' }.take(3) },
                    label = { Text("Result") },
                    modifier = Modifier.weight(1f),
                )
                Button(onClick = { initiativeText.toIntOrNull()?.let { runtime.store.setInitiative(combatant.id, it, "GM manual") } }) { Text("Set") }
                FilledTonalButton(onClick = { runtime.store.rollInitiative(combatant.id) }) { Text("Roll") }
            }
            val groupKey = combatant.groupKey
            val groupSize = if (groupKey == null) 0 else encounter.combatants.count { it.groupKey == groupKey }
            if (groupKey != null && groupSize > 1) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        initiativeText.toIntOrNull()?.let { runtime.store.setGroupInitiative(groupKey, it, "GM group manual") }
                    }) { Text("Set group ×$groupSize") }
                    OutlinedButton(onClick = { runtime.store.rollGroupInitiative(groupKey) }) { Text("Roll group") }
                }
                Text("Set an individual result later to split this creature from the group; set the group again to merge their initiative.")
            }

            Text("Fast HP", fontSize = 18.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(-10, -5, -1, 1, 5, 10).forEach { delta ->
                    if (delta < 0) OutlinedButton(onClick = { runtime.store.combatantHpDelta(combatant.id, delta) }) { Text(delta.toString()) }
                    else FilledTonalButton(onClick = { runtime.store.combatantHpDelta(combatant.id, delta) }) { Text("+$delta") }
                }
                OutlinedButton(onClick = { runtime.store.combatantTempHpDelta(combatant.id, 5) }) { Text("+5 temp") }
                if (combatant.kind != "pc") {
                    OutlinedButton(onClick = { runtime.store.setDefeated(combatant.id, !combatant.defeated) }) {
                        Text(if (combatant.defeated) "Restore" else "Defeated")
                    }
                }
            }

            HorizontalDivider()
            Text("Conditions / effects", fontSize = 18.sp)
            if (combatant.conditions.isEmpty()) {
                Text("None")
            } else {
                combatant.conditions.forEach { condition ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text(condition.name + (condition.value?.let { " $it" } ?: ""))
                                    val details = effectSummary(condition, encounter, combatant)
                                    if (details.isNotBlank()) Text(details, fontSize = 12.sp)
                                    if (condition.partyInflicted) Text("Party-inflicted • visible to players", fontSize = 12.sp)
                                }
                                OutlinedButton(onClick = { runtime.store.removeCombatantEffect(combatant.id, condition.id) }) { Text("Remove") }
                            }
                            if (condition.value != null) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = { runtime.store.setCombatantEffectValue(combatant.id, condition.id, condition.value - 1) }) { Text("−") }
                                    OutlinedButton(onClick = { runtime.store.setCombatantEffectValue(combatant.id, condition.id, condition.value + 1) }) { Text("+") }
                                }
                            }
                        }
                    }
                }
            }

            if (combatant.kind != "pc") {
                OutlinedButton(onClick = { partyEffect = !partyEffect }) {
                    Text(if (partyEffect) "New effects: party-visible" else "New effects: normal visibility")
                }
            }
            Button(onClick = { showEffectPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text("+ Add condition or effect")
            }
            Text("Only active effects stay on this page. Search the picker for PF2e, Cubeborne, recent, or custom timed effects.", fontSize = 12.sp)

            if (showEffectPicker) {
                EffectPickerDialog(
                    runtime = runtime,
                    combatant = combatant,
                    encounter = encounter,
                    initialPartyInflicted = partyEffect,
                    onDismiss = { showEffectPicker = false },
                )
            }

            HorizontalDivider()
            Text("Turn options", fontSize = 18.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (encounter.currentCombatant()?.id == combatant.id && encounter.active) {
                    OutlinedButton(onClick = { runtime.store.delayCurrent() }) { Text("Delay") }
                }
                if (combatant.delayed) FilledTonalButton(onClick = { runtime.store.resumeDelayed(combatant.id) }) { Text("Resume now") }
            }
            OutlinedTextField(readyAction, { readyAction = it.take(120) }, label = { Text("Readied action") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(readyTrigger, { readyTrigger = it.take(120) }, label = { Text("Trigger") }, modifier = Modifier.fillMaxWidth())
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { runtime.store.setReadyDetails(combatant.id, readyAction, readyTrigger) }) { Text("Set Ready") }
                if (combatant.readyAction.isNotBlank() || combatant.readyTrigger.isNotBlank()) {
                    OutlinedButton(onClick = { runtime.store.clearReadyDetails(combatant.id) }) { Text("Resolve / Clear") }
                }
            }
            if (combatant.readyAction.isNotBlank() || combatant.readyTrigger.isNotBlank()) {
                Text("READY: ${combatant.readyAction.ifBlank { "Action" }} • Trigger: ${combatant.readyTrigger.ifBlank { "not entered" }}")
            }
        }
    }
}

@Composable
private fun LootPanel(runtime: HostRuntime, encounter: EncounterState) {
    var customLoot by remember(encounter.id) { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Encounter Loot", fontSize = 20.sp)
            Text("Generation is local and lightweight. Treat the result as a GM-editable draft rather than strict treasure-by-level enforcement.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { runtime.store.generateLoot() }) { Text(if (encounter.loot.generatedAt == null) "Generate Loot" else "Reroll Loot") }
                if (encounter.loot.generatedAt != null && !encounter.loot.revealed) {
                    FilledTonalButton(onClick = { runtime.store.revealLoot() }) { Text("Reveal Loot") }
                }
                if (encounter.loot.generatedAt != null && !encounter.loot.movedToParty) {
                    OutlinedButton(onClick = { runtime.store.moveLootToParty() }) { Text("Move to Party Loot") }
                }
                if (encounter.loot.movedToParty) Text("Moved to Party Loot")
            }
            if (encounter.loot.generatedAt != null) {
                Text("Coins: ${formatGp(encounter.loot.coinsGp)} gp • ${if (encounter.loot.revealed) "Visible to players" else "GM-only"}")
                encounter.loot.items.forEach { item ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${if (item.quantity > 1) "${item.quantity}× " else ""}${item.name} • ${item.category}", modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { runtime.store.removeEncounterLootItem(item.id) }) { Text("Remove") }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(customLoot, { customLoot = it.take(80) }, label = { Text("Add custom loot") }, modifier = Modifier.weight(1f))
                Button(onClick = {
                    if (customLoot.isNotBlank()) {
                        runtime.store.addEncounterLootItem(customLoot)
                        customLoot = ""
                    }
                }) { Text("Add") }
            }
            OutlinedButton(onClick = { runtime.store.clearEncounter() }) { Text("Close encounter") }
        }
    }
}

@Composable
private fun CombatHistory(encounter: EncounterState) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Combat History", fontSize = 20.sp)
            if (encounter.history.isEmpty()) Text("No combat events yet.")
            encounter.history.takeLast(15).asReversed().forEach { entry -> Text("• ${entry.label}") }
        }
    }
}

@Composable
private fun StatusBadge(label: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp), fontSize = 11.sp)
    }
}

private fun effectSummary(effect: Condition, encounter: EncounterState, target: Combatant): String {
    val timing = if (effect.timingPhase == EffectPhase.MANUAL) {
        "Manual timing"
    } else {
        val phase = if (effect.timingPhase == EffectPhase.START) "Start" else "End"
        val anchorName = if (effect.timingAnchor == EffectAnchor.SOURCE) {
            encounter.combatants.firstOrNull { it.id == effect.sourceCombatantId }?.name ?: "source"
        } else target.name
        "$phase of $anchorName's turn"
    }
    val action = when (effect.triggerAction) {
        EffectTriggerAction.REMOVE -> "remove"
        EffectTriggerAction.DECREMENT_VALUE -> "reduce value"
        EffectTriggerAction.CHECK -> "check${effect.checkDc?.let { " DC $it" } ?: ""}"
        else -> ""
    }
    val count = effect.remainingTriggers?.let { " • $it trigger${if (it == 1) "" else "s"} left" }.orEmpty()
    return listOf(timing, action).filter { it.isNotBlank() }.joinToString(" • ") + count
}

private fun formatGp(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
