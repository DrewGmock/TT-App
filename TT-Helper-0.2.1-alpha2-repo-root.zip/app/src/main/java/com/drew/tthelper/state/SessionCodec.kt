package com.drew.tthelper.state

import com.drew.tthelper.model.CombatLogEntry
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.Condition
import com.drew.tthelper.model.EncounterLoot
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.SessionPrep
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.defaultCharacters
import org.json.JSONArray
import org.json.JSONObject

object SessionCodec {
    fun encode(state: SessionState): String = JSONObject().apply {
        put("revision", state.revision)
        put("campaignName", state.campaignName)
        put("sceneName", state.sceneName)
        put("lastEventLabel", state.lastEventLabel ?: JSONObject.NULL)
        put("prep", prepToJson(state.prep))
        put("pcs", JSONArray().apply { state.pcs.forEach { put(pcToJson(it)) } })
        put("encounter", state.encounter?.let(::encounterToJson) ?: JSONObject.NULL)
        put("partyLoot", JSONArray().apply { state.partyLoot.forEach { put(lootItemToJson(it)) } })
    }.toString()

    fun decode(raw: String): SessionState {
        val root = JSONObject(raw)
        val pcs = root.optJSONArray("pcs").toObjectList(::pcFromJson).ifEmpty { defaultCharacters() }
        return SessionState(
            revision = root.optLong("revision", 0),
            campaignName = root.optString("campaignName", "Cube-Borne"),
            sceneName = root.optString("sceneName", "Between Sessions"),
            pcs = pcs,
            prep = prepFromJson(root.optJSONObject("prep") ?: JSONObject()),
            encounter = root.optJSONObject("encounter")?.let(::encounterFromJson),
            partyLoot = root.optJSONArray("partyLoot").toObjectList(::lootItemFromJson),
            lastEventLabel = root.optNullableString("lastEventLabel"),
        )
    }

    private fun prepToJson(prep: SessionPrep) = JSONObject().apply {
        put("sessionTitle", prep.sessionTitle)
        put("openingScene", prep.openingScene)
        put("gmNotes", prep.gmNotes)
        put("encounterNotes", prep.encounterNotes)
        put("enemyLibrary", JSONArray().apply { prep.enemyLibrary.forEach { put(preparedEnemyToJson(it)) } })
        put("preparedEncounters", JSONArray().apply { prep.preparedEncounters.forEach { put(preparedEncounterToJson(it)) } })
    }

    private fun prepFromJson(json: JSONObject) = SessionPrep(
        sessionTitle = json.optString("sessionTitle", "Next Session"),
        openingScene = json.optString("openingScene"),
        gmNotes = json.optString("gmNotes"),
        encounterNotes = json.optString("encounterNotes"),
        enemyLibrary = json.optJSONArray("enemyLibrary").toObjectList(::preparedEnemyFromJson),
        preparedEncounters = json.optJSONArray("preparedEncounters").toObjectList(::preparedEncounterFromJson),
    )

    private fun preparedEnemyToJson(enemy: PreparedEnemy) = JSONObject().apply {
        put("id", enemy.id)
        put("name", enemy.name)
        put("level", enemy.level ?: JSONObject.NULL)
        put("maxHp", enemy.maxHp)
        put("initiativeModifier", enemy.initiativeModifier)
        put("gmNotes", enemy.gmNotes)
        put("publicNotes", enemy.publicNotes)
        put("quantity", enemy.quantity)
    }

    private fun preparedEnemyFromJson(json: JSONObject) = PreparedEnemy(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Enemy"),
        level = json.optNullableInt("level"),
        maxHp = json.optInt("maxHp", 10).coerceAtLeast(1),
        initiativeModifier = json.optInt("initiativeModifier", 0),
        gmNotes = json.optString("gmNotes"),
        publicNotes = json.optString("publicNotes"),
        quantity = json.optInt("quantity", 1).coerceAtLeast(1),
    )

    private fun preparedEncounterToJson(encounter: PreparedEncounter) = JSONObject().apply {
        put("id", encounter.id)
        put("name", encounter.name)
        put("gmNotes", encounter.gmNotes)
        put("startingNotes", encounter.startingNotes)
        put("enemies", JSONArray().apply { encounter.enemies.forEach { put(preparedEnemyToJson(it)) } })
    }

    private fun preparedEncounterFromJson(json: JSONObject) = PreparedEncounter(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Prepared Encounter"),
        gmNotes = json.optString("gmNotes"),
        startingNotes = json.optString("startingNotes"),
        enemies = json.optJSONArray("enemies").toObjectList(::preparedEnemyFromJson),
    )

    private fun pcToJson(pc: PlayerCharacter) = JSONObject().apply {
        put("id", pc.id)
        put("name", pc.name)
        put("ancestry", pc.ancestry)
        put("characterClass", pc.characterClass)
        put("level", pc.level ?: JSONObject.NULL)
        put("hp", pc.hp)
        put("maxHp", pc.maxHp)
        put("tempHp", pc.tempHp)
        put("heroPoints", pc.heroPoints)
        put("ready", pc.ready)
        put("publicNote", pc.publicNote)
        put("gmNote", pc.gmNote)
        put("conditions", JSONArray().apply { pc.conditions.forEach { put(conditionToJson(it)) } })
    }

    private fun pcFromJson(json: JSONObject) = PlayerCharacter(
        id = json.getString("id"),
        name = json.getString("name"),
        ancestry = json.optString("ancestry"),
        characterClass = json.optString("characterClass"),
        level = json.optNullableInt("level"),
        hp = json.optInt("hp", 10),
        maxHp = json.optInt("maxHp", 10).coerceAtLeast(1),
        tempHp = json.optInt("tempHp", 0).coerceAtLeast(0),
        heroPoints = json.optInt("heroPoints", 1),
        ready = json.optBoolean("ready", false),
        conditions = json.optJSONArray("conditions").toObjectList(::conditionFromJson),
        publicNote = json.optString("publicNote"),
        gmNote = json.optString("gmNote"),
    )

    private fun conditionToJson(condition: Condition) = JSONObject().apply {
        put("name", condition.name)
        put("value", condition.value ?: JSONObject.NULL)
        put("publicToPlayers", condition.publicToPlayers)
        put("partyInflicted", condition.partyInflicted)
        put("id", condition.id)
        put("sourceCombatantId", condition.sourceCombatantId ?: JSONObject.NULL)
        put("timingAnchor", condition.timingAnchor)
        put("timingPhase", condition.timingPhase)
        put("remainingTriggers", condition.remainingTriggers ?: JSONObject.NULL)
        put("triggerAction", condition.triggerAction)
        put("checkType", condition.checkType ?: JSONObject.NULL)
        put("checkLabel", condition.checkLabel)
        put("checkDc", condition.checkDc ?: JSONObject.NULL)
        put("checkSuccessAction", condition.checkSuccessAction)
        put("checkFailureAction", condition.checkFailureAction)
        put("checkCriticalSuccessAction", condition.checkCriticalSuccessAction)
        put("checkCriticalFailureAction", condition.checkCriticalFailureAction)
        put("repeatCheck", condition.repeatCheck)
    }

    private fun conditionFromJson(json: JSONObject) = Condition(
        name = json.optString("name"),
        value = json.optNullableInt("value"),
        publicToPlayers = json.optBoolean("publicToPlayers", true),
        partyInflicted = json.optBoolean("partyInflicted", false),
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        sourceCombatantId = json.optNullableString("sourceCombatantId"),
        timingAnchor = json.optString("timingAnchor", "TARGET"),
        timingPhase = json.optString("timingPhase", "MANUAL"),
        remainingTriggers = json.optNullableInt("remainingTriggers"),
        triggerAction = json.optString("triggerAction", "NONE"),
        checkType = json.optNullableString("checkType"),
        checkLabel = json.optString("checkLabel"),
        checkDc = json.optNullableInt("checkDc"),
        checkSuccessAction = json.optString("checkSuccessAction", "REMOVE"),
        checkFailureAction = json.optString("checkFailureAction", "KEEP"),
        checkCriticalSuccessAction = json.optString("checkCriticalSuccessAction", "REMOVE"),
        checkCriticalFailureAction = json.optString("checkCriticalFailureAction", "KEEP"),
        repeatCheck = json.optBoolean("repeatCheck", true),
    )

    private fun effectCheckToJson(prompt: EffectCheckPrompt) = JSONObject().apply {
        put("id", prompt.id)
        put("effectId", prompt.effectId)
        put("targetCombatantId", prompt.targetCombatantId)
        put("targetName", prompt.targetName)
        put("effectName", prompt.effectName)
        put("checkType", prompt.checkType)
        put("checkLabel", prompt.checkLabel)
        put("dc", prompt.dc ?: JSONObject.NULL)
        put("timingText", prompt.timingText)
        put("successAction", prompt.successAction)
        put("failureAction", prompt.failureAction)
        put("criticalSuccessAction", prompt.criticalSuccessAction)
        put("criticalFailureAction", prompt.criticalFailureAction)
        put("repeatCheck", prompt.repeatCheck)
    }

    private fun effectCheckFromJson(json: JSONObject) = EffectCheckPrompt(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        effectId = json.optString("effectId"),
        targetCombatantId = json.optString("targetCombatantId"),
        targetName = json.optString("targetName"),
        effectName = json.optString("effectName"),
        checkType = json.optString("checkType", "Custom roll"),
        checkLabel = json.optString("checkLabel"),
        dc = json.optNullableInt("dc"),
        timingText = json.optString("timingText"),
        successAction = json.optString("successAction", "REMOVE"),
        failureAction = json.optString("failureAction", "KEEP"),
        criticalSuccessAction = json.optString("criticalSuccessAction", "REMOVE"),
        criticalFailureAction = json.optString("criticalFailureAction", "KEEP"),
        repeatCheck = json.optBoolean("repeatCheck", true),
    )

    private fun combatantToJson(combatant: Combatant) = JSONObject().apply {
        put("id", combatant.id)
        put("name", combatant.name)
        put("kind", combatant.kind)
        put("pcId", combatant.pcId ?: JSONObject.NULL)
        put("level", combatant.level ?: JSONObject.NULL)
        put("initiative", combatant.initiative ?: JSONObject.NULL)
        put("initiativeModifier", combatant.initiativeModifier)
        put("initiativeSource", combatant.initiativeSource ?: JSONObject.NULL)
        put("hp", combatant.hp)
        put("maxHp", combatant.maxHp)
        put("tempHp", combatant.tempHp)
        put("conditions", JSONArray().apply { combatant.conditions.forEach { put(conditionToJson(it)) } })
        put("gmNote", combatant.gmNote)
        put("publicNote", combatant.publicNote)
        put("groupKey", combatant.groupKey ?: JSONObject.NULL)
        put("defeated", combatant.defeated)
        put("delayed", combatant.delayed)
        put("readyAction", combatant.readyAction)
        put("readyTrigger", combatant.readyTrigger)
    }

    private fun combatantFromJson(json: JSONObject) = Combatant(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Combatant"),
        kind = json.optString("kind", "enemy"),
        pcId = json.optNullableString("pcId"),
        level = json.optNullableInt("level"),
        initiative = json.optNullableInt("initiative"),
        initiativeModifier = json.optInt("initiativeModifier", 0),
        initiativeSource = json.optNullableString("initiativeSource"),
        hp = json.optInt("hp", 10),
        maxHp = json.optInt("maxHp", 10).coerceAtLeast(1),
        tempHp = json.optInt("tempHp", 0).coerceAtLeast(0),
        conditions = json.optJSONArray("conditions").toObjectList(::conditionFromJson),
        gmNote = json.optString("gmNote"),
        publicNote = json.optString("publicNote"),
        groupKey = json.optNullableString("groupKey"),
        defeated = json.optBoolean("defeated", false),
        delayed = json.optBoolean("delayed", false),
        readyAction = json.optString("readyAction"),
        readyTrigger = json.optString("readyTrigger"),
    )

    private fun logToJson(entry: CombatLogEntry) = JSONObject().apply {
        put("id", entry.id)
        put("timestamp", entry.timestamp)
        put("label", entry.label)
    }

    private fun logFromJson(json: JSONObject) = CombatLogEntry(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        timestamp = json.optLong("timestamp", System.currentTimeMillis()),
        label = json.optString("label"),
    )

    private fun lootItemToJson(item: LootItem) = JSONObject().apply {
        put("id", item.id)
        put("name", item.name)
        put("category", item.category)
        put("quantity", item.quantity)
        put("valueGp", item.valueGp)
        put("notes", item.notes)
        put("assignedToPcId", item.assignedToPcId ?: JSONObject.NULL)
    }

    private fun lootItemFromJson(json: JSONObject) = LootItem(
        id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
        name = json.optString("name", "Treasure"),
        category = json.optString("category", "Treasure"),
        quantity = json.optInt("quantity", 1).coerceAtLeast(1),
        valueGp = json.optDouble("valueGp", 0.0),
        notes = json.optString("notes"),
        assignedToPcId = json.optNullableString("assignedToPcId"),
    )

    private fun encounterToJson(encounter: EncounterState) = JSONObject().apply {
        put("id", encounter.id)
        put("name", encounter.name)
        put("gmNotes", encounter.gmNotes)
        put("startingNotes", encounter.startingNotes)
        put("active", encounter.active)
        put("ended", encounter.ended)
        put("round", encounter.round)
        put("turnIndex", encounter.turnIndex)
        put("combatants", JSONArray().apply { encounter.combatants.forEach { put(combatantToJson(it)) } })
        put("endTurnRequests", JSONArray().apply { encounter.endTurnRequests.forEach { put(it) } })
        put("pendingEffectChecks", JSONArray().apply { encounter.pendingEffectChecks.forEach { put(effectCheckToJson(it)) } })
        put("pendingTurnAdvance", encounter.pendingTurnAdvance)
        put("history", JSONArray().apply { encounter.history.forEach { put(logToJson(it)) } })
        put("loot", JSONObject().apply {
            put("generatedAt", encounter.loot.generatedAt ?: JSONObject.NULL)
            put("revealed", encounter.loot.revealed)
            put("movedToParty", encounter.loot.movedToParty)
            put("coinsGp", encounter.loot.coinsGp)
            put("items", JSONArray().apply { encounter.loot.items.forEach { put(lootItemToJson(it)) } })
        })
    }

    private fun encounterFromJson(json: JSONObject): EncounterState {
        val lootJson = json.optJSONObject("loot") ?: JSONObject()
        return EncounterState(
            id = json.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
            name = json.optString("name", "Encounter"),
            gmNotes = json.optString("gmNotes"),
            startingNotes = json.optString("startingNotes"),
            active = json.optBoolean("active", true),
            ended = json.optBoolean("ended", false),
            round = json.optInt("round", 1).coerceAtLeast(1),
            turnIndex = json.optInt("turnIndex", 0).coerceAtLeast(0),
            combatants = json.optJSONArray("combatants").toObjectList(::combatantFromJson),
            endTurnRequests = json.optJSONArray("endTurnRequests").toStringList(),
            pendingEffectChecks = json.optJSONArray("pendingEffectChecks").toObjectList(::effectCheckFromJson),
            pendingTurnAdvance = json.optBoolean("pendingTurnAdvance", false),
            history = json.optJSONArray("history").toObjectList(::logFromJson),
            loot = EncounterLoot(
                generatedAt = lootJson.optNullableLong("generatedAt"),
                revealed = lootJson.optBoolean("revealed", false),
                movedToParty = lootJson.optBoolean("movedToParty", false),
                coinsGp = lootJson.optDouble("coinsGp", 0.0),
                items = lootJson.optJSONArray("items").toObjectList(::lootItemFromJson),
            ),
        )
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

    private fun JSONObject.optNullableInt(key: String): Int? =
        if (!has(key) || isNull(key)) null else optInt(key)

    private fun JSONObject.optNullableLong(key: String): Long? =
        if (!has(key) || isNull(key)) null else optLong(key)

    private fun <T> JSONArray?.toObjectList(transform: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) {
                optJSONObject(i)?.let { add(transform(it)) }
            }
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) optString(i).takeIf { it.isNotBlank() }?.let(::add)
        }
    }
}
