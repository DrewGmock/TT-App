package com.drew.tthelper.server

import com.drew.tthelper.state.SessionStore
import io.ktor.server.websocket.DefaultWebSocketServerSession
import io.ktor.websocket.Frame
import java.util.concurrent.ConcurrentHashMap

class WebSocketHub(
    private val store: SessionStore,
    private val registry: PlayerRegistry,
) {
    private val sessions = ConcurrentHashMap<String, DefaultWebSocketServerSession>()

    fun add(token: String, session: DefaultWebSocketServerSession) {
        sessions[token] = session
        registry.setConnected(token, true)
    }

    fun remove(token: String) {
        sessions.remove(token)
        registry.setConnected(token, false)
    }

    suspend fun broadcastSnapshots() {
        sessions.entries.toList().forEach { (token, session) ->
            val client = registry.resolve(token)
            if (client == null) {
                sessions.remove(token)
            } else {
                runCatching { session.send(Frame.Text(store.playerSnapshotJson(client.pcId))) }
                    .onFailure { remove(token) }
            }
        }
    }
}
