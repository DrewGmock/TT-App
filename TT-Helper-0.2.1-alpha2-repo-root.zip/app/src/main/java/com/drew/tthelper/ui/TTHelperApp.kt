package com.drew.tthelper.ui

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EffectCheckType
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.server.HostRuntime
import kotlinx.coroutines.delay
import kotlin.random.Random

private enum class AppPage(val label: String) { LIVE("Live"), PREP("Session Prep"), CONNECTIONS("Players") }

@Composable
fun TTHelperApp(runtime: HostRuntime) {
    val context = LocalContext.current
    val status by runtime.status.collectAsState()
    val state by runtime.store.state.collectAsState()
    var page by remember { mutableStateOf(AppPage.LIVE) }
    var alertSoundEnabled by rememberSaveable { mutableStateOf(true) }

    val encounter = state.encounter
    val playerRequestCount = encounter?.endTurnRequests?.size ?: 0
    val checkCount = encounter?.pendingEffectChecks?.size ?: 0
    val attentionCount = playerRequestCount + checkCount

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val tablet = maxWidth >= 760.dp
        Scaffold(
            bottomBar = {
                if (!tablet) {
                    NavigationBar {
                        AppPage.entries.forEach { item ->
                            NavigationBarItem(
                                selected = page == item,
                                onClick = { page = item },
                                icon = { Text(if (item == AppPage.LIVE && attentionCount > 0) "!" else item.label.take(1)) },
                                label = { Text(navLabel(item, playerRequestCount, attentionCount)) },
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Row(Modifier.fillMaxSize().padding(padding)) {
                if (tablet) {
                    NavigationRail {
                        Text("TT", fontSize = 22.sp, modifier = Modifier.padding(12.dp))
                        AppPage.entries.forEach { item ->
                            NavigationRailItem(
                                selected = page == item,
                                onClick = { page = item },
                                icon = { Text(if (item == AppPage.LIVE && attentionCount > 0) "!" else item.label.take(1)) },
                                label = { Text(navLabel(item, playerRequestCount, attentionCount)) },
                            )
                        }
                    }
                }
                Column(Modifier.fillMaxSize()) {
                    HostBar(
                        running = status.running,
                        address = status.address,
                        port = status.port,
                        onStart = { runtime.requestStart(context) },
                        onStop = { runtime.requestStop(context) },
                        onUndo = { runtime.store.undo() },
                    )
                    GlobalAttentionBanner(
                        runtime = runtime,
                        state = state,
                        soundEnabled = alertSoundEnabled,
                        onToggleSound = { alertSoundEnabled = !alertSoundEnabled },
                    )
                    Box(Modifier.fillMaxSize()) {
                        when (page) {
                            AppPage.LIVE -> LiveSessionScreen(runtime, tablet)
                            AppPage.PREP -> SessionPrepScreen(runtime)
                            AppPage.CONNECTIONS -> ConnectionsScreen(runtime)
                        }
                    }
                }
            }
        }
    }
}

private fun navLabel(page: AppPage, playerRequests: Int, attentionCount: Int): String = when (page) {
    AppPage.CONNECTIONS -> if (playerRequests > 0) "Players ($playerRequests)" else page.label
    AppPage.LIVE -> if (attentionCount > 0) "Live ($attentionCount)" else page.label
    else -> page.label
}

@Composable
private fun GlobalAttentionBanner(
    runtime: HostRuntime,
    state: SessionState,
    soundEnabled: Boolean,
    onToggleSound: () -> Unit,
) {
    val encounter = state.encounter ?: return
    val check = encounter.pendingEffectChecks.firstOrNull()
    val requestPcId = encounter.endTurnRequests.firstOrNull()
    if (check == null && requestPcId == null) return

    val context = LocalContext.current
    val alertKey = check?.let { "check:${it.id}" } ?: "request:$requestPcId"
    LaunchedEffect(alertKey, soundEnabled) {
        runCatching {
            val vibrator = context.getSystemService(Vibrator::class.java)
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 140, 80, 180), -1))
        }
        if (soundEnabled) {
            runCatching {
                val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 220)
                delay(280)
                tone.release()
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val total = encounter.pendingEffectChecks.size + encounter.endTurnRequests.size
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (total > 1) "GM ATTENTION • $total alerts" else "GM ATTENTION", fontSize = 18.sp)
                TextButton(onClick = onToggleSound) { Text(if (soundEnabled) "Sound on" else "Sound off") }
            }

            if (check != null) {
                EffectCheckAlert(runtime, check)
            } else if (requestPcId != null) {
                val pcName = state.pcs.firstOrNull { it.id == requestPcId }?.name ?: "Player"
                Text("END TURN REQUEST", fontSize = 16.sp)
                Text("$pcName is finished and wants to advance the turn.")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { runtime.store.approveEndTurnRequest(requestPcId) }) { Text("Advance Turn") }
                    OutlinedButton(onClick = { runtime.store.dismissEndTurnRequest(requestPcId) }) { Text("Dismiss") }
                }
            }
        }
    }
}

@Composable
private fun EffectCheckAlert(runtime: HostRuntime, check: EffectCheckPrompt) {
    Text("CHECK REQUIRED", fontSize = 16.sp)
    Text("${check.targetName} • ${check.effectName}")
    val dcText = check.dc?.let { " vs DC $it" }.orEmpty()
    Text("${check.checkType}$dcText${if (check.timingText.isNotBlank()) " • ${check.timingText}" else ""}")
    if (check.checkLabel.isNotBlank()) Text(check.checkLabel)

    FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if ((check.checkType == EffectCheckType.FLAT || check.checkType == EffectCheckType.RECOVERY) && check.dc != null) {
            Button(onClick = {
                val die = Random.nextInt(1, 21)
                runtime.store.resolveEffectCheck(check.id, degreeFromRoll(die, check.dc))
            }) { Text("Roll d20") }
        }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "criticalSuccess") }) { Text("Crit Success") }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "success") }) { Text("Success") }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "failure") }) { Text("Failure") }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "criticalFailure") }) { Text("Crit Failure") }
        TextButton(onClick = { runtime.store.dismissEffectCheck(check.id) }) { Text("Skip") }
    }
}

private fun degreeFromRoll(die: Int, dc: Int): String {
    var degree = when {
        die >= dc + 10 -> 3
        die >= dc -> 2
        die <= dc - 10 -> 0
        else -> 1
    }
    if (die == 20) degree = (degree + 1).coerceAtMost(3)
    if (die == 1) degree = (degree - 1).coerceAtLeast(0)
    return when (degree) {
        3 -> "criticalSuccess"
        2 -> "success"
        1 -> "failure"
        else -> "criticalFailure"
    }
}

@Composable
private fun HostBar(
    running: Boolean,
    address: String?,
    port: Int,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onUndo: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text("TT Helper", fontSize = 22.sp)
            Text(if (running) "Hosting • ${address ?: "finding IP"}:$port" else "Host offline")
        }
        TextButton(onClick = onUndo) { Text("Undo") }
        Button(onClick = if (running) onStop else onStart) { Text(if (running) "Stop host" else "Start host") }
    }
}
