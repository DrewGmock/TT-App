package com.drew.tthelper.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.drew.tthelper.MainActivity
import com.drew.tthelper.R
import com.drew.tthelper.TTApplication

class LocalServerService : Service() {
    private var hostServer: HostServer? = null
    private var nsdAdvertiser: NsdAdvertiser? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopHosting()
            else -> startHosting()
        }
        return START_STICKY
    }

    private fun startHosting() {
        if (hostServer != null) return
        startInForeground()
        val app = application as TTApplication
        val server = HostServer(this, app.runtime.store, app.runtime.registry)
        val advertiser = NsdAdvertiser(this)
        runCatching {
            server.start()
            advertiser.register(server.port)
            hostServer = server
            nsdAdvertiser = advertiser
            app.runtime.markRunning(server.port)
        }.onFailure { error ->
            server.close()
            advertiser.unregister()
            app.runtime.markStopped(error.message ?: "Unable to start host")
            stopSelf()
        }
    }

    private fun stopHosting() {
        nsdAdvertiser?.unregister()
        nsdAdvertiser = null
        hostServer?.close()
        hostServer = null
        (application as TTApplication).runtime.markStopped()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startInForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_tt)
            .setContentTitle("TT Helper is hosting")
            .setContentText("Players on your Wi-Fi can connect while hosting is on.")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Session hosting", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        nsdAdvertiser?.unregister()
        hostServer?.close()
        (application as TTApplication).runtime.markStopped()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.drew.tthelper.START_HOST"
        const val ACTION_STOP = "com.drew.tthelper.STOP_HOST"
        private const val CHANNEL_ID = "tt_helper_host"
        private const val NOTIFICATION_ID = 8787
    }
}
