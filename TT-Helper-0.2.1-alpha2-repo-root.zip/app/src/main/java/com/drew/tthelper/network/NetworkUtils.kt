package com.drew.tthelper.network

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {
    fun localIpv4Address(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { address ->
                val host = address.hostAddress.orEmpty()
                address.isSiteLocalAddress && !host.startsWith("169.254.")
            }
            ?.hostAddress
    }.getOrNull()
}
