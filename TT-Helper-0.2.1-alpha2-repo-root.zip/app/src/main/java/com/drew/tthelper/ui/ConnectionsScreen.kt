package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.qr.QrCodeImage
import com.drew.tthelper.server.HostRuntime

@Composable
fun ConnectionsScreen(runtime: HostRuntime) {
    val status by runtime.status.collectAsState()
    val clients by runtime.registry.clients.collectAsState()
    val pin by runtime.registry.pin.collectAsState()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 620.dp
        val joinUrl = if (status.running && status.address != null) {
            "http://${status.address}:${status.port}/?pin=$pin"
        } else null

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Player Connections", fontSize = 26.sp)
            if (!status.running || joinUrl == null) {
                Text("Start the host to create a join address and PIN.")
            } else if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    QrCodeImage(joinUrl, Modifier.size(210.dp))
                    JoinDetails(joinUrl, pin) { runtime.registry.rotatePin() }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    QrCodeImage(joinUrl, Modifier.size(220.dp))
                    JoinDetails(joinUrl, pin) { runtime.registry.rotatePin() }
                }
            }

            Text("Assignments", fontSize = 20.sp)
            if (clients.isEmpty()) Text("No characters assigned yet.")
            clients.forEach { client ->
                val pcName = runtime.store.state.value.pcs.firstOrNull { it.id == client.pcId }?.name ?: client.pcId
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("$pcName • ${client.displayName}")
                            Text(if (client.connected) "Connected" else "Assigned, offline")
                        }
                        Button(onClick = { runtime.registry.releasePc(client.pcId) }) { Text("Release") }
                    }
                }
            }
        }
    }
}

@Composable
private fun JoinDetails(joinUrl: String, pin: String, onRotatePin: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("PIN $pin", fontSize = 30.sp)
        Text(joinUrl)
        Text("Players can scan the QR code or type the address in Safari/Chrome while on the same Wi-Fi.")
        OutlinedButton(onClick = onRotatePin) { Text("Rotate PIN") }
    }
}
