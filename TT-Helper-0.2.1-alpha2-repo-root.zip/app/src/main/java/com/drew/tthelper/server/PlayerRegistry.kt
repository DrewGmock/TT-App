package com.drew.tthelper.server

import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlayerClient(
    val token: String,
    val displayName: String,
    val pcId: String,
    val joinedAt: Long = System.currentTimeMillis(),
    val connected: Boolean = false,
)

data class JoinResult(val client: PlayerClient? = null, val error: String? = null)

class PlayerRegistry {
    private val secureRandom = SecureRandom()
    private val clientsByToken = ConcurrentHashMap<String, PlayerClient>()
    private val _clients = MutableStateFlow<List<PlayerClient>>(emptyList())
    val clients: StateFlow<List<PlayerClient>> = _clients.asStateFlow()

    private val _pin = MutableStateFlow(newPin())
    val pin: StateFlow<String> = _pin.asStateFlow()

    fun rotatePin(): String {
        val next = newPin()
        _pin.value = next
        return next
    }

    @Synchronized
    fun join(displayName: String, requestedPcId: String, providedPin: String): JoinResult {
        if (providedPin != _pin.value) return JoinResult(error = "Wrong PIN")
        val claimed = clientsByToken.values.any { it.pcId == requestedPcId }
        if (claimed) return JoinResult(error = "That character is already assigned. Ask the GM to release it.")

        val token = UUID.randomUUID().toString().replace("-", "")
        val client = PlayerClient(
            token = token,
            displayName = displayName.trim().ifBlank { "Player" }.take(30),
            pcId = requestedPcId,
        )
        clientsByToken[token] = client
        publish()
        return JoinResult(client = client)
    }

    fun resolve(token: String?): PlayerClient? = token?.let(clientsByToken::get)

    @Synchronized
    fun setConnected(token: String, connected: Boolean) {
        val client = clientsByToken[token] ?: return
        clientsByToken[token] = client.copy(connected = connected)
        publish()
    }

    @Synchronized
    fun releasePc(pcId: String) {
        clientsByToken.entries.removeIf { it.value.pcId == pcId }
        publish()
    }

    @Synchronized
    fun clearAll() {
        clientsByToken.clear()
        publish()
    }

    private fun publish() {
        _clients.value = clientsByToken.values.sortedBy { it.joinedAt }
    }

    private fun newPin(): String = (100000 + secureRandom.nextInt(900000)).toString()
}
