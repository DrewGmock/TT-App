package com.drew.tthelper.qr

import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.Modifier
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

fun qrBitmap(contents: String, size: Int = 640): Bitmap {
    val matrix = QRCodeWriter().encode(contents, BarcodeFormat.QR_CODE, size, size)
    val pixels = IntArray(size * size)
    for (y in 0 until size) {
        val offset = y * size
        for (x in 0 until size) {
            pixels[offset + x] = if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE
        }
    }
    return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
        setPixels(pixels, 0, size, 0, 0, size, size)
    }
}

@Composable
fun QrCodeImage(contents: String, modifier: Modifier = Modifier) {
    val bitmap = remember(contents) { qrBitmap(contents) }
    Image(bitmap = bitmap.asImageBitmap(), contentDescription = "Player join QR code", modifier = modifier)
}
