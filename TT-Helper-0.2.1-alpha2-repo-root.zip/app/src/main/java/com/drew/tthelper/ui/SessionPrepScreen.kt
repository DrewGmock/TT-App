package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.server.HostRuntime

@Composable
fun SessionPrepScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var title by remember { mutableStateOf(state.prep.sessionTitle) }
    var opening by remember { mutableStateOf(state.prep.openingScene) }
    var encounterNotes by remember { mutableStateOf(state.prep.encounterNotes) }
    var notes by remember { mutableStateOf(state.prep.gmNotes) }
    var backupMessage by remember { mutableStateOf("") }

    LaunchedEffect(state.revision) {
        if (state.lastEventLabel?.startsWith("Backup restored") == true) {
            title = state.prep.sessionTitle
            opening = state.prep.openingScene
            encounterNotes = state.prep.encounterNotes
            notes = state.prep.gmNotes
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Session Prep", fontSize = 26.sp)
        Text("GM-only. Prep notes, enemy stats, and encounter templates are never included in player snapshots.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Session Notes", fontSize = 20.sp)
                OutlinedTextField(title, { title = it }, label = { Text("Session title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(opening, { opening = it }, label = { Text("Opening scene") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(encounterNotes, { encounterNotes = it }, label = { Text("Encounters / beats") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Private GM notes") }, minLines = 5, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    runtime.store.updatePrep(state.prep.copy(
                        sessionTitle = title,
                        openingScene = opening,
                        gmNotes = notes,
                        encounterNotes = encounterNotes,
                    ))
                }) { Text("Save notes") }
            }
        }

        EnemyLibraryEditor(runtime, state.prep.enemyLibrary)
        PreparedEncounterEditor(runtime, state.prep.enemyLibrary, state.prep.preparedEncounters)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backups", fontSize = 20.sp)
                Text("The live save is atomic. Manual snapshots include session prep, encounters, combat history, and party loot.")
                Button(onClick = {
                    val file = runtime.store.exportBackup()
                    backupMessage = "Saved ${file.name}"
                }) { Text("Create backup") }
                val latest = runtime.store.listBackups().firstOrNull()
                OutlinedButton(
                    enabled = latest != null,
                    onClick = {
                        if (latest != null) {
                            backupMessage = if (runtime.store.restoreBackup(latest)) "Restored ${latest.name}" else "Restore failed"
                        }
                    }
                ) { Text(if (latest == null) "No backup yet" else "Restore latest") }
                if (backupMessage.isNotBlank()) Text(backupMessage)
            }
        }
    }
}

@Composable
private fun EnemyLibraryEditor(runtime: HostRuntime, library: List<PreparedEnemy>) {
    var name by remember { mutableStateOf("") }
    var hp by remember { mutableStateOf("10") }
    var level by remember { mutableStateOf("") }
    var initMod by remember { mutableStateOf("0") }
    var gmNotes by remember { mutableStateOf("") }
    var publicNotes by remember { mutableStateOf("") }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Enemy Library", fontSize = 20.sp)
            Text("Reusable stat stubs for fast encounter setup. Full rules/stat-block integration comes later.")
            OutlinedTextField(name, { name = it.take(50) }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(hp, { hp = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Max HP") }, modifier = Modifier.weight(1f))
                OutlinedTextField(level, { level = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Level") }, modifier = Modifier.weight(1f))
                OutlinedTextField(initMod, { initMod = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Init mod") }, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(publicNotes, { publicNotes = it.take(160) }, label = { Text("Player-visible note (optional)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(gmNotes, { gmNotes = it.take(300) }, label = { Text("Private GM note") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                if (name.isNotBlank()) {
                    runtime.store.saveEnemyToLibrary(
                        PreparedEnemy(
                            name = name.trim(),
                            level = level.toIntOrNull(),
                            maxHp = hp.toIntOrNull()?.coerceAtLeast(1) ?: 10,
                            initiativeModifier = initMod.toIntOrNull() ?: 0,
                            gmNotes = gmNotes,
                            publicNotes = publicNotes,
                        )
                    )
                    name = ""
                    gmNotes = ""
                    publicNotes = ""
                }
            }) { Text("Save enemy") }

            if (library.isNotEmpty()) {
                HorizontalDivider()
                library.forEach { enemy ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(enemy.name)
                            Text("HP ${enemy.maxHp}${enemy.level?.let { " • Level $it" } ?: ""} • Init ${if (enemy.initiativeModifier >= 0) "+" else ""}${enemy.initiativeModifier}")
                        }
                        OutlinedButton(onClick = { runtime.store.deleteEnemyFromLibrary(enemy.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreparedEncounterEditor(
    runtime: HostRuntime,
    library: List<PreparedEnemy>,
    prepared: List<PreparedEncounter>,
) {
    var encounterName by remember { mutableStateOf("") }
    var startingNotes by remember { mutableStateOf("") }
    var gmNotes by remember { mutableStateOf("") }
    var draftEnemies by remember { mutableStateOf<List<PreparedEnemy>>(emptyList()) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Prepared Encounters", fontSize = 20.sp)
            OutlinedTextField(encounterName, { encounterName = it.take(60) }, label = { Text("Encounter name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(startingNotes, { startingNotes = it.take(300) }, label = { Text("Starting positions / order notes") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(gmNotes, { gmNotes = it.take(500) }, label = { Text("Private encounter notes") }, modifier = Modifier.fillMaxWidth())

            Text("Add from Enemy Library")
            if (library.isEmpty()) Text("Save an enemy above first, or use Quick Add during live combat.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                library.forEach { enemy ->
                    FilledTonalButton(onClick = {
                        val existing = draftEnemies.firstOrNull { it.id == enemy.id }
                        draftEnemies = if (existing == null) {
                            draftEnemies + enemy.copy(quantity = 1)
                        } else {
                            draftEnemies.map { if (it.id == enemy.id) it.copy(quantity = it.quantity + 1) else it }
                        }
                    }) { Text("+ ${enemy.name}") }
                }
            }

            if (draftEnemies.isNotEmpty()) {
                Text("Encounter roster")
                draftEnemies.forEach { enemy ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${enemy.name} ×${enemy.quantity}", modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = {
                            draftEnemies = draftEnemies.map { if (it.id == enemy.id) it.copy(quantity = it.quantity + 1) else it }
                        }) { Text("+") }
                        OutlinedButton(onClick = {
                            draftEnemies = if (enemy.quantity <= 1) draftEnemies.filterNot { it.id == enemy.id }
                            else draftEnemies.map { if (it.id == enemy.id) it.copy(quantity = it.quantity - 1) else it }
                        }) { Text("-") }
                        OutlinedButton(onClick = { draftEnemies = draftEnemies.filterNot { it.id == enemy.id } }) { Text("Remove") }
                    }
                }
            }

            Button(onClick = {
                if (encounterName.isNotBlank()) {
                    runtime.store.savePreparedEncounter(
                        PreparedEncounter(
                            name = encounterName.trim(),
                            startingNotes = startingNotes,
                            gmNotes = gmNotes,
                            enemies = draftEnemies,
                        )
                    )
                    encounterName = ""
                    startingNotes = ""
                    gmNotes = ""
                    draftEnemies = emptyList()
                }
            }) { Text("Save prepared encounter") }

            if (prepared.isNotEmpty()) {
                HorizontalDivider()
                prepared.forEach { encounter ->
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(encounter.name)
                                Text(if (encounter.enemies.isEmpty()) "No enemies" else encounter.enemies.joinToString(" • ") { "${it.name} ×${it.quantity}" })
                            }
                            OutlinedButton(onClick = { runtime.store.deletePreparedEncounter(encounter.id) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
