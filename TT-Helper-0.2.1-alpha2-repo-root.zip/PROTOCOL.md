# LAN protocol — alpha 0.2

## Join

`GET /api/public` returns campaign/scene and the joinable PC list. It never includes Session Prep, enemy GM notes, or hidden combat data.

`POST /api/join`

```json
{"pin":"123456","displayName":"Drew","pcId":"rufus"}
```

Returns an opaque token. A PC can only have one active assignment until the GM releases it.

## WebSocket

`GET /ws?token=<opaque-token>`

The host sends player-filtered snapshots. During combat the snapshot also includes a player-safe `encounter` object:

```json
{
  "type":"snapshot",
  "revision":42,
  "campaignName":"Cube-Borne",
  "sceneName":"Guild Hall",
  "you":{"id":"rufus","name":"Rufus","hp":18,"maxHp":28,"conditions":[]},
  "party":[],
  "encounter":{
    "name":"Goblin Ambush",
    "round":2,
    "currentName":"Rufus",
    "currentIsYou":true,
    "yourInitiative":19,
    "initiative":[],
    "enemies":[
      {"name":"Goblin Warrior 1","health":"Hurt","conditions":[{"name":"Prone"}]}
    ],
    "loot":null
  }
}
```

Enemy snapshots omit exact HP, max HP, level, initiative modifiers, hidden conditions, and GM notes. Conditions are included when they are obvious or explicitly marked as party-inflicted.

Player actions use unique request IDs:

```json
{"type":"action","requestId":"uuid","action":"hpDelta","payload":{"delta":-5}}
```

Supported player actions in 0.2:

- `hpDelta`
- `tempHpDelta`
- `toggleReady`
- `toggleCondition`
- `submitInitiative`
- `requestEndTurn`
- `recordRoll`

The server ignores any attempted target-PC field and applies character-changing actions only to the PC owned by the token.
