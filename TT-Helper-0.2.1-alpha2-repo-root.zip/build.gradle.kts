buildscript {
    dependencies {
        // AGP 9.x has built-in Kotlin support. Pin the compiler/tooling version used by Compose.
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.20")
        classpath("org.jetbrains.kotlin.plugin.compose:org.jetbrains.kotlin.plugin.compose.gradle.plugin:2.4.20")
    }
}

plugins {
    id("com.android.application") version "9.4.0" apply false
}
