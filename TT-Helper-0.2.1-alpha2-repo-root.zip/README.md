# TT Helper — LAN Alpha 0.2.1

TT Helper is a local-first Pathfinder 2e table helper. The Samsung/Android tablet is the authoritative GM host. Players use Safari/Chrome on phones or tablets; there is no cloud backend and no player app-store install.

## What 0.2.1 adds

- Compact searchable effect picker instead of an always-visible condition wall.
- Turn-aware effect engine with target/source anchors and start/end timing.
- Persistent check reminders for skill, save, flat, recovery, and custom rolls.
- Prominent GM attention banner with vibration, optional sound, and request controls.
- Clearer initiative status badges and blocked turn advancement until initiative/checks are ready.

- Live encounter workspace with round and current-turn tracking.
- Initiative from three paths: GM manual entry, player physical-roll submission, or digital rolls.
- Tie visibility plus GM-controlled initiative reordering.
- Duplicate enemies remain individually tracked for HP/conditions while sharing a group key and optional group initiative.
- Quick Add and Add from Enemy Library during a live fight.
- Session Prep enemy library and reusable prepared encounters.
- Delay handling, Ready action/trigger tracking, and player End Turn requests.
- Enemy HP/temp HP/conditions/defeated state plus GM-only notes.
- Player-safe encounter snapshots: enemy name, descriptive health, obvious conditions, and party-inflicted effects only.
- Hybrid PF2e automation: Frightened ticks down at end of turn; healing out of Dying adds Wounded; dropping to 0 in a live encounter adds Dying based on Wounded; persistent damage creates an end-turn reminder.
- Reversible combat history backed by the existing Undo snapshot system.
- Lightweight local loot generation when an encounter ends. Loot stays GM-only until **Reveal Loot**.
- Party Loot area with shared/PC assignment.
- Existing LAN ownership enforcement, reconnect caching, PIN pairing, backups, and hidden-GM-data boundary remain intact.

## Seeded party

Exact levels remain intentionally unset until the GM enters them.

- Captain Morrow Vain — Skeleton Swashbuckler
- Everleaf — Human Druid
- Rufus — Orc Barbarian
- Yorik — Vampire Wizard (Necromancer)

## Build baseline

The 0.2.1 cloud-build baseline intentionally stays on Android API 36:

- Android Gradle Plugin 9.4.0
- Kotlin / Compose compiler tooling 2.4.20
- Compose BOM 2026.04.01
- AndroidX Activity Compose 1.11.0
- AndroidX Core KTX 1.17.0
- Ktor 3.6.0
- ZXing 3.5.4
- Gradle 9.6.0
- JDK 17
- `compileSdk = 36`
- `targetSdk = 36`

This matches the build path that got the 0.1 LAN alpha compiling on GitHub Actions without requiring Android Studio on the tablet.

## Build the APK with GitHub Actions

The repository includes `.github/workflows/build-apk.yml`.

1. Upload/replace the project files in the GitHub repository root.
2. Open **Actions → Build TT Helper APK**.
3. Run the workflow on `main` (a push to `main` also starts it automatically).
4. When the run is green, download the **TT-Helper-debug-apk** artifact.
5. Extract it and install `app-debug.apk` on the GM tablet.

## First encounter flow

1. Start the tablet host and connect player browsers as usual.
2. In **Session Prep**, save reusable enemies and optional prepared encounters.
3. In **Live**, start a quick encounter or one of the prepared encounters.
4. Enter initiative manually, let players submit their physical rolls, or use digital rolls.
5. Use **Next Turn**, **Previous**, **Delay**, Ready tracking, conditions, HP controls, and Undo during combat.
6. End the encounter. TT Helper creates a small GM-only loot draft locally.
7. Edit/reroll/remove/add loot, then tap **Reveal Loot** when the party actually finds it.
8. Move accepted loot into **Party Loot**, then close the encounter.

## Deliberate 0.2.1 limits

- Generated loot is a lightweight editable draft, not strict treasure-by-level enforcement yet.
- Enemy Library entries are fast stat stubs (name, level, HP, initiative modifier, notes), not full PF2e stat blocks yet.
- Automatic condition handling is intentionally conservative and GM-overridable.
- Ready stores the action and trigger; the GM resolves the reaction timing.
- Delay moves the combatant out of its slot and provides a Resume control; the GM can reorder precisely with the initiative arrows.
- No cloud accounts/sync and no app-store dependency.
- LAN HTTP is intended for a trusted private network.
