# TT Helper 1.0 RC1 — Test Checklist

Use this once before calling the build 1.0 stable.

## Install / upgrade
- Install over 0.9 without uninstalling.
- Verify version is `1.0.0-rc1`.
- Confirm the Quick Start appears once and stays dismissed after restart.

## Campaign safety
- Run Settings → Campaign Ready → Run readiness check.
- Create a safety backup.
- Restart the app and confirm campaign state remains intact.
- Export a full campaign backup and restore it only after confirming the export exists.
- Confirm rotating backups are listed and readable.

## LAN / player recovery
- Start host and connect at least one player.
- Assign a PC, refresh the browser, and confirm reassignment/reconnect works.
- Briefly disable/re-enable Wi-Fi and confirm player reconnects.
- Stop/start the host and confirm the campaign state remains intact.

## Combat
- Start a prepared encounter.
- Cycle initiative through a full round.
- Test actions, reaction, MAP, effects, rules requests, and Undo.
- End encounter and verify History + loot flow.

## Content workflows
- Submit/approve/decline a player spell or ability; declined content must return to Drafts.
- Import a `.ttsession`, `.ttenemy`, or `.ttloot` package using preview first.
- Export content and confirm the file can be re-imported.

## UI
- Test sidebar scrolling/collapse.
- Test pinned prep.
- Test light/dark theme, accent color, font size, density, and high contrast.
- Open `/display` on a second screen and confirm no GM-only data appears.
