# TT Helper Protocol — 1.0 RC1

The GM Android tablet is authoritative. Player browser clients connect over the local network, receive player-safe state, and submit actions/requests that are validated by the host.

## Campaign safety

- The host persists shared campaign state locally.
- Meaningful changes trigger persistence/backups according to the SessionStore safety policy.
- Full campaign restore validates before replacing live state and creates a safety backup first.
- Import packages are previewed/validated before merge/replace/copy operations.
- Player tokens and assignments survive process restarts where safe.
- UI appearance/onboarding preferences are device-local and not part of campaign exports.

## 1.0 RC1

This release candidate adds Quick Start onboarding, Campaign Ready checks, About/version information, and visible host-error guidance without changing the established LAN authority model.
