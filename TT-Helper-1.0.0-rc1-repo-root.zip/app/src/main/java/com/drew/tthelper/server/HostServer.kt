package com.drew.tthelper.server

import android.content.Context
import com.drew.tthelper.state.SessionStore
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.Application
import io.ktor.server.application.call
import io.ktor.server.application.install
import io.ktor.server.cio.CIO
import io.ktor.server.engine.EmbeddedServer
import io.ktor.server.engine.embeddedServer
import io.ktor.server.request.receiveText
import io.ktor.server.response.respondBytes
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import io.ktor.server.websocket.WebSockets
import io.ktor.server.websocket.webSocket
import io.ktor.server.websocket.pingPeriod
import io.ktor.server.websocket.timeout
import io.ktor.websocket.CloseReason
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readText
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import org.json.JSONObject

class HostServer(
    private val context: Context,
    private val store: SessionStore,
    private val registry: PlayerRegistry,
    val port: Int = 8787,
) {
    private var server: EmbeddedServer<*, *>? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var broadcastJob: Job? = null
    private val hub = WebSocketHub(store, registry)

    fun start() {
        if (server != null) return
        registry.rotatePin()
        val instance = embeddedServer(CIO, host = "0.0.0.0", port = port) {
            module(context, store, registry, hub)
        }
        server = instance
        instance.start(wait = false)
        broadcastJob = scope.launch {
            store.state.drop(1).collect { hub.broadcastSnapshots() }
        }
    }

    fun stop() {
        broadcastJob?.cancel()
        broadcastJob = null
        server?.stop(500, 1_500)
        server = null
    }

    fun close() {
        stop()
        scope.cancel()
    }
}

private fun Application.module(
    context: Context,
    store: SessionStore,
    registry: PlayerRegistry,
    hub: WebSocketHub,
) {
    install(WebSockets) {
        pingPeriod = 20.seconds
        timeout = 45.seconds
        maxFrameSize = 64 * 1024
        masking = false
    }

    routing {
        get("/") { call.respondAsset(context, "player/index.html", ContentType.Text.Html) }
        get("/player.css") { call.respondAsset(context, "player/player.css", ContentType.Text.CSS) }
        get("/player.js") { call.respondAsset(context, "player/player.js", ContentType.Application.JavaScript) }
        get("/display") { call.respondAsset(context, "display/index.html", ContentType.Text.Html) }
        get("/display.css") { call.respondAsset(context, "display/display.css", ContentType.Text.CSS) }
        get("/display.js") { call.respondAsset(context, "display/display.js", ContentType.Application.JavaScript) }

        get("/api/public") {
            call.respondText(store.publicLobbyJson(), ContentType.Application.Json)
        }

        get("/api/display") {
            call.respondText(store.displaySnapshotJson(), ContentType.Application.Json)
        }

        post("/api/request-character") {
            val body = runCatching { JSONObject(call.receiveText()) }.getOrNull()
            if (body == null) {
                call.respondText(errorJson("Invalid request"), ContentType.Application.Json, HttpStatusCode.BadRequest)
                return@post
            }
            if (body.optString("pin") != registry.pin.value) {
                call.respondText(errorJson("Wrong PIN"), ContentType.Application.Json, HttpStatusCode.Unauthorized)
                return@post
            }
            val ok = store.requestCharacterCreation(
                playerName = body.optString("displayName"),
                characterName = body.optString("characterName"),
                ancestry = body.optString("ancestry"),
                heritage = body.optString("heritage"),
                background = body.optString("background"),
                characterClass = body.optString("characterClass"),
                level = body.optInt("level", -1).takeIf { it >= 0 },
                notes = body.optString("notes"),
            )
            if (!ok) {
                call.respondText(errorJson("Character name is required"), ContentType.Application.Json, HttpStatusCode.BadRequest)
            } else {
                call.respondText(JSONObject().apply { put("ok", true) }.toString(), ContentType.Application.Json)
            }
        }

        post("/api/join") {
            val body = runCatching { JSONObject(call.receiveText()) }.getOrNull()
            if (body == null) {
                call.respondText(errorJson("Invalid request"), ContentType.Application.Json, HttpStatusCode.BadRequest)
                return@post
            }
            val pcId = body.optString("pcId")
            if (store.state.value.pcs.none { it.id == pcId }) {
                call.respondText(errorJson("Unknown character"), ContentType.Application.Json, HttpStatusCode.BadRequest)
                return@post
            }
            val result = registry.join(
                displayName = body.optString("displayName"),
                requestedPcId = pcId,
                providedPin = body.optString("pin"),
            )
            if (result.client == null) {
                call.respondText(errorJson(result.error ?: "Unable to join"), ContentType.Application.Json, HttpStatusCode.Conflict)
            } else {
                call.respondText(JSONObject().apply {
                    put("ok", true)
                    put("token", result.client.token)
                    put("pcId", result.client.pcId)
                }.toString(), ContentType.Application.Json)
            }
        }

        get("/api/resume") {
            val token = call.request.queryParameters["token"]
            val client = registry.resolve(token)
            if (client == null) {
                call.respondText(errorJson("Session not found"), ContentType.Application.Json, HttpStatusCode.Unauthorized)
            } else {
                call.respondText(JSONObject().apply {
                    put("ok", true)
                    put("pcId", client.pcId)
                    put("displayName", client.displayName)
                }.toString(), ContentType.Application.Json)
            }
        }

        webSocket("/ws") {
            val token = call.request.queryParameters["token"]
            val client = registry.resolve(token)
            if (token == null || client == null) {
                close(CloseReason(CloseReason.Codes.VIOLATED_POLICY, "Invalid player token"))
                return@webSocket
            }

            hub.add(token, this)
            registry.setConnected(token, true)
            try {
                send(Frame.Text(store.playerSnapshotJson(client.pcId)))
                for (frame in incoming) {
                    if (frame !is Frame.Text) continue
                    val message = runCatching { JSONObject(frame.readText()) }.getOrNull() ?: continue
                    if (message.optString("type") != "action") continue
                    val requestId = message.optString("requestId")
                    val action = message.optString("action")
                    val payload = message.optJSONObject("payload") ?: JSONObject()
                    val accepted = store.applyPlayerRequest(requestId) {
                        when (action) {
                            "hpDelta" -> store.hpDelta(client.pcId, payload.optInt("delta", 0), "${client.displayName}: HP")
                            "tempHpDelta" -> store.tempHpDelta(client.pcId, payload.optInt("delta", 0))
                            "toggleReady" -> store.toggleReady(client.pcId)
                            "toggleCondition" -> {
                                val name = payload.optString("name").trim().take(40)
                                if (name.isNotBlank()) store.toggleCondition(client.pcId, name)
                            }
                            "submitInitiative" -> {
                                val value = payload.optInt("value", Int.MIN_VALUE)
                                if (value != Int.MIN_VALUE) {
                                    store.submitPlayerInitiative(
                                        client.pcId,
                                        value.coerceIn(-20, 100),
                                        payload.optString("source", "Player submission").take(30),
                                    )
                                }
                            }
                            "requestEndTurn" -> store.requestEndTurn(client.pcId)
                            "spendActions" -> store.spendActions(client.pcId, payload.optInt("count", 1))
                            "refundAction" -> store.refundAction(client.pcId, payload.optInt("count", 1))
                            "useReaction" -> store.useReaction(client.pcId)
                            "restoreReaction" -> store.restoreReaction(client.pcId)
                            "castSpell" -> store.castSpell(client.pcId, payload.optString("spellId"))
                            "refocus" -> store.refocus(client.pcId)
                            "saveContentDraft" -> store.saveContentDraft(client.pcId, payload)
                            "submitContentDraft" -> store.submitContentDraft(client.pcId, payload.optString("draftId"))
                            "deleteContentDraft" -> store.deleteContentDraft(client.pcId, payload.optString("draftId"))
                            "togglePinned" -> store.togglePinned(client.pcId, payload.optString("kind"), payload.optString("entryId"))
                            "useAbility" -> store.useAbility(client.pcId, payload.optString("abilityId"))
                            "useStrike" -> {
                                val d20 = payload.optInt("d20", Int.MIN_VALUE).takeIf { it != Int.MIN_VALUE }
                                store.useStrike(client.pcId, payload.optString("strikeId"), d20)
                            }
                            "adjustResource" -> store.adjustResource(client.pcId, payload.optString("resourceId"), payload.optInt("delta", 0))
                            "heroDelta" -> {
                                val current = store.state.value.pcs.firstOrNull { it.id == client.pcId }?.heroPoints ?: 0
                                store.setHeroPoints(client.pcId, current + payload.optInt("delta", 0))
                            }
                            "commonAction" -> store.performCommonAction(client.pcId, payload.optString("label"), payload.optInt("actions", 1))
                            "setTarget" -> store.setTarget(client.pcId, payload.optString("combatantId").takeIf { it.isNotBlank() })
                            "rollRuleRequest" -> store.rollRuleRequest(payload.optString("requestId"), client.pcId)
                            "saveCharacterSheet" -> store.saveCharacterSheet(client.pcId, payload)
                            "inventoryUse" -> store.useInventoryItem(payload.optString("itemId"), client.pcId)
                            "inventoryCarryState" -> store.setInventoryCarryState(payload.optString("itemId"), client.pcId, payload.optString("carryState", "Stowed"))
                            "inventoryContainer" -> store.setInventoryContainer(payload.optString("itemId"), client.pcId, payload.optString("containerId").takeIf { it.isNotBlank() })
                            "recordRoll" -> {
                                val result = payload.optInt("result", Int.MIN_VALUE)
                                if (result != Int.MIN_VALUE) {
                                    store.recordPlayerRoll(
                                        client.pcId,
                                        payload.optString("label", "d20").take(30),
                                        result.coerceIn(-999, 999),
                                    )
                                }
                            }
                        }
                    }
                    send(Frame.Text(JSONObject().apply {
                        put("type", "ack")
                        put("requestId", requestId)
                        put("accepted", accepted)
                    }.toString()))
                }
            } finally {
                hub.remove(token)
                registry.setConnected(token, false)
            }
        }
    }
}

private suspend fun io.ktor.server.application.ApplicationCall.respondAsset(
    context: Context,
    path: String,
    contentType: ContentType,
) {
    val bytes = context.assets.open(path).use { it.readBytes() }
    respondBytes(bytes, contentType)
}

private fun errorJson(message: String) = JSONObject().apply {
    put("ok", false)
    put("error", message)
}.toString()
