package com.drew.tthelper.state

import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.SessionPrep
import com.drew.tthelper.model.SessionState
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object ImportStrategy {
    const val KEEP_EXISTING = "KEEP_EXISTING"
    const val MERGE = "MERGE"
    const val REPLACE = "REPLACE"
    const val COPY = "COPY"
}

object ContentPackageType {
    const val SESSION = "ttsession"
    const val ENEMY = "ttenemy"
    const val ENEMY_PACK = "ttenemypack"
    const val LOOT = "ttloot"
    const val LOOT_PACK = "ttlootpack"
}

data class ImportedContentPackage(
    val type: String,
    val name: String,
    val schemaVersion: Int = 1,
    val sessionPrep: SessionPrep? = null,
    val enemies: List<PreparedEnemy> = emptyList(),
    val loot: List<LootItem> = emptyList(),
    val warnings: List<String> = emptyList(),
)

object ContentPackageCodec {
    private const val SCHEMA_VERSION = 1

    fun encodeSession(prep: SessionPrep): String {
        val prepJson = JSONObject(SessionCodec.encode(SessionState(prep = prep.copy(pinnedPrepKeys = emptyList())))).getJSONObject("prep")
        return wrapper(
            type = ContentPackageType.SESSION,
            name = prep.sessionTitle.ifBlank { "Session Prep" },
            payload = prepJson,
        ).toString(2)
    }

    fun encodeEnemies(enemies: List<PreparedEnemy>, name: String = "Enemy Pack"): String {
        val normalizedType = if (enemies.size == 1) ContentPackageType.ENEMY else ContentPackageType.ENEMY_PACK
        val stateJson = JSONObject(SessionCodec.encode(SessionState(prep = SessionPrep(enemyLibrary = enemies))))
        val payload = stateJson.getJSONObject("prep").getJSONArray("enemyLibrary")
        return wrapper(normalizedType, if (enemies.size == 1) enemies.first().name else name, payload).toString(2)
    }

    fun encodeLoot(items: List<LootItem>, name: String = "Loot Pack"): String {
        val normalizedType = if (items.size == 1) ContentPackageType.LOOT else ContentPackageType.LOOT_PACK
        val stateJson = JSONObject(SessionCodec.encode(SessionState(partyLoot = items)))
        val payload = stateJson.getJSONArray("partyLoot")
        return wrapper(normalizedType, if (items.size == 1) items.first().name else name, payload).toString(2)
    }

    fun decode(raw: String): ImportedContentPackage {
        require(raw.length <= 5_000_000) { "Package is too large for a safe import" }
        val root = JSONObject(raw)
        require(root.optBoolean("ttHelperPackage", false)) { "Not a TT Helper content package" }
        val schemaVersion = root.optInt("schemaVersion", 1)
        require(schemaVersion in 1..SCHEMA_VERSION) { "Package schema $schemaVersion is newer than this app supports" }
        val type = root.optString("packageType")
        val name = root.optString("name", "Imported Content").trim().ifBlank { "Imported Content" }.take(120)
        val payload = root.opt("payload")

        val decoded = when (type) {
            ContentPackageType.SESSION -> {
                val prepObject = payload as? JSONObject ?: error("Session package payload is missing")
                val decodedState = SessionCodec.decode(JSONObject().apply {
                    put("prep", prepObject)
                    put("pcs", JSONArray())
                }.toString())
                ImportedContentPackage(type, name, schemaVersion, sessionPrep = decodedState.prep)
            }
            ContentPackageType.ENEMY, ContentPackageType.ENEMY_PACK -> {
                val array = when (payload) {
                    is JSONArray -> payload
                    is JSONObject -> JSONArray().put(payload)
                    else -> error("Enemy package payload is missing")
                }
                require(array.length() <= 500) { "Enemy package contains too many entries" }
                val decodedState = SessionCodec.decode(JSONObject().apply {
                    put("prep", JSONObject().apply { put("enemyLibrary", array) })
                    put("pcs", JSONArray())
                }.toString())
                ImportedContentPackage(type, name, schemaVersion, enemies = decodedState.prep.enemyLibrary)
            }
            ContentPackageType.LOOT, ContentPackageType.LOOT_PACK -> {
                val array = when (payload) {
                    is JSONArray -> payload
                    is JSONObject -> JSONArray().put(payload)
                    else -> error("Loot package payload is missing")
                }
                require(array.length() <= 1000) { "Loot package contains too many entries" }
                val decodedState = SessionCodec.decode(JSONObject().apply {
                    put("partyLoot", array)
                    put("pcs", JSONArray())
                }.toString())
                ImportedContentPackage(type, name, schemaVersion, loot = decodedState.partyLoot)
            }
            else -> error("Unsupported TT Helper package type: $type")
        }

        val warnings = buildList {
            decoded.sessionPrep?.let { prep ->
                if (prep.sessionTitle.isBlank()) add("Session title is blank.")
                if (prep.preparedEncounters.size > 100) add("This package contains more than 100 prepared encounters.")
                if (prep.enemyLibrary.any { it.name.isBlank() }) add("One or more library entries have blank names.")
            }
            if (decoded.enemies.any { it.name.isBlank() }) add("One or more imported enemy/NPC/hazard entries have blank names.")
            if (decoded.enemies.any { it.maxHp <= 0 }) add("One or more imported entries have invalid HP and will be normalized.")
            if (decoded.loot.any { it.name.isBlank() }) add("One or more loot entries have blank names.")
            if (decoded.loot.any { it.quantity <= 0 }) add("One or more loot entries have invalid quantities and will be normalized.")
        }
        return decoded.copy(warnings = warnings)
    }

    fun copyEnemy(enemy: PreparedEnemy): PreparedEnemy = enemy.copy(id = UUID.randomUUID().toString())

    fun copyLoot(item: LootItem): LootItem = item.copy(id = UUID.randomUUID().toString())

    fun copyLootPack(items: List<LootItem>): List<LootItem> {
        val idMap = items.associate { it.id to UUID.randomUUID().toString() }
        return items.map { item ->
            item.copy(
                id = idMap.getValue(item.id),
                containerId = item.containerId?.let { idMap[it] },
            )
        }
    }

    private fun wrapper(type: String, name: String, payload: Any): JSONObject = JSONObject().apply {
        put("ttHelperPackage", true)
        put("schemaVersion", SCHEMA_VERSION)
        put("packageType", type)
        put("name", name)
        put("createdAt", System.currentTimeMillis())
        put("payload", payload)
    }
}
