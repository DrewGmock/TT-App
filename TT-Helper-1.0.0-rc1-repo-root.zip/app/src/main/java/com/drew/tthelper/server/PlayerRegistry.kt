package com.drew.tthelper.server

import android.content.Context
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class PlayerClient(
    val token: String,
    val displayName: String,
    val pcId: String,
    val joinedAt: Long = System.currentTimeMillis(),
    val connected: Boolean = false,
)

data class JoinResult(val client: PlayerClient? = null, val error: String? = null)

class PlayerRegistry(context: Context) {
    private val secureRandom = SecureRandom()
    private val preferences = context.getSharedPreferences("tthelper-player-registry", Context.MODE_PRIVATE)
    private val clientsByToken = ConcurrentHashMap<String, PlayerClient>()
    private val _clients = MutableStateFlow<List<PlayerClient>>(emptyList())
    val clients: StateFlow<List<PlayerClient>> = _clients.asStateFlow()

    private val _pin = MutableStateFlow(preferences.getString("pin", null)?.takeIf { it.length == 6 } ?: newPin())
    val pin: StateFlow<String> = _pin.asStateFlow()

    init {
        restoreAssignments()
        persist()
    }

    fun rotatePin(): String {
        val next = newPin()
        _pin.value = next
        persist()
        return next
    }

    @Synchronized
    fun join(displayName: String, requestedPcId: String, providedPin: String): JoinResult {
        if (providedPin != _pin.value) return JoinResult(error = "Wrong PIN")
        val claimed = clientsByToken.values.any { it.pcId == requestedPcId }
        if (claimed) return JoinResult(error = "That character is already assigned. Ask the GM to release it.")

        val token = UUID.randomUUID().toString().replace("-", "")
        val client = PlayerClient(
            token = token,
            displayName = displayName.trim().ifBlank { "Player" }.take(30),
            pcId = requestedPcId,
        )
        clientsByToken[token] = client
        publishAndPersist()
        return JoinResult(client = client)
    }

    fun resolve(token: String?): PlayerClient? = token?.let(clientsByToken::get)

    @Synchronized
    fun setConnected(token: String, connected: Boolean) {
        val client = clientsByToken[token] ?: return
        clientsByToken[token] = client.copy(connected = connected)
        publishAndPersist()
    }

    @Synchronized
    fun releasePc(pcId: String) {
        clientsByToken.entries.removeIf { it.value.pcId == pcId }
        publishAndPersist()
    }

    @Synchronized
    fun clearAll() {
        clientsByToken.clear()
        publishAndPersist()
    }

    private fun restoreAssignments() {
        val raw = preferences.getString("clients", "[]") ?: "[]"
        runCatching {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val token = item.optString("token")
                val pcId = item.optString("pcId")
                if (token.isBlank() || pcId.isBlank()) continue
                clientsByToken[token] = PlayerClient(
                    token = token,
                    displayName = item.optString("displayName", "Player").take(30),
                    pcId = pcId,
                    joinedAt = item.optLong("joinedAt", System.currentTimeMillis()),
                    connected = false,
                )
            }
        }
        publish()
    }

    private fun publishAndPersist() {
        publish()
        persist()
    }

    private fun publish() {
        _clients.value = clientsByToken.values.sortedBy { it.joinedAt }
    }

    private fun persist() {
        val array = JSONArray().apply {
            clientsByToken.values.sortedBy { it.joinedAt }.forEach { client ->
                put(JSONObject().apply {
                    put("token", client.token)
                    put("displayName", client.displayName)
                    put("pcId", client.pcId)
                    put("joinedAt", client.joinedAt)
                })
            }
        }
        preferences.edit()
            .putString("pin", _pin.value)
            .putString("clients", array.toString())
            .apply()
    }

    private fun newPin(): String = (100000 + secureRandom.nextInt(900000)).toString()
}
