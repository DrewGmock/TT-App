package com.drew.tthelper.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.server.HostRuntime
import com.drew.tthelper.state.ContentPackageCodec
import com.drew.tthelper.state.ContentPackageType
import com.drew.tthelper.state.ImportStrategy
import com.drew.tthelper.state.ImportedContentPackage

@Composable
fun ImportExportScreen(runtime: HostRuntime) {
    val context = LocalContext.current
    val state by runtime.store.state.collectAsState()
    var imported by remember { mutableStateOf<ImportedContentPackage?>(null) }
    var status by remember { mutableStateOf("") }
    var pendingExportText by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Could not open selected file")
        }.mapCatching(ContentPackageCodec::decode)
            .onSuccess {
                imported = it
                status = "Loaded ${it.name}. Review it before importing."
            }
            .onFailure {
                imported = null
                status = "Import failed: ${it.message ?: "Unknown package error"}"
            }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        val text = pendingExportText
        pendingExportText = null
        if (uri == null || text == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(text) }
                ?: error("Could not create export file")
        }.onSuccess {
            status = "Export saved ✓"
        }.onFailure {
            status = "Export failed: ${it.message ?: "Unable to write file"}"
        }
    }

    fun export(filename: String, content: String) {
        pendingExportText = content
        exportLauncher.launch(filename)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Import / Export", fontSize = 26.sp)
        Text("Bring prep made with ChatGPT into TT Helper, or export your current content for editing and re-importing later.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Content Library", fontSize = 20.sp)
                Text("${state.prep.preparedEncounters.size} prepared encounters • ${state.prep.enemyLibrary.size} creatures/NPCs/hazards • ${state.partyLoot.size} loot items")
                Text("Supported packages: .ttsession, .ttenemy, .ttenemypack, .ttloot, .ttlootpack")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Import", fontSize = 20.sp)
                Text("TT Helper never imports a package immediately. Select a file, review the preview and conflicts, then choose how it should be merged.")
                Button(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) {
                    Text("Choose TT Helper package")
                }
                if (status.isNotBlank()) Text(status)
            }
        }

        imported?.let { pkg ->
            ImportPreviewCard(
                pkg = pkg,
                enemyConflicts = packageEnemyNames(pkg).count { name -> state.prep.enemyLibrary.any { it.name.equals(name, true) } },
                encounterConflicts = pkg.sessionPrep?.preparedEncounters?.count { incoming -> state.prep.preparedEncounters.any { it.name.equals(incoming.name, true) } } ?: 0,
                lootConflicts = pkg.loot.count { incoming -> state.partyLoot.any { it.name.equals(incoming.name, true) } },
                onImport = { strategy ->
                    when (pkg.type) {
                        ContentPackageType.SESSION -> pkg.sessionPrep?.let { runtime.store.importSessionPrep(it, strategy) }
                        ContentPackageType.ENEMY, ContentPackageType.ENEMY_PACK -> runtime.store.importEnemies(pkg.enemies, strategy)
                        ContentPackageType.LOOT, ContentPackageType.LOOT_PACK -> runtime.store.importLoot(pkg.loot, strategy)
                    }
                    status = "Imported ${pkg.name} ✓"
                    imported = null
                },
                onCancel = {
                    imported = null
                    status = "Import cancelled"
                },
            )
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Export Session Prep", fontSize = 20.sp)
                Text("Includes session notes, your reusable enemy/NPC/hazard library and prepared encounters. It does not export player characters or active combat state.")
                Button(onClick = {
                    export(safeFileName(state.prep.sessionTitle, ".ttsession"), ContentPackageCodec.encodeSession(state.prep))
                }) { Text("Export .ttsession") }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Export Enemies / NPCs / Hazards", fontSize = 20.sp)
                if (state.prep.enemyLibrary.isEmpty()) {
                    Text("Your prep library is empty.")
                } else {
                    Button(onClick = {
                        export("TT-Helper-Enemy-Pack.ttenemypack", ContentPackageCodec.encodeEnemies(state.prep.enemyLibrary, "TT Helper Enemy Library"))
                    }) { Text("Export entire library") }
                    HorizontalDivider()
                    state.prep.enemyLibrary.take(30).forEach { enemy ->
                        ExportEnemyRow(enemy) {
                            export(safeFileName(enemy.name, ".ttenemy"), ContentPackageCodec.encodeEnemies(listOf(enemy)))
                        }
                    }
                    if (state.prep.enemyLibrary.size > 30) Text("Showing the first 30 entries. Export the entire library to include all ${state.prep.enemyLibrary.size}.")
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Export Loot", fontSize = 20.sp)
                Text("Exports current party/shared and assigned inventory records from Loot & Inventory, including GM-only fields.")
                if (state.partyLoot.isEmpty()) {
                    Text("No inventory/loot records yet.")
                } else {
                    Button(onClick = {
                        export("TT-Helper-Loot-Pack.ttlootpack", ContentPackageCodec.encodeLoot(state.partyLoot, "TT Helper Loot & Inventory"))
                    }) { Text("Export all loot / inventory") }
                    HorizontalDivider()
                    state.partyLoot.take(30).forEach { item ->
                        ExportLootRow(item) {
                            export(safeFileName(item.name, ".ttloot"), ContentPackageCodec.encodeLoot(listOf(item)))
                        }
                    }
                    if (state.partyLoot.size > 30) Text("Showing the first 30 entries. Export all to include all ${state.partyLoot.size}.")
                }
            }
        }
    }
}

@Composable
private fun ImportPreviewCard(
    pkg: ImportedContentPackage,
    enemyConflicts: Int,
    encounterConflicts: Int,
    lootConflicts: Int,
    onImport: (String) -> Unit,
    onCancel: () -> Unit,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("IMPORT PREVIEW", fontSize = 20.sp)
            Text(pkg.name, fontSize = 18.sp)
            Text("Type: ${pkg.type} • Schema ${pkg.schemaVersion}")
            pkg.sessionPrep?.let { prep ->
                Text("Session: ${prep.sessionTitle}")
                Text("${prep.preparedEncounters.size} encounters • ${prep.enemyLibrary.size} library entries")
            }
            if (pkg.enemies.isNotEmpty()) Text("${pkg.enemies.size} creatures/NPCs/hazards")
            if (pkg.loot.isNotEmpty()) Text("${pkg.loot.size} loot/inventory entries")
            if (pkg.warnings.isNotEmpty()) {
                Text("IMPORT WARNINGS")
                pkg.warnings.forEach { Text("• $it") }
            }
            val totalConflicts = enemyConflicts + encounterConflicts + lootConflicts
            if (totalConflicts > 0) {
                Text("Conflicts: $enemyConflicts library • $encounterConflicts encounters • $lootConflicts loot")
            } else {
                Text("No name conflicts detected.")
            }
            Text("Keep Existing imports only new names. Merge updates same-name records. Replace replaces conflicting records (and replaces all Session Prep for .ttsession). Copy keeps everything and creates imported copies.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { onImport(ImportStrategy.KEEP_EXISTING) }) { Text("Keep Existing") }
                Button(onClick = { onImport(ImportStrategy.MERGE) }) { Text("Merge") }
                OutlinedButton(onClick = { onImport(ImportStrategy.REPLACE) }) { Text("Replace") }
                OutlinedButton(onClick = { onImport(ImportStrategy.COPY) }) { Text("Import as Copies") }
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun ExportEnemyRow(enemy: PreparedEnemy, onExport: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(enemy.name)
            Text("${enemy.kind} • level ${enemy.level ?: "—"}")
        }
        OutlinedButton(onClick = onExport) { Text("Export") }
    }
}

@Composable
private fun ExportLootRow(item: LootItem, onExport: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(item.name)
            Text("${item.category} • qty ${item.quantity}")
        }
        OutlinedButton(onClick = onExport) { Text("Export") }
    }
}

private fun packageEnemyNames(pkg: ImportedContentPackage): List<String> = when {
    pkg.sessionPrep != null -> pkg.sessionPrep.enemyLibrary.map { it.name }
    else -> pkg.enemies.map { it.name }
}

private fun safeFileName(name: String, extension: String): String {
    val cleaned = name.trim().ifBlank { "TT-Helper" }
        .replace(Regex("[^A-Za-z0-9._ -]"), "_")
        .replace(Regex("\\s+"), "-")
        .take(80)
    return if (cleaned.endsWith(extension, ignoreCase = true)) cleaned else "$cleaned$extension"
}
