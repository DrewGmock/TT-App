# TT Helper Changelog

## 1.0.0-rc1 — Campaign Ready candidate

- Adds a first-run Quick Start for GM setup, player joining, prep, Live play, and backups.
- Adds a Campaign Ready checklist in Settings with integrity and safety-backup actions.
- Adds clear host warning UI when the LAN host reports an error.
- Adds About/version/release-focus information and a way to reopen Quick Start.
- Keeps all 0.9 campaign-safety features: rotating backups, last-known-good recovery, migration backups, import validation, reconnect hardening, and independent appearance settings.
- Version code 18.

## 0.9.0-alpha1

- Stability, campaign recovery, diagnostics, appearance presets, and PC accent colors.
