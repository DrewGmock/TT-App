# TT Helper 1.0.0 RC1

TT Helper is a local-first Pathfinder 2e table companion. The Android GM tablet hosts the authoritative session over the local network, while players use a browser on phones/tablets.

## Campaign-ready focus

1.0 RC1 freezes the major feature set and focuses on reliability and usability: backups/recovery, save migration safety, reconnect behavior, diagnostics, import validation, accessibility/appearance, Quick Start onboarding, campaign readiness checks, and clearer host errors.

## Main systems

- Live encounter + initiative tracking
- PF2e action economy, MAP, rules requests, saves/attacks, effects, recurring checks
- Character, spell, ability, feat, strike, and player-submission workflows
- Loot, inventory, containers, consumables, unidentified/hidden items
- Session Prep 2.0, encounter budgeting, hazards, history
- Session/enemy/loot import-export packages
- TV/second-screen mode
- Rotating backups, last-known-good recovery, full-campaign portability, diagnostics
- Themes, accents, accessibility, player/GM customization

## Build

Use the existing GitHub Actions ZIP build flow. This package reports `versionCode = 18` and `versionName = "1.0.0-rc1"`.
