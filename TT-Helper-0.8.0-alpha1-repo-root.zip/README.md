# TT Helper

## 0.8.0-alpha1 — Table Experience
TT Helper is a local-first Pathfinder 2e tabletop companion. The Android GM device is authoritative and hosts lightweight browser clients for players on the same LAN.

### New in 0.8
- GM System/Light/Dark themes, font scaling, Compact/Comfortable density, high contrast, and a persistent Quick Bar.
- Tablet Live layout presets for Split, Initiative/Party, and Focus views.
- Player-safe second-screen / TV page at `http://<GM-IP>:8787/display`.
- Player theme/text-size settings plus reorderable player tabs.
- Reconnect status and last-sync feedback on player devices.
- Encounter History recap text with Android clipboard copy.
- Smaller-screen GM navigation remains fully reachable with a horizontally scrollable page bar.

### Second-screen safety
The `/display` endpoint deliberately contains only public table information: scene, round/current turn, initiative names, party HP/status, visible enemy health descriptions, and public effects. It does not include exact enemy HP/defenses, GM notes, hidden loot, private Session Prep, approvals, or rules secrets.

### Existing systems carried forward
- Live combat, initiative, Delay/Ready, rules requests, MAP, spell saves/attacks, effect timing/checks, and Undo.
- Character dashboards, spell/ability/strike builder and GM approval workflow.
- Loot & Inventory, containers, hidden/unidentified items, consumables, encounter loot, and player inventory.
- Session Prep 2.0, encounter budgets, Creature/NPC/Hazard library, Weak/Elite, templates, History, collapsible prep, Pinned Prep, and content Import/Export.

## Build
`versionCode = 16`

`versionName = "0.8.0-alpha1"`

The repo retains the same local-development signing key as prior signed builds so Android should install it as a normal update.
