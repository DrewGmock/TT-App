package com.drew.tthelper.model

data class EncounterBudget(
    val totalXp: Int,
    val difficulty: String,
    val trivial: Int,
    val low: Int,
    val moderate: Int,
    val severe: Int,
    val extreme: Int,
)

fun effectiveLevel(entry: PreparedEnemy): Int? {
    val base = entry.level ?: return null
    return when (entry.adjustment) {
        EncounterAdjustment.WEAK -> base - 1
        EncounterAdjustment.ELITE -> base + 1
        else -> base
    }
}

fun creatureXpForLevel(partyLevel: Int, creatureLevel: Int): Int {
    return when (creatureLevel - partyLevel) {
        in Int.MIN_VALUE..-5 -> 0
        -4 -> 10
        -3 -> 15
        -2 -> 20
        -1 -> 30
        0 -> 40
        1 -> 60
        2 -> 80
        3 -> 120
        else -> 160
    }
}

fun entryXp(entry: PreparedEnemy, partyLevel: Int): Int {
    val level = effectiveLevel(entry) ?: return 0
    val base = creatureXpForLevel(partyLevel, level)
    val perEntry = if (entry.kind == PrepEntryKind.HAZARD && entry.hazardComplexity == HazardComplexity.SIMPLE) {
        (base / 5.0).toInt().coerceAtLeast(if (base > 0) 1 else 0)
    } else base
    return perEntry * entry.quantity.coerceAtLeast(1)
}

fun encounterBudget(entries: List<PreparedEnemy>, partyLevel: Int, partySize: Int): EncounterBudget {
    val size = partySize.coerceAtLeast(1)
    fun scaled(base: Int): Int = ((base * size) / 4.0).toInt()
    val trivial = scaled(40)
    val low = scaled(60)
    val moderate = scaled(80)
    val severe = scaled(120)
    val extreme = scaled(160)
    val total = entries.sumOf { entryXp(it, partyLevel) }
    val difficulty = when {
        total <= 0 -> "Unrated"
        total <= trivial -> "Trivial"
        total <= low -> "Low"
        total <= moderate -> "Moderate"
        total <= severe -> "Severe"
        total <= extreme -> "Extreme"
        else -> "Extreme+"
    }
    return EncounterBudget(total, difficulty, trivial, low, moderate, severe, extreme)
}

fun eliteWeakHpAdjustment(level: Int): Int = when {
    level <= 1 -> 10
    level <= 4 -> 15
    level <= 19 -> 20
    else -> 30
}

fun adjustedPreparedEntry(entry: PreparedEnemy): PreparedEnemy {
    val shift = when (entry.adjustment) {
        EncounterAdjustment.WEAK -> -1
        EncounterAdjustment.ELITE -> 1
        else -> 0
    }
    if (shift == 0) return entry
    val hpDelta = eliteWeakHpAdjustment(entry.level ?: 1) * shift
    val checkDelta = 2 * shift
    return entry.copy(
        level = entry.level?.plus(shift),
        maxHp = (entry.maxHp + hpDelta).coerceAtLeast(1),
        armorClass = entry.armorClass?.plus(checkDelta),
        fortitude = entry.fortitude?.plus(checkDelta),
        reflex = entry.reflex?.plus(checkDelta),
        will = entry.will?.plus(checkDelta),
        initiativeModifier = entry.initiativeModifier + checkDelta,
    )
}
