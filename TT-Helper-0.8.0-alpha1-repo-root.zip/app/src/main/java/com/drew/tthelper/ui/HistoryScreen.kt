package com.drew.tthelper.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.EncounterHistoryEntry
import com.drew.tthelper.server.HostRuntime
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    val entries = state.completedEncounters.sortedByDescending { it.endedAt }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var copiedId by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Encounter History", fontSize = 26.sp)
        Text("Ended encounters stay here even after Live is cleared. Use Copy recap to paste a concise session summary into your notes or a chat.")

        if (entries.isEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("No completed encounters yet.")
                    Text("End an encounter from Live and it will be archived automatically.")
                }
            }
        }

        entries.forEach { entry ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(entry.name, fontSize = 19.sp)
                    Text("${formatTime(entry.endedAt)} • ${entry.difficulty} • ${entry.totalXp} XP")
                    Text("Party ${entry.partySize} @ level ${entry.partyLevel} • ${entry.rounds} rounds • ${entry.defeatedCount}/${entry.combatantCount} non-PC combatants defeated")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { expandedId = if (expandedId == entry.id) null else entry.id }) {
                            Text(if (expandedId == entry.id) "Hide log" else "Show log")
                        }
                        TextButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("TT Helper recap", recapText(entry)))
                            copiedId = entry.id
                        }) { Text(if (copiedId == entry.id) "Copied ✓" else "Copy recap") }
                        TextButton(onClick = { runtime.store.deleteEncounterHistory(entry.id) }) { Text("Delete history") }
                    }
                    if (expandedId == entry.id) {
                        HorizontalDivider()
                        Text(recapText(entry))
                    }
                }
            }
        }
    }
}

private fun recapText(entry: EncounterHistoryEntry): String = buildString {
    appendLine(entry.name)
    appendLine("${entry.difficulty} encounter • ${entry.totalXp} XP • ${entry.rounds} rounds")
    appendLine("Party ${entry.partySize} @ level ${entry.partyLevel}")
    appendLine("Defeated ${entry.defeatedCount}/${entry.combatantCount} non-PC combatants")
    if (entry.history.isNotEmpty()) {
        appendLine("Highlights:")
        entry.history.takeLast(12).forEach { appendLine("• $it") }
    }
}.trim()

private fun formatTime(epochMillis: Long): String = runCatching {
    SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault()).format(Date(epochMillis))
}.getOrDefault("Completed encounter")
