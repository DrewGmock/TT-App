package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.DegreeOfSuccess
import com.drew.tthelper.model.RuleRequest
import com.drew.tthelper.model.RuleRequestStatus
import com.drew.tthelper.server.HostRuntime

@Composable
fun RulesScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    val requests = state.encounter?.ruleRequests.orEmpty()
    val pending = requests.filter { it.status == RuleRequestStatus.PENDING }
    val consequenceQueue = requests.filter { it.status == RuleRequestStatus.RESOLVED && !it.consequenceApplied && (it.damageFormula.isNotBlank() || listOf(it.effectCriticalSuccess, it.effectSuccess, it.effectFailure, it.effectCriticalFailure).any { effect -> effect.isNotBlank() }) }
    val actionable = pending + consequenceQueue
    val recent = requests.filter { it.status != RuleRequestStatus.PENDING && it !in consequenceQueue }.takeLast(12).reversed()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Rules & Resolution", fontSize = 26.sp)
        Text("Targeted attacks, spell saves, attack-trait skill actions, and secret checks land here. TT Helper suggests outcomes when it has enough numbers; the GM remains final authority.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Needs attention • ${actionable.size}", fontSize = 20.sp)
                if (actionable.isEmpty()) Text("No rule requests waiting.")
                actionable.forEach { RuleRequestCard(runtime, it) }
            }
        }

        if (recent.isNotEmpty()) {
            HorizontalDivider()
            Text("Recent resolutions", fontSize = 20.sp)
            recent.forEach { request ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(request.label)
                        Text("${request.actorName}${request.targetName?.let { " → $it" } ?: ""}")
                        Text(request.outcome ?: request.status)
                    }
                }
            }
        }
    }
}

@Composable
private fun RuleRequestCard(runtime: HostRuntime, request: RuleRequest) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(request.label, fontSize = 18.sp)
                    Text("${request.actorName}${request.targetName?.let { " → $it" } ?: ""}")
                    Text(if (request.secret) "SECRET CHECK • ${request.type}" else request.type)
                }
                if (request.mapPenalty != 0) Text("MAP ${signed(request.mapPenalty)}")
            }

            if (!request.secret) {
                when (request.type) {
                    "SAVE" -> {
                        Text("TARGET ROLLS", fontSize = 12.sp)
                        Text("${request.targetName ?: "Target"} • ${request.notes.ifBlank { "Saving throw modifier ${request.modifier?.let(::signed) ?: "not entered"}" }}")
                        Text("CASTER DC", fontSize = 12.sp)
                        Text("${request.actorName} • ${request.dcLabel}${request.dc?.let { " $it" } ?: " not entered"}")
                    }
                    "ATTACK" -> {
                        Text("ATTACKER ROLLS", fontSize = 12.sp)
                        Text("${request.actorName} • modifier ${request.modifier?.let(::signed) ?: "not entered"}${if (request.mapPenalty != 0) " • MAP ${signed(request.mapPenalty)}" else ""}")
                        Text("TARGET DEFENSE", fontSize = 12.sp)
                        Text("${request.targetName ?: "Target"} • ${request.dcLabel}${request.dc?.let { " $it" } ?: " not entered"}")
                    }
                    else -> {
                        Text("CHECK", fontSize = 12.sp)
                        Text("${request.actorName} rolls${request.targetName?.let { " against $it" } ?: ""}")
                        request.dc?.let { Text("${request.dcLabel} $it") }
                    }
                }
                request.roll?.let { die ->
                    val mod = request.modifier ?: 0
                    val total = request.total ?: die + mod
                    Text("ROLL", fontSize = 12.sp)
                    Text("${if (die == 1 || die == 20) "Natural $die" else die.toString()} ${signed(mod)} = $total", fontSize = 18.sp)
                    request.dc?.let { dc ->
                        val base = baseDegree(total, dc)
                        Text("Base result: $base")
                        if (die == 20) Text("Natural 20: increase the degree by one step")
                        if (die == 1) Text("Natural 1: decrease the degree by one step")
                    }
                } ?: request.modifier?.let { Text("Waiting for roll • modifier ${signed(it)}") }
                request.suggestedOutcome?.let { Text("FINAL RESULT: ${it.uppercase()}", fontSize = 18.sp) }
            } else {
                Text("SECRET CHECK", fontSize = 12.sp)
                Text("${request.actorName}${request.targetName?.let { " → $it" } ?: ""}")
                Text("Keep the actual roll/result on the GM side. Players only see that a secret check was sent.")
            }
            if (request.notes.isNotBlank()) Text(request.notes)
            if (request.status == RuleRequestStatus.RESOLVED && request.damageFormula.isNotBlank()) {
                Text("Damage/Healing: ${request.damageFormula}${request.damageType.takeIf { it.isNotBlank() }?.let { " $it" } ?: ""}")
                request.rolledDamage?.let { Text("Base roll: $it • Proposed ${request.proposedAmount ?: 0}${if (request.healing) " healing" else " damage"}") }
                if (request.consequenceApplied) Text("✓ Consequences applied")
            }

            FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (request.status == RuleRequestStatus.PENDING) {
                    if (request.modifier != null && request.total == null) {
                        FilledTonalButton(onClick = { runtime.store.rollRuleRequest(request.id) }) { Text("Roll digitally") }
                    }
                    request.suggestedOutcome?.let { suggestion ->
                        Button(onClick = { runtime.store.resolveRuleRequest(request.id, suggestion) }) { Text("Accept $suggestion") }
                    }
                    OutlinedButton(onClick = { runtime.store.resolveRuleRequest(request.id, DegreeOfSuccess.CRITICAL_SUCCESS) }) { Text("Crit Success") }
                    OutlinedButton(onClick = { runtime.store.resolveRuleRequest(request.id, DegreeOfSuccess.SUCCESS) }) { Text("Success") }
                    OutlinedButton(onClick = { runtime.store.resolveRuleRequest(request.id, DegreeOfSuccess.FAILURE) }) { Text("Failure") }
                    OutlinedButton(onClick = { runtime.store.resolveRuleRequest(request.id, DegreeOfSuccess.CRITICAL_FAILURE) }) { Text("Crit Failure") }
                }
                if (request.status == RuleRequestStatus.RESOLVED && !request.consequenceApplied && (request.damageFormula.isNotBlank() || listOf(request.effectCriticalSuccess, request.effectSuccess, request.effectFailure, request.effectCriticalFailure).any { it.isNotBlank() })) {
                    if (request.damageFormula.isNotBlank()) FilledTonalButton(onClick = { runtime.store.rerollRuleDamage(request.id) }) { Text("Reroll damage") }
                    Button(onClick = { runtime.store.applyRuleRequestConsequences(request.id) }) { Text("Apply consequences") }
                }
                TextButton(onClick = { runtime.store.dismissRuleRequest(request.id) }) { Text("Dismiss") }
            }
        }
    }
}

private fun baseDegree(total: Int, dc: Int): String = when {
    total >= dc + 10 -> DegreeOfSuccess.CRITICAL_SUCCESS
    total >= dc -> DegreeOfSuccess.SUCCESS
    total <= dc - 10 -> DegreeOfSuccess.CRITICAL_FAILURE
    else -> DegreeOfSuccess.FAILURE
}

private fun signed(value: Int): String = if (value >= 0) "+$value" else value.toString()
