package com.drew.tthelper.ui

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Density
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import com.drew.tthelper.BuildConfig
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EffectCheckType
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.RuleRequestStatus
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.server.HostRuntime
import kotlinx.coroutines.delay
import kotlin.random.Random

private enum class AppPage(val label: String) { LIVE("Live"), RULES("Rules"), CHARACTERS("Characters"), SPELLS("Spells"), APPROVALS("Approvals"), INVENTORY("Loot & Inventory"), PREP("Session Prep"), IMPORT_EXPORT("Import / Export"), HISTORY("History"), CONNECTIONS("Players"), SETTINGS("Settings") }

@Composable
fun TTHelperApp(runtime: HostRuntime) {
    val context = LocalContext.current
    val status by runtime.status.collectAsState()
    val state by runtime.store.state.collectAsState()
    var page by remember { mutableStateOf(AppPage.LIVE) }
    var alertSoundEnabled by rememberSaveable { mutableStateOf(true) }
    var sidebarCollapsed by rememberSaveable { mutableStateOf(false) }
    var uiPreferences by remember { mutableStateOf(loadUiPreferences(context)) }

    val encounter = state.encounter
    val playerRequestCount = encounter?.endTurnRequests?.size ?: 0
    val checkCount = encounter?.pendingEffectChecks?.size ?: 0
    val submissionCount = state.pcs.sumOf { pc -> pc.contentDrafts.count { it.status == "PENDING" } }
    val characterRequestCount = state.characterRequests.size
    val rulesCount = encounter?.ruleRequests?.count { it.status == RuleRequestStatus.PENDING } ?: 0
    val attentionCount = playerRequestCount + checkCount + submissionCount + characterRequestCount + rulesCount

    val systemDark = isSystemInDarkTheme()
    val useDark = when (uiPreferences.themeMode) { "dark" -> true; "light" -> false; else -> systemDark }
    val scheme = when {
        uiPreferences.highContrast && useDark -> darkColorScheme(primary = Color.White, onPrimary = Color.Black, background = Color.Black, surface = Color.Black, onSurface = Color.White)
        uiPreferences.highContrast && !useDark -> lightColorScheme(primary = Color.Black, onPrimary = Color.White, background = Color.White, surface = Color.White, onSurface = Color.Black)
        useDark -> darkColorScheme()
        else -> lightColorScheme()
    }
    val baseDensity = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(baseDensity.density, uiPreferences.fontScale)) {
      MaterialTheme(colorScheme = scheme) {
      BoxWithConstraints(Modifier.fillMaxSize()) {
        val tablet = maxWidth >= 760.dp
        val compactUi = uiPreferences.densityMode == "compact"
        Scaffold(
            bottomBar = {
                if (!tablet) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        AppPage.entries.forEach { item ->
                            val label = navLabel(item, playerRequestCount, attentionCount, submissionCount + characterRequestCount, rulesCount)
                            if (page == item) FilledTonalButton(onClick = { page = item }) { Text(label) }
                            else TextButton(onClick = { page = item }) { Text(label) }
                        }
                    }
                }
            }
        ) { padding ->
            Row(Modifier.fillMaxSize().padding(padding)) {
                if (tablet) {
                    GmSidebar(
                        selected = page,
                        collapsed = sidebarCollapsed,
                        onToggleCollapsed = { sidebarCollapsed = !sidebarCollapsed },
                        playerRequests = playerRequestCount,
                        attentionCount = attentionCount,
                        submissionCount = submissionCount + characterRequestCount,
                        rulesCount = rulesCount,
                        compactUi = compactUi,
                        onSelect = { page = it },
                    )
                }
                Column(Modifier.fillMaxSize()) {
                    HostBar(
                        running = status.running,
                        address = status.address,
                        port = status.port,
                        onStart = { runtime.requestStart(context) },
                        onStop = { runtime.requestStop(context) },
                        onUndo = { runtime.store.undo() },
                    )
                    GlobalAttentionBanner(
                        runtime = runtime,
                        state = state,
                        soundEnabled = alertSoundEnabled,
                        onToggleSound = { alertSoundEnabled = !alertSoundEnabled },
                    )
                    if (uiPreferences.quickBar) {
                        GmQuickBar(
                            runtime = runtime,
                            state = state,
                            compact = compactUi,
                            playerRequests = playerRequestCount,
                            approvals = submissionCount + characterRequestCount,
                            rules = rulesCount,
                            onNavigate = { page = it },
                        )
                    }
                    Box(Modifier.fillMaxSize()) {
                        when (page) {
                            AppPage.LIVE -> LiveSessionScreen(runtime, tablet)
                            AppPage.RULES -> RulesScreen(runtime)
                            AppPage.CHARACTERS -> CharacterManagementScreen(runtime)
                            AppPage.SPELLS -> GmSpellScreen(runtime)
                            AppPage.APPROVALS -> ApprovalInboxScreen(runtime)
                            AppPage.INVENTORY -> InventoryScreen(runtime)
                            AppPage.PREP -> SessionPrepScreen(runtime)
                            AppPage.IMPORT_EXPORT -> ImportExportScreen(runtime)
                            AppPage.HISTORY -> HistoryScreen(runtime)
                            AppPage.CONNECTIONS -> ConnectionsScreen(runtime)
                            AppPage.SETTINGS -> SettingsScreen(
                                runtime = runtime,
                                preferences = uiPreferences,
                                onPreferencesChanged = { value ->
                                    uiPreferences = value
                                    saveUiPreferences(context, value)
                                },
                            )
                        }
                    }
                }
            }
        }
      }
      }
    }
}

@Composable
private fun GmSidebar(
    selected: AppPage,
    collapsed: Boolean,
    onToggleCollapsed: () -> Unit,
    playerRequests: Int,
    attentionCount: Int,
    submissionCount: Int,
    rulesCount: Int,
    compactUi: Boolean,
    onSelect: (AppPage) -> Unit,
) {
    var playExpanded by rememberSaveable { mutableStateOf(true) }
    var campaignExpanded by rememberSaveable { mutableStateOf(true) }
    var prepExpanded by rememberSaveable { mutableStateOf(true) }
    var systemExpanded by rememberSaveable { mutableStateOf(true) }
    val width = if (collapsed) 68.dp else if (compactUi) 156.dp else 176.dp
    Column(
        Modifier
            .width(width)
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (collapsed) Arrangement.Center else Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (!collapsed) Text("TT Helper", fontSize = 18.sp)
            TextButton(onClick = onToggleCollapsed) { Text(if (collapsed) "»" else "«") }
        }
        HorizontalDivider()
        if (collapsed) {
            AppPage.entries.forEach { item ->
                SidebarPageButton(
                    page = item,
                    selected = selected == item,
                    collapsed = true,
                    label = navLabel(item, playerRequests, attentionCount, submissionCount, rulesCount),
                    attention = item == AppPage.LIVE && attentionCount > 0,
                    onClick = { onSelect(item) },
                )
            }
        } else {
            SidebarGroup(
                title = "Play",
                expanded = playExpanded,
                onToggle = { playExpanded = !playExpanded },
                pages = listOf(AppPage.LIVE, AppPage.RULES, AppPage.CONNECTIONS),
                selected = selected,
                playerRequests = playerRequests,
                attentionCount = attentionCount,
                submissionCount = submissionCount,
                rulesCount = rulesCount,
                onSelect = onSelect,
            )
            SidebarGroup(
                title = "Campaign",
                expanded = campaignExpanded,
                onToggle = { campaignExpanded = !campaignExpanded },
                pages = listOf(AppPage.CHARACTERS, AppPage.SPELLS, AppPage.APPROVALS, AppPage.INVENTORY),
                selected = selected,
                playerRequests = playerRequests,
                attentionCount = attentionCount,
                submissionCount = submissionCount,
                rulesCount = rulesCount,
                onSelect = onSelect,
            )
            SidebarGroup(
                title = "Prep",
                expanded = prepExpanded,
                onToggle = { prepExpanded = !prepExpanded },
                pages = listOf(AppPage.PREP, AppPage.IMPORT_EXPORT, AppPage.HISTORY),
                selected = selected,
                playerRequests = playerRequests,
                attentionCount = attentionCount,
                submissionCount = submissionCount,
                rulesCount = rulesCount,
                onSelect = onSelect,
            )
            SidebarGroup(
                title = "System",
                expanded = systemExpanded,
                onToggle = { systemExpanded = !systemExpanded },
                pages = listOf(AppPage.SETTINGS),
                selected = selected,
                playerRequests = playerRequests,
                attentionCount = attentionCount,
                submissionCount = submissionCount,
                rulesCount = rulesCount,
                onSelect = onSelect,
            )
        }
    }
}

@Composable
private fun SidebarGroup(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    pages: List<AppPage>,
    selected: AppPage,
    playerRequests: Int,
    attentionCount: Int,
    submissionCount: Int,
    rulesCount: Int,
    onSelect: (AppPage) -> Unit,
) {
    TextButton(onClick = onToggle, modifier = Modifier.fillMaxWidth()) {
        Text(if (expanded) "▾ $title" else "▸ $title")
    }
    if (expanded) {
        pages.forEach { item ->
            SidebarPageButton(
                page = item,
                selected = selected == item,
                collapsed = false,
                label = navLabel(item, playerRequests, attentionCount, submissionCount, rulesCount),
                attention = item == AppPage.LIVE && attentionCount > 0,
                onClick = { onSelect(item) },
            )
        }
    }
}

@Composable
private fun SidebarPageButton(
    page: AppPage,
    selected: Boolean,
    collapsed: Boolean,
    label: String,
    attention: Boolean,
    onClick: () -> Unit,
) {
    val short = if (attention) "!" else page.label.take(1)
    if (selected) {
        FilledTonalButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
            Text(if (collapsed) short else label)
        }
    } else {
        TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
            Text(if (collapsed) short else label)
        }
    }
}

private fun navLabel(page: AppPage, playerRequests: Int, attentionCount: Int, submissionCount: Int, rulesCount: Int): String = when (page) {
    AppPage.CONNECTIONS -> if (playerRequests > 0) "Players ($playerRequests)" else page.label
    AppPage.APPROVALS -> if (submissionCount > 0) "Approvals ($submissionCount)" else page.label
    AppPage.RULES -> if (rulesCount > 0) "Rules ($rulesCount)" else page.label
    AppPage.LIVE -> if (attentionCount > 0) "Live ($attentionCount)" else page.label
    else -> page.label
}


@Composable
private fun GmQuickBar(
    runtime: HostRuntime,
    state: SessionState,
    compact: Boolean,
    playerRequests: Int,
    approvals: Int,
    rules: Int,
    onNavigate: (AppPage) -> Unit,
) {
    val encounter = state.encounter
    val current = encounter?.currentCombatant()
    Card(
        Modifier.fillMaxWidth().padding(horizontal = if (compact) 8.dp else 12.dp, vertical = 3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        FlowRow(
            Modifier.fillMaxWidth().padding(if (compact) 6.dp else 8.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Text(
                if (encounter?.active == true) "Round ${encounter.round} • ${current?.name ?: "Awaiting turn"}" else "Between encounters"
            )
            if (encounter?.active == true) {
                Button(onClick = { runtime.store.nextTurn() }) { Text("Next Turn") }
            }
            OutlinedButton(onClick = { runtime.store.undo() }) { Text("Undo") }
            if (rules > 0) FilledTonalButton(onClick = { onNavigate(AppPage.RULES) }) { Text("Rules $rules") }
            if (approvals > 0) FilledTonalButton(onClick = { onNavigate(AppPage.APPROVALS) }) { Text("Approvals $approvals") }
            if (playerRequests > 0) FilledTonalButton(onClick = { onNavigate(AppPage.CONNECTIONS) }) { Text("Players $playerRequests") }
            TextButton(onClick = { onNavigate(AppPage.PREP) }) { Text("Prep") }
        }
    }
}


@Composable
private fun GlobalAttentionBanner(
    runtime: HostRuntime,
    state: SessionState,
    soundEnabled: Boolean,
    onToggleSound: () -> Unit,
) {
    val encounter = state.encounter
    val check = encounter?.pendingEffectChecks?.firstOrNull()
    val requestPcId = encounter?.endTurnRequests?.firstOrNull()
    val ruleRequest = encounter?.ruleRequests?.firstOrNull { it.status == RuleRequestStatus.PENDING }
    val pendingSubmission = state.pcs.firstNotNullOfOrNull { pc ->
        pc.contentDrafts.firstOrNull { it.status == "PENDING" }?.let { pc to it }
    }
    val characterRequest = state.characterRequests.firstOrNull()
    if (check == null && requestPcId == null && ruleRequest == null && pendingSubmission == null && characterRequest == null) return

    val context = LocalContext.current
    val alertKey = check?.let { "check:${it.id}" } ?: requestPcId?.let { "request:$it" } ?: ruleRequest?.let { "rule:${it.id}" } ?: pendingSubmission?.let { "submission:${it.second.id}" } ?: "character:${characterRequest?.id}"
    LaunchedEffect(alertKey, soundEnabled) {
        runCatching {
            val vibrator = context.getSystemService(Vibrator::class.java)
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 140, 80, 180), -1))
        }
        if (soundEnabled) {
            runCatching {
                val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 220)
                delay(280)
                tone.release()
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val total = (encounter?.pendingEffectChecks?.size ?: 0) + (encounter?.endTurnRequests?.size ?: 0) + (encounter?.ruleRequests?.count { it.status == RuleRequestStatus.PENDING } ?: 0) + state.pcs.sumOf { pc -> pc.contentDrafts.count { it.status == "PENDING" } } + state.characterRequests.size
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (total > 1) "GM ATTENTION • $total alerts" else "GM ATTENTION", fontSize = 18.sp)
                TextButton(onClick = onToggleSound) { Text(if (soundEnabled) "Sound on" else "Sound off") }
            }

            if (check != null) {
                EffectCheckAlert(runtime, check)
            } else if (requestPcId != null) {
                val pcName = state.pcs.firstOrNull { it.id == requestPcId }?.name ?: "Player"
                Text("END TURN REQUEST", fontSize = 16.sp)
                Text("$pcName is finished and wants to advance the turn.")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { runtime.store.approveEndTurnRequest(requestPcId) }) { Text("Advance Turn") }
                    OutlinedButton(onClick = { runtime.store.dismissEndTurnRequest(requestPcId) }) { Text("Dismiss") }
                }
            } else if (ruleRequest != null) {
                Text("RULES REQUEST", fontSize = 16.sp)
                if (ruleRequest.type == "SAVE") {
                    Text("${ruleRequest.targetName ?: "Target"} rolls ${ruleRequest.label.substringAfter("•", "save").trim()} against ${ruleRequest.actorName}'s ${ruleRequest.dcLabel}.")
                } else if (ruleRequest.type == "ATTACK") {
                    Text("${ruleRequest.actorName} attacks ${ruleRequest.targetName ?: "target"} against ${ruleRequest.dcLabel}.")
                } else {
                    Text("${ruleRequest.actorName}: ${ruleRequest.label}${ruleRequest.targetName?.let { " → $it" } ?: ""}")
                }
                Text(if (ruleRequest.secret) "Secret check waiting for GM resolution." else "Open Rules to see the roller, modifier, DC, natural-die shift, and final result.")
            } else if (pendingSubmission != null) {
                val (pc, draft) = pendingSubmission
                Text("PLAYER SUBMISSION", fontSize = 16.sp)
                Text("${pc.name} submitted ${draft.name} (${draft.kind.lowercase()}) for approval.")
                Text("Open Approvals to review, edit, approve, or return it to Drafts.")
            } else if (characterRequest != null) {
                Text("NEW CHARACTER REQUEST", fontSize = 16.sp)
                Text("${characterRequest.playerName} requested ${characterRequest.characterName}.")
                Text("Open Approvals to approve or decline the new character.")
            }
        }
    }
}

@Composable
private fun EffectCheckAlert(runtime: HostRuntime, check: EffectCheckPrompt) {
    Text("CHECK REQUIRED", fontSize = 16.sp)
    Text("${check.targetName} • ${check.effectName}")
    val dcText = check.dc?.let { " vs DC $it" }.orEmpty()
    Text("${check.checkType}$dcText${if (check.timingText.isNotBlank()) " • ${check.timingText}" else ""}")
    if (check.checkLabel.isNotBlank()) Text(check.checkLabel)

    FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if ((check.checkType == EffectCheckType.FLAT || check.checkType == EffectCheckType.RECOVERY) && check.dc != null) {
            Button(onClick = {
                val die = Random.nextInt(1, 21)
                runtime.store.resolveEffectCheck(check.id, degreeFromRoll(die, check.dc))
            }) { Text("Roll d20") }
        }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "criticalSuccess") }) { Text("Crit Success") }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "success") }) { Text("Success") }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "failure") }) { Text("Failure") }
        OutlinedButton(onClick = { runtime.store.resolveEffectCheck(check.id, "criticalFailure") }) { Text("Crit Failure") }
        TextButton(onClick = { runtime.store.dismissEffectCheck(check.id) }) { Text("Skip") }
    }
}

private fun degreeFromRoll(die: Int, dc: Int): String {
    var degree = when {
        die >= dc + 10 -> 3
        die >= dc -> 2
        die <= dc - 10 -> 0
        else -> 1
    }
    if (die == 20) degree = (degree + 1).coerceAtMost(3)
    if (die == 1) degree = (degree - 1).coerceAtLeast(0)
    return when (degree) {
        3 -> "criticalSuccess"
        2 -> "success"
        1 -> "failure"
        else -> "criticalFailure"
    }
}

@Composable
private fun HostBar(
    running: Boolean,
    address: String?,
    port: Int,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onUndo: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text("TT Helper", fontSize = 22.sp)
            Text("v${BuildConfig.VERSION_NAME}", fontSize = 12.sp)
            Text(if (running) "Hosting • ${address ?: "finding IP"}:$port" else "Host offline")
        }
        TextButton(onClick = onUndo) { Text("Undo") }
        Button(onClick = if (running) onStop else onStart) { Text(if (running) "Stop host" else "Start host") }
    }
}
