package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.EncounterAdjustment
import com.drew.tthelper.model.HazardComplexity
import com.drew.tthelper.model.PrepEntryKind
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.encounterBudget
import com.drew.tthelper.model.entryXp
import com.drew.tthelper.model.effectiveLevel
import com.drew.tthelper.server.HostRuntime
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SessionPrepScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var title by remember { mutableStateOf(state.prep.sessionTitle) }
    var opening by remember { mutableStateOf(state.prep.openingScene) }
    var objectives by remember { mutableStateOf(state.prep.objectives) }
    var locations by remember { mutableStateOf(state.prep.locations) }
    var referenceNotes by remember { mutableStateOf(state.prep.referenceNotes) }
    var lootSuggestions by remember { mutableStateOf(state.prep.lootSuggestions) }
    var encounterNotes by remember { mutableStateOf(state.prep.encounterNotes) }
    var notes by remember { mutableStateOf(state.prep.gmNotes) }
    var backupMessage by remember { mutableStateOf("") }
    var saveMessage by remember { mutableStateOf("") }
    var lastSavedAt by remember { mutableStateOf("") }

    var overviewOpen by rememberSaveable { mutableStateOf(true) }
    var objectivesOpen by rememberSaveable { mutableStateOf(false) }
    var locationsOpen by rememberSaveable { mutableStateOf(false) }
    var lootOpen by rememberSaveable { mutableStateOf(false) }
    var referenceOpen by rememberSaveable { mutableStateOf(false) }
    var beatsOpen by rememberSaveable { mutableStateOf(false) }
    var gmNotesOpen by rememberSaveable { mutableStateOf(false) }
    var libraryOpen by rememberSaveable { mutableStateOf(false) }
    var encountersOpen by rememberSaveable { mutableStateOf(true) }
    var rulesOpen by rememberSaveable { mutableStateOf(false) }
    var backupsOpen by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(state.revision) {
        val externalPrepChange = state.lastEventLabel?.startsWith("Backup restored") == true ||
            state.lastEventLabel?.contains("imported", ignoreCase = true) == true
        if (externalPrepChange) {
            title = state.prep.sessionTitle
            opening = state.prep.openingScene
            objectives = state.prep.objectives
            locations = state.prep.locations
            referenceNotes = state.prep.referenceNotes
            lootSuggestions = state.prep.lootSuggestions
            encounterNotes = state.prep.encounterNotes
            notes = state.prep.gmNotes
            saveMessage = "Loaded saved/imported prep ✓"
        }
    }

    val notesDirty = title != state.prep.sessionTitle || opening != state.prep.openingScene ||
        objectives != state.prep.objectives || locations != state.prep.locations ||
        referenceNotes != state.prep.referenceNotes || lootSuggestions != state.prep.lootSuggestions ||
        encounterNotes != state.prep.encounterNotes || notes != state.prep.gmNotes

    fun savePrep(label: String) {
        runtime.store.updatePrepNotes(
            sessionTitle = title,
            openingScene = opening,
            objectives = objectives,
            locations = locations,
            referenceNotes = referenceNotes,
            lootSuggestions = lootSuggestions,
            encounterNotes = encounterNotes,
            gmNotes = notes,
        )
        lastSavedAt = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        saveMessage = label
    }

    LaunchedEffect(title, opening, objectives, locations, referenceNotes, lootSuggestions, encounterNotes, notes) {
        if (notesDirty) {
            delay(2200)
            savePrep("Autosaved ✓")
        }
    }

    val pins = state.prep.pinnedPrepKeys
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Session Prep Workspace", fontSize = 26.sp)
        Text("Open only the section you need. Pin current work so it stays surfaced at the top of prep.")

        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(title.ifBlank { "Next Session" }, fontSize = 19.sp)
                    Text(
                        when {
                            notesDirty -> "Unsaved changes • autosaves shortly"
                            lastSavedAt.isNotBlank() -> "$saveMessage • Last saved $lastSavedAt"
                            saveMessage.isNotBlank() -> saveMessage
                            else -> "Saved to tablet"
                        }
                    )
                }
                Button(enabled = notesDirty, onClick = { savePrep("Saved ✓") }) { Text(if (notesDirty) "Save now" else "Saved") }
            }
        }

        PinnedPrepBar(
            runtime = runtime,
            pinnedKeys = pins,
            library = state.prep.enemyLibrary,
            encounters = state.prep.preparedEncounters,
        )

        PrepSection(
            title = "Overview",
            summary = title.ifBlank { "Session title & opening scene" },
            expanded = overviewOpen,
            onToggle = { overviewOpen = !overviewOpen },
            pinned = "section:overview" in pins,
            onPin = { runtime.store.togglePrepPin("section:overview") },
        ) {
            OutlinedTextField(title, { title = it }, label = { Text("Session title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(opening, { opening = it }, label = { Text("Opening scene") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Objectives / Quests",
            summary = if (objectives.isBlank()) "No objectives yet" else "Objectives ready",
            expanded = objectivesOpen,
            onToggle = { objectivesOpen = !objectivesOpen },
            pinned = "section:objectives" in pins,
            onPin = { runtime.store.togglePrepPin("section:objectives") },
        ) {
            OutlinedTextField(objectives, { objectives = it }, label = { Text("Objectives / quests") }, minLines = 4, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Locations",
            summary = if (locations.isBlank()) "No location notes" else "Location notes ready",
            expanded = locationsOpen,
            onToggle = { locationsOpen = !locationsOpen },
            pinned = "section:locations" in pins,
            onPin = { runtime.store.togglePrepPin("section:locations") },
        ) {
            OutlinedTextField(locations, { locations = it }, label = { Text("Locations / scene notes") }, minLines = 4, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Loot & Rewards",
            summary = if (lootSuggestions.isBlank()) "No reward notes" else "Reward notes ready",
            expanded = lootOpen,
            onToggle = { lootOpen = !lootOpen },
            pinned = "section:loot" in pins,
            onPin = { runtime.store.togglePrepPin("section:loot") },
        ) {
            OutlinedTextField(lootSuggestions, { lootSuggestions = it }, label = { Text("Loot / reward suggestions") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Reference Notes",
            summary = if (referenceNotes.isBlank()) "No reminders" else "Reference notes ready",
            expanded = referenceOpen,
            onToggle = { referenceOpen = !referenceOpen },
            pinned = "section:reference" in pins,
            onPin = { runtime.store.togglePrepPin("section:reference") },
        ) {
            OutlinedTextField(referenceNotes, { referenceNotes = it }, label = { Text("Reference notes / reminders") }, minLines = 4, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Encounter Beats",
            summary = if (encounterNotes.isBlank()) "No beat notes" else "Beat notes ready",
            expanded = beatsOpen,
            onToggle = { beatsOpen = !beatsOpen },
            pinned = "section:beats" in pins,
            onPin = { runtime.store.togglePrepPin("section:beats") },
        ) {
            OutlinedTextField(encounterNotes, { encounterNotes = it }, label = { Text("Encounters / beats") }, minLines = 4, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Private GM Notes",
            summary = if (notes.isBlank()) "No private notes" else "Private notes ready",
            expanded = gmNotesOpen,
            onToggle = { gmNotesOpen = !gmNotesOpen },
            pinned = "section:gmnotes" in pins,
            onPin = { runtime.store.togglePrepPin("section:gmnotes") },
        ) {
            OutlinedTextField(notes, { notes = it }, label = { Text("Private GM notes") }, minLines = 5, modifier = Modifier.fillMaxWidth())
        }

        PrepSection(
            title = "Enemies, NPCs & Hazards",
            summary = "${state.prep.enemyLibrary.size} library entries",
            expanded = libraryOpen,
            onToggle = { libraryOpen = !libraryOpen },
            pinned = "section:library" in pins,
            onPin = { runtime.store.togglePrepPin("section:library") },
        ) {
            CreatureLibraryEditor(runtime, state.prep.enemyLibrary, pins)
        }

        PrepSection(
            title = "Encounter Builder",
            summary = "${state.prep.preparedEncounters.size} prepared encounters",
            expanded = encountersOpen,
            onToggle = { encountersOpen = !encountersOpen },
            pinned = "section:encounters" in pins,
            onPin = { runtime.store.togglePrepPin("section:encounters") },
        ) {
            PreparedEncounterEditor(runtime, state.prep.enemyLibrary, state.prep.preparedEncounters, pins)
        }

        PrepSection(
            title = "Quick PF2e Reference",
            summary = "Budgets, MAP, saves, effects & recovery",
            expanded = rulesOpen,
            onToggle = { rulesOpen = !rulesOpen },
            pinned = "section:rules" in pins,
            onPin = { runtime.store.togglePrepPin("section:rules") },
        ) {
            QuickRulesReferenceContent()
        }

        PrepSection(
            title = "Backups",
            summary = "Manual campaign snapshots",
            expanded = backupsOpen,
            onToggle = { backupsOpen = !backupsOpen },
            pinned = "section:backups" in pins,
            onPin = { runtime.store.togglePrepPin("section:backups") },
        ) {
            Text("Manual snapshots include prep, encounters, combat history, inventory, player submissions, and completed encounter history.")
            Button(onClick = {
                val file = runtime.store.exportBackup()
                backupMessage = "Saved ${file.name}"
            }) { Text("Create backup") }
            val latest = runtime.store.listBackups().firstOrNull()
            OutlinedButton(
                enabled = latest != null,
                onClick = {
                    if (latest != null) {
                        backupMessage = if (runtime.store.restoreBackup(latest)) "Restored ${latest.name}" else "Restore failed"
                    }
                }
            ) { Text(if (latest == null) "No backup yet" else "Restore latest") }
            if (backupMessage.isNotBlank()) Text(backupMessage)
        }
    }
}

@Composable
private fun PrepSection(
    title: String,
    summary: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    pinned: Boolean,
    onPin: () -> Unit,
    content: @Composable () -> Unit,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onToggle, modifier = Modifier.weight(1f)) {
                    Column(Modifier.fillMaxWidth()) {
                        Text((if (expanded) "▾ " else "▸ ") + title, fontSize = 19.sp)
                        Text(summary, fontSize = 13.sp)
                    }
                }
                TextButton(onClick = onPin) { Text(if (pinned) "📌 Unpin" else "Pin") }
            }
            if (expanded) content()
        }
    }
}

@Composable
private fun PinnedPrepBar(
    runtime: HostRuntime,
    pinnedKeys: List<String>,
    library: List<PreparedEnemy>,
    encounters: List<PreparedEncounter>,
) {
    if (pinnedKeys.isEmpty()) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pinned Prep", fontSize = 20.sp)
                TextButton(onClick = { runtime.store.clearPrepPins() }) { Text("Clear all") }
            }
            Text("Keep current work surfaced here while the rest of Prep stays collapsed.")
            pinnedKeys.forEach { key ->
                when {
                    key.startsWith("encounter:") -> {
                        val encounter = encounters.firstOrNull { it.id == key.removePrefix("encounter:") }
                        if (encounter != null) {
                            val budget = encounterBudget(encounter.enemies, encounter.partyLevel, encounter.partySize)
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text("📌 ${encounter.name}", fontSize = 17.sp)
                                        Text("${budget.totalXp} XP • ${budget.difficulty} • ${encounter.enemies.sumOf { it.quantity }} entries")
                                    }
                                    Button(onClick = { runtime.store.startPreparedEncounter(encounter.id) }) { Text("Start") }
                                    TextButton(onClick = { runtime.store.togglePrepPin(key) }) { Text("Unpin") }
                                }
                            }
                        }
                    }
                    key.startsWith("enemy:") -> {
                        val enemy = library.firstOrNull { it.id == key.removePrefix("enemy:") }
                        if (enemy != null) {
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text("📌 ${enemy.name}", fontSize = 17.sp)
                                        Text("${enemy.kind}${enemy.level?.let { " • Level $it" } ?: ""} • HP ${enemy.maxHp} • AC ${enemy.armorClass ?: "—"}")
                                    }
                                    TextButton(onClick = { runtime.store.togglePrepPin(key) }) { Text("Unpin") }
                                }
                            }
                        }
                    }
                    else -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("📌 ${prepPinLabel(key, library, encounters)}", modifier = Modifier.weight(1f))
                            TextButton(onClick = { runtime.store.togglePrepPin(key) }) { Text("Unpin") }
                        }
                    }
                }
            }
        }
    }
}

private fun prepPinLabel(key: String, library: List<PreparedEnemy>, encounters: List<PreparedEncounter>): String = when {
    key == "section:overview" -> "Overview"
    key == "section:objectives" -> "Objectives"
    key == "section:locations" -> "Locations"
    key == "section:loot" -> "Loot & Rewards"
    key == "section:reference" -> "Reference Notes"
    key == "section:beats" -> "Encounter Beats"
    key == "section:gmnotes" -> "GM Notes"
    key == "section:library" -> "Enemy Library"
    key == "section:encounters" -> "Encounter Builder"
    key == "section:rules" -> "Quick Rules"
    key == "section:backups" -> "Backups"
    key.startsWith("enemy:") -> library.firstOrNull { it.id == key.removePrefix("enemy:") }?.name ?: "Enemy"
    key.startsWith("encounter:") -> encounters.firstOrNull { it.id == key.removePrefix("encounter:") }?.name ?: "Encounter"
    else -> "Prep item"
}

@Composable
private fun CreatureLibraryEditor(runtime: HostRuntime, library: List<PreparedEnemy>, pinnedKeys: List<String>) {
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(PrepEntryKind.CREATURE) }
    var hp by remember { mutableStateOf("10") }
    var level by remember { mutableStateOf("") }
    var initMod by remember { mutableStateOf("0") }
    var ac by remember { mutableStateOf("") }
    var fort by remember { mutableStateOf("") }
    var reflex by remember { mutableStateOf("") }
    var will by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var traits by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }
    var hazardComplexity by remember { mutableStateOf(HazardComplexity.COMPLEX) }
    var gmNotes by remember { mutableStateOf("") }
    var publicNotes by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var filterKind by remember { mutableStateOf("All") }
    var librarySaveStatus by remember { mutableStateOf("") }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Creature, NPC & Hazard Library", fontSize = 20.sp)
            Text("Reusable combat entries. Search by name, role, trait, tag, or kind.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it.take(60) }, label = { Text("Name") }, modifier = Modifier.weight(1.5f))
                SimpleMenuButton("Type", kind, listOf(PrepEntryKind.CREATURE, PrepEntryKind.NPC, PrepEntryKind.HAZARD)) { kind = it }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(hp, { hp = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Max HP") }, modifier = Modifier.weight(1f))
                OutlinedTextField(level, { level = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Level") }, modifier = Modifier.weight(1f))
                OutlinedTextField(initMod, { initMod = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Init mod") }, modifier = Modifier.weight(1f))
                if (kind == PrepEntryKind.HAZARD) {
                    SimpleMenuButton("Hazard", hazardComplexity, listOf(HazardComplexity.SIMPLE, HazardComplexity.COMPLEX)) { hazardComplexity = it }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(ac, { ac = it.filter(Char::isDigit).take(3) }, label = { Text("AC") }, modifier = Modifier.weight(1f))
                OutlinedTextField(fort, { fort = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Fort") }, modifier = Modifier.weight(1f))
                OutlinedTextField(reflex, { reflex = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Reflex") }, modifier = Modifier.weight(1f))
                OutlinedTextField(will, { will = it.filter { c -> c.isDigit() || c == '-' }.take(3) }, label = { Text("Will") }, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(role, { role = it.take(40) }, label = { Text("Role / purpose") }, modifier = Modifier.weight(1f))
                OutlinedTextField(traits, { traits = it.take(100) }, label = { Text("Traits") }, modifier = Modifier.weight(1f))
                OutlinedTextField(tags, { tags = it.take(100) }, label = { Text("Search tags") }, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(publicNotes, { publicNotes = it.take(200) }, label = { Text("Player-visible note") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(gmNotes, { gmNotes = it.take(500) }, label = { Text("Private GM note") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                if (name.isNotBlank()) {
                    runtime.store.saveEnemyToLibrary(
                        PreparedEnemy(
                            name = name.trim(),
                            kind = kind,
                            level = level.toIntOrNull(),
                            maxHp = hp.toIntOrNull()?.coerceAtLeast(1) ?: 10,
                            armorClass = ac.toIntOrNull(),
                            fortitude = fort.toIntOrNull(),
                            reflex = reflex.toIntOrNull(),
                            will = will.toIntOrNull(),
                            initiativeModifier = initMod.toIntOrNull() ?: 0,
                            hazardComplexity = hazardComplexity,
                            role = role,
                            traits = traits,
                            tags = tags,
                            gmNotes = gmNotes,
                            publicNotes = publicNotes,
                        )
                    )
                    name = ""
                    role = ""
                    traits = ""
                    tags = ""
                    gmNotes = ""
                    publicNotes = ""
                    librarySaveStatus = "Saved to library ✓"
                }
            }) { Text("Save to library") }
            if (librarySaveStatus.isNotBlank()) Text(librarySaveStatus)

            if (library.isNotEmpty()) {
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(search, { search = it.take(80) }, label = { Text("Search library") }, modifier = Modifier.weight(1f))
                    SimpleMenuButton("Filter", filterKind, listOf("All", PrepEntryKind.CREATURE, PrepEntryKind.NPC, PrepEntryKind.HAZARD)) { filterKind = it }
                }
                val q = search.trim().lowercase()
                val visible = library.filter { entry ->
                    (filterKind == "All" || entry.kind == filterKind) &&
                        (q.isBlank() || listOf(entry.name, entry.role, entry.traits, entry.tags, entry.kind).any { it.lowercase().contains(q) })
                }
                if (visible.isEmpty()) Text("No matching library entries.")
                visible.forEach { entry ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("${entry.name} • ${entry.kind}${entry.level?.let { " • Level $it" } ?: ""}")
                            val roleText = listOf(entry.role, entry.traits).filter { it.isNotBlank() }.joinToString(" • ")
                            if (roleText.isNotBlank()) Text(roleText)
                            Text("HP ${entry.maxHp} • AC ${entry.armorClass ?: "—"} • Fort ${signed(entry.fortitude)} • Ref ${signed(entry.reflex)} • Will ${signed(entry.will)}")
                            if (entry.kind == PrepEntryKind.HAZARD) Text("${entry.hazardComplexity} hazard")
                        }
                        val pinKey = "enemy:${entry.id}"
                        OutlinedButton(onClick = { runtime.store.togglePrepPin(pinKey) }) {
                            Text(if (pinKey in pinnedKeys) "Unpin" else "Pin")
                        }
                        OutlinedButton(onClick = { runtime.store.deleteEnemyFromLibrary(entry.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreparedEncounterEditor(
    runtime: HostRuntime,
    library: List<PreparedEnemy>,
    prepared: List<PreparedEncounter>,
    pinnedKeys: List<String>,
) {
    var encounterName by remember { mutableStateOf("") }
    var startingNotes by remember { mutableStateOf("") }
    var gmNotes by remember { mutableStateOf("") }
    var partyLevel by remember { mutableStateOf("1") }
    var partySize by remember { mutableStateOf("4") }
    var templateTag by remember { mutableStateOf("Standard") }
    var librarySearch by remember { mutableStateOf("") }
    var draftEnemies by remember { mutableStateOf<List<PreparedEnemy>>(emptyList()) }
    var encounterSaveStatus by remember { mutableStateOf("") }

    val pLevel = partyLevel.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val pSize = partySize.toIntOrNull()?.coerceIn(1, 12) ?: 4
    val budget = encounterBudget(draftEnemies, pLevel, pSize)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Encounter Builder", fontSize = 20.sp)
            Text("The XP meter uses party level and party size. Weak/Elite changes the entry's effective level for the budget and applies the combat stat adjustment when launched.")
            OutlinedTextField(encounterName, { encounterName = it.take(70) }, label = { Text("Encounter name") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(partyLevel, { partyLevel = it.filter(Char::isDigit).take(2) }, label = { Text("Party level") }, modifier = Modifier.weight(1f))
                OutlinedTextField(partySize, { partySize = it.filter(Char::isDigit).take(2) }, label = { Text("Party size") }, modifier = Modifier.weight(1f))
                SimpleMenuButton("Template", templateTag, listOf("Standard", "Boss", "Horde", "Hazard", "Mixed", "Custom")) { templateTag = it }
            }
            EncounterBudgetCard(budget.totalXp, budget.difficulty, budget.trivial, budget.low, budget.moderate, budget.severe, budget.extreme)
            OutlinedTextField(startingNotes, { startingNotes = it.take(500) }, label = { Text("Starting positions / order notes") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(gmNotes, { gmNotes = it.take(800) }, label = { Text("Private encounter notes") }, modifier = Modifier.fillMaxWidth())

            Text("Add from Library")
            OutlinedTextField(librarySearch, { librarySearch = it.take(80) }, label = { Text("Search creatures, NPCs, hazards") }, modifier = Modifier.fillMaxWidth())
            val q = librarySearch.trim().lowercase()
            val choices = library.filter { entry ->
                q.isBlank() || listOf(entry.name, entry.role, entry.traits, entry.tags, entry.kind).any { it.lowercase().contains(q) }
            }.take(16)
            if (choices.isEmpty()) Text("No matching entries. Add one to the library above.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                choices.forEach { entry ->
                    FilledTonalButton(onClick = {
                        val existing = draftEnemies.firstOrNull { it.id == entry.id }
                        draftEnemies = if (existing == null) {
                            draftEnemies + entry.copy(quantity = 1, adjustment = EncounterAdjustment.NORMAL)
                        } else {
                            draftEnemies.map { if (it.id == entry.id) it.copy(quantity = it.quantity + 1) else it }
                        }
                    }) { Text("+ ${entry.name}") }
                }
            }

            if (draftEnemies.isNotEmpty()) {
                Text("Encounter roster", fontSize = 18.sp)
                draftEnemies.forEach { entry ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("${entry.name} ×${entry.quantity}")
                                    Text("${entry.kind} • ${entry.adjustment} • Effective level ${effectiveLevel(entry)?.toString() ?: "—"} • ${entryXp(entry, pLevel)} XP")
                                }
                                OutlinedButton(onClick = {
                                    draftEnemies = draftEnemies.map { if (it.id == entry.id) it.copy(quantity = it.quantity + 1) else it }
                                }) { Text("+") }
                                OutlinedButton(onClick = {
                                    draftEnemies = if (entry.quantity <= 1) draftEnemies.filterNot { it.id == entry.id }
                                    else draftEnemies.map { if (it.id == entry.id) it.copy(quantity = it.quantity - 1) else it }
                                }) { Text("−") }
                                TextButton(onClick = { draftEnemies = draftEnemies.filterNot { it.id == entry.id } }) { Text("Remove") }
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(EncounterAdjustment.WEAK, EncounterAdjustment.NORMAL, EncounterAdjustment.ELITE).forEach { option ->
                                    if (entry.adjustment == option) {
                                        FilledTonalButton(onClick = {}) { Text(option) }
                                    } else {
                                        OutlinedButton(onClick = {
                                            draftEnemies = draftEnemies.map { if (it.id == entry.id) it.copy(adjustment = option) else it }
                                        }) { Text(option) }
                                    }
                                }
                                if (entry.kind == PrepEntryKind.HAZARD) {
                                    Text("${entry.hazardComplexity} hazard")
                                }
                            }
                        }
                    }
                }
            }

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = {
                    if (encounterName.isNotBlank()) {
                        runtime.store.savePreparedEncounter(
                            PreparedEncounter(
                                name = encounterName.trim(),
                                startingNotes = startingNotes,
                                gmNotes = gmNotes,
                                enemies = draftEnemies,
                                partyLevel = pLevel,
                                partySize = pSize,
                                templateTag = templateTag,
                            )
                        )
                        encounterName = ""
                        startingNotes = ""
                        gmNotes = ""
                        draftEnemies = emptyList()
                        encounterSaveStatus = "Encounter template saved ✓"
                    }
                }) { Text("Save encounter template") }
                OutlinedButton(onClick = {
                    encounterName = when (templateTag) {
                        "Boss" -> "Boss Encounter"
                        "Horde" -> "Horde Encounter"
                        "Hazard" -> "Hazard Encounter"
                        "Mixed" -> "Mixed Encounter"
                        else -> "New Encounter"
                    }
                    startingNotes = when (templateTag) {
                        "Boss" -> "Boss starts in a strong position; note phase or terrain triggers here."
                        "Horde" -> "Group identical creatures and plan reinforcements or morale here."
                        "Hazard" -> "Record trigger, reset, disable, and environmental clues here."
                        else -> startingNotes
                    }
                }) { Text("Apply template starter") }
            }
            if (encounterSaveStatus.isNotBlank()) Text(encounterSaveStatus)

            if (prepared.isNotEmpty()) {
                HorizontalDivider()
                Text("Saved encounters", fontSize = 18.sp)
                prepared.forEach { encounter ->
                    val savedBudget = encounterBudget(encounter.enemies, encounter.partyLevel, encounter.partySize)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(encounter.name, fontSize = 17.sp)
                            Text("${encounter.templateTag.ifBlank { "Standard" }} • Party ${encounter.partySize} @ level ${encounter.partyLevel} • ${savedBudget.totalXp} XP • ${savedBudget.difficulty}")
                            Text(if (encounter.enemies.isEmpty()) "No entries" else encounter.enemies.joinToString(" • ") { "${it.name} ×${it.quantity} (${it.adjustment})" })
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(onClick = { runtime.store.startPreparedEncounter(encounter.id) }) { Text("Start Encounter") }
                                val pinKey = "encounter:${encounter.id}"
                                OutlinedButton(onClick = { runtime.store.togglePrepPin(pinKey) }) { Text(if (pinKey in pinnedKeys) "Unpin" else "Pin") }
                                OutlinedButton(onClick = { runtime.store.duplicatePreparedEncounter(encounter.id) }) { Text("Duplicate") }
                                TextButton(onClick = { runtime.store.deletePreparedEncounter(encounter.id) }) { Text("Delete") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EncounterBudgetCard(total: Int, difficulty: String, trivial: Int, low: Int, moderate: Int, severe: Int, extreme: Int) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Encounter budget: $total XP • $difficulty", fontSize = 18.sp)
            Text("Trivial $trivial • Low $low • Moderate $moderate • Severe $severe • Extreme $extreme")
            if (difficulty == "Extreme+") Text("Above the adjusted Extreme budget. Treat this as outside the normal encounter-building range.")
            if (total == 0) Text("Entries without a level are not counted in the XP budget.")
        }
    }
}

@Composable
private fun QuickRulesReferenceContent() {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("Encounter budgets (4 PCs): Trivial 40 • Low 60 • Moderate 80 • Severe 120 • Extreme 160. TT Helper scales these for party size.")
        Text("MAP: usually 0 / −5 / −10; Agile usually 0 / −4 / −8.")
        Text("Basic save: critical success 0, success half, failure full, critical failure double.")
        Text("Frightened normally decreases by 1 at the end of the affected creature's turn.")
        Text("Persistent damage resolves at the end of the affected creature's turn, followed by its flat check when applicable.")
        Text("Delay changes initiative position. Ready records the chosen action/trigger and uses the reaction when triggered.")
        Text("Recovery checks and Dying/Wounded are handled through the effect/check reminder system when configured.")
        Text("Use Rules requests when you want the GM to approve an attack, save, secret check, damage, or consequence before it changes state.")
    }
}

@Composable
private fun SimpleMenuButton(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text("$label: $value") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        open = false
                    },
                )
            }
        }
    }
}

private fun signed(value: Int?): String = value?.let { if (it >= 0) "+$it" else "$it" } ?: "—"
