package com.drew.tthelper.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime
@Composable fun GmSpellScreen(runtime: HostRuntime){
 val state by runtime.store.state.collectAsState(); var id by remember{mutableStateOf(state.pcs.firstOrNull()?.id)}; val pc=state.pcs.firstOrNull{it.id==id}?:state.pcs.firstOrNull()
 Row(Modifier.fillMaxSize().padding(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){
  Column(Modifier.width(250.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Spellcasting",fontSize=24.sp); state.pcs.forEach{p->OutlinedButton(onClick={id=p.id},modifier=Modifier.fillMaxWidth()){Text(p.name)}}}
  if(pc!=null) Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){Text(pc.name,fontSize=26.sp); SpellcastingPanel(runtime,pc,true)}
 }
}
