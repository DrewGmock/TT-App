package com.drew.tthelper.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.server.HostRuntime

internal data class UiPreferences(
    val themeMode: String = "system",
    val fontScale: Float = 1f,
    val densityMode: String = "comfortable",
    val highContrast: Boolean = false,
    val quickBar: Boolean = true,
)

internal fun loadUiPreferences(context: Context): UiPreferences {
    val p = context.getSharedPreferences("tthelper-ui", Context.MODE_PRIVATE)
    return UiPreferences(
        themeMode = p.getString("themeMode", "system") ?: "system",
        fontScale = p.getFloat("fontScale", 1f),
        densityMode = p.getString("densityMode", "comfortable") ?: "comfortable",
        highContrast = p.getBoolean("highContrast", false),
        quickBar = p.getBoolean("quickBar", true),
    )
}

internal fun saveUiPreferences(context: Context, value: UiPreferences) {
    context.getSharedPreferences("tthelper-ui", Context.MODE_PRIVATE).edit()
        .putString("themeMode", value.themeMode)
        .putFloat("fontScale", value.fontScale)
        .putString("densityMode", value.densityMode)
        .putBoolean("highContrast", value.highContrast)
        .putBoolean("quickBar", value.quickBar)
        .apply()
}

@Composable
internal fun SettingsScreen(
    runtime: HostRuntime,
    preferences: UiPreferences,
    onPreferencesChanged: (UiPreferences) -> Unit,
) {
    val status by runtime.status.collectAsState()
    val displayUrl = if (status.running && status.address != null) {
        "http://${status.address}:${status.port}/display"
    } else null

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Table Experience", fontSize = 26.sp)
        Text("Customize the GM tablet without changing campaign data. These settings stay on this device.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Appearance", fontSize = 20.sp)
                Text("Theme")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (value, label) ->
                        FilterChip(
                            selected = preferences.themeMode == value,
                            onClick = { onPreferencesChanged(preferences.copy(themeMode = value)) },
                            label = { Text(label) },
                        )
                    }
                }
                Text("Text size")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(.9f to "Small", 1f to "Normal", 1.15f to "Large", 1.3f to "Extra large").forEach { (value, label) ->
                        FilterChip(
                            selected = kotlin.math.abs(preferences.fontScale - value) < .02f,
                            onClick = { onPreferencesChanged(preferences.copy(fontScale = value)) },
                            label = { Text(label) },
                        )
                    }
                }
                Text("Workspace density")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("compact" to "Compact", "comfortable" to "Comfortable").forEach { (value, label) ->
                        FilterChip(
                            selected = preferences.densityMode == value,
                            onClick = { onPreferencesChanged(preferences.copy(densityMode = value)) },
                            label = { Text(label) },
                        )
                    }
                }
                ToggleRow("High contrast", preferences.highContrast) {
                    onPreferencesChanged(preferences.copy(highContrast = it))
                }
                ToggleRow("Persistent GM quick bar", preferences.quickBar) {
                    onPreferencesChanged(preferences.copy(quickBar = it))
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Second-screen / TV mode", fontSize = 20.sp)
                if (displayUrl == null) {
                    Text("Start the host, then this tablet will show a player-safe display address for a TV, monitor, or spare browser.")
                } else {
                    Text(displayUrl)
                    Text("Open this address on any device on the same Wi-Fi. It shows only public encounter information: round, current turn, initiative, party status, visible enemies, and public effects.")
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Accessibility", fontSize = 20.sp)
                Text("Status and condition information uses text labels in addition to color. Font scaling and high contrast can be combined for a larger, clearer table view.")
                OutlinedButton(onClick = {
                    onPreferencesChanged(UiPreferences())
                }) { Text("Reset display settings") }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    androidx.compose.foundation.layout.Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
