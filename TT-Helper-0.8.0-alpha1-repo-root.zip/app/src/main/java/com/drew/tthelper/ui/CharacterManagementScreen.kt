package com.drew.tthelper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.standardSkillNames
import com.drew.tthelper.server.HostRuntime
import org.json.JSONObject

@Composable
fun CharacterManagementScreen(runtime: HostRuntime) {
    val state by runtime.store.state.collectAsState()
    var selectedId by remember { mutableStateOf(state.pcs.firstOrNull()?.id) }
    val pc = state.pcs.firstOrNull { it.id == selectedId } ?: state.pcs.firstOrNull()
    Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.width(250.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Characters", fontSize = 24.sp)
            state.pcs.forEach { candidate ->
                OutlinedButton(onClick = { selectedId = candidate.id }, modifier = Modifier.fillMaxWidth()) { Text(candidate.name) }
            }
        }
        if (pc != null) CharacterEditor(runtime, pc, Modifier.weight(1f))
    }
}

@Composable
private fun CharacterEditor(runtime: HostRuntime, pc: PlayerCharacter, modifier: Modifier) {
    var name by remember(pc.id, pc.name) { mutableStateOf(pc.name) }
    var ancestry by remember(pc.id, pc.ancestry) { mutableStateOf(pc.ancestry) }
    var heritage by remember(pc.id, pc.heritage) { mutableStateOf(pc.heritage) }
    var background by remember(pc.id, pc.background) { mutableStateOf(pc.background) }
    var cls by remember(pc.id, pc.characterClass) { mutableStateOf(pc.characterClass) }
    var level by remember(pc.id, pc.level) { mutableStateOf(pc.level?.toString().orEmpty()) }

    var hp by remember(pc.id, pc.hp) { mutableStateOf(pc.hp.toString()) }
    var maxHp by remember(pc.id, pc.maxHp) { mutableStateOf(pc.maxHp.toString()) }
    var tempHp by remember(pc.id, pc.tempHp) { mutableStateOf(pc.tempHp.toString()) }
    var size by remember(pc.id, pc.stats.size) { mutableStateOf(pc.stats.size) }
    var speed by remember(pc.id, pc.stats.speed) { mutableStateOf(pc.stats.speed.toString()) }
    var languages by remember(pc.id, pc.stats.languages) { mutableStateOf(pc.stats.languages) }
    var senses by remember(pc.id, pc.stats.senses) { mutableStateOf(pc.stats.senses) }

    var str by remember(pc.id, pc.stats.strength) { mutableStateOf(pc.stats.strength.toString()) }
    var dex by remember(pc.id, pc.stats.dexterity) { mutableStateOf(pc.stats.dexterity.toString()) }
    var con by remember(pc.id, pc.stats.constitution) { mutableStateOf(pc.stats.constitution.toString()) }
    var intel by remember(pc.id, pc.stats.intelligence) { mutableStateOf(pc.stats.intelligence.toString()) }
    var wis by remember(pc.id, pc.stats.wisdom) { mutableStateOf(pc.stats.wisdom.toString()) }
    var cha by remember(pc.id, pc.stats.charisma) { mutableStateOf(pc.stats.charisma.toString()) }

    var ac by remember(pc.id, pc.stats.armorClass) { mutableStateOf(pc.stats.armorClass.toString()) }
    var perception by remember(pc.id, pc.stats.perception) { mutableStateOf(pc.stats.perception.toString()) }
    var fort by remember(pc.id, pc.stats.fortitude) { mutableStateOf(pc.stats.fortitude.toString()) }
    var reflex by remember(pc.id, pc.stats.reflex) { mutableStateOf(pc.stats.reflex.toString()) }
    var will by remember(pc.id, pc.stats.will) { mutableStateOf(pc.stats.will.toString()) }
    var classDc by remember(pc.id, pc.stats.classDc) { mutableStateOf(pc.stats.classDc.toString()) }
    var spellDc by remember(pc.id, pc.spellcasting.spellDc) { mutableStateOf(pc.spellcasting.spellDc.toString()) }
    var spellAttack by remember(pc.id, pc.spellcasting.spellAttackModifier) { mutableStateOf(pc.spellcasting.spellAttackModifier.toString()) }

    val skillValues = remember(pc.id, pc.stats.skillModifiers) { mutableStateMapOf<String, String>().apply { standardSkillNames.forEach { put(it, (pc.stats.skillModifiers[it] ?: 0).toString()) } } }
    val skillProfs = remember(pc.id, pc.stats.skillProficiencies) { mutableStateMapOf<String, String>().apply { standardSkillNames.forEach { put(it, pc.stats.skillProficiencies[it] ?: "Untrained") } } }
    var weaponProf by remember(pc.id, pc.stats.weaponProficiency) { mutableStateOf(pc.stats.weaponProficiency) }
    var armorProf by remember(pc.id, pc.stats.armorProficiency) { mutableStateOf(pc.stats.armorProficiency) }
    var immunities by remember(pc.id, pc.stats.immunities) { mutableStateOf(pc.stats.immunities) }
    var resistances by remember(pc.id, pc.stats.resistances) { mutableStateOf(pc.stats.resistances) }
    var weaknesses by remember(pc.id, pc.stats.weaknesses) { mutableStateOf(pc.stats.weaknesses) }

    var featName by remember(pc.id) { mutableStateOf("") }
    var featType by remember(pc.id) { mutableStateOf("Class Feat") }
    var featLevel by remember(pc.id) { mutableStateOf("") }
    var featTraits by remember(pc.id) { mutableStateOf("") }
    var featPrereq by remember(pc.id) { mutableStateOf("") }
    var featNotes by remember(pc.id) { mutableStateOf("") }

    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(pc.name, fontSize = 26.sp)
        Text("Identity", fontSize = 20.sp)
        OutlinedTextField(name, { name = it.take(60) }, label={Text("Name")}, modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(ancestry,{ancestry=it.take(60)},label={Text("Ancestry")},modifier=Modifier.weight(1f))
            OutlinedTextField(heritage,{heritage=it.take(80)},label={Text("Heritage")},modifier=Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(background,{background=it.take(80)},label={Text("Background")},modifier=Modifier.weight(1f))
            OutlinedTextField(cls,{cls=it.take(80)},label={Text("Class")},modifier=Modifier.weight(1f))
            SmallNumberField(level, { level = it }, "Level")
        }
        Button(onClick={runtime.store.updateCharacterProfile(pc.id,name,ancestry,heritage,background,cls,level.toIntOrNull())}) { Text("Save profile") }

        HorizontalDivider()
        Text("Character Sheet", fontSize = 20.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallNumberField(hp, { hp = it }, "HP")
            SmallNumberField(maxHp, { maxHp = it }, "Max HP")
            SmallNumberField(tempHp, { tempHp = it }, "Temp HP")
            OutlinedTextField(size, { size = it.take(30) }, label={Text("Size")}, modifier=Modifier.width(130.dp))
            SmallNumberField(speed, { speed = it }, "Speed")
        }
        Text("Ability modifiers")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SignedField(str,{str=it},"STR"); SignedField(dex,{dex=it},"DEX"); SignedField(con,{con=it},"CON")
            SignedField(intel,{intel=it},"INT"); SignedField(wis,{wis=it},"WIS"); SignedField(cha,{cha=it},"CHA")
        }
        Text("Defenses & DCs")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallNumberField(ac,{ac=it},"AC"); SignedField(perception,{perception=it},"Perception"); SignedField(fort,{fort=it},"Fort")
            SignedField(reflex,{reflex=it},"Reflex"); SignedField(will,{will=it},"Will"); SmallNumberField(classDc,{classDc=it},"Class DC")
            SmallNumberField(spellDc,{spellDc=it},"Spell DC"); SignedField(spellAttack,{spellAttack=it},"Spell Atk")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(languages,{languages=it.take(500)},label={Text("Languages")},modifier=Modifier.weight(1f))
            OutlinedTextField(senses,{senses=it.take(500)},label={Text("Senses")},modifier=Modifier.weight(1f))
        }
        Text("Skills")
        standardSkillNames.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { skill ->
                    Card(Modifier.weight(1f)) {
                        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(skillValues[skill].orEmpty(), { skillValues[skill] = cleanSigned(it) }, label={Text(skill)}, modifier=Modifier.weight(1f))
                            ProficiencyMenu(skillProfs[skill] ?: "Untrained") { skillProfs[skill] = it }
                        }
                    }
                }
            }
        }
        OutlinedTextField(weaponProf,{weaponProf=it.take(500)},label={Text("Weapon proficiencies")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(armorProf,{armorProf=it.take(500)},label={Text("Armor proficiencies")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(immunities,{immunities=it.take(500)},label={Text("Immunities")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(resistances,{resistances=it.take(500)},label={Text("Resistances")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(weaknesses,{weaknesses=it.take(500)},label={Text("Weaknesses")},modifier=Modifier.fillMaxWidth())
        Button(onClick = {
            val skillMods = JSONObject().apply { standardSkillNames.forEach { put(it, skillValues[it]?.toIntOrNull() ?: 0) } }
            val profs = JSONObject().apply { standardSkillNames.forEach { put(it, skillProfs[it] ?: "Untrained") } }
            val stats = JSONObject().apply {
                put("size", size); put("speed", speed.toIntOrNull() ?: 25); put("languages", languages); put("senses", senses)
                put("strength", str.toIntOrNull() ?: 0); put("dexterity", dex.toIntOrNull() ?: 0); put("constitution", con.toIntOrNull() ?: 0)
                put("intelligence", intel.toIntOrNull() ?: 0); put("wisdom", wis.toIntOrNull() ?: 0); put("charisma", cha.toIntOrNull() ?: 0)
                put("armorClass", ac.toIntOrNull() ?: 10); put("perception", perception.toIntOrNull() ?: 0); put("fortitude", fort.toIntOrNull() ?: 0)
                put("reflex", reflex.toIntOrNull() ?: 0); put("will", will.toIntOrNull() ?: 0); put("classDc", classDc.toIntOrNull() ?: 0)
                put("skillModifiers", skillMods); put("skillProficiencies", profs); put("weaponProficiency", weaponProf); put("armorProficiency", armorProf)
                put("immunities", immunities); put("resistances", resistances); put("weaknesses", weaknesses)
            }
            runtime.store.saveCharacterSheet(pc.id, JSONObject().apply {
                put("hp", hp.toIntOrNull() ?: pc.hp); put("maxHp", maxHp.toIntOrNull() ?: pc.maxHp); put("tempHp", tempHp.toIntOrNull() ?: pc.tempHp)
                put("spellDc", spellDc.toIntOrNull() ?: pc.spellcasting.spellDc); put("spellAttackModifier", spellAttack.toIntOrNull() ?: pc.spellcasting.spellAttackModifier)
                put("stats", stats)
            })
        }) { Text("Save character sheet") }

        HorizontalDivider()
        Text("Feats", fontSize=20.sp)
        pc.feats.sortedWith(compareBy({it.type},{it.level ?: 0},{it.name})).forEach { feat ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) { Text(feat.name); Text("${feat.type}${feat.level?.let { " • Level $it" } ?: ""}", fontSize=12.sp); if(feat.traits.isNotBlank()) Text("Traits: ${feat.traits}",fontSize=12.sp); if(feat.notes.isNotBlank()) Text(feat.notes,fontSize=12.sp) }
                OutlinedButton(onClick={runtime.store.removeFeat(pc.id, feat.id)}) { Text("Remove") }
            } }
        }
        OutlinedTextField(featName,{featName=it.take(80)},label={Text("Feat name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(featType,{featType=it.take(50)},label={Text("Feat type")},modifier=Modifier.fillMaxWidth())
        FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("Ancestry Feat","Class Feat","Skill Feat","General Feat","Archetype Feat").forEach { t -> TextButton(onClick={featType=t}){Text(t)} } }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { SmallNumberField(featLevel,{featLevel=it},"Feat level"); OutlinedTextField(featTraits,{featTraits=it.take(180)},label={Text("Traits")},modifier=Modifier.weight(1f)) }
        OutlinedTextField(featPrereq,{featPrereq=it.take(240)},label={Text("Prerequisites")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(featNotes,{featNotes=it.take(600)},label={Text("Notes")},modifier=Modifier.fillMaxWidth())
        Button(onClick={ runtime.store.addFeat(pc.id,featName,featType,featLevel.toIntOrNull(),featTraits,featPrereq,featNotes); featName=""; featNotes="" }) { Text("Add feat") }
    }
}

@Composable
private fun SmallNumberField(value: String, onChange: (String) -> Unit, label: String) = OutlinedTextField(
    value = value,
    onValueChange = { onChange(it.filter(Char::isDigit).take(3)) },
    label = { Text(label) },
    modifier = Modifier.width(110.dp),
)

@Composable
private fun SignedField(value: String, onChange: (String) -> Unit, label: String) = OutlinedTextField(
    value = value,
    onValueChange = { onChange(cleanSigned(it)) },
    label = { Text(label) },
    modifier = Modifier.width(115.dp),
)

private fun cleanSigned(value: String): String = value.filterIndexed { index, ch -> ch.isDigit() || (ch == '-' && index == 0) }.take(4)

@Composable
private fun ProficiencyMenu(value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text(value.take(3)) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf("Untrained", "Trained", "Expert", "Master", "Legendary").forEach { rank ->
                DropdownMenuItem(text = { Text(rank) }, onClick = { onChange(rank); expanded = false })
            }
        }
    }
}
