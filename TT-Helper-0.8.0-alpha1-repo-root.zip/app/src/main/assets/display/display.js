(() => {
  const $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  function chips(items){ return (items||[]).map(c=>`<span class="chip">${esc(c.name)}${c.value!=null?` ${c.value}`:''}</span>`).join(''); }
  function render(data){
    $('campaign').textContent=data.campaignName||'Campaign'; $('scene').textContent=data.sceneName||'Between sessions';
    const e=data.encounter; $('encounter').classList.toggle('hidden',!e||!e.active);
    if(e&&e.active){$('encounter-name').textContent=e.name||'Encounter';$('round').textContent=`Round ${e.round||1}`;$('current-turn').textContent=e.currentName||'Waiting';}
    $('initiative').innerHTML=e&&e.active?(e.initiative||[]).map(x=>`<div class="row ${x.current?'current':''} ${x.defeated?'defeated':''}"><strong>${esc(x.name)}</strong><span>${x.initiative==null?'—':x.initiative}</span></div>`).join(''):'<div class="muted">No active encounter.</div>';
    $('party').innerHTML=(data.party||[]).map(pc=>`<div class="row"><div><strong>${esc(pc.name)}</strong><div class="chips">${chips(pc.conditions)}</div></div><div class="hp">${pc.hp}/${pc.maxHp}${pc.tempHp?` +${pc.tempHp}`:''}</div></div>`).join('')||'<div class="muted">No party data.</div>';
    $('enemies').innerHTML=e&&e.active?(e.enemies||[]).map(x=>`<div class="enemy ${x.defeated?'defeated':''}"><strong>${esc(x.name)}</strong><div class="muted">${esc(x.health)}</div><div class="chips">${chips(x.conditions)}</div></div>`).join(''):'<div class="muted">No visible enemies.</div>';
  }
  async function refresh(){try{const r=await fetch('/api/display',{cache:'no-store'});if(!r.ok)throw new Error();render(await r.json());$('connection').textContent='Live';}catch(_){$('connection').textContent='Reconnecting…';}}
  refresh(); setInterval(refresh,1200);
})();
