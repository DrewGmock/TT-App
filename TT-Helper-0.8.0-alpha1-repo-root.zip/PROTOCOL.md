# TT Helper LAN & Display Protocol — 0.8.0-alpha1

The GM Android app remains the authoritative state owner. Players connect through the embedded LAN web client and receive filtered snapshots.

## Player client
- `GET /` serves the player application.
- Authenticated player state is delivered over `/ws` using the assigned player token.
- Client UI preferences (theme, text size, tab order, last selected page) are browser-local and are not authoritative campaign state.
- When the socket drops, the client keeps its cached snapshot visible, shows `Reconnecting…`, and retries.

## Second-screen / TV mode
- `GET /display` serves a read-only public table display.
- `GET /api/display` returns the filtered display snapshot polled by that page.
- Display data includes campaign/scene, active encounter name, round/current turn, initiative names/order, public party HP/status, visible enemy health descriptions, and public/party-inflicted effects.
- It explicitly excludes exact enemy HP/AC/saves, GM notes, hidden loot, private Session Prep, submissions, secret checks, and private rules data.

## GM UI preferences
GM theme, font scale, density, high-contrast mode, and Quick Bar visibility are stored in Android SharedPreferences. They do not alter campaign save data or exported content packages.

## Content packages
Existing 0.7 package formats remain unchanged:
- `.ttsession`
- `.ttenemy`
- `.ttenemypack`
- `.ttloot`
- `.ttlootpack`

Prep pins remain local GM workspace state and are not exported.
