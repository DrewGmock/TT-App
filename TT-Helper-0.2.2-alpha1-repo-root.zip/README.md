# TT Helper — LAN Alpha 0.2.2

TT Helper is a local-first Pathfinder 2e table helper. The Samsung/Android GM tablet is the authoritative host; players connect from phone/tablet browsers on the same LAN.

## 0.2.2 highlights

- Encounter and initiative tracker with grouped enemies, Delay, Ready, HP, effects, loot, history, and Undo.
- Effect timing engine with source/target turn anchoring and recurring check reminders.
- Prominent GM attention alerts for player requests and unresolved effect checks.
- Compact searchable condition/effect picker.
- **Spellcasting dashboard** with Focus Points, spell slots by rank, cantrips, focus spells, prepared/ranked spells, spell action cost, and resource use.
- **3-action economy tracker** plus reaction tracking on both GM and player views.
- Casting during a PC's current turn automatically spends its configured action cost.
- Player browser receives only player-safe encounter information.
- Local persistence, backups, reconnect caching, QR/PIN joining, and LAN WebSocket sync.

## Spellcasting setup

Select a PC on the GM tablet. In the Spellcasting card you can:
- enable/disable spellcasting;
- choose Prepared or Spontaneous;
- set tradition and max Focus Points;
- add slot pools by rank;
- add a cantrip, focus spell, or ranked spell;
- choose a 0–3 action cost and optional short note;
- cast, restore, mark prepared spells expended, or remove spells.

Everleaf starts with an empty enabled Primal/Prepared profile and Yorik with an empty enabled Arcane/Prepared profile. Their exact spells and slots are intentionally not guessed.

## Permanent local signing

This repository includes `signing/tt-helper-local.jks`, a development-only key used for debug builds. The first 0.2.2 install will require uninstalling the older randomly signed alpha once. Keep the exact same `signing/` folder in all future packages and Android should allow in-place updates after that.

**Do not use this local-development key for a future public or store release.**

## Build

The project compiles against Android API 36 and targets API 36. The GitHub Actions workflow uses Java 17 and Gradle 9.6.
