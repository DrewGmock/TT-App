package com.drew.tthelper.state

import android.content.Context
import com.drew.tthelper.model.ActionEconomy
import com.drew.tthelper.model.CastingMode
import com.drew.tthelper.model.SpellEntry
import com.drew.tthelper.model.SpellSlotPool
import com.drew.tthelper.model.CombatLogEntry
import com.drew.tthelper.model.Combatant
import com.drew.tthelper.model.Condition
import com.drew.tthelper.model.EncounterState
import com.drew.tthelper.model.EffectAnchor
import com.drew.tthelper.model.EffectCheckPrompt
import com.drew.tthelper.model.EffectOutcomeAction
import com.drew.tthelper.model.EffectPhase
import com.drew.tthelper.model.EffectPreset
import com.drew.tthelper.model.EffectTriggerAction
import com.drew.tthelper.model.LootItem
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.PreparedEncounter
import com.drew.tthelper.model.PreparedEnemy
import com.drew.tthelper.model.SessionPrep
import com.drew.tthelper.model.SessionState
import com.drew.tthelper.model.StateSnapshot
import com.drew.tthelper.model.currentCombatant
import com.drew.tthelper.model.effectPresets
import com.drew.tthelper.model.obviousEnemyConditions
import com.drew.tthelper.model.valuedConditions
import java.io.File
import java.util.ArrayDeque
import java.util.LinkedHashSet
import java.util.UUID
import kotlin.random.Random
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class SessionStore(context: Context) {
    private val sessionFile = File(context.filesDir, "session-state.json")
    private val backupDir = File(context.filesDir, "backups").also { it.mkdirs() }
    private val undoStack = ArrayDeque<StateSnapshot>()
    private val processedRequestIds = LinkedHashSet<String>()

    private val _state = MutableStateFlow(loadOrDefault())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    @Synchronized
    fun setHp(pcId: String, hp: Int, label: String = "Set HP") {
        val currentPc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val delta = hp.coerceIn(0, currentPc.maxHp) - currentPc.hp
        hpDelta(pcId, delta, label)
    }

    @Synchronized
    fun hpDelta(pcId: String, delta: Int, label: String = if (delta < 0) "Damage" else "Healing") {
        val beforePc = _state.value.pcs.firstOrNull { it.id == pcId } ?: return
        val displayLabel = if (label == "Damage" || label == "Healing") {
            if (delta < 0) "${beforePc.name} took ${-delta} damage" else "${beforePc.name} healed ${delta}"
        } else label

        mutate(displayLabel, logEncounter = _state.value.encounter != null) { current ->
            val encounterActive = current.encounter?.active == true
            var updatedPc = applyPcHpDelta(beforePc = current.pcs.first { it.id == pcId }, delta = delta, encounterActive = encounterActive)
            val pcs = current.pcs.map { if (it.id == pcId) updatedPc else it }
            val encounter = current.encounter?.let { syncPcIntoEncounter(it, updatedPc) }
            current.copy(pcs = pcs, encounter = encounter)
        }
    }

    @Synchronized
    fun tempHpDelta(pcId: String, delta: Int) = mutate("Temp HP", logEncounter = _state.value.encounter != null) { current ->
        val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
        val updated = pc.copy(tempHp = (pc.tempHp + delta).coerceAtLeast(0))
        current.copy(
            pcs = current.pcs.map { if (it.id == pcId) updated else it },
            encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
        )
    }

    @Synchronized
    fun toggleReady(pcId: String) = mutate("Ready status") { current ->
        current.updatePc(pcId) { it.copy(ready = !it.ready) }
    }


    @Synchronized
    fun spendActions(pcId: String, count: Int) {
        val amount = count.coerceIn(1, 3)
        val encounter = _state.value.encounter
        if (encounter?.active == true && encounter.currentCombatant()?.pcId != pcId) return
        mutate("Action spent", logEncounter = _state.value.encounter != null) { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(actionEconomy = pc.actionEconomy.copy(
                    actionsRemaining = (pc.actionEconomy.actionsRemaining - amount).coerceAtLeast(0),
                ))
            }
        }
    }

    @Synchronized
    fun refundAction(pcId: String, count: Int = 1) {
        val amount = count.coerceIn(1, 3)
        mutate("Action refunded", logEncounter = _state.value.encounter != null) { current ->
            current.updatePc(pcId) { pc ->
                pc.copy(actionEconomy = pc.actionEconomy.copy(
                    actionsRemaining = (pc.actionEconomy.actionsRemaining + amount).coerceAtMost(pc.actionEconomy.baseActions),
                ))
            }
        }
    }

    @Synchronized
    fun useReaction(pcId: String) = mutate("Reaction used", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(actionEconomy = it.actionEconomy.copy(reactionAvailable = false)) }
    }

    @Synchronized
    fun restoreReaction(pcId: String) = mutate("Reaction restored", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { it.copy(actionEconomy = it.actionEconomy.copy(reactionAvailable = true)) }
    }

    @Synchronized
    fun resetActionEconomy(pcId: String) = mutate("Action economy reset", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(actionEconomy = ActionEconomy(baseActions = 3, actionsRemaining = 3, reactionAvailable = true))
        }
    }

    @Synchronized
    fun configureSpellcasting(
        pcId: String,
        enabled: Boolean,
        tradition: String,
        castingMode: String,
        maxFocusPoints: Int,
    ) = mutate("Spellcasting configured") { current ->
        current.updatePc(pcId) { pc ->
            val old = pc.spellcasting
            val maxFocus = maxFocusPoints.coerceIn(0, 3)
            pc.copy(spellcasting = old.copy(
                enabled = enabled,
                tradition = tradition.trim().take(30),
                castingMode = if (castingMode == CastingMode.SPONTANEOUS) CastingMode.SPONTANEOUS else CastingMode.PREPARED,
                maxFocusPoints = maxFocus,
                focusPoints = old.focusPoints.coerceIn(0, maxFocus),
            ))
        }
    }

    @Synchronized
    fun setFocusPoints(pcId: String, value: Int) = mutate("Focus points changed", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(
                focusPoints = value.coerceIn(0, pc.spellcasting.maxFocusPoints),
            ))
        }
    }

    @Synchronized
    fun refocus(pcId: String) = mutate("Refocused", logEncounter = _state.value.encounter != null) { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(focusPoints = pc.spellcasting.maxFocusPoints))
        }
    }

    @Synchronized
    fun setSpellSlotPool(pcId: String, rank: Int, total: Int, remaining: Int? = null) {
        val r = rank.coerceIn(1, 10)
        val t = total.coerceIn(0, 10)
        mutate("Spell slots updated") { current ->
            current.updatePc(pcId) { pc ->
                val old = pc.spellcasting.slots.firstOrNull { it.rank == r }
                val rem = (remaining ?: old?.remaining ?: t).coerceIn(0, t)
                val slots = (pc.spellcasting.slots.filterNot { it.rank == r } + SpellSlotPool(r, t, rem)).sortedBy { it.rank }
                pc.copy(spellcasting = pc.spellcasting.copy(slots = slots))
            }
        }
    }

    @Synchronized
    fun restoreSpellSlots(pcId: String) = mutate("Spell slots restored") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(
                slots = pc.spellcasting.slots.map { it.copy(remaining = it.total) },
                spells = pc.spellcasting.spells.map { if (it.isCantrip || it.isFocus) it else it.copy(expended = false) },
            ))
        }
    }

    @Synchronized
    fun addSpell(
        pcId: String,
        name: String,
        rank: Int,
        actions: Int,
        isCantrip: Boolean,
        isFocus: Boolean,
        notes: String = "",
    ) {
        val clean = name.trim().take(60)
        if (clean.isBlank()) return
        mutate("Spell added: $clean") { current ->
            current.updatePc(pcId) { pc ->
                val spell = SpellEntry(
                    name = clean,
                    rank = if (isCantrip) 0 else rank.coerceIn(1, 10),
                    actions = actions.coerceIn(0, 3),
                    isCantrip = isCantrip,
                    isFocus = isFocus,
                    notes = notes.trim().take(200),
                )
                pc.copy(spellcasting = pc.spellcasting.copy(enabled = true, spells = pc.spellcasting.spells + spell))
            }
        }
    }

    @Synchronized
    fun removeSpell(pcId: String, spellId: String) = mutate("Spell removed") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.filterNot { it.id == spellId }))
        }
    }

    @Synchronized
    fun setSpellExpended(pcId: String, spellId: String, expended: Boolean) = mutate("Prepared spell updated") { current ->
        current.updatePc(pcId) { pc ->
            pc.copy(spellcasting = pc.spellcasting.copy(spells = pc.spellcasting.spells.map {
                if (it.id == spellId) it.copy(expended = expended) else it
            }))
        }
    }

    @Synchronized
    fun castSpell(pcId: String, spellId: String) {
        val snapshot = _state.value
        val pc = snapshot.pcs.firstOrNull { it.id == pcId } ?: return
        val spell = pc.spellcasting.spells.firstOrNull { it.id == spellId } ?: return
        if (!pc.spellcasting.enabled) return

        val encounterActive = snapshot.encounter?.active == true
        val inOwnTurn = encounterActive && snapshot.encounter?.currentCombatant()?.pcId == pcId
        if (encounterActive && !inOwnTurn && spell.actions > 0) return
        if (inOwnTurn && pc.actionEconomy.actionsRemaining < spell.actions) return
        if (spell.isFocus && pc.spellcasting.focusPoints <= 0) return
        if (!spell.isCantrip && !spell.isFocus) {
            val pool = pc.spellcasting.slots.firstOrNull { it.rank == spell.rank }
            if (pool != null && pool.remaining <= 0) return
            if (pc.spellcasting.castingMode == CastingMode.PREPARED && spell.expended) return
        }

        mutate("${pc.name} cast ${spell.name}", logEncounter = snapshot.encounter != null) { current ->
            current.updatePc(pcId) { currentPc ->
                var casting = currentPc.spellcasting
                var actionsState = currentPc.actionEconomy
                if (inOwnTurn && spell.actions > 0) {
                    actionsState = actionsState.copy(actionsRemaining = (actionsState.actionsRemaining - spell.actions).coerceAtLeast(0))
                }
                if (spell.isFocus) {
                    casting = casting.copy(focusPoints = (casting.focusPoints - 1).coerceAtLeast(0))
                } else if (!spell.isCantrip) {
                    casting = casting.copy(
                        slots = casting.slots.map { slot ->
                            if (slot.rank == spell.rank) slot.copy(remaining = (slot.remaining - 1).coerceAtLeast(0)) else slot
                        },
                        spells = if (casting.castingMode == CastingMode.PREPARED) {
                            casting.spells.map { if (it.id == spellId) it.copy(expended = true) else it }
                        } else casting.spells,
                    )
                }
                currentPc.copy(spellcasting = casting, actionEconomy = actionsState)
            }
        }
    }

    @Synchronized
    fun toggleCondition(pcId: String, name: String, value: Int? = null) {
        val trimmed = name.trim().take(40)
        if (trimmed.isBlank()) return
        mutate("Condition: $trimmed", logEncounter = _state.value.encounter != null) { current ->
            val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
            val existing = pc.conditions.firstOrNull { it.name.equals(trimmed, ignoreCase = true) }
            val nextConditions = if (existing != null) {
                pc.conditions.filterNot { it.id == existing.id }
            } else {
                val sourceId = current.encounter?.currentCombatant()?.id
                pc.conditions + conditionFromPreset(
                    name = trimmed,
                    sourceCombatantId = sourceId,
                    publicToPlayers = true,
                    partyInflicted = false,
                    valueOverride = value,
                )
            }
            val updated = pc.copy(conditions = nextConditions)
            current.copy(
                pcs = current.pcs.map { if (it.id == pcId) updated else it },
                encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
            )
        }
    }

    @Synchronized
    fun setPcConditionValue(pcId: String, name: String, value: Int) {
        mutate("$name ${value.coerceAtLeast(0)}", logEncounter = _state.value.encounter != null) { current ->
            val pc = current.pcs.firstOrNull { it.id == pcId } ?: return@mutate current
            val existing = pc.conditions.firstOrNull { it.name.equals(name, true) }
            val next = if (value <= 0) {
                pc.conditions.filterNot { it.name.equals(name, true) }
            } else if (existing != null) {
                pc.conditions.map { if (it.id == existing.id) it.copy(value = value) else it }
            } else {
                pc.conditions + conditionFromPreset(
                    name = name,
                    sourceCombatantId = current.encounter?.currentCombatant()?.id,
                    publicToPlayers = true,
                    partyInflicted = false,
                    valueOverride = value,
                )
            }
            val updated = pc.copy(conditions = next)
            current.copy(
                pcs = current.pcs.map { if (it.id == pcId) updated else it },
                encounter = current.encounter?.let { syncPcIntoEncounter(it, updated) },
            )
        }
    }

    @Synchronized
    fun updatePrep(prep: SessionPrep) = mutate("Session prep saved") { it.copy(prep = prep) }

    @Synchronized
    fun saveEnemyToLibrary(enemy: PreparedEnemy) = mutate("Enemy saved to library") { current ->
        current.copy(prep = current.prep.copy(enemyLibrary = current.prep.enemyLibrary + enemy.copy(quantity = 1)))
    }

    @Synchronized
    fun deleteEnemyFromLibrary(enemyId: String) = mutate("Enemy removed from library") { current ->
        current.copy(prep = current.prep.copy(enemyLibrary = current.prep.enemyLibrary.filterNot { it.id == enemyId }))
    }

    @Synchronized
    fun savePreparedEncounter(encounter: PreparedEncounter) = mutate("Prepared encounter saved") { current ->
        val withoutOld = current.prep.preparedEncounters.filterNot { it.id == encounter.id }
        current.copy(prep = current.prep.copy(preparedEncounters = withoutOld + encounter))
    }

    @Synchronized
    fun deletePreparedEncounter(encounterId: String) = mutate("Prepared encounter removed") { current ->
        current.copy(prep = current.prep.copy(preparedEncounters = current.prep.preparedEncounters.filterNot { it.id == encounterId }))
    }

    @Synchronized
    fun updateScene(sceneName: String) = mutate("Scene changed") {
        it.copy(sceneName = sceneName.trim().ifBlank { "Unnamed Scene" })
    }

    @Synchronized
    fun startQuickEncounter(name: String = "Quick Encounter") = mutate("Encounter started", logEncounter = true) { current ->
        val resetPcs = current.pcs.map { it.copy(actionEconomy = ActionEconomy()) }
        val resetState = current.copy(pcs = resetPcs)
        resetState.copy(encounter = newEncounter(resetState, name.trim().ifBlank { "Quick Encounter" }, emptyList()))
    }

    @Synchronized
    fun startPreparedEncounter(preparedId: String) {
        val prepared = _state.value.prep.preparedEncounters.firstOrNull { it.id == preparedId } ?: return
        mutate("Encounter started: ${prepared.name}", logEncounter = true) { current ->
            val resetPcs = current.pcs.map { it.copy(actionEconomy = ActionEconomy()) }
            val resetState = current.copy(pcs = resetPcs)
            resetState.copy(encounter = newEncounter(resetState, prepared.name, prepared.enemies, prepared.gmNotes, prepared.startingNotes))
        }
    }

    @Synchronized
    fun clearEncounter() = mutate("Encounter cleared") { it.copy(encounter = null) }

    @Synchronized
    fun addQuickEnemy(
        name: String,
        maxHp: Int,
        level: Int? = null,
        initiativeModifier: Int = 0,
        quantity: Int = 1,
        gmNote: String = "",
    ) {
        val cleanName = name.trim().ifBlank { "Enemy" }.take(50)
        val qty = quantity.coerceIn(1, 20)
        mutate("Added $cleanName ×$qty", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val group = UUID.randomUUID().toString()
            val additions = (1..qty).map { index ->
                Combatant(
                    name = if (qty == 1) cleanName else "$cleanName $index",
                    kind = "enemy",
                    level = level,
                    initiativeModifier = initiativeModifier,
                    hp = maxHp.coerceAtLeast(1),
                    maxHp = maxHp.coerceAtLeast(1),
                    gmNote = gmNote,
                    groupKey = group,
                )
            }
            current.copy(encounter = encounter.copy(combatants = encounter.combatants + additions))
        }
    }

    @Synchronized
    fun addEnemyFromLibrary(enemyId: String, quantity: Int = 1) {
        val enemy = _state.value.prep.enemyLibrary.firstOrNull { it.id == enemyId } ?: return
        addQuickEnemy(enemy.name, enemy.maxHp, enemy.level, enemy.initiativeModifier, quantity, enemy.gmNotes)
    }

    @Synchronized
    fun setInitiative(combatantId: String, value: Int, source: String = "GM") {
        mutate("Initiative set", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val changed = encounter.combatants.map {
                if (it.id == combatantId) it.copy(initiative = value, initiativeSource = source) else it
            }
            val sorted = stableInitiativeSort(changed)
            val newIndex = currentId?.let { id -> sorted.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
            current.copy(encounter = encounter.copy(combatants = sorted, turnIndex = newIndex.coerceAtLeast(0)))
        }
    }

    @Synchronized
    fun rollInitiative(combatantId: String) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val result = Random.nextInt(1, 21) + combatant.initiativeModifier
        setInitiative(combatantId, result, "Digital roll")
    }

    @Synchronized
    fun setGroupInitiative(groupKey: String, value: Int, source: String = "GM group") {
        mutate("Group initiative set", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val changed = encounter.combatants.map {
                if (it.groupKey == groupKey) it.copy(initiative = value, initiativeSource = source) else it
            }
            val sorted = stableInitiativeSort(changed)
            val newIndex = currentId?.let { id -> sorted.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
            current.copy(encounter = encounter.copy(combatants = sorted, turnIndex = newIndex.coerceAtLeast(0)))
        }
    }

    @Synchronized
    fun rollGroupInitiative(groupKey: String) {
        val group = _state.value.encounter?.combatants?.filter { it.groupKey == groupKey }.orEmpty()
        val first = group.firstOrNull() ?: return
        val result = Random.nextInt(1, 21) + first.initiativeModifier
        setGroupInitiative(groupKey, result, "Digital group roll")
    }

    @Synchronized
    fun submitPlayerInitiative(pcId: String, value: Int, source: String) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.pcId == pcId } ?: return
        setInitiative(combatant.id, value, source)
    }

    @Synchronized
    fun moveCombatant(combatantId: String, delta: Int) {
        mutate("Initiative order adjusted", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val oldIndex = encounter.combatants.indexOfFirst { it.id == combatantId }
            if (oldIndex < 0) return@mutate current
            val newIndex = (oldIndex + delta).coerceIn(0, encounter.combatants.lastIndex.coerceAtLeast(0))
            if (newIndex == oldIndex) return@mutate current
            val currentId = encounter.currentCombatant()?.id
            val mutable = encounter.combatants.toMutableList()
            val item = mutable.removeAt(oldIndex)
            mutable.add(newIndex, item)
            val turn = currentId?.let { id -> mutable.indexOfFirst { it.id == id } }?.takeIf { it >= 0 } ?: 0
            current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = turn))
        }
    }

    @Synchronized
    fun nextTurn() {
        val snapshot = _state.value
        val encounter = snapshot.encounter ?: return
        if (!encounter.active || encounter.combatants.isEmpty()) return
        if (encounter.combatants.any { it.initiative == null }) return
        if (encounter.pendingEffectChecks.isNotEmpty()) return
        val currentName = encounter.currentCombatant()?.name ?: return

        mutate("Turn ended: $currentName", logEncounter = true) { current ->
            val activeEncounter = current.encounter ?: return@mutate current
            val actor = activeEncounter.currentCombatant() ?: return@mutate current

            val endProcessed = processEffectPhase(
                pcs = current.pcs,
                encounter = activeEncounter,
                actorId = actor.id,
                phase = EffectPhase.END,
            )

            if (endProcessed.encounter.pendingEffectChecks.isNotEmpty()) {
                return@mutate current.copy(
                    pcs = endProcessed.pcs,
                    encounter = endProcessed.encounter.copy(pendingTurnAdvance = true),
                )
            }

            val advanced = advanceEncounterTurn(current.copy(pcs = endProcessed.pcs), endProcessed.encounter)
            advanced
        }
    }

    @Synchronized
    fun previousTurn() = mutate("Previous turn", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.combatants.isEmpty()) return@mutate current
        val wraps = encounter.turnIndex <= 0
        current.copy(encounter = encounter.copy(
            turnIndex = if (wraps) encounter.combatants.lastIndex else encounter.turnIndex - 1,
            round = if (wraps) (encounter.round - 1).coerceAtLeast(1) else encounter.round,
        ))
    }

    @Synchronized
    fun delayCurrent() {
        val name = _state.value.encounter?.currentCombatant()?.name ?: return
        mutate("$name delayed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            if (encounter.combatants.size < 2) return@mutate current
            val index = encounter.turnIndex.coerceIn(0, encounter.combatants.lastIndex)
            val mutable = encounter.combatants.toMutableList()
            val delayed = mutable.removeAt(index).copy(delayed = true)
            mutable.add(delayed)
            val nextIndex = index.coerceAtMost(mutable.lastIndex)
            current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = nextIndex))
        }
    }

    @Synchronized
    fun resumeDelayed(combatantId: String) = mutate("Delayed combatant resumed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val oldIndex = encounter.combatants.indexOfFirst { it.id == combatantId && it.delayed }
        if (oldIndex < 0) return@mutate current
        val mutable = encounter.combatants.toMutableList()
        val combatant = mutable.removeAt(oldIndex).copy(delayed = false)
        val target = encounter.turnIndex.coerceIn(0, mutable.size)
        mutable.add(target, combatant)
        current.copy(encounter = encounter.copy(combatants = mutable, turnIndex = target))
    }

    @Synchronized
    fun setReadyDetails(combatantId: String, action: String, trigger: String) = mutate("Ready action set", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId) it.copy(readyAction = action.trim().take(120), readyTrigger = trigger.trim().take(120)) else it
        }))
    }

    @Synchronized
    fun clearReadyDetails(combatantId: String) = mutate("Ready action cleared", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId) it.copy(readyAction = "", readyTrigger = "") else it
        }))
    }

    @Synchronized
    fun combatantHpDelta(combatantId: String, delta: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        if (combatant.pcId != null) {
            hpDelta(combatant.pcId, delta)
            return
        }
        val label = if (delta < 0) "${combatant.name} took ${-delta} damage" else "${combatant.name} healed $delta"
        mutate(label, logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val next = encounter.combatants.map { c ->
                if (c.id != combatantId) return@map c
                var remaining = delta
                var temp = c.tempHp
                var hp = c.hp
                if (remaining < 0 && temp > 0) {
                    val absorbed = minOf(temp, -remaining)
                    temp -= absorbed
                    remaining += absorbed
                }
                hp = (hp + remaining).coerceIn(0, c.maxHp.coerceAtLeast(1))
                c.copy(hp = hp, tempHp = temp, defeated = hp <= 0)
            }
            current.copy(encounter = encounter.copy(combatants = next))
        }
    }

    @Synchronized
    fun combatantTempHpDelta(combatantId: String, delta: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        if (combatant.pcId != null) {
            tempHpDelta(combatant.pcId, delta)
            return
        }
        mutate("Temp HP: ${combatant.name}", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
                if (it.id == combatantId) it.copy(tempHp = (it.tempHp + delta).coerceAtLeast(0)) else it
            }))
        }
    }

    @Synchronized
    fun addCombatantEffect(
        combatantId: String,
        presetName: String,
        sourceCombatantId: String? = null,
        partyInflicted: Boolean = false,
        valueOverride: Int? = null,
    ) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val cleanName = presetName.trim().take(40)
        if (cleanName.isBlank()) return
        val effect = conditionFromPreset(
            name = cleanName,
            sourceCombatantId = sourceCombatantId ?: _state.value.encounter?.currentCombatant()?.id,
            publicToPlayers = combatant.kind == "pc" || partyInflicted || cleanName in obviousEnemyConditions,
            partyInflicted = partyInflicted,
            valueOverride = valueOverride,
        )
        addEffectToCombatant(combatantId, effect)
    }

    @Synchronized
    fun addCustomEffect(
        combatantId: String,
        name: String,
        value: Int?,
        sourceCombatantId: String?,
        partyInflicted: Boolean,
        timingAnchor: String,
        timingPhase: String,
        remainingTriggers: Int?,
        triggerAction: String,
        checkType: String?,
        checkLabel: String,
        checkDc: Int?,
        successAction: String,
        failureAction: String,
        criticalSuccessAction: String,
        criticalFailureAction: String,
        repeatCheck: Boolean,
    ) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val cleanName = name.trim().take(60)
        if (cleanName.isBlank()) return
        val effect = Condition(
            name = cleanName,
            value = value?.coerceAtLeast(0)?.takeIf { it > 0 },
            publicToPlayers = combatant.kind == "pc" || partyInflicted || cleanName in obviousEnemyConditions,
            partyInflicted = partyInflicted,
            sourceCombatantId = sourceCombatantId,
            timingAnchor = timingAnchor,
            timingPhase = timingPhase,
            remainingTriggers = remainingTriggers?.coerceAtLeast(1),
            triggerAction = triggerAction,
            checkType = checkType,
            checkLabel = checkLabel.trim().take(160),
            checkDc = checkDc?.coerceIn(1, 99),
            checkSuccessAction = successAction,
            checkFailureAction = failureAction,
            checkCriticalSuccessAction = criticalSuccessAction,
            checkCriticalFailureAction = criticalFailureAction,
            repeatCheck = repeatCheck,
        )
        addEffectToCombatant(combatantId, effect)
    }

    @Synchronized
    fun removeCombatantEffect(combatantId: String, effectId: String) {
        mutate("Effect removed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id == combatantId) c.copy(conditions = c.conditions.filterNot { it.id == effectId }) else c
            }
            val cleanedEncounter = encounter.copy(
                combatants = updatedCombatants,
                pendingEffectChecks = encounter.pendingEffectChecks.filterNot { it.effectId == effectId },
            )
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = cleanedEncounter,
            )
        }
    }

    @Synchronized
    fun setCombatantEffectValue(combatantId: String, effectId: String, value: Int) {
        mutate("Effect value changed", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id != combatantId) c else c.copy(
                    conditions = if (value <= 0) c.conditions.filterNot { it.id == effectId }
                    else c.conditions.map { effect -> if (effect.id == effectId) effect.copy(value = value) else effect }
                )
            }
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = encounter.copy(
                    combatants = updatedCombatants,
                    pendingEffectChecks = if (value <= 0) encounter.pendingEffectChecks.filterNot { it.effectId == effectId } else encounter.pendingEffectChecks,
                ),
            )
        }
    }

    @Synchronized
    fun toggleCombatantCondition(combatantId: String, name: String, partyInflicted: Boolean = false) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val existing = combatant.conditions.firstOrNull { it.name.equals(name.trim(), true) }
        if (existing != null) removeCombatantEffect(combatantId, existing.id)
        else addCombatantEffect(combatantId, name, partyInflicted = partyInflicted)
    }

    @Synchronized
    fun setCombatantConditionValue(combatantId: String, name: String, value: Int) {
        val combatant = _state.value.encounter?.combatants?.firstOrNull { it.id == combatantId } ?: return
        val existing = combatant.conditions.firstOrNull { it.name.equals(name, true) }
        if (existing != null) setCombatantEffectValue(combatantId, existing.id, value)
        else if (value > 0) addCombatantEffect(combatantId, name, valueOverride = value)
    }

    @Synchronized
    fun setDefeated(combatantId: String, defeated: Boolean) = mutate(if (defeated) "Combatant defeated" else "Combatant restored", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(combatants = encounter.combatants.map {
            if (it.id == combatantId && it.kind != "pc") it.copy(defeated = defeated) else it
        }))
    }

    @Synchronized
    fun requestEndTurn(pcId: String) = mutate("End turn requested", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (pcId in encounter.endTurnRequests) current
        else current.copy(encounter = encounter.copy(endTurnRequests = encounter.endTurnRequests + pcId))
    }

    @Synchronized
    fun dismissEndTurnRequest(pcId: String) = mutate("End turn request dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(endTurnRequests = encounter.endTurnRequests.filterNot { it == pcId }))
    }

    @Synchronized
    fun approveEndTurnRequest(pcId: String) {
        val encounter = _state.value.encounter ?: return
        if (encounter.currentCombatant()?.pcId != pcId) {
            dismissEndTurnRequest(pcId)
            return
        }
        dismissEndTurnRequest(pcId)
        nextTurn()
    }

    @Synchronized
    fun dismissEffectCheck(promptId: String) = mutate("Effect check dismissed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val remaining = encounter.pendingEffectChecks.filterNot { it.id == promptId }
        val updated = encounter.copy(pendingEffectChecks = remaining)
        if (remaining.isEmpty() && encounter.pendingTurnAdvance) {
            advanceEncounterTurn(current, updated.copy(pendingTurnAdvance = false))
        } else {
            current.copy(encounter = updated)
        }
    }

    @Synchronized
    fun resolveEffectCheck(promptId: String, outcome: String) = mutate("Effect check resolved", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val prompt = encounter.pendingEffectChecks.firstOrNull { it.id == promptId } ?: return@mutate current
        val action = when (outcome) {
            "criticalSuccess" -> prompt.criticalSuccessAction
            "success" -> prompt.successAction
            "criticalFailure" -> prompt.criticalFailureAction
            else -> prompt.failureAction
        }

        var updatedCombatants = encounter.combatants.map { combatant ->
            if (combatant.id != prompt.targetCombatantId) return@map combatant
            val effect = combatant.conditions.firstOrNull { it.id == prompt.effectId } ?: return@map combatant
            var nextEffect = applyOutcomeToEffect(effect, action)

            // Check-triggered effects can also have a finite number of trigger windows.
            val remainingTriggerCount = nextEffect?.remainingTriggers
            if (nextEffect != null && remainingTriggerCount != null) {
                nextEffect = if (remainingTriggerCount <= 1) null
                else nextEffect.copy(remainingTriggers = remainingTriggerCount - 1)
            }

            var nextConditions = if (nextEffect == null) {
                combatant.conditions.filterNot { it.id == effect.id }
            } else {
                combatant.conditions.map { if (it.id == effect.id) nextEffect else it }
            }

            // Stabilizing from Dying increases Wounded. Keep this GM-overridable via Undo.
            if (effect.name.equals("Dying", true) && nextEffect == null && combatant.pcId != null) {
                val wounded = nextConditions.firstOrNull { it.name.equals("Wounded", true) }
                nextConditions = if (wounded == null) {
                    nextConditions + conditionFromPreset(
                        name = "Wounded",
                        sourceCombatantId = effect.sourceCombatantId,
                        publicToPlayers = true,
                        partyInflicted = false,
                        valueOverride = 1,
                    )
                } else {
                    nextConditions.map { condition ->
                        if (condition.id == wounded.id) condition.copy(value = (condition.value ?: 0) + 1) else condition
                    }
                }
            }

            combatant.copy(conditions = nextConditions)
        }

        if (!prompt.repeatCheck) {
            updatedCombatants = updatedCombatants.map { combatant ->
                if (combatant.id != prompt.targetCombatantId) combatant else combatant.copy(
                    conditions = combatant.conditions.map { effect ->
                        if (effect.id == prompt.effectId) effect.copy(triggerAction = EffectTriggerAction.NONE, timingPhase = EffectPhase.MANUAL)
                        else effect
                    }
                )
            }
        }

        val remaining = encounter.pendingEffectChecks.filterNot { it.id == promptId }
        val baseEncounter = encounter.copy(
            combatants = updatedCombatants,
            pendingEffectChecks = remaining,
        )
        val baseState = current.copy(
            pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
            encounter = baseEncounter,
        )
        if (remaining.isEmpty() && encounter.pendingTurnAdvance) {
            advanceEncounterTurn(baseState, baseEncounter.copy(pendingTurnAdvance = false))
        } else baseState
    }

    @Synchronized
    fun recordPlayerRoll(pcId: String, label: String, result: Int) {
        val name = _state.value.pcs.firstOrNull { it.id == pcId }?.name ?: "Player"
        mutate("$name rolled $label: $result", logEncounter = _state.value.encounter != null) { it }
    }

    @Synchronized
    fun endEncounter() = mutate("Encounter ended • loot draft generated", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        val loot = if (encounter.loot.generatedAt == null) LootGenerator.generate(encounter) else encounter.loot
        current.copy(encounter = encounter.copy(active = false, ended = true, loot = loot))
    }

    @Synchronized
    fun generateLoot() = mutate("Loot generated", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = LootGenerator.generate(encounter)))
    }

    @Synchronized
    fun revealLoot() = mutate("Loot revealed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = encounter.loot.copy(revealed = true)))
    }

    @Synchronized
    fun addEncounterLootItem(name: String, category: String = "Treasure", valueGp: Double = 0.0) {
        val clean = name.trim().take(80)
        if (clean.isBlank()) return
        mutate("Loot item added", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            current.copy(encounter = encounter.copy(loot = encounter.loot.copy(
                items = encounter.loot.items + LootItem(name = clean, category = category, valueGp = valueGp),
            )))
        }
    }

    @Synchronized
    fun removeEncounterLootItem(itemId: String) = mutate("Loot item removed", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        current.copy(encounter = encounter.copy(loot = encounter.loot.copy(
            items = encounter.loot.items.filterNot { it.id == itemId },
        )))
    }

    @Synchronized
    fun moveLootToParty() = mutate("Loot moved to party", logEncounter = true) { current ->
        val encounter = current.encounter ?: return@mutate current
        if (encounter.loot.movedToParty) return@mutate current
        val coinItem = if (encounter.loot.coinsGp > 0) {
            listOf(LootItem(name = "${formatGp(encounter.loot.coinsGp)} gp", category = "Coins", valueGp = encounter.loot.coinsGp))
        } else emptyList()
        current.copy(
            partyLoot = current.partyLoot + coinItem + encounter.loot.items,
            encounter = encounter.copy(loot = encounter.loot.copy(movedToParty = true)),
        )
    }

    @Synchronized
    fun assignPartyLoot(itemId: String, pcId: String?) = mutate("Party loot assigned") { current ->
        current.copy(partyLoot = current.partyLoot.map {
            if (it.id == itemId) it.copy(assignedToPcId = pcId) else it
        })
    }

    @Synchronized
    fun removePartyLoot(itemId: String) = mutate("Party loot removed") { current ->
        current.copy(partyLoot = current.partyLoot.filterNot { it.id == itemId })
    }

    @Synchronized
    fun applyPlayerRequest(requestId: String, block: () -> Unit): Boolean {
        if (requestId.isBlank() || requestId in processedRequestIds) return false
        processedRequestIds += requestId
        while (processedRequestIds.size > 500) {
            val first = processedRequestIds.firstOrNull() ?: break
            processedRequestIds.remove(first)
        }
        block()
        return true
    }

    @Synchronized
    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        val previous = undoStack.removeLast()
        val restoredBase = previous.state
        val restoredEncounter = restoredBase.encounter?.let { encounter ->
            encounter.copy(history = (encounter.history + CombatLogEntry(label = "Undo: ${previous.label}")).takeLast(250))
        }
        val restored = restoredBase.copy(
            encounter = restoredEncounter,
            revision = _state.value.revision + 1,
            lastEventLabel = "Undo: ${previous.label}",
        )
        _state.value = restored
        persist(restored)
        return true
    }

    fun canUndo(): Boolean = synchronized(this) { undoStack.isNotEmpty() }

    fun publicLobbyJson(): String {
        val current = _state.value
        return JSONObject().apply {
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("revision", current.revision)
            put("pcs", JSONArray().apply {
                current.pcs.forEach { pc ->
                    put(JSONObject().apply {
                        put("id", pc.id)
                        put("name", pc.name)
                        put("ancestry", pc.ancestry)
                        put("characterClass", pc.characterClass)
                        put("level", pc.level ?: JSONObject.NULL)
                    })
                }
            })
        }.toString()
    }

    fun playerSnapshotJson(pcId: String): String {
        val current = _state.value
        val ownPc = current.pcs.firstOrNull { it.id == pcId }
        return JSONObject().apply {
            put("type", "snapshot")
            put("revision", current.revision)
            put("campaignName", current.campaignName)
            put("sceneName", current.sceneName)
            put("lastEventLabel", current.lastEventLabel ?: JSONObject.NULL)
            put("you", ownPc?.toPublicJson() ?: JSONObject.NULL)
            put("party", JSONArray().apply { current.pcs.forEach { put(it.toPartyJson()) } })
            put("encounter", current.encounter?.toPlayerJson(pcId) ?: JSONObject.NULL)
        }.toString()
    }

    fun exportBackup(): File {
        val stamp = System.currentTimeMillis()
        val file = File(backupDir, "tt-helper-$stamp.json")
        file.writeText(SessionCodec.encode(_state.value))
        return file
    }

    fun listBackups(): List<File> = backupDir.listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()

    @Synchronized
    fun restoreBackup(file: File): Boolean = runCatching {
        val restored = SessionCodec.decode(file.readText()).copy(
            revision = _state.value.revision + 1,
            lastEventLabel = "Backup restored",
        )
        undoStack.addLast(StateSnapshot(_state.value, "Restore backup"))
        _state.value = restored
        persist(restored)
        true
    }.getOrDefault(false)

    private data class EffectProcessingResult(
        val pcs: List<PlayerCharacter>,
        val encounter: EncounterState,
    )

    private fun conditionFromPreset(
        name: String,
        sourceCombatantId: String?,
        publicToPlayers: Boolean,
        partyInflicted: Boolean,
        valueOverride: Int? = null,
    ): Condition {
        val preset: EffectPreset? = effectPresets.firstOrNull { it.name.equals(name, true) }
        return Condition(
            name = name,
            value = valueOverride ?: preset?.defaultValue,
            publicToPlayers = publicToPlayers,
            partyInflicted = partyInflicted,
            sourceCombatantId = sourceCombatantId,
            timingAnchor = preset?.timingAnchor ?: EffectAnchor.TARGET,
            timingPhase = preset?.timingPhase ?: EffectPhase.MANUAL,
            triggerAction = preset?.triggerAction ?: EffectTriggerAction.NONE,
            checkType = preset?.checkType,
            checkLabel = preset?.checkLabel.orEmpty(),
            checkDc = preset?.checkDc,
            checkSuccessAction = preset?.successAction ?: EffectOutcomeAction.REMOVE,
            checkFailureAction = preset?.failureAction ?: EffectOutcomeAction.KEEP,
            checkCriticalSuccessAction = preset?.criticalSuccessAction ?: EffectOutcomeAction.REMOVE,
            checkCriticalFailureAction = preset?.criticalFailureAction ?: EffectOutcomeAction.KEEP,
        )
    }

    private fun addEffectToCombatant(combatantId: String, effect: Condition) {
        mutate("Effect added: ${effect.name}", logEncounter = true) { current ->
            val encounter = current.encounter ?: return@mutate current
            val updatedCombatants = encounter.combatants.map { c ->
                if (c.id != combatantId) c else c.copy(
                    conditions = c.conditions.filterNot { it.name.equals(effect.name, true) } + effect
                )
            }
            current.copy(
                pcs = syncPcsFromCombatants(current.pcs, updatedCombatants),
                encounter = encounter.copy(combatants = updatedCombatants),
            )
        }
    }

    private fun applyOutcomeToEffect(effect: Condition, action: String): Condition? = when (action) {
        EffectOutcomeAction.REMOVE -> null
        EffectOutcomeAction.DECREMENT -> effect.value?.let { next ->
            if (next - 1 <= 0) null else effect.copy(value = next - 1)
        } ?: effect
        EffectOutcomeAction.DECREMENT_2 -> effect.value?.let { next ->
            if (next - 2 <= 0) null else effect.copy(value = next - 2)
        } ?: effect
        EffectOutcomeAction.INCREMENT -> effect.copy(value = (effect.value ?: 0) + 1)
        EffectOutcomeAction.INCREMENT_2 -> effect.copy(value = (effect.value ?: 0) + 2)
        else -> effect
    }

    private fun processEffectPhase(
        pcs: List<PlayerCharacter>,
        encounter: EncounterState,
        actorId: String,
        phase: String,
    ): EffectProcessingResult {
        val prompts = encounter.pendingEffectChecks.toMutableList()
        val updatedCombatants = encounter.combatants.map { target ->
            val nextConditions = target.conditions.mapNotNull { effect ->
                val matchesActor = when (effect.timingAnchor) {
                    EffectAnchor.SOURCE -> effect.sourceCombatantId == actorId
                    else -> target.id == actorId
                }
                if (effect.timingPhase != phase || !matchesActor) return@mapNotNull effect

                var next: Condition? = when (effect.triggerAction) {
                    EffectTriggerAction.REMOVE -> null
                    EffectTriggerAction.DECREMENT_VALUE -> {
                        val value = effect.value ?: 1
                        if (value - 1 <= 0) null else effect.copy(value = value - 1)
                    }
                    EffectTriggerAction.CHECK -> {
                        if (prompts.none { it.effectId == effect.id }) {
                            val dynamicDc = if (effect.name.equals("Dying", true) && effect.value != null) {
                                10 + effect.value
                            } else effect.checkDc
                            prompts += EffectCheckPrompt(
                                effectId = effect.id,
                                targetCombatantId = target.id,
                                targetName = target.name,
                                effectName = effect.name,
                                checkType = effect.checkType ?: "Custom roll",
                                checkLabel = effect.checkLabel,
                                dc = dynamicDc,
                                timingText = effectTimingText(effect, target, encounter),
                                successAction = effect.checkSuccessAction,
                                failureAction = effect.checkFailureAction,
                                criticalSuccessAction = effect.checkCriticalSuccessAction,
                                criticalFailureAction = effect.checkCriticalFailureAction,
                                repeatCheck = effect.repeatCheck,
                            )
                        }
                        effect
                    }
                    else -> effect
                }

                val remainingTriggerCount = next?.remainingTriggers
                if (next != null && effect.triggerAction != EffectTriggerAction.CHECK && remainingTriggerCount != null) {
                    next = if (remainingTriggerCount <= 1) null else next.copy(remainingTriggers = remainingTriggerCount - 1)
                }
                next
            }
            target.copy(conditions = nextConditions)
        }
        return EffectProcessingResult(
            pcs = syncPcsFromCombatants(pcs, updatedCombatants),
            encounter = encounter.copy(
                combatants = updatedCombatants,
                pendingEffectChecks = prompts,
            ),
        )
    }

    private fun advanceEncounterTurn(state: SessionState, encounter: EncounterState): SessionState {
        if (encounter.combatants.isEmpty()) return state.copy(encounter = encounter)
        val oldCurrent = encounter.currentCombatant()
        val wraps = encounter.turnIndex >= encounter.combatants.lastIndex
        val nextIndex = if (wraps) 0 else encounter.turnIndex + 1
        val nextRound = if (wraps) encounter.round + 1 else encounter.round
        var moved = encounter.copy(
            turnIndex = nextIndex,
            round = nextRound,
            pendingTurnAdvance = false,
            endTurnRequests = encounter.endTurnRequests.filterNot { it == oldCurrent?.pcId },
        )
        val nextActor = moved.currentCombatant()
        if (nextActor != null) {
            val startProcessed = processEffectPhase(state.pcs, moved, nextActor.id, EffectPhase.START)
            moved = startProcessed.encounter
            val nextPcs = if (nextActor.pcId != null) {
                startProcessed.pcs.map { pc ->
                    if (pc.id == nextActor.pcId) pc.copy(actionEconomy = ActionEconomy()) else pc
                }
            } else startProcessed.pcs
            return state.copy(pcs = nextPcs, encounter = moved)
        }
        return state.copy(encounter = moved)
    }

    private fun effectTimingText(effect: Condition, target: Combatant, encounter: EncounterState): String {
        val phaseText = when (effect.timingPhase) {
            EffectPhase.START -> "start"
            EffectPhase.END -> "end"
            else -> "manual timing"
        }
        if (effect.timingPhase == EffectPhase.MANUAL) return "Manual timing"
        val anchorName = if (effect.timingAnchor == EffectAnchor.SOURCE) {
            encounter.combatants.firstOrNull { it.id == effect.sourceCombatantId }?.name ?: "source"
        } else target.name
        return "$phaseText of $anchorName's turn"
    }

    private fun syncPcsFromCombatants(
        pcs: List<PlayerCharacter>,
        combatants: List<Combatant>,
    ): List<PlayerCharacter> = pcs.map { pc ->
        val combatant = combatants.firstOrNull { it.pcId == pc.id }
        if (combatant == null) pc else pc.copy(conditions = combatant.conditions)
    }

    private fun mutate(label: String, logEncounter: Boolean = false, transform: (SessionState) -> SessionState) {
        val before = _state.value
        undoStack.addLast(StateSnapshot(before, label))
        while (undoStack.size > 100) undoStack.removeFirst()
        var after = transform(before)
        val encounterAfter = after.encounter
        if (logEncounter && encounterAfter != null) {
            after = after.copy(encounter = encounterAfter.copy(
                history = (encounterAfter.history + CombatLogEntry(label = label)).takeLast(250),
            ))
        }
        after = after.copy(revision = before.revision + 1, lastEventLabel = label)
        _state.value = after
        persist(after)
    }

    private fun loadOrDefault(): SessionState = runCatching {
        if (sessionFile.exists()) SessionCodec.decode(sessionFile.readText()) else SessionState()
    }.getOrElse { SessionState() }

    private fun persist(state: SessionState) {
        val temp = File(sessionFile.parentFile, "${sessionFile.name}.tmp")
        temp.writeText(SessionCodec.encode(state))
        if (!temp.renameTo(sessionFile)) {
            sessionFile.writeText(temp.readText())
            temp.delete()
        }
    }

    private fun newEncounter(
        current: SessionState,
        name: String,
        enemies: List<PreparedEnemy>,
        gmNote: String = "",
        startingNotes: String = "",
    ): EncounterState {
        val pcs = current.pcs.map { pc ->
            Combatant(
                id = "pc-${pc.id}",
                name = pc.name,
                kind = "pc",
                pcId = pc.id,
                level = pc.level,
                hp = pc.hp,
                maxHp = pc.maxHp,
                tempHp = pc.tempHp,
                conditions = pc.conditions,
                gmNote = pc.gmNote,
                publicNote = pc.publicNote,
            )
        }
        val enemyCombatants = enemies.flatMap { enemy ->
            val qty = enemy.quantity.coerceIn(1, 20)
            val group = enemy.id.ifBlank { UUID.randomUUID().toString() }
            (1..qty).map { index ->
                Combatant(
                    name = if (qty == 1) enemy.name else "${enemy.name} $index",
                    kind = "enemy",
                    level = enemy.level,
                    initiativeModifier = enemy.initiativeModifier,
                    hp = enemy.maxHp.coerceAtLeast(1),
                    maxHp = enemy.maxHp.coerceAtLeast(1),
                    gmNote = listOf(gmNote, enemy.gmNotes).filter { it.isNotBlank() }.joinToString("\n"),
                    publicNote = enemy.publicNotes,
                    groupKey = group,
                )
            }
        }
        return EncounterState(
            name = name,
            gmNotes = gmNote,
            startingNotes = startingNotes,
            combatants = pcs + enemyCombatants,
        )
    }

    private fun stableInitiativeSort(combatants: List<Combatant>): List<Combatant> = combatants.withIndex()
        .sortedWith(compareByDescending<IndexedValue<Combatant>> { it.value.initiative ?: Int.MIN_VALUE }.thenBy { it.index })
        .map { it.value }

    private fun applyPcHpDelta(beforePc: PlayerCharacter, delta: Int, encounterActive: Boolean): PlayerCharacter {
        var remaining = delta
        var temp = beforePc.tempHp
        var hp = beforePc.hp
        if (remaining < 0 && temp > 0) {
            val absorbed = minOf(temp, -remaining)
            temp -= absorbed
            remaining += absorbed
        }
        hp = (hp + remaining).coerceIn(0, beforePc.maxHp.coerceAtLeast(1))
        var conditions = beforePc.conditions

        if (encounterActive && beforePc.hp > 0 && hp == 0) {
            val wounded = conditions.firstOrNull { it.name.equals("Wounded", true) }?.value ?: 0
            val dyingValue = 1 + wounded
            conditions = conditions.filterNot { it.name.equals("Dying", true) } + Condition("Dying", dyingValue, publicToPlayers = true)
        }
        if (encounterActive && beforePc.hp == 0 && hp > 0 && conditions.any { it.name.equals("Dying", true) }) {
            val wounded = (conditions.firstOrNull { it.name.equals("Wounded", true) }?.value ?: 0) + 1
            conditions = conditions.filterNot { it.name.equals("Dying", true) || it.name.equals("Wounded", true) } +
                Condition("Wounded", wounded, publicToPlayers = true)
        }
        return beforePc.copy(hp = hp, tempHp = temp, conditions = conditions)
    }

    private fun syncPcIntoEncounter(encounter: EncounterState, pc: PlayerCharacter): EncounterState = encounter.copy(
        combatants = encounter.combatants.map { combatant ->
            if (combatant.pcId == pc.id) combatant.copy(
                hp = pc.hp,
                maxHp = pc.maxHp,
                tempHp = pc.tempHp,
                conditions = pc.conditions,
            ) else combatant
        }
    )

    private fun SessionState.updatePc(pcId: String, transform: (PlayerCharacter) -> PlayerCharacter): SessionState =
        copy(pcs = pcs.map { if (it.id == pcId) transform(it) else it })

    private fun PlayerCharacter.toPublicJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("ancestry", ancestry)
        put("characterClass", characterClass)
        put("level", level ?: JSONObject.NULL)
        put("hp", hp)
        put("maxHp", maxHp)
        put("tempHp", tempHp)
        put("heroPoints", heroPoints)
        put("ready", ready)
        put("publicNote", publicNote)
        put("actionEconomy", JSONObject().apply {
            put("baseActions", actionEconomy.baseActions)
            put("actionsRemaining", actionEconomy.actionsRemaining)
            put("reactionAvailable", actionEconomy.reactionAvailable)
        })
        put("spellcasting", JSONObject().apply {
            put("enabled", spellcasting.enabled)
            put("tradition", spellcasting.tradition)
            put("castingMode", spellcasting.castingMode)
            put("focusPoints", spellcasting.focusPoints)
            put("maxFocusPoints", spellcasting.maxFocusPoints)
            put("slots", JSONArray().apply {
                spellcasting.slots.sortedBy { it.rank }.forEach { slot ->
                    put(JSONObject().apply {
                        put("rank", slot.rank)
                        put("total", slot.total)
                        put("remaining", slot.remaining)
                    })
                }
            })
            put("spells", JSONArray().apply {
                spellcasting.spells.forEach { spell ->
                    put(JSONObject().apply {
                        put("id", spell.id)
                        put("name", spell.name)
                        put("rank", spell.rank)
                        put("actions", spell.actions)
                        put("isCantrip", spell.isCantrip)
                        put("isFocus", spell.isFocus)
                        put("expended", spell.expended)
                        put("notes", spell.notes)
                    })
                }
            })
        })
        put("conditions", JSONArray().apply {
            conditions.forEach { c -> put(c.toJson()) }
        })
    }

    private fun PlayerCharacter.toPartyJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("hp", hp)
        put("maxHp", maxHp)
        put("tempHp", tempHp)
        put("ready", ready)
        put("conditions", JSONArray().apply { conditions.forEach { put(it.toJson()) } })
    }

    private fun Condition.toJson() = JSONObject().apply {
        put("name", name)
        put("value", value ?: JSONObject.NULL)
        put("partyInflicted", partyInflicted)
    }

    private fun EncounterState.toPlayerJson(pcId: String) = JSONObject().apply {
        val current = currentCombatant()
        val own = combatants.firstOrNull { it.pcId == pcId }
        put("id", id)
        put("name", name)
        put("active", active)
        put("ended", ended)
        put("round", round)
        put("currentCombatantId", current?.id ?: JSONObject.NULL)
        put("currentName", current?.name ?: JSONObject.NULL)
        put("currentIsYou", current?.pcId == pcId)
        put("yourInitiative", own?.initiative ?: JSONObject.NULL)
        put("endTurnRequested", pcId in endTurnRequests)
        put("initiative", JSONArray().apply {
            combatants.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("kind", c.kind)
                    put("isYou", c.pcId == pcId)
                    put("current", c.id == current?.id)
                    put("delayed", c.delayed)
                    put("defeated", c.defeated)
                })
            }
        })
        put("enemies", JSONArray().apply {
            combatants.filter { it.kind != "pc" }.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("health", healthState(c))
                    put("defeated", c.defeated)
                    put("publicNote", c.publicNote)
                    put("conditions", JSONArray().apply {
                        c.conditions.filter { it.publicToPlayers || it.partyInflicted }.forEach { put(it.toJson()) }
                    })
                })
            }
        })
        put("loot", if (loot.revealed) JSONObject().apply {
            put("coinsGp", loot.coinsGp)
            put("items", JSONArray().apply {
                loot.items.forEach { item ->
                    put(JSONObject().apply {
                        put("name", item.name)
                        put("category", item.category)
                        put("quantity", item.quantity)
                        put("notes", item.notes)
                    })
                }
            })
        } else JSONObject.NULL)
    }

    private fun healthState(c: Combatant): String {
        if (c.defeated || c.hp <= 0) return "Defeated"
        val ratio = c.hp.toDouble() / c.maxHp.coerceAtLeast(1).toDouble()
        return when {
            ratio > 0.75 -> "Healthy"
            ratio > 0.50 -> "Hurt"
            ratio > 0.25 -> "Badly Hurt"
            else -> "Near Death"
        }
    }

    private fun formatGp(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
}
