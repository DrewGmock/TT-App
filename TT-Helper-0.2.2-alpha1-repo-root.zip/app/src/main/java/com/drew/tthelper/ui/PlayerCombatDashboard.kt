package com.drew.tthelper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drew.tthelper.model.CastingMode
import com.drew.tthelper.model.PlayerCharacter
import com.drew.tthelper.model.SpellEntry
import com.drew.tthelper.server.HostRuntime

@Composable
fun PlayerCombatDashboard(runtime: HostRuntime, pc: PlayerCharacter, gmEditable: Boolean = true) {
    ActionEconomyPanel(runtime, pc)
    SpellcastingPanel(runtime, pc, gmEditable)
}

@Composable
private fun ActionEconomyPanel(runtime: HostRuntime, pc: PlayerCharacter) {
    val economy = pc.actionEconomy
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Action Economy", fontSize = 20.sp)
            val pips = (1..economy.baseActions).joinToString(" ") { index ->
                if (index <= economy.actionsRemaining) "●" else "○"
            }
            Text("$pips   ${economy.actionsRemaining}/${economy.baseActions} actions remaining", fontSize = 18.sp)
            Text(if (economy.reactionAvailable) "Reaction: available" else "Reaction: used")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                (1..3).forEach { count ->
                    OutlinedButton(
                        enabled = economy.actionsRemaining >= count,
                        onClick = { runtime.store.spendActions(pc.id, count) },
                    ) { Text("Spend $count") }
                }
                FilledTonalButton(
                    enabled = economy.actionsRemaining < economy.baseActions,
                    onClick = { runtime.store.refundAction(pc.id) },
                ) { Text("Refund 1") }
                OutlinedButton(onClick = {
                    if (economy.reactionAvailable) runtime.store.useReaction(pc.id) else runtime.store.restoreReaction(pc.id)
                }) { Text(if (economy.reactionAvailable) "Use reaction" else "Restore reaction") }
                OutlinedButton(onClick = { runtime.store.resetActionEconomy(pc.id) }) { Text("Reset turn") }
            }
            Text("Casting a spell during this PC's active turn automatically spends its listed actions.", fontSize = 12.sp)
        }
    }
}

@Composable
private fun SpellcastingPanel(runtime: HostRuntime, pc: PlayerCharacter, gmEditable: Boolean) {
    val casting = pc.spellcasting
    var tradition by remember(pc.id, casting.tradition) { mutableStateOf(casting.tradition) }
    var focusMax by remember(pc.id, casting.maxFocusPoints) { mutableStateOf(casting.maxFocusPoints.toString()) }
    var slotRank by remember(pc.id) { mutableStateOf("1") }
    var slotTotal by remember(pc.id) { mutableStateOf("1") }
    var spellName by remember(pc.id) { mutableStateOf("") }
    var spellRank by remember(pc.id) { mutableStateOf("1") }
    var spellActions by remember(pc.id) { mutableStateOf("2") }
    var spellNotes by remember(pc.id) { mutableStateOf("") }
    var isCantrip by remember(pc.id) { mutableStateOf(false) }
    var isFocus by remember(pc.id) { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Spellcasting", fontSize = 20.sp)
                    if (casting.enabled) {
                        Text("${casting.tradition.ifBlank { "Tradition not set" }} • ${if (casting.castingMode == CastingMode.SPONTANEOUS) "Spontaneous" else "Prepared"}")
                    } else Text("Spellcasting is disabled for this character.")
                }
                if (gmEditable) {
                    OutlinedButton(onClick = {
                        runtime.store.configureSpellcasting(
                            pcId = pc.id,
                            enabled = !casting.enabled,
                            tradition = tradition,
                            castingMode = casting.castingMode,
                            maxFocusPoints = focusMax.toIntOrNull() ?: casting.maxFocusPoints,
                        )
                    }) { Text(if (casting.enabled) "Disable" else "Enable") }
                }
            }

            if (!casting.enabled) return@Column

            Text("Focus Points: ${casting.focusPoints}/${casting.maxFocusPoints}")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = casting.focusPoints > 0,
                    onClick = { runtime.store.setFocusPoints(pc.id, casting.focusPoints - 1) },
                ) { Text("− Focus") }
                OutlinedButton(
                    enabled = casting.focusPoints < casting.maxFocusPoints,
                    onClick = { runtime.store.setFocusPoints(pc.id, casting.focusPoints + 1) },
                ) { Text("+ Focus") }
                FilledTonalButton(onClick = { runtime.store.refocus(pc.id) }) { Text("Refocus") }
            }

            if (casting.slots.isNotEmpty()) {
                Text("Spell Slots", fontSize = 17.sp)
                casting.slots.sortedBy { it.rank }.forEach { slot ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Rank ${slot.rank}: ${slot.remaining}/${slot.total}", modifier = Modifier.weight(1f))
                        if (gmEditable) {
                            OutlinedButton(onClick = { runtime.store.setSpellSlotPool(pc.id, slot.rank, slot.total, slot.remaining - 1) }, enabled = slot.remaining > 0) { Text("−") }
                            OutlinedButton(onClick = { runtime.store.setSpellSlotPool(pc.id, slot.rank, slot.total, slot.remaining + 1) }, enabled = slot.remaining < slot.total) { Text("+") }
                        }
                    }
                }
                if (gmEditable) OutlinedButton(onClick = { runtime.store.restoreSpellSlots(pc.id) }) { Text("Restore all slots") }
            } else {
                Text("No spell-slot ranks configured yet.")
            }

            val cantrips = casting.spells.filter { it.isCantrip }
            val focusSpells = casting.spells.filter { it.isFocus && !it.isCantrip }
            val ranked = casting.spells.filter { !it.isCantrip && !it.isFocus }.groupBy { it.rank }.toSortedMap()

            if (cantrips.isNotEmpty()) {
                HorizontalDivider()
                Text("Cantrips", fontSize = 17.sp)
                cantrips.forEach { SpellRow(runtime, pc, it, gmEditable) }
            }
            if (focusSpells.isNotEmpty()) {
                HorizontalDivider()
                Text("Focus Spells", fontSize = 17.sp)
                focusSpells.forEach { SpellRow(runtime, pc, it, gmEditable) }
            }
            ranked.forEach { (rank, spells) ->
                HorizontalDivider()
                Text("Rank $rank", fontSize = 17.sp)
                spells.forEach { SpellRow(runtime, pc, it, gmEditable) }
            }
            if (casting.spells.isEmpty()) Text("No spells added yet.")

            if (gmEditable) {
                HorizontalDivider()
                Text("Spellcasting Setup", fontSize = 17.sp)
                OutlinedTextField(tradition, { tradition = it.take(30) }, label = { Text("Tradition") }, modifier = Modifier.fillMaxWidth())
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        runtime.store.configureSpellcasting(pc.id, true, tradition, CastingMode.PREPARED, focusMax.toIntOrNull() ?: 0)
                    }) { Text(if (casting.castingMode == CastingMode.PREPARED) "Prepared ✓" else "Prepared") }
                    OutlinedButton(onClick = {
                        runtime.store.configureSpellcasting(pc.id, true, tradition, CastingMode.SPONTANEOUS, focusMax.toIntOrNull() ?: 0)
                    }) { Text(if (casting.castingMode == CastingMode.SPONTANEOUS) "Spontaneous ✓" else "Spontaneous") }
                    OutlinedTextField(focusMax, { focusMax = it.filter(Char::isDigit).take(1) }, label = { Text("Max focus") }, modifier = Modifier.weight(1f))
                    Button(onClick = {
                        runtime.store.configureSpellcasting(pc.id, true, tradition, casting.castingMode, focusMax.toIntOrNull() ?: 0)
                    }) { Text("Save") }
                }

                Text("Add / replace a slot rank")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(slotRank, { slotRank = it.filter(Char::isDigit).take(2) }, label = { Text("Rank") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(slotTotal, { slotTotal = it.filter(Char::isDigit).take(2) }, label = { Text("Total slots") }, modifier = Modifier.weight(1f))
                    Button(onClick = {
                        runtime.store.setSpellSlotPool(pc.id, slotRank.toIntOrNull() ?: 1, slotTotal.toIntOrNull() ?: 0, slotTotal.toIntOrNull() ?: 0)
                    }) { Text("Set") }
                }

                Text("Add spell")
                OutlinedTextField(spellName, { spellName = it.take(60) }, label = { Text("Spell name") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(spellRank, { spellRank = it.filter(Char::isDigit).take(2) }, label = { Text("Rank") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(spellActions, { spellActions = it.filter(Char::isDigit).take(1) }, label = { Text("Actions") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(spellNotes, { spellNotes = it.take(200) }, label = { Text("Short notes") }, modifier = Modifier.fillMaxWidth())
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { isCantrip = !isCantrip; if (isCantrip) isFocus = false }) { Text(if (isCantrip) "Cantrip ✓" else "Cantrip") }
                    OutlinedButton(onClick = { isFocus = !isFocus; if (isFocus) isCantrip = false }) { Text(if (isFocus) "Focus spell ✓" else "Focus spell") }
                    Button(onClick = {
                        runtime.store.addSpell(
                            pcId = pc.id,
                            name = spellName,
                            rank = spellRank.toIntOrNull() ?: 1,
                            actions = spellActions.toIntOrNull() ?: 2,
                            isCantrip = isCantrip,
                            isFocus = isFocus,
                            notes = spellNotes,
                        )
                        spellName = ""
                        spellNotes = ""
                    }) { Text("Add spell") }
                }
            }
        }
    }
}

@Composable
private fun SpellRow(runtime: HostRuntime, pc: PlayerCharacter, spell: SpellEntry, gmEditable: Boolean) {
    val casting = pc.spellcasting
    val slot = casting.slots.firstOrNull { it.rank == spell.rank }
    val resourceAvailable = when {
        spell.isCantrip -> true
        spell.isFocus -> casting.focusPoints > 0
        casting.castingMode == CastingMode.PREPARED && spell.expended -> false
        slot != null -> slot.remaining > 0
        else -> true
    }
    val actionAvailable = pc.actionEconomy.actionsRemaining >= spell.actions
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(spell.name)
                    val type = when {
                        spell.isCantrip -> "Cantrip"
                        spell.isFocus -> "Focus"
                        else -> "Rank ${spell.rank}"
                    }
                    val actionText = if (spell.actions == 0) "Free action" else "${spell.actions} action${if (spell.actions == 1) "" else "s"}"
                    Text("$type • $actionText${if (spell.expended) " • Expended" else ""}", fontSize = 12.sp)
                    if (spell.notes.isNotBlank()) Text(spell.notes, fontSize = 12.sp)
                }
                Button(
                    enabled = resourceAvailable && actionAvailable,
                    onClick = { runtime.store.castSpell(pc.id, spell.id) },
                ) { Text("Cast") }
            }
            if (gmEditable) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!spell.isCantrip && !spell.isFocus && casting.castingMode == CastingMode.PREPARED) {
                        OutlinedButton(onClick = { runtime.store.setSpellExpended(pc.id, spell.id, !spell.expended) }) {
                            Text(if (spell.expended) "Restore prepared" else "Mark expended")
                        }
                    }
                    OutlinedButton(onClick = { runtime.store.removeSpell(pc.id, spell.id) }) { Text("Remove") }
                }
            }
        }
    }
}
