# TT Helper LAN Protocol — 0.2.2

The GM tablet remains authoritative. Player clients authenticate with a host-issued token and may mutate only their assigned PC through server-approved actions.

## Player actions

Existing actions remain supported, including HP, temp HP, conditions, initiative, End Turn requests, and roll logging.

0.2.2 adds:
- `spendActions { count }`
- `refundAction { count }`
- `useReaction {}`
- `restoreReaction {}`
- `castSpell { spellId }`
- `refocus {}`

The host resolves the PC from the authenticated token; the client cannot choose a different target PC.

## Player snapshot additions

`you.actionEconomy`
- `baseActions`
- `actionsRemaining`
- `reactionAvailable`

`you.spellcasting`
- `enabled`
- `tradition`
- `castingMode`
- `focusPoints`
- `maxFocusPoints`
- `slots[] { rank, total, remaining }`
- `spells[] { id, name, rank, actions, isCantrip, isFocus, expended, notes }`
