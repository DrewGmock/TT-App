# TT Helper Changelog

## 0.2.2-alpha1

### Spellcasting dashboard
- Added per-character spellcasting state with prepared/spontaneous modes.
- Added Focus Point tracking and Refocus.
- Added spell-slot pools by rank.
- Added cantrips, focus spells, and ranked/prepared spells.
- GM can configure spellcasting, slot counts, spell actions, and short notes.
- Casting a spell updates spell resources and, during the character's active combat turn, spends the listed number of actions.
- Player browser can cast configured spells directly from its dashboard.

### Action economy
- Added 3-action turn tracker to GM and player views.
- Added Spend 1 / 2 / 3, Refund 1, reaction used/available, and Reset Turn controls.
- Action economy resets when a PC's turn begins.
- Reactions reset with the turn tracker.

### Update/install reliability
- Added a permanent local-development signing key at `signing/tt-helper-local.jks`.
- 0.2.2-alpha1 is the first build using this key. One final uninstall is required when moving from older randomly signed debug builds; future builds that keep this key should install as normal updates.

### Compatibility
- Existing 0.2.1 saves migrate forward. Everleaf and Yorik receive an enabled empty spellcasting profile if their older save did not contain spellcasting data. Existing HP, effects, prep, encounters, and loot remain compatible.
