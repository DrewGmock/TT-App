# TT Helper — LAN Alpha 0.3.0

TT Helper is a local-first Pathfinder 2e table helper. The Samsung/Android GM tablet is the authoritative host; players connect from phone/tablet browsers on the same LAN.

## 0.3.0 highlights

- Full encounter/initiative system, effect timing/check reminders, player requests, Undo, loot, and Session Prep from 0.2.x.
- Spellcasting dashboard with prepared/spontaneous casting, Focus Points, cantrips, slots, and action-cost integration.
- 3-action economy + reactions.
- **Character Combat Dashboard** with Hero Points, pinned entries, approved abilities, strikes, resources, spells, and common actions.
- **Player Builder** for spells, abilities, strikes, and custom resources.
- **GM Approval Inbox** with Approve, Edit & Approve, and Decline → Drafts.
- Rejected content is never wiped. The draft, player notes, and GM feedback stay intact for editing/resubmission.
- Suggested edits to approved entries also require GM approval before replacing the live version.
- Strong GM alert when a new player submission arrives.

## Moderated player-content workflow

1. Player creates or edits an entry in the browser and saves it as a Draft.
2. Drafts are private working copies and do not alert the GM.
3. Player submits when ready.
4. GM reviews it in **Approvals**.
5. GM can approve it, edit fields and approve, or return it to Drafts with feedback.
6. Only approved entries appear as usable spells/abilities/strikes/resources.

## Build / install

The project compiles against and targets Android API 36. GitHub Actions uses Java 17 and Gradle 9.6.

The repo keeps the development signing key at `signing/tt-helper-local.jks`. Since 0.2.2 used the same key, this build should update the installed app in place instead of requiring an uninstall.

For the tablet-friendly GitHub workflow, upload the ZIP file itself and let the existing Action extract it on the GitHub runner. Do not extract/upload the folder tree from the tablet.
