# TT Helper LAN Protocol — 0.3.0

The GM tablet remains authoritative. Player clients authenticate with a host-issued token and may mutate only their assigned PC through server-approved actions.

## Existing player actions

HP/temp HP, conditions, initiative, End Turn requests, roll logging, action economy, reaction use, spell casting, and Refocus remain supported.

## 0.3.0 player actions

- `saveContentDraft { ... }` — saves/updates a draft owned by the authenticated PC.
- `submitContentDraft { draftId }` — moves one of that PC's drafts to Pending GM Approval.
- `deleteContentDraft { draftId }` — deletes a non-pending draft.
- `togglePinned { kind, entryId }` — player dashboard customization.
- `useAbility { abilityId }`
- `useStrike { strikeId }`
- `adjustResource { resourceId, delta }`
- `heroDelta { delta }`
- `commonAction { label, actions }`

The host always derives the target PC from the authenticated token. Player payloads never choose another character.

## Moderated content lifecycle

`DRAFT -> PENDING -> APPROVED_HISTORY`

If declined, `PENDING -> DRAFT` and the server retains all draft fields plus `gmFeedback`. Rejection never deletes the player's work.

Approved entries are copied into the character's authoritative spell/ability/strike/resource collection. Suggested edits to an approved entry carry `sourceEntryId`; the live entry remains unchanged until the GM approves the replacement.

## Player snapshot additions

`you.abilities[]`
- id, name, category, actionType, actions
- usageMode, maxUses, remainingUses
- notes, pinned

`you.strikes[]`
- id, name, actions, attackModifier, damage, traits, notes, pinned

`you.resources[]`
- id, name, current, max, notes, pinned

`you.contentDrafts[]`
- draft/submission status and all builder fields
- gmFeedback, sourceEntryId, submittedAt

`you.spellcasting.spells[]` also adds:
- range, targets, checkOrSave, pinned
