package com.drew.tthelper.model

import java.util.UUID

object EffectAnchor {
    const val TARGET = "TARGET"
    const val SOURCE = "SOURCE"
}

object EffectPhase {
    const val MANUAL = "MANUAL"
    const val START = "START"
    const val END = "END"
}

object EffectTriggerAction {
    const val NONE = "NONE"
    const val REMOVE = "REMOVE"
    const val DECREMENT_VALUE = "DECREMENT_VALUE"
    const val CHECK = "CHECK"
}

object EffectOutcomeAction {
    const val KEEP = "KEEP"
    const val REMOVE = "REMOVE"
    const val DECREMENT = "DECREMENT"
    const val DECREMENT_2 = "DECREMENT_2"
    const val INCREMENT = "INCREMENT"
    const val INCREMENT_2 = "INCREMENT_2"
}

object EffectCheckType {
    const val SKILL = "Skill check"
    const val SAVE = "Saving throw"
    const val FLAT = "Flat check"
    const val RECOVERY = "Recovery check"
    const val CUSTOM = "Custom roll"
}

data class Condition(
    val name: String,
    val value: Int? = null,
    val publicToPlayers: Boolean = true,
    val partyInflicted: Boolean = false,
    val id: String = UUID.randomUUID().toString(),
    val sourceCombatantId: String? = null,
    val timingAnchor: String = EffectAnchor.TARGET,
    val timingPhase: String = EffectPhase.MANUAL,
    val remainingTriggers: Int? = null,
    val triggerAction: String = EffectTriggerAction.NONE,
    val checkType: String? = null,
    val checkLabel: String = "",
    val checkDc: Int? = null,
    val checkSuccessAction: String = EffectOutcomeAction.REMOVE,
    val checkFailureAction: String = EffectOutcomeAction.KEEP,
    val checkCriticalSuccessAction: String = EffectOutcomeAction.REMOVE,
    val checkCriticalFailureAction: String = EffectOutcomeAction.KEEP,
    val repeatCheck: Boolean = true,
)

data class EffectCheckPrompt(
    val id: String = UUID.randomUUID().toString(),
    val effectId: String,
    val targetCombatantId: String,
    val targetName: String,
    val effectName: String,
    val checkType: String,
    val checkLabel: String = "",
    val dc: Int? = null,
    val timingText: String = "",
    val successAction: String = EffectOutcomeAction.REMOVE,
    val failureAction: String = EffectOutcomeAction.KEEP,
    val criticalSuccessAction: String = EffectOutcomeAction.REMOVE,
    val criticalFailureAction: String = EffectOutcomeAction.KEEP,
    val repeatCheck: Boolean = true,
)

data class EffectPreset(
    val name: String,
    val category: String,
    val defaultValue: Int? = null,
    val timingAnchor: String = EffectAnchor.TARGET,
    val timingPhase: String = EffectPhase.MANUAL,
    val triggerAction: String = EffectTriggerAction.NONE,
    val checkType: String? = null,
    val checkLabel: String = "",
    val checkDc: Int? = null,
    val successAction: String = EffectOutcomeAction.REMOVE,
    val failureAction: String = EffectOutcomeAction.KEEP,
    val criticalSuccessAction: String = EffectOutcomeAction.REMOVE,
    val criticalFailureAction: String = EffectOutcomeAction.KEEP,
)


object CastingMode {
    const val PREPARED = "PREPARED"
    const val SPONTANEOUS = "SPONTANEOUS"
}


object ContentKind {
    const val SPELL = "SPELL"
    const val ABILITY = "ABILITY"
    const val STRIKE = "STRIKE"
    const val RESOURCE = "RESOURCE"
}

object ContentStatus {
    const val DRAFT = "DRAFT"
    const val PENDING = "PENDING"
    const val APPROVED_HISTORY = "APPROVED_HISTORY"
}

object AbilityActionType {
    const val ACTION = "ACTION"
    const val REACTION = "REACTION"
    const val FREE = "FREE"
    const val PASSIVE = "PASSIVE"
}

object UsageMode {
    const val UNLIMITED = "UNLIMITED"
    const val ONCE_PER_TURN = "ONCE_PER_TURN"
    const val ENCOUNTER = "ENCOUNTER"
    const val DAILY = "DAILY"
    const val CUSTOM = "CUSTOM"
}

data class AbilityEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = "Ability",
    val actionType: String = AbilityActionType.ACTION,
    val actions: Int = 1,
    val usageMode: String = UsageMode.UNLIMITED,
    val maxUses: Int = 0,
    val remainingUses: Int = 0,
    val notes: String = "",
    val pinned: Boolean = false,
)

data class StrikeEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val actions: Int = 1,
    val attackModifier: Int = 0,
    val damage: String = "",
    val traits: String = "",
    val notes: String = "",
    val pinned: Boolean = false,
)

data class CharacterResource(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val current: Int = 0,
    val max: Int = 0,
    val notes: String = "",
    val pinned: Boolean = false,
)

data class PlayerContentDraft(
    val id: String = UUID.randomUUID().toString(),
    val kind: String = ContentKind.ABILITY,
    val status: String = ContentStatus.DRAFT,
    val name: String = "",
    val rank: Int = 1,
    val actions: Int = 1,
    val isCantrip: Boolean = false,
    val isFocus: Boolean = false,
    val notes: String = "",
    val range: String = "",
    val targets: String = "",
    val checkOrSave: String = "",
    val abilityCategory: String = "Ability",
    val actionType: String = AbilityActionType.ACTION,
    val usageMode: String = UsageMode.UNLIMITED,
    val maxUses: Int = 0,
    val attackModifier: Int = 0,
    val damage: String = "",
    val traits: String = "",
    val resourceMax: Int = 0,
    val gmFeedback: String = "",
    val sourceEntryId: String? = null,
    val submittedAt: Long? = null,
)

data class SpellSlotPool(
    val rank: Int,
    val total: Int = 0,
    val remaining: Int = 0,
)

data class SpellEntry(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val rank: Int = 0,
    val actions: Int = 2,
    val isCantrip: Boolean = false,
    val isFocus: Boolean = false,
    val expended: Boolean = false,
    val notes: String = "",
    val range: String = "",
    val targets: String = "",
    val checkOrSave: String = "",
    val pinned: Boolean = false,
)

data class SpellcastingState(
    val enabled: Boolean = false,
    val tradition: String = "",
    val castingMode: String = CastingMode.PREPARED,
    val focusPoints: Int = 0,
    val maxFocusPoints: Int = 0,
    val slots: List<SpellSlotPool> = emptyList(),
    val spells: List<SpellEntry> = emptyList(),
)

data class ActionEconomy(
    val baseActions: Int = 3,
    val actionsRemaining: Int = 3,
    val reactionAvailable: Boolean = true,
)

data class PlayerCharacter(
    val id: String,
    val name: String,
    val ancestry: String,
    val characterClass: String,
    val level: Int? = null,
    val hp: Int = 10,
    val maxHp: Int = 10,
    val tempHp: Int = 0,
    val heroPoints: Int = 1,
    val ready: Boolean = false,
    val conditions: List<Condition> = emptyList(),
    val publicNote: String = "",
    val gmNote: String = "",
    val spellcasting: SpellcastingState = SpellcastingState(),
    val actionEconomy: ActionEconomy = ActionEconomy(),
    val abilities: List<AbilityEntry> = emptyList(),
    val strikes: List<StrikeEntry> = emptyList(),
    val resources: List<CharacterResource> = emptyList(),
    val contentDrafts: List<PlayerContentDraft> = emptyList(),
)

data class PreparedEnemy(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val level: Int? = null,
    val maxHp: Int = 10,
    val initiativeModifier: Int = 0,
    val gmNotes: String = "",
    val publicNotes: String = "",
    val quantity: Int = 1,
)

data class PreparedEncounter(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val gmNotes: String = "",
    val startingNotes: String = "",
    val enemies: List<PreparedEnemy> = emptyList(),
)

data class SessionPrep(
    val sessionTitle: String = "Next Session",
    val openingScene: String = "",
    val gmNotes: String = "",
    val encounterNotes: String = "",
    val enemyLibrary: List<PreparedEnemy> = emptyList(),
    val preparedEncounters: List<PreparedEncounter> = emptyList(),
)

data class Combatant(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String,
    val pcId: String? = null,
    val level: Int? = null,
    val initiative: Int? = null,
    val initiativeModifier: Int = 0,
    val initiativeSource: String? = null,
    val hp: Int = 10,
    val maxHp: Int = 10,
    val tempHp: Int = 0,
    val conditions: List<Condition> = emptyList(),
    val gmNote: String = "",
    val publicNote: String = "",
    val groupKey: String? = null,
    val defeated: Boolean = false,
    val delayed: Boolean = false,
    val readyAction: String = "",
    val readyTrigger: String = "",
)

data class CombatLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val label: String,
)

data class LootItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = "Treasure",
    val quantity: Int = 1,
    val valueGp: Double = 0.0,
    val notes: String = "",
    val assignedToPcId: String? = null,
)

data class EncounterLoot(
    val generatedAt: Long? = null,
    val revealed: Boolean = false,
    val movedToParty: Boolean = false,
    val coinsGp: Double = 0.0,
    val items: List<LootItem> = emptyList(),
)

data class EncounterState(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val gmNotes: String = "",
    val startingNotes: String = "",
    val active: Boolean = true,
    val ended: Boolean = false,
    val round: Int = 1,
    val turnIndex: Int = 0,
    val combatants: List<Combatant> = emptyList(),
    val endTurnRequests: List<String> = emptyList(),
    val pendingEffectChecks: List<EffectCheckPrompt> = emptyList(),
    val pendingTurnAdvance: Boolean = false,
    val history: List<CombatLogEntry> = emptyList(),
    val loot: EncounterLoot = EncounterLoot(),
)

data class SessionState(
    val revision: Long = 0,
    val campaignName: String = "Cube-Borne",
    val sceneName: String = "Between Sessions",
    val pcs: List<PlayerCharacter> = defaultCharacters(),
    val prep: SessionPrep = SessionPrep(),
    val encounter: EncounterState? = null,
    val partyLoot: List<LootItem> = emptyList(),
    val lastEventLabel: String? = null,
)

data class StateSnapshot(
    val state: SessionState,
    val label: String,
)

fun EncounterState.currentCombatant(): Combatant? = combatants.getOrNull(turnIndex.coerceIn(0, (combatants.size - 1).coerceAtLeast(0)))

fun defaultCharacters() = listOf(
    PlayerCharacter(
        id = "morrow",
        name = "Captain Morrow Vain",
        ancestry = "Skeleton",
        characterClass = "Swashbuckler",
        hp = 10,
        maxHp = 10,
    ),
    PlayerCharacter(
        id = "everleaf",
        name = "Everleaf",
        ancestry = "Human",
        characterClass = "Druid",
        hp = 10,
        spellcasting = SpellcastingState(enabled = true, tradition = "Primal", castingMode = CastingMode.PREPARED, maxFocusPoints = 1, focusPoints = 1),
        maxHp = 10,
    ),
    PlayerCharacter(
        id = "rufus",
        name = "Rufus",
        ancestry = "Orc",
        characterClass = "Barbarian",
        hp = 10,
        maxHp = 10,
    ),
    PlayerCharacter(
        id = "yorik",
        name = "Yorik",
        ancestry = "Vampire",
        characterClass = "Wizard (Necromancer)",
        hp = 10,
        spellcasting = SpellcastingState(enabled = true, tradition = "Arcane", castingMode = CastingMode.PREPARED, maxFocusPoints = 1, focusPoints = 1),
        maxHp = 10,
    ),
)

val commonConditions = listOf(
    "Clumsy", "Doomed", "Drained", "Dying", "Enfeebled", "Frightened",
    "Grabbed", "Immobilized", "Off-Guard", "Persistent Damage", "Prone",
    "Sickened", "Slowed", "Stunned", "Stupefied", "Wounded"
)

val valuedConditions = setOf(
    "Clumsy", "Doomed", "Drained", "Dying", "Enfeebled", "Frightened",
    "Sickened", "Slowed", "Stunned", "Stupefied", "Wounded"
)

val obviousEnemyConditions = setOf(
    "Dying", "Frightened", "Grabbed", "Immobilized", "Persistent Damage",
    "Prone", "Sickened", "Slowed", "Stunned", "Wounded"
)

val homebrewEffects = listOf(
    "Chaos Aura",
    "Cube's Favorite Mistake",
    "Thorn-Crowned Rage",
    "Borrowed Pulse",
    "The Duel That Already Happened",
    "Beast Out of Time",
)

val effectPresets: List<EffectPreset> = buildList {
    commonConditions.forEach { name ->
        add(
            when (name) {
                "Frightened" -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    defaultValue = 1,
                    timingAnchor = EffectAnchor.TARGET,
                    timingPhase = EffectPhase.END,
                    triggerAction = EffectTriggerAction.DECREMENT_VALUE,
                )
                "Persistent Damage" -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    timingAnchor = EffectAnchor.TARGET,
                    timingPhase = EffectPhase.END,
                    triggerAction = EffectTriggerAction.CHECK,
                    checkType = EffectCheckType.FLAT,
                    checkLabel = "Resolve persistent damage, then make the recovery flat check",
                    checkDc = 15,
                    successAction = EffectOutcomeAction.REMOVE,
                    failureAction = EffectOutcomeAction.KEEP,
                )
                "Dying" -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    defaultValue = 1,
                    timingAnchor = EffectAnchor.TARGET,
                    timingPhase = EffectPhase.START,
                    triggerAction = EffectTriggerAction.CHECK,
                    checkType = EffectCheckType.RECOVERY,
                    checkLabel = "Recovery check",
                    checkDc = 10,
                    criticalSuccessAction = EffectOutcomeAction.DECREMENT_2,
                    successAction = EffectOutcomeAction.DECREMENT,
                    failureAction = EffectOutcomeAction.INCREMENT,
                    criticalFailureAction = EffectOutcomeAction.INCREMENT_2,
                )
                else -> EffectPreset(
                    name = name,
                    category = "PF2e conditions",
                    defaultValue = if (name in valuedConditions) 1 else null,
                )
            }
        )
    }
    homebrewEffects.forEach { add(EffectPreset(it, "Cubeborne / homebrew")) }
}
