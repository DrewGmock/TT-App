# TT Helper Changelog

## 0.3.0-alpha1

### Character Combat Dashboard
- Added Hero Point controls, pinned combat entries, abilities, strikes, character resources, and common combat actions.
- Players can pin/unpin approved spells, abilities, strikes, and resources for faster access.
- Approved abilities can spend actions or reactions and track once-per-turn, encounter, daily, custom, or unlimited uses.
- Strikes spend their configured action cost and show attack modifier, damage, traits, and notes.
- Generic resources can be adjusted during play.

### Player-created content + GM approval
- Players can create Spell, Ability, Strike, and Resource drafts from the browser client.
- Drafts can be saved without notifying the GM.
- Submit sends the entry to a new GM Approval Inbox and triggers the GM attention alert.
- GM can Approve as submitted, Edit & Approve, or Decline with feedback.
- Decline NEVER deletes the player's work: it returns the exact entry to Drafts with GM feedback attached.
- Players can edit and resubmit returned drafts.
- Players can suggest edits to already approved entries; the existing live entry stays unchanged until the GM approves the replacement.
- Lightweight approval history is retained on the player's account.

### Combat usability
- Added common 1-action shortcuts such as Stride, Step, Raise a Shield, Take Cover, Recall Knowledge, Demoralize, Grapple, Trip, and Shove.
- Action costs feed the same 3-action economy introduced in 0.2.2.
- Once-per-turn ability uses reset when that PC's turn begins; encounter-use abilities reset when a new encounter starts.

### Compatibility
- Existing 0.2.2 saves migrate forward with empty abilities/strikes/resources/drafts lists.
- Existing HP, conditions, spellcasting, action economy, prep, encounters, loot, and LAN player assignments remain compatible.
- Uses the same permanent local-development signing key as 0.2.2 so Android should allow an in-place update.
